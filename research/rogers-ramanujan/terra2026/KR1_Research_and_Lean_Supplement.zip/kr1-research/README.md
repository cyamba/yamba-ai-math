# KR1 positive cut-word research package

The full structural KR1 bijection remains open. This package presents a general positive divided-difference theorem, positive models for every auxiliary index, supplementary Lean lemmas, exact failures, and finite regression evidence. Historical novelty is not verified.

## Start here

The article, full notes, and proof certificates are in:

    research/rogers-ramanujan/terra2026/

Open kr1-positive-models.pdf for the twelve-page illustrated article and README.md in that directory for the complete map of the supplement.

## Reproduce

From this archive's root:

    cd research/rogers-ramanujan/terra2026
    python3 verify.py --lean /absolute/path/to/lean

Use Lean 4.34.0 and Python 3.11+. No mathlib installation is needed. The default runner creates verification-local/ and preserves the included original logs. Add --full to repeat the earlier 3,178,008-state independent check. The certificate scope is in formal/verification-scope.json; selected components are formalized, not the full KR1 theorem or cut-word generating-series argument.

To compile the article from that same directory:

    pdflatex -interaction=nonstopmode -halt-on-error kr1-positive-models.tex
    pdflatex -interaction=nonstopmode -halt-on-error kr1-positive-models.tex

## Repository continuation

The isolated local research branch is research/kr1-terra-global, based on 4ccc4fe60008e52c9846e9a63d4bf98d23108702 from research/argon-tableau-continuation. The new local commit is cc22667cdf20c4f5e86d86be27fb1fcafe0f90a3. It has not been pushed or published. The included kr1-terra-global.patch can be reviewed and applied to the matching repository baseline.

The research used three explicitly selected GPT-6.1 Terra workers for theory, construction, and formal verification/criticism. The coordinating session used its assigned GPT-6 Astra Pro model. The repository's theorem-fleet plan is included; execution was manual collaboration, not an automated command-adapter run. Token and monetary costs were not measured.

## Included historical context

The original KR1 enumerator and cluster endpoint, its frozen verifier, the weight-41 erratum, and selected Argon obstruction proofs are included unchanged with the original MIT license. Old status strings saying separate review outstanding are historical; the new independent review lives in terra2026/. This is a selected research bundle, not a complete copy of the repository or its harness.

BUNDLE_MANIFEST.json records every included file's SHA-256 except itself. It also records the baseline and local commit. The original verification logs preserve their original workspace paths; reproduction logs use your local paths.
