Supplementary files for "Four diagonals for doubled letters, five for tripled: completeness of
Parikh matrices" (version 2) by Christopher Yamba. Copyright (c) 2026
Christopher Yamba. All rights reserved.

ParikhCompleteness.lean, ParikhCompletenessThree.lean, lakefile.toml, lean-toolchain
    The Lean 4 formalisation (Lean 4.34.0, core library only). Build with "lake build" in a
    directory containing these four files.
    ParikhCompleteness.lean: rectangle (Lemma 3.1), crossing_formula (Theorem 4.2(iii)),
    complete_two (Theorem A), determined_by_short (Corollary 1.1), sharp_fourth_diagonal
    (Example 4.5), family_three and family_four (Theorem B for n = 3, 4).
    ParikhCompletenessThree.lean: pivot_theorem (Theorem D), complete_three and
    determined_by_short_three (Corollary 1.2), determined_by_short_doubled (Corollary 1.3),
    chain_lemma (Lemma 6.6, by kernel evaluation).

check_article3.py
    Standard-library Python 3 checks of the numerical statements of Sections 2-5 and 7 (Section
    8). Run "python3 check_article3.py" (about 4 minutes) or with "--full".

check_c3.py
    Standard-library Python 3 checks of Sections 6 and 7: Lemmas 6.1, 6.2, 6.4, 6.7 and Theorem
    6.8 on every tuple of projections of the listed contents, Lemma 6.6 and Table 1 with the
    examples after it, the example after Lemma 6.4, Corollaries 1.2 and 1.3 on larger contents,
    the words of Example 4.5 and Proposition 7.1, and the 27 contents of the reduction in
    Section 8. Run "python3 check_c3.py" (about 40 seconds) or with "--full" (about 4 minutes).

Numbering
    check_c3.py and ParikhCompletenessThree.lean were written for the proof note behind Section
    6. check_c3.py prints the article's numbering, with the note's in brackets; the comments of
    the Lean file use the note's numbering, which maps to the article as follows:
    note Lemma 2.1 = Lemma 6.1(i); note Lemma 2.2 = Lemma 6.1(ii)-(iii); note Lemma 3.1 and
    Rule 1 = Lemma 6.2; note Lemma 3.2 and Rule 2 = Lemma 6.4 and equation (6.1); note Lemma 3.3
    = Lemma 6.6; note Lemma 3.4 = Lemma 6.7; note Table 1 = Table 1; note Theorem 4.1 =
    Theorem 6.8 and Theorem D; note Corollaries 4.2 and 4.3 = Corollary 1.2; note Corollary 4.4
    = Corollary 1.3; note Proposition 4.5(a) = Example 4.5 (tripled letters), (b) = Proposition
    7.1(ii), first part, (c) = Proposition 7.1(iii), (d) = Proposition 7.1(i), (e) =
    Proposition 7.1(ii), second part; note Remark 7.1 = the reduction at the end of Section 8.

corner.c
    Exact test of corner independence for a window content, used for the larger entries of
    Table 2. Compile with "cc -O2 -o corner corner.c" and run "./corner c1 c2 ... cr".
