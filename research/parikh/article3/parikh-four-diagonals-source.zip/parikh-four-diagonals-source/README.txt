Copyright (c) 2006, 2026 Christopher Yamba. All rights reserved.

LaTeX source of "Four diagonals for doubled letters, five for tripled: completeness of Parikh matrices" (version 2). Build with pdflatex article3 (twice); the .bbl is included.
