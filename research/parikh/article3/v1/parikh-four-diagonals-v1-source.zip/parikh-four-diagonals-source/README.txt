Copyright (c) 2006, 2026 Christopher Yamba. All rights reserved.

LaTeX source of "Four diagonals suffice". Build with pdflatex article3 (twice); the .bbl is included.
