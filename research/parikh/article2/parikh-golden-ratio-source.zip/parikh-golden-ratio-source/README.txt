Copyright (c) 2006, 2026 Christopher Yamba. All rights reserved.

LaTeX source of "From Euler numbers to the golden ratio". Build with pdflatex article2 (twice); the .bbl is included.
