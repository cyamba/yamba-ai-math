"""check_article2: every number printed in Article 2 (paper2/), recomputed from scratch.

Article 2 is "From Euler numbers to the golden ratio: rigidity, ranges and the most ambiguous
Parikh matrices for words with repeated letters" (Christopher Yamba; paper2/).  Its number
registry paper2/numbers.json (merged from paper2/numbers/*.json by paper2/numbers/registry.py)
lists every computational number, formula and range printed in the article, with the line of
paper2/<tex_file> that prints it (the anchor).  This check

  (a) asserts that every registry entry is current: its anchor occurs on exactly one line of
      paper2/<tex_file> (white space normalised), its value occurs on that line, its recorded
      line number is that line, and the merged file agrees with paper2/numbers/*.json;
  (b) RECOMPUTES every entry independently, with the code of this file (own enumerations and
      dynamic programmes, listed under "Methods" below) or, for the slowest ranges (C1 for
      6 <= k <= 12 and C4 for 4 <= k <= 11 in --full, beyond the ranges k <= 7 and k <= 6 that
      the default mode recomputes with PMX, and the all-class confirmations of the group PM),
      by calling the computing functions of check_article2_data.py (MITM, SPLIT, its C4
      classifier and its prefix-matrix DP) under this file's own acceptance logic; it never
      reads a saved log or a .dat file as the source of a value.  Each entry has one of four
      kinds:
        default  recomputed in the default mode;
        full     recomputable only slowly (C1 at k = 12, C4, Question E, the (2,b,2) range
                 b <= 100, ...): recomputed with --full, and in the default mode the check
                 asserts that the entry is registered with a --full section (and recomputes a
                 smaller range where that is cheap);
        process  a wall-clock time or a count of logged runs: it cannot be recomputed; the check
                 only confirms that the log or note it cites exists and contains the number,
                 and, for a log written by notes/article2-scripts/article2-check/run_logged.sh,
                 that the log is a run of the current file of that check, with exit status 0
                 (the times of this check itself are optional entries, registered only after
                 the logged runs they quote, since a run cannot quote its own time);
        cited    a constant quoted from the literature (2/pi of Ehrenborg 2002): nothing to
                 recompute;
      the last two kinds are listed as "not recomputed" at the end of the run;
  (c) regenerates every paper2/figures/data/*.dat with its own code (not the figure scripts) and
      compares header and rows;
  (d) checks that the abstract has at most 1,920 characters, as typed and as plain text, and
      that no .tex file under paper2/, nor the shipped article2.bbl, contains a comment: an
      unescaped % is allowed only as the last character of a line that has other content;
  (e) checks that every \\cite key of the .tex files exists in paper2/references.bib (entries
      that are never cited are reported, not failed: BibTeX does not print them), and that every
      DOI printed in the .bib is recorded in notes/article2-references.md as resolved by
      Crossref (and logged as resolved in notes/article2-scripts/references/out/, or, for the
      entries added in Phase 4, in notes/article2-scripts/article2-check/references/);
  (m) validates the methods below against each other (and against literal enumeration) on
      small contents, before any of them is used.

    python3 checks/check_article2.py                    # default, under a minute
    python3 checks/check_article2.py --full             # every group at full range (~30 min)
    python3 checks/check_article2.py --full --only=C1   # selected groups: base, C1, C4, PM, QE

Groups.  base: (a), (c), (d), (e), (m) and every entry of kind default, process or cited, with the
extended ranges of --full ((2,b,2) for b <= 100, Theorem F by class counts for a <= 19 and the
tie (40,2,65), the central fibre of (2^k) for k <= 12, the one-end relaxations of (3^k) for
k <= 40).  C1: C1 for 6 <= k <= 12.  C4: C4 for 4 <= k <= 11.  PM: C1 for k <= 9 and C4 for
k <= 8 from every Parikh class.  QE: Question 5.6 to a+b+c = 45 and its four odd-odd islands.
Run in three parts, each under 20 minutes, the --full mode is
    python3 checks/check_article2.py --full --only=base
    python3 checks/check_article2.py --full --only=C1
    python3 checks/check_article2.py --full --only=C4,PM,QE
(notes/article2-scripts/article2-check/run_logged.sh writes a log of each part).

Unknown arguments are ignored (run_all.py passes --max-n).  Python 3.11, standard library only,
deterministic, exact integer and Fraction (or 60-digit Decimal) arithmetic in every assertion, at
most two worker processes (the default mode uses one; the --full groups use a pool of two).  The
exit status is non-zero on any failure, and the last line reads
"check_article2: N checks, F failures, T s".
A pass is evidence on the stated finite ranges, not a proof.

Conventions.  Letters 1 < 2 < ... < k; scattered subwords; |w|_{j..l} counts j(j+1)...l;
psi_2(w) = (|w|_12, ..., |w|_{(k-1)k}).  Ternary content (a,b,c): x = |w|_12, y = |w|_23,
z = |w|_123, lambda = cx + ay - abc, P(x,y) the psi_2-fibre size, rho(x,y,z) the class size.

Methods (all written for this file).
  LIT    every word of a content, the counts updated letter by letter.
  TDP    ternary word-prefix DP over (#1, #2, #3) with the (x, y, z) distribution, or the set of
         z values as a bitmask (no profile model).
  GAP    the gap model of a ternary content (Lemma 2.3 of the article; MSY04 section 7):
         alpha_g ones and gamma_g threes in gap g, weight prod C(alpha_g + gamma_g, alpha_g);
         validated against TDP on small contents.
  PSI    P(x,y) of a ternary content by a word-prefix DP whose bivariate polynomial is packed in
         one integer.
  PMX    every Parikh class of a content by a word-prefix DP over the partial Parikh matrix,
         packed in one integer, equal states merged; with an optional psi_2 target and pruning.
  INS    the alternating class of a content and its one-end relaxations by inserting one letter
         chain at a time (state: the number of letters before the first, or after the last,
         copy of the current letter).
  DOWN   words with prescribed extreme edges and tracked areas, by a DP over the downsets
         (numbers of copies of each letter placed).
  KERN   the transfer operator of Section 7 in exact rational polynomial arithmetic.
  CERT   the items [C1]-[C3] of Appendix A from their definitions.
"""

from __future__ import annotations

import glob
import hashlib
import json
import os
import re
import sys
import time
from collections import Counter, defaultdict
from decimal import ROUND_FLOOR, ROUND_HALF_EVEN, Decimal, getcontext, localcontext
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, combinations_with_replacement, product
from math import comb, factorial, isqrt, prod

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PAPER = os.path.join(ROOT, "paper2")
ARGV = sys.argv[1:]
FULL = "--full" in ARGV
ONLY: set[str] = set()
for _arg in ARGV:
    if _arg.startswith("--only="):
        ONLY.update(s.strip() for s in _arg.split("=", 1)[1].split(",") if s.strip())
GROUPS = ("base", "C1", "C4", "PM", "QE")
WORKERS = 2
START = time.perf_counter()
getcontext().prec = 60


def group_on(g: str) -> bool:
    """Is group g run?  Default mode: base only.  --full: every group, or the --only list."""
    if ONLY:
        return g in ONLY
    return FULL or g == "base"


def ext() -> bool:
    """The extended ranges of the base group (--full)."""
    return FULL and group_on("base")


# ---------------------------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------------------------


class Checker:
    def __init__(self) -> None:
        self.count = 0
        self.failures: list[str] = []

    def ok(self, cond, label: str) -> bool:
        self.count += 1
        if not cond:
            self.failures.append(label)
            print(f"   FAIL: {label}", flush=True)
        return bool(cond)

    def eq(self, got, want, label: str) -> bool:
        good = got == want
        return self.ok(good, label if good else f"{label}: got {got!r}, expected {want!r}")


CHK = Checker()


def note(msg: str) -> None:
    print(f"   {msg}", flush=True)


def head(msg: str) -> None:
    print(f"[{msg}]", flush=True)


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def read(path: str) -> str:
    with open(path, encoding="utf-8") as fh:
        return fh.read()


# ---------------------------------------------------------------------------------------------
# (a) the registry and its anchors
# ---------------------------------------------------------------------------------------------

REGISTRY = os.path.join(PAPER, "numbers.json")
REQUIRED = ("id", "value", "tex_file", "anchor", "row", "check")


def load_registry() -> list[dict]:
    with open(REGISTRY, encoding="utf-8") as fh:
        return json.load(fh)


def sec_anchors(entries: list[dict]) -> None:
    head("a  registry: anchors, values and line numbers in paper2/; merged file = numbers/*.json")
    cache: dict[str, list[str]] = {}
    ids = Counter(e.get("id") for e in entries)
    CHK.eq([i for i, m in ids.items() if m > 1], [], "registry ids are unique")
    for e in entries:
        miss = [k for k in REQUIRED if k not in e]
        if not CHK.ok(not miss, f"{e.get('id')}: registry keys present (missing {miss})"):
            continue
        path = os.path.join(PAPER, e["tex_file"])
        if not CHK.ok(os.path.exists(path), f"{e['id']}: {e['tex_file']} exists"):
            continue
        if path not in cache:
            cache[path] = [norm(line) for line in read(path).split("\n")]
        lines = cache[path]
        anchor = norm(e["anchor"])
        hits = [i for i, line in enumerate(lines) if anchor in line]
        if not CHK.ok(len(hits) == 1, f"{e['id']}: anchor on exactly one line of {e['tex_file']} "
                                      f"(found on {len(hits)}): {e['anchor']!r}"):
            continue
        CHK.ok(norm(e["value"]) in lines[hits[0]],
               f"{e['id']}: value {e['value']!r} on its anchor line {hits[0] + 1}")
        CHK.ok(norm(e["value"]) in anchor or norm(e["value"]) in lines[hits[0]],
               f"{e['id']}: value printed")
        CHK.eq(e.get("tex_line"), hits[0] + 1, f"{e['id']}: recorded line number is current")
    parts = []
    for path in sorted(glob.glob(os.path.join(PAPER, "numbers", "*.json"))):
        with open(path, encoding="utf-8") as fh:
            for f in json.load(fh):
                parts.append((os.path.basename(path), f))
    merged = {e["id"]: e for e in entries}
    CHK.eq(sorted(f["id"] for _, f in parts), sorted(merged), "numbers.json has exactly the ids "
                                                              "of numbers/*.json")
    stale = [f["id"] for src, f in parts if f["id"] in merged and (
        any(merged[f["id"]].get(k) != v for k, v in f.items() if k not in ("tex_line", "registry"))
        or merged[f["id"]].get("registry") != src)]
    CHK.eq(stale, [], "every merged entry equals its source entry in numbers/*.json (the merge "
                      "recomputes tex_line)")
    note(f"{len(entries)} entries in {len(cache)} .tex files")


# ---------------------------------------------------------------------------------------------
# (d) the abstract and the comment rule; (e) citations and DOIs
# ---------------------------------------------------------------------------------------------

ABSTRACT_LIMIT = 1920


def abstract_text() -> tuple[str, str]:
    src = read(os.path.join(PAPER, "article2.tex"))
    m = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", src, re.S)
    raw = norm(m.group(1)) if m else ""
    plain = raw
    for pat, rep in ((r"\\binom\{([^{}]*)\}\{([^{}]*)\}", r"binom(\1,\2)"), (r"\\lfloor", "floor("),
                     (r"\\rfloor", ")"), (r"\\ge(?![a-zA-Z])", ">="), (r"\\le(?![a-zA-Z])", "<="),
                     (r"\\ne(?![a-zA-Z])", "!="), (r"\\min(?![a-zA-Z])", "min"),
                     (r"\\dots", "..."), (r"\\[a-zA-Z]+", ""), (r"[$]", ""), (r"~", " ")):
        plain = re.sub(pat, rep, plain)
    plain = norm(plain.replace("{", "").replace("}", ""))
    return raw, plain


def comment_violations(text: str) -> list[tuple[int, str]]:
    """Lines with an unescaped % that is not the last character of a line with other content."""
    bad = []
    for no, line in enumerate(text.split("\n"), 1):
        i = 0
        while i < len(line):
            ch = line[i]
            if ch == "\\":
                i += 2
                continue
            if ch == "%":
                if i != len(line) - 1 or not line[:i].strip():
                    bad.append((no, line))
                break
            i += 1
    return bad


def tex_files() -> list[str]:
    out = []
    for dirpath, dirnames, filenames in os.walk(PAPER):
        dirnames[:] = sorted(d for d in dirnames if d != "build")
        for f in sorted(filenames):
            if f.endswith(".tex"):
                out.append(os.path.join(dirpath, f))
    return sorted(out)


def sec_tex() -> None:
    head("d  abstract length and the comment rule")
    raw, plain = abstract_text()
    CHK.ok(0 < len(raw) <= ABSTRACT_LIMIT, f"abstract as typed: {len(raw)} <= {ABSTRACT_LIMIT}")
    CHK.ok(0 < len(plain) <= ABSTRACT_LIMIT, f"abstract as plain text: {len(plain)} <= "
                                             f"{ABSTRACT_LIMIT}")
    files = tex_files()
    for path in files:
        bad = comment_violations(read(path))
        CHK.eq(bad, [], f"no comment in {os.path.relpath(path, PAPER)}")
    bbl = os.path.join(PAPER, "article2.bbl")
    CHK.ok(os.path.exists(bbl), "the shipped article2.bbl exists")
    if os.path.exists(bbl):
        CHK.eq(comment_violations(read(bbl)), [], "no comment line in the shipped article2.bbl")
    note(f"abstract: {len(raw)} characters as typed, {len(plain)} as plain text; "
         f"{len(files)} .tex files scanned")


def cite_keys(text: str) -> list[str]:
    """Keys of every \\cite-like command, optional arguments skipped with brace matching."""
    keys = []
    for m in re.finditer(r"\\(?:no)?[cC]ite[a-zA-Z]*\*?", text):
        i = m.end()
        while True:
            while i < len(text) and text[i] in " \n":
                i += 1
            if i < len(text) and text[i] == "[":
                depth, i = 0, i + 1
                while i < len(text) and not (text[i] == "]" and depth == 0):
                    depth += {"{": 1, "}": -1}.get(text[i], 0)
                    i += 1
                i += 1
                continue
            break
        if i < len(text) and text[i] == "{":
            j = text.index("}", i)
            keys += [k.strip() for k in text[i + 1:j].split(",") if k.strip()]
    return keys


def bib_entries() -> dict[str, str]:
    src = read(os.path.join(PAPER, "references.bib"))
    out = {}
    for m in re.finditer(r"@([a-zA-Z]+)\s*\{\s*([^,\s]+)\s*,", src):
        if m.group(1).lower() in ("preamble", "string", "comment"):
            continue
        start = m.end()
        nxt = re.search(r"\n@", src[start:])
        out[m.group(2)] = src[start: start + nxt.start() if nxt else len(src)]
    return out


def sec_bib() -> None:
    head("e  citations against references.bib; DOIs against the reference ledger")
    bib = bib_entries()
    cited = []
    for path in tex_files():
        if os.path.basename(path) == "test-section.tex":
            continue
        cited += cite_keys(read(path))
    missing = sorted(set(cited) - set(bib))
    CHK.eq(missing, [], "every cited key is in references.bib")
    unused = sorted(set(bib) - set(cited))
    ledger = norm(read(os.path.join(ROOT, "notes", "article2-references.md")))
    dois = []
    for key, body in bib.items():
        for d in re.findall(r"https?://(?:dx\.)?doi\.org/([^\s}]+)", body):
            dois.append((key, d))
        for d in re.findall(r"\bdoi\s*=\s*\{([^}]*)\}", body, re.I):
            dois.append((key, d.strip()))
    for key, d in dois:
        pat = r"DOI " + re.escape(d) + r"\s*\(Crossref"
        CHK.ok(re.search(pat, ledger) is not None,
               f"{key}: DOI {d} recorded as Crossref-resolved in notes/article2-references.md")
    logs = [os.path.join(ROOT, "notes", "article2-scripts", "references", "out",
                         "resolve_refs.log"),
            os.path.join(ROOT, "notes", "article2-scripts", "article2-check", "references",
                         "resolve_refs_addendum.log")]
    logtext = "\n".join(read(p) for p in logs if os.path.exists(p))
    for key, d in dois:
        CHK.ok(re.search(r"^ok\s+" + re.escape(key) + r"\s+" + re.escape(d) + r"\s", logtext,
                         re.M) is not None,
               f"{key}: DOI {d} logged as resolved in references/out/resolve_refs.log or "
               f"article2-check/references/resolve_refs_addendum.log")
    note(f"{len(set(cited))} distinct keys cited, {len(bib)} entries ({len(unused)} not cited, "
         f"which BibTeX does not print), {len(dois)} DOIs in the .bib")


# ---------------------------------------------------------------------------------------------
# Library: small arithmetic
# ---------------------------------------------------------------------------------------------


def multinomial(ns) -> int:
    out = factorial(sum(ns))
    for v in ns:
        out //= factorial(v)
    return out


def binom0(n: int, k: int) -> int:
    return comb(n, k) if 0 <= k <= n else 0


def fib(n: int) -> int:
    u, v = 0, 1
    for _ in range(n):
        u, v = v, u + v
    return u


def lucas(n: int) -> int:
    u, v = 2, 1
    for _ in range(n):
        u, v = v, u + v
    return u


@lru_cache(maxsize=None)
def euler_numbers(N: int) -> tuple:
    """E_0..E_N, the alternating permutations of [n], by the boustrophedon (Seidel) triangle."""
    out = [1]
    row = [1]
    for n in range(1, N + 1):
        new = [0]
        for v in reversed(row):
            new.append(new[-1] + v)
        row = new
        out.append(row[-1])
    return tuple(out)


def dec_round(fr: Fraction, digits: int) -> str:
    """Exact Fraction -> decimal string, rounded half to even."""
    fr = Fraction(fr)
    sign = "-" if fr < 0 else ""
    fr = abs(fr)
    scaled = fr * 10 ** digits
    q, r = divmod(scaled.numerator, scaled.denominator)
    if 2 * r > scaled.denominator or (2 * r == scaled.denominator and q % 2 == 1):
        q += 1
    s = str(q).rjust(digits + 1, "0")
    out = s[:-digits] + "." + s[-digits:] if digits else s
    return ("" if q == 0 else sign) + out


def dec_decimal(x: Decimal, digits: int) -> str:
    """60-digit Decimal -> string with `digits` decimals, half to even, away from boundaries."""
    with localcontext() as ctx:
        ctx.prec = 80
        scaled = x.scaleb(digits)
        frac = scaled - scaled.to_integral_value(rounding=ROUND_FLOOR)
        assert abs(frac - Decimal("0.5")) > Decimal(10) ** -40, x
        return str(x.quantize(Decimal(1).scaleb(-digits), rounding=ROUND_HALF_EVEN))


def trunc_dec(fr: Fraction, digits: int) -> Fraction:
    return Fraction((fr * 10 ** digits).__floor__(), 10 ** digits)


def ceil_dec(fr: Fraction, digits: int) -> Fraction:
    return Fraction(-((-fr * 10 ** digits).__floor__()), 10 ** digits)


def occ(word, pat) -> int:
    """Scattered occurrences of pat in word."""
    dp = [1] + [0] * len(pat)
    for ch in word:
        for j in range(len(pat), 0, -1):
            if pat[j - 1] == ch:
                dp[j] += dp[j - 1]
    return dp[len(pat)]


def interval_word(j: int, l: int) -> tuple:
    return tuple(range(j, l + 1))


# ---------------------------------------------------------------------------------------------
# Library: ternary contents
# ---------------------------------------------------------------------------------------------


def tern_lit(a: int, b: int, c: int) -> Counter:
    """LIT: Counter (x, y, z) -> words, every word enumerated."""
    out: Counter = Counter()

    def rec(r1, r2, r3, n1, n2, x, y, z):
        if not (r1 or r2 or r3):
            out[(x, y, z)] += 1
            return
        if r1:
            rec(r1 - 1, r2, r3, n1 + 1, n2, x, y, z)
        if r2:
            rec(r1, r2 - 1, r3, n1, n2 + 1, x + n1, y, z)
        if r3:
            rec(r1, r2, r3 - 1, n1, n2, x, y + n2, z + x)

    rec(a, b, c, 0, 0, 0, 0, 0)
    return out


def tern_tdp(a: int, b: int, c: int) -> Counter:
    """TDP: word-prefix DP, state (#1, #2, #3) -> Counter (x, y, z); appending a 2 adds #1 to x,
    a 3 adds #2 to y and x to z."""
    layer = {(0, 0, 0): Counter({(0, 0, 0): 1})}
    for _ in range(a + b + c):
        new: dict = {}
        for (n1, n2, n3), dist in layer.items():
            if n1 < a:
                t = new.setdefault((n1 + 1, n2, n3), Counter())
                t.update(dist)
            if n2 < b:
                t = new.setdefault((n1, n2 + 1, n3), Counter())
                for (x, y, z), m in dist.items():
                    t[(x + n1, y, z)] += m
            if n3 < c:
                t = new.setdefault((n1, n2, n3 + 1), Counter())
                for (x, y, z), m in dist.items():
                    t[(x, y + n2, z + x)] += m
        layer = new
    (final,) = layer.values()
    return final


def tern_vals(a: int, b: int, c: int) -> dict:
    """TDP with bitmasks: (x, y) -> frozenset of the values of z on the fibre."""
    layer = {(0, 0, 0): {(0, 0): 1}}
    for _ in range(a + b + c):
        new: dict = {}
        for (n1, n2, n3), cells in layer.items():
            if n1 < a:
                t = new.setdefault((n1 + 1, n2, n3), {})
                for xy, m in cells.items():
                    t[xy] = t.get(xy, 0) | m
            if n2 < b:
                t = new.setdefault((n1, n2 + 1, n3), {})
                for (x, y), m in cells.items():
                    k2 = (x + n1, y)
                    t[k2] = t.get(k2, 0) | m
            if n3 < c:
                t = new.setdefault((n1, n2, n3 + 1), {})
                for (x, y), m in cells.items():
                    k2 = (x, y + n2)
                    t[k2] = t.get(k2, 0) | (m << x)
        layer = new
    (final,) = layer.values()
    return {xy: frozenset(z for z in range(m.bit_length()) if m >> z & 1)
            for xy, m in final.items()}


def compositions(total: int, parts: int):
    if parts == 1:
        yield (total,)
        return
    for first in range(total + 1):
        for rest in compositions(total - first, parts - 1):
            yield (first,) + rest


def tern_gap(a: int, b: int, c: int) -> Counter:
    """GAP: alpha (ones) and gamma (threes) over the gaps 0..b; x = ab - sum g alpha_g,
    y = sum g gamma_g, z = sum_{g<h} (h - g) alpha_g gamma_h, weight prod C(alpha+gamma, alpha)."""
    out: Counter = Counter()
    G = b + 1
    gams = []
    for gam in compositions(c, G):
        y = sum(g * v for g, v in enumerate(gam))
        suff = [0] * (G + 1)          # suff[g] = sum_{h >= g} gamma_h * h, and count
        cnt = [0] * (G + 1)
        for g in range(G - 1, -1, -1):
            suff[g] = suff[g + 1] + gam[g] * g
            cnt[g] = cnt[g + 1] + gam[g]
        gams.append((gam, y, suff, cnt))
    for al in compositions(a, G):
        x = a * b - sum(g * v for g, v in enumerate(al))
        for gam, y, suff, cnt in gams:
            z = 0
            w = 1
            for g in range(G):
                if al[g]:
                    z += al[g] * (suff[g + 1] - g * cnt[g + 1])
                    if gam[g]:
                        w *= comb(al[g] + gam[g], al[g])
            out[(x, y, z)] += w
    return out


def psi_table(a: int, b: int, c: int) -> list:
    """PSI: P[x][y] for (a,b,c); prefix DP over (#1, #2, #3), the polynomial in (x, y) packed
    in one integer (field (x, y) at bit offset (x (bc+1) + y) W)."""
    X, Y = a * b, b * c
    W = (multinomial((a, b, c)).bit_length() + 9) // 8 * 8
    SX, SY = (Y + 1) * W, W
    prev = None
    for n1 in range(a + 1):
        cur = [[0] * (c + 1) for _ in range(b + 1)]
        for n2 in range(b + 1):
            row = cur[n2]
            up = cur[n2 - 1] if n2 else None
            pr = prev[n2] if n1 else None
            sh2, sh3 = n1 * SX, n2 * SY
            for n3 in range(c + 1):
                v = 1 if (n1 == n2 == n3 == 0) else (pr[n3] if n1 else 0)
                if n2:
                    v += up[n3] << sh2
                if n3:
                    v += row[n3 - 1] << sh3
                row[n3] = v
        prev = cur
    poly = prev[b][c]
    nb = W // 8
    raw = poly.to_bytes((X + 1) * (Y + 1) * nb, "little")
    return [[int.from_bytes(raw[(x * (Y + 1) + y) * nb:(x * (Y + 1) + y + 1) * nb], "little")
             for y in range(Y + 1)] for x in range(X + 1)]


def fibres(classes: Counter) -> Counter:
    P: Counter = Counter()
    for (x, y, _z), m in classes.items():
        P[(x, y)] += m
    return P


def a2c_classes(a: int, c: int) -> Counter:
    """GAP for (a,2,c): x = 2 a0 + a1, y = c1 + 2 c2, z = a0 c1 + x c2."""
    out: Counter = Counter()
    rows = [[comb(i + j, i) for j in range(c + 1)] for i in range(a + 1)]
    for a0 in range(a + 1):
        r0 = rows[a0]
        for a1 in range(a - a0 + 1):
            a2 = a - a0 - a1
            r1, r2 = rows[a1], rows[a2]
            x = 2 * a0 + a1
            for c1 in range(c + 1):
                w01 = r1[c1]
                for c2 in range(c - c1 + 1):
                    out[(x, c1 + 2 * c2, a0 * c1 + x * c2)] += r0[c - c1 - c2] * w01 * r2[c2]
    return out


def classes_2b2(b: int) -> Counter:
    """(2,b,2) by levels (Lemma 5.9; [Y26a] Lemma 1): the ones at levels u1 <= u2, the threes at
    levels v1 <= v2 (level = number of 2s to the right); x = u1 + u2, y = 2b - v1 - v2,
    z = sum (u_i - v_j)^+, weight prod over levels C(#1 + #3, #1)."""
    out: Counter = Counter()
    pairs = [(u1, u2) for u1 in range(b + 1) for u2 in range(u1, b + 1)]
    for u1, u2 in pairs:
        x = u1 + u2
        for v1, v2 in pairs:
            z = (max(0, u1 - v1) + max(0, u1 - v2) + max(0, u2 - v1) + max(0, u2 - v2))
            if u1 == u2:
                w = 6 if (v1 == v2 == u1) else (3 if (v1 == u1 or v2 == u1) else 1)
            elif v1 == v2:
                w = 3 if v1 in (u1, u2) else 1
            else:
                w = (2 if (u1 == v1 or u1 == v2) else 1) * (2 if (u2 == v1 or u2 == v2) else 1)
            out[(x, 2 * b - v1 - v2, z)] += w
    return out


# ---------------------------------------------------------------------------------------------
# Library: every Parikh class of a content (PMX)
# ---------------------------------------------------------------------------------------------


class PMX:
    """Word-prefix DP over the partial Parikh matrix (|w|_{j..l}, j <= l, 0-based letters),
    packed in one integer: field (j, l) at bit offset (l k + j) W, so appending letter m adds the
    column m-1 (shifted by k W) to the column m, and 1 to the field (m, m).  Equal states are
    merged.  With a psi_2 target, prefixes that cannot reach it are dropped (x_i only grows, by
    at least rem_{i+1} * placed_i and at most rem_{i+1} * n_i)."""

    def __init__(self, n) -> None:
        self.n = tuple(n)
        k = self.k = len(n)
        top = max(prod(n[j:l + 1]) for j in range(k) for l in range(j, k))
        W = self.W = top.bit_length() + 1
        self.FM = (1 << W) - 1
        self.off = {(j, l): (l * k + j) * W for j in range(k) for l in range(j, k)}
        self.moves = []
        for m in range(k):
            mask = 0
            for j in range(m):
                mask |= self.FM << self.off[(j, m - 1)]
            self.moves.append((mask, 1 << self.off[(m, m)], self.off[(m, m)], n[m]))
        self.shift = k * W

    def classes(self, target=None) -> dict:
        FM, shift, n, k = self.FM, self.shift, self.n, self.k
        diag = [self.off[(m, m)] for m in range(k)]
        pair = [self.off[(i, i + 1)] for i in range(k - 1)]
        layer = {0: 1}
        for _ in range(sum(n)):
            new: dict = {}
            get = new.get
            for S, c in layer.items():
                for mask, unit, om, nm in self.moves:
                    if (S >> om) & FM < nm:
                        S2 = S + ((S & mask) << shift) + unit
                        if target is not None:
                            bad = False
                            for i in range(k - 1):
                                xi = (S2 >> pair[i]) & FM
                                rem = n[i + 1] - ((S2 >> diag[i + 1]) & FM)
                                if xi + rem * ((S2 >> diag[i]) & FM) > target[i] or \
                                        xi + rem * n[i] < target[i]:
                                    bad = True
                                    break
                            if bad:
                                continue
                        new[S2] = get(S2, 0) + c
            layer = new
        return layer

    def field(self, S: int, j: int, l: int) -> int:
        return (S >> self.off[(j, l)]) & self.FM

    def psi2(self, S: int) -> tuple:
        return tuple(self.field(S, i, i + 1) for i in range(self.k - 1))

    def higher(self, S: int) -> tuple:
        """(|w|_{j..l}) for l - j >= 2, 1-based (j, l) in lexicographic order."""
        return tuple(self.field(S, j, l) for j in range(self.k) for l in range(j + 2, self.k))


def alt_psi2(n, first_full: bool = True) -> tuple:
    """psi_2 of the alternating class Z (edge 1 full) or Z' (edge 1 empty)."""
    out = []
    for i in range(len(n) - 1):
        full = (i % 2 == 0) == first_full
        out.append(n[i] * n[i + 1] if full else 0)
    return tuple(out)


@lru_cache(maxsize=None)
def pmx_all(n) -> tuple:
    """Every class of content n: tuple of (psi_2, higher entries, size), sorted by size desc."""
    pm = PMX(n)
    out = [(pm.psi2(S), pm.higher(S), m) for S, m in pm.classes().items()]
    out.sort(key=lambda t: (-t[2], t[0], t[1]))
    return tuple(out)


@lru_cache(maxsize=None)
def pmx_fibre(n, x) -> tuple:
    """The classes of the psi_2 fibre x of content n: tuple of (higher entries, size)."""
    pm = PMX(n)
    out = [(pm.higher(S), m) for S, m in pm.classes(tuple(x)).items() if pm.psi2(S) == tuple(x)]
    out.sort(key=lambda t: (-t[1], t[0]))
    return tuple(out)


# ---------------------------------------------------------------------------------------------
# Library: alternating classes and their relaxations (INS, DOWN)
# ---------------------------------------------------------------------------------------------


def ins_from(n, start: dict) -> int:
    """INS: the number of words of content n whose subword on {1,2} is given by `start`
    (dict: number of letters 1 before the first letter 2 -> number of such {1,2}-words) and
    whose edges 2, ..., k-1 are alternately empty and full (edge 2 empty).  The state after
    placing the letters 1..i is the number s of letters before the first copy of i (edge i
    empty: the copies of i+1 go there) or after the last copy (edge i full); inserting the
    n_{i+1} copies so that j of those s letters end up on the far side of the new chain gives
    the state L - s + j with weight C(s - j + n_{i+1} - 1, n_{i+1} - 1)."""
    k = len(n)
    if k == 2:
        return sum(start.values())
    cur = dict(start)
    L = n[0] + n[1]
    for i in range(2, k):
        m = n[i]
        if i == k - 1:
            return sum(w * comb(s + m, m) for s, w in cur.items())
        nxt: dict = defaultdict(int)
        for s, w in cur.items():
            for j in range(s + 1):
                nxt[L - s + j] += w * comb(s - j + m - 1, m - 1)
        cur = nxt
        L += m
    raise AssertionError


def ez(n) -> int:
    """|Z(n)|: edge 1 full (1^{n_1} 2^{n_2} on {1,2})."""
    return ins_from(n, {n[0]: 1})


@lru_cache(maxsize=None)
def proj_first(n1: int, n2: int) -> dict:
    """area u -> Counter (A_1 -> number of projections A in [0,n1]^{n2}, nondecreasing, sum u)."""
    out: dict = defaultdict(Counter)
    for A in combinations_with_replacement(range(n1 + 1), n2):
        out[sum(A)][A[0]] += 1
    return dict(out)


def z_relaxed(n, u: int) -> int:
    """|Z_k(S_u)| for content n: the psi_2-fibre of psi_2(Z) with edge 1 replaced by u."""
    return ins_from(n, proj_first(n[0], n[1]).get(u, {}))


def down_count(n, rel, track=()) -> Counter:
    """DOWN: words of content n whose edge i is 'F' (every i before every i+1), 'E' (every i+1
    before every i) or None (free), by a DP over the numbers of letters placed; the areas of the
    edges in `track` are recorded.  Returns Counter: tuple of tracked areas -> words."""
    k = len(n)
    track = tuple(track)
    tpos = {e: t for t, e in enumerate(track)}
    layer = {(tuple([0] * k), tuple([0] * len(track))): 1}
    for _ in range(sum(n)):
        new: dict = defaultdict(int)
        for (ms, ar), c in layer.items():
            for m in range(k):
                if ms[m] == n[m]:
                    continue
                if m > 0:
                    r = rel[m - 1]
                    if (r == "F" and ms[m - 1] < n[m - 1]) or (r == "E" and ms[m - 1] > 0):
                        continue
                if m < k - 1:
                    r = rel[m]
                    if (r == "F" and ms[m + 1] > 0) or (r == "E" and ms[m + 1] < n[m + 1]):
                        continue
                ms2 = ms[:m] + (ms[m] + 1,) + ms[m + 1:]
                ar2 = ar
                if m > 0 and (m - 1) in tpos:
                    t = tpos[m - 1]
                    ar2 = ar[:t] + (ar[t] + ms[m - 1],) + ar[t + 1:]
                new[(ms2, ar2)] += c
        layer = new
    out: Counter = Counter()
    for (_ms, ar), c in layer.items():
        out[ar] += c
    return out


def alt_rel(k: int, first_full: bool = True) -> list:
    return [("F" if (i % 2 == 0) == first_full else "E") for i in range(k - 1)]


# ---------------------------------------------------------------------------------------------
# Library: the transfer operator of Section 7 (KERN), exact rational polynomials
# ---------------------------------------------------------------------------------------------


def p_trim(p: list) -> list:
    p = list(p)
    while p and p[-1] == 0:
        p.pop()
    return p


def p_add(p: list, q: list) -> list:
    out = [Fraction(0)] * max(len(p), len(q))
    for i, v in enumerate(p):
        out[i] += v
    for i, v in enumerate(q):
        out[i] += v
    return p_trim(out)


def p_mul(p: list, q: list) -> list:
    if not p or not q:
        return []
    out = [Fraction(0)] * (len(p) + len(q) - 1)
    for i, u in enumerate(p):
        if u:
            for j, v in enumerate(q):
                out[i + j] += u * v
    return p_trim(out)


def p_scale(p: list, s) -> list:
    return p_trim([v * s for v in p])


def p_antider(p: list) -> list:
    return p_trim([Fraction(0)] + [v / (i + 1) for i, v in enumerate(p)])


def p_eval(p: list, v) -> Fraction:
    out = Fraction(0)
    for c in reversed(p):
        out = out * v + c
    return out


@lru_cache(maxsize=None)
def kern_basics(n: int) -> tuple:
    """h_n(1 - t) and H_n(t) as coefficient lists."""
    h1 = [Fraction(comb(n - 1, i) * (-1) ** i, factorial(n - 1)) for i in range(n)]
    H = [Fraction(0)] * n + [Fraction(1, factorial(n))]
    return tuple(h1), tuple(H)


def kern_apply(n: int, g: list) -> list:
    """(K g)(v) = int_0^v h_n(1-t) H_n(t) g(t) dt + H_n(v) int_v^1 h_n(1-t) g(t) dt."""
    h1, H = (list(t) for t in kern_basics(n))
    A = p_antider(p_mul(p_mul(h1, H), g))
    I = p_antider(p_mul(h1, g))
    I1 = p_eval(I, Fraction(1))
    return p_add(A, p_mul(H, p_add([I1], p_scale(I, -1))))


@lru_cache(maxsize=None)
def kern_g(n: int, k: int) -> tuple:
    if k == 2:
        return (Fraction(1),)
    if k == 3:
        return tuple(kern_basics(n)[1])
    return tuple(kern_apply(n, list(kern_g(n, k - 2))))


def theta(n: int, p: int) -> list:
    """theta_p(v) = v^p (1-v)^{2n-1-p} / (p! (2n-1-p)!)."""
    q = 2 * n - 1 - p
    poly = [Fraction(0)] * p + [Fraction(comb(q, i) * (-1) ** i) for i in range(q + 1)]
    return p_scale(poly, Fraction(1, factorial(p) * factorial(q)))


def kern_count(n: int, k: int, p: int) -> Fraction:
    """(nk)! int_0^1 theta_p g_k: |Z_k({A})| for A_1 = p (Proposition 7.3)."""
    return factorial(n * k) * p_eval(p_antider(p_mul(theta(n, p), list(kern_g(n, k)))),
                                     Fraction(1))


# ---------------------------------------------------------------------------------------------
# Library: (a,2,c) (Section 6) and the certificate of Appendix A (CERT)
# ---------------------------------------------------------------------------------------------

SQRT5 = Decimal(5).sqrt()
PHI = (1 + SQRT5) / 2
GAP_LO = (1 - 1 / SQRT5) / 2
GAP_HI = (3 - SQRT5) / 2


def f_bound(a: int, c: int, j: int) -> int:
    """f(j) = sum_{i=j}^{min(2j,c)} C(a+c-i, a) = P(0, 2c-2j)."""
    return sum(comb(a + c - i, a) for i in range(j, min(2 * j, c) + 1))


def p0(a: int, c: int, m: int) -> int:
    """P_0(m) = P(0, 2c - m) (Proposition 6.4)."""
    return sum(comb(a + c - i, a) for i in range(-(-m // 2), min(m, c) + 1))


def cstar(a) -> Decimal:
    a = Decimal(a)
    return ((a + 1) + (5 * a * a - 2 * a + 1).sqrt()) / 2


def golden_ties(amax: int) -> list:
    """All (a, c), 1 <= a <= amax, a <= c, with c(c-1) = a(a+c-1), by the integer root test."""
    out = []
    for a in range(1, amax + 1):
        D = 5 * a * a - 2 * a + 1
        r = isqrt(D)
        if r * r == D and (a + 1 + r) % 2 == 0:
            c = (a + 1 + r) // 2
            if c >= a and c * (c - 1) == a * (a + c - 1):
                out.append((a, c))
    return out


def threshold(a: int) -> int:
    """The largest c >= a with c(c-1) <= a(a+c-1)."""
    c = a
    while (c + 1) * c <= a * (a + c):
        c += 1
    return c


def a2c_class(a: int, c: int, x: int, y: int, z: int) -> int:
    """rho(x, y, z) of (a,2,c) by GAP, one class."""
    tot = 0
    for a0 in range(a + 1):
        a1 = x - 2 * a0
        a2 = a - a0 - a1
        if a1 < 0 or a2 < 0:
            continue
        for c2 in range(c + 1):
            c1 = y - 2 * c2
            c0 = c - c1 - c2
            if c1 < 0 or c0 < 0 or a0 * c1 + x * c2 != z:
                continue
            tot += comb(a0 + c0, a0) * comb(a1 + c1, a1) * comb(a2 + c2, a2)
    return tot


def a2c_fibre(a: int, c: int, x: int, y: int) -> int:
    tot = 0
    for a0 in range(a + 1):
        a1 = x - 2 * a0
        a2 = a - a0 - a1
        if a1 < 0 or a2 < 0:
            continue
        for c2 in range(c + 1):
            c1 = y - 2 * c2
            c0 = c - c1 - c2
            if c1 < 0 or c0 < 0:
                continue
            tot += comb(a0 + c0, a0) * comb(a1 + c1, a1) * comb(a2 + c2, a2)
    return tot


def cert_u(mu: int, n: int) -> int:
    return comb(mu + n, mu) if n >= 0 else 0


def cert_U(mu: int, n: int) -> int:
    return comb(mu + n + 1, mu + 1) if n >= 0 else 0


def cert_hmin(mu: int, nu: int) -> int:
    h = 0
    while cert_u(mu, nu - h) + cert_u(mu, nu - h - 1) > cert_u(mu, nu + 1):
        h += 1
    return h


def cert_slacks(mu: int, nu: int, h: int) -> tuple:
    """Left minus right side of (C-a), (C-b) and (C-b') at h."""
    U = lambda n: cert_U(mu, n)
    ca = sum(U(k) for k in range(nu - 2 * h, nu - h + 1)) - comb(mu + nu + 1, mu)
    lhs = sum(U(k) for k in range(nu - h - 1, nu))
    rhs = sum(U(nu) - U(k) for k in range(nu - h, nu))
    cbp = lhs - rhs
    return ca, cbp - comb(mu + nu, mu - 1), cbp


def cert_C1_rows() -> dict:
    """nu -> {mu: (h, Ca, Cb, Cb')} for mu in {2,3,4}, mu <= nu <= 14."""
    rows: dict = {}
    for mu in (2, 3, 4):
        for nu in range(mu, 15):
            h = cert_hmin(mu, nu)
            rows.setdefault(nu, {})[mu] = (h,) + cert_slacks(mu, nu, h)
    return rows


def cert_C2() -> tuple:
    """[C2]: e_J, E_1(J), E_2(J) of P_0(0) - K^+(2,3) for J = 0..40, and K^+'s coefficients."""
    mu, nu = 2, 3
    kp: Counter = Counter()
    for i in range(nu, 2 * nu + 1):
        kp[i] += cert_u(mu, 2 * nu - i)
    hb = comb(mu + nu, mu - 1)
    kp[nu] += hb
    kp[nu + 1] -= hb
    e = [sum(comb(mu - 1 + j - i, mu - 1) for i in range(0, min(0, j) + 1)) - kp[j]
         for j in range(41)]
    E1, E2 = [], []
    for v in e:
        E1.append((E1[-1] if E1 else 0) + v)
        E2.append((E2[-1] if E2 else 0) + E1[-1])
    return e, E1, E2, kp, hb


ETA = Fraction(6932, 10000)


def cert_C3(mu0: int, t1: int) -> tuple:
    lam2 = 1 - (1 + ETA) / (mu0 + 1)
    lam1 = (1 + ETA) / (mu0 + 1)
    th1 = t1 * (1 - ETA / mu0) - ETA / mu0
    ka1 = Fraction(1 + t1) / (1 + t1 - Fraction(1, mu0))
    m2 = (2 + 1 / th1) * ka1 * ETA ** 2 / 6
    m1 = (2 + 1 / th1) * (ka1 * ETA * (2 + ETA) / 6 + Fraction(1, 3 * t1))
    return th1, lam2, lam1, m2, m1


def ln2_below(bound: Fraction) -> bool:
    """ln 2 = sum_{k>=1} 1/(k 2^k) < bound, with the tail sum_{k>N} <= 1/((N+1) 2^N)."""
    s = Fraction(0)
    for k in range(1, 41):
        s += Fraction(1, k * 2 ** k)
    return s + Fraction(1, 41 * 2 ** 40) < bound


# ---------------------------------------------------------------------------------------------
# (b) the recomputation registry
# ---------------------------------------------------------------------------------------------
#
# RC[id] = (kind, group, fn, partial).  fn(e) returns a list of (condition, label) pairs; an
# entry passes when all of them hold.  kind is "default", "full", "process" or "cited" (see the
# module docstring); group is the --only group that recomputes it in --full; for a "full"
# entry, `partial` (optional) recomputes a smaller range in the default mode.

RC: dict = {}


def reg(ids, kind: str = "default", group: str = "base", partial=None):
    if isinstance(ids, str):
        ids = [ids]

    def deco(fn):
        for i in ids:
            assert i not in RC, f"duplicate registration {i}"
            RC[i] = (kind, group, fn, partial)
        return fn
    return deco


def ungroup(s: str) -> str:
    """The article groups the digits of numbers with five or more digits by thin spaces
    (484\\,422); the comparisons below ignore a separator \\, or {,} between two digits, so the
    strings rebuilt from recomputed numbers need no grouping of their own."""
    return re.sub(r"(?<=\d)(?:\\,|\{,\})(?=\d)", "", s)


def grouping_ok(s: str) -> bool:
    """Every grouped number in s is grouped canonically: at least five digits, groups of three
    from the right (so four-digit numbers are not grouped); and no standalone number of five or
    more digits is left ungrouped (a digit run next to a letter, a brace, a backslash, a point
    or an underscore, as in a hex digest, a word or a file name, is not a number)."""
    if re.search(r"(?<![0-9.a-zA-Z_{\\])[0-9]{5,}(?![0-9.a-zA-Z_])", s):
        return False
    for m in re.finditer(r"\d+(?:(?:\\,|\{,\})\d+)+", s):
        parts = re.split(r"\\,|\{,\}", m.group(0))
        if not (1 <= len(parts[0]) <= 3 and all(len(p) == 3 for p in parts[1:])
                and len("".join(parts)) >= 5):
            return False
    return True


def val(e: dict, want: str) -> list:
    """The registered value must equal the string rebuilt from the recomputed numbers (digit
    grouping aside, see ungroup), and its grouping must be canonical."""
    return [(ungroup(e["value"]) == ungroup(want) and grouping_ok(e["value"]),
             f"value {e['value']!r} == recomputed {want!r}, canonical digit grouping")]


def lit(e: dict, latex: str, *checks) -> list:
    """A formula or a range: the registered value is the transcribed LaTeX (digit grouping
    aside), and `checks` (pairs (condition, label)) verify what it states."""
    return [(ungroup(e["value"]) == ungroup(latex) and grouping_ok(e["value"]),
             f"value {e['value']!r} == transcribed {latex!r}, canonical digit grouping")] + \
        list(checks)


WORDS_NUM = {2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven"}


def dollars(vals) -> str:
    return ", ".join(f"${v}$" for v in vals)


def and_list(items: list) -> str:
    """'$a$, $b$ and $c$' style (the items already formatted)."""
    if len(items) == 1:
        return items[0]
    return ", ".join(items[:-1]) + " and " + items[-1]


def tup(t) -> str:
    return "(" + ",".join(str(v) for v in t) + ")"


# ---------------------------------------------------------------------------------------------
# (b.1) ternary contents: Figures 1-4 and 6, Sections 3 and 4
# ---------------------------------------------------------------------------------------------


@lru_cache(maxsize=None)
def T327() -> dict:
    """(3,2,7) by LIT (all 7920 words), cross-checked against GAP and TDP."""
    a, b, c = 3, 2, 7
    lit_ = tern_lit(a, b, c)
    assert lit_ == tern_gap(a, b, c) == tern_tdp(a, b, c)
    P = fibres(lit_)
    by: dict = {}
    for (x, y, z), m in lit_.items():
        by.setdefault((x, y), {})[z] = m
    top = max(lit_.values())
    at = sorted(k for k, v in lit_.items() if v == top)
    pmax = max(P.values())
    centre = sorted(k for k, v in P.items() if v == pmax)
    return {"cl": lit_, "P": P, "by": by, "top": top, "at": at, "pmax": pmax, "centre": centre,
            "tau": comb(a + c, a), "words": sum(lit_.values())}


@reg(["fig1-B", "s1-fig-largest-class-140"])
def _(e):
    return val(e, str(T327()["top"]))


@reg("fig1-holes")
def _(e):
    d = T327()["by"][(3, 7)]
    holes = [z for z in range(max(d) + 1) if z not in d]
    return val(e, "$z=" + ",".join(map(str, holes)) + "$") + [
        (max(d) == 10, "z_max = 10 at (3,7)")]


@reg(["fig1-maximisers", "s6-ex-327-max"])
def _(e):
    at = T327()["at"]
    s = " and ".join(f"${tup(t)}$" for t in at)
    if e["id"] == "fig1-maximisers":
        s = "$(x,y,z)=" + tup(at[0]) + "$ and $" + tup(at[1]) + "$"
    return val(e, s)


@reg(["fig1-psi2-max", "s1-fig-centre-300"])
def _(e):
    return val(e, str(T327()["pmax"]))


@reg("s1-fig-centre-point")
def _(e):
    (cx,) = T327()["centre"]
    return val(e, f"$(x,y)={tup(cx)}$")


@reg(["fig1-split-count", "s1-fig-seven-classes"])
def _(e):
    return val(e, WORDS_NUM[len(T327()["by"][(3, 7)])])


@reg("fig1-split-sizes")
def _(e):
    d = T327()["by"][(3, 7)]
    return val(e, dollars(d[z] for z in sorted(d)))


@reg("fig1-split-z")
def _(e):
    return val(e, "$z=" + ",".join(map(str, sorted(T327()["by"][(3, 7)]))) + "$")


@reg(["fig1-tau"])
def _(e):
    return val(e, str(T327()["tau"]))


@reg("s1-fig-central-largest-120")
def _(e):
    d = T327()["by"][(3, 7)]
    return val(e, str(max(d.values()))) + [(d[0] == max(d.values()), "the largest class at z=0")]


@reg("s1-F-327")
def _(e):
    t = T327()
    return val(e, f"${t['top']}>\\tau={t['tau']}$")


@reg("s6-ex-327")
def _(e):
    t = T327()
    f1 = f_bound(3, 7, 1)
    return val(e, f"$\\beta(3,7)=f(1)={f1}>\\tau={t['tau']}$") + [(f1 == t["top"], "f(1) = beta")]


def word_info(w: str) -> tuple:
    """content, (x, y, z), the lattice points of the 2s, the centre, (delta, eps)."""
    letters = [int(ch) for ch in w]
    content = tuple(letters.count(i) for i in (1, 2, 3))
    x, y, z = occ(letters, (1, 2)), occ(letters, (2, 3)), occ(letters, (1, 2, 3))
    p = q = 0
    pts = []
    path = [(0, 0)]
    for ch in letters:
        if ch == 1:
            p += 1
            path.append((p, q))
        elif ch == 3:
            q += 1
            path.append((p, q))
        else:
            pts.append((p, q))
    return content, (x, y, z), pts, path


FIG6 = {"a": "313233132133", "b": "333211132333"}


def latex_word(w: str) -> str:
    return "".join("\\mathbf{2}" if ch == "2" else ch for ch in w)


@reg(["fig6-word-a", "fig6-word-b"])
def _(e):
    key = e["id"][-1]
    w = FIG6[key]
    content, xyz, pts, _ = word_info(w)
    return val(e, latex_word(w)) + [(content == (3, 2, 7) and xyz == (3, 7, 9),
                                     f"w_{key} has content (3,2,7) and (x,y,z) = (3,7,9)")]


@reg("fig6-centre")
def _(e):
    cs = set()
    for w in FIG6.values():
        _, _, (v1, v2), _ = word_info(w)
        cs.add((Fraction(v1[0] + v2[0], 2), Fraction(v1[1] + v2[1], 2)))
    (mu, nu), = cs
    return val(e, f"$(\\mu,\\nu)=({mu},{nu})$")


@reg("fig6-class")
def _(e):
    xyzs = {word_info(w)[1] for w in FIG6.values()}
    (xyz,) = xyzs
    return val(e, f"$(x,y,z)={tup(xyz)}$")


@reg("fig6-class-size")
def _(e):
    return val(e, str(T327()["cl"][(3, 7, 9)]))


@reg(["fig6-points-a", "fig6-points-b"])
def _(e):
    key = e["id"][-1]
    _, (x, y, z), (v1, v2), _ = word_info(FIG6[key])
    d, eps = v2[0] - v1[0], v2[1] - v1[1]
    # the class (3,7,9): every word of it has one of the two point pairs of the figure
    pairs = Counter()
    for w in all_words((3, 2, 7)):
        cw, xyz, pts, _ = word_info(w)
        if xyz == (3, 7, 9):
            pairs[tuple(pts)] += 1
    want = sorted(tuple(word_info(w)[2]) for w in FIG6.values())
    return val(e, f"$v_1={tup(v1)}$, $v_2={tup(v2)}$, $\\Delta={d}\\cdot {eps}$") + [
        (x * y - 2 * z == d * eps, "xy - 2z = delta * epsilon"),
        (sorted(pairs) == want and sum(pairs.values()) == 40,
         "the 40 words of the class (3,7,9) have exactly the two point pairs of the figure")]


def all_words(content):
    """Every word of a ternary content, as a string."""
    a, b, c = content

    def rec(r1, r2, r3, pre):
        if not (r1 or r2 or r3):
            yield pre
            return
        if r1:
            yield from rec(r1 - 1, r2, r3, pre + "1")
        if r2:
            yield from rec(r1, r2 - 1, r3, pre + "2")
        if r3:
            yield from rec(r1, r2, r3 - 1, pre + "3")

    yield from rec(a, b, c, "")


def gset(m: int, n: int) -> set:
    return set(range(m * n + 1)) if min(m, n) <= 1 else {0, 1, m * n - 1, m * n}


def rules(a: int, b: int, c: int, u: int, v: int) -> list:
    out = []
    if u in (0, a * b) or v in (0, b * c):
        out.append("E")
    if u + v <= b:
        out.append("N")
    if (a * b - u) + (b * c - v) <= b:
        out.append("Ch")
    if u in gset(a, b) and v in gset(b, c):
        out.append("G")
    return out


def profiles(top: int, b: int, total: int, increasing: bool = True) -> list:
    """The nondecreasing vectors in [0, top]^b with the given sum (reversed if not
    `increasing`), in lexicographic order."""
    out = []

    def rec(prefix, lo, left, rem):
        if left == 0:
            if rem == 0:
                out.append(tuple(prefix) if increasing else tuple(reversed(prefix)))
            return
        for v in range(lo, top + 1):
            if v * left > rem:
                break
            if rem - v > (left - 1) * top:
                continue
            prefix.append(v)
            rec(prefix, v, left - 1, rem - v)
            prefix.pop()

    rec([], 0, b, total)
    return out


SMALL_TERNARY = [(a, b, c) for a in range(1, 5) for b in range(1, 6) for c in range(1, 5)
                 if a + b + c <= 12]


@lru_cache(maxsize=None)
def vals_of(abc: tuple) -> dict:
    return tern_vals(*abc)


@lru_cache(maxsize=None)
def rigidity_scan() -> dict:
    """Theorem A(i), the forced values and Corollary 3.6 on every small ternary content."""
    bad_iff, bad_val, bad_cor = [], [], []
    for (a, b, c) in SMALL_TERNARY:
        V = vals_of((a, b, c))
        for (x, y), zs in V.items():
            rs = rules(a, b, c, x, y)
            if (len(zs) == 1) != bool(rs):
                bad_iff.append((a, b, c, x, y))
            if len(zs) != 1:
                continue
            (z,) = zs
            lam = c * x + a * y - a * b * c
            want = set()
            if x == 0 or y == 0 or "N" in rs:
                want.add(0)
            if x == a * b:
                want.add(a * y)
            if y == b * c:
                want.add(c * x)
            if "Ch" in rs:
                want.add(lam)
            if "G" in rs:
                (A,) = profiles(a, b, x)
                (C,) = profiles(c, b, y, increasing=False)
                want.add(sum(p * q for p, q in zip(A, C)))
            if want != {z}:
                bad_val.append((a, b, c, x, y, z, want))
        if min(a, b, c) >= 2:
            if V[(1, b * c - 1)] != {c - 1} or V[(a * b - 1, 1)] != {a - 1}:
                bad_cor.append((a, b, c))
            rigid = {xy for xy in V if rules(a, b, c, *xy)}
            cor = {(x, y) for (x, y) in V if x in (0, a * b) or y in (0, b * c) or x + y <= b or
                   (a * b - x) + (b * c - y) <= b} | {(1, b * c - 1), (a * b - 1, 1)}
            if rigid != cor:
                bad_cor.append(("shape", a, b, c))
    return {"iff": bad_iff, "val": bad_val, "cor": bad_cor, "n": len(SMALL_TERNARY)}


@reg("s3-thmA-forced-values")
def _(e):
    s = rigidity_scan()
    return lit(e, "$ay$ if $x=ab$; $cx$ if $y=bc$; $\\lambda$ under \\ruleCh; and $A\\cdot C$",
               (s["iff"] == [], f"Theorem A(i): one value iff rigid, {s['n']} contents"),
               (s["val"] == [], "the forced values 0, ay, cx, lambda, A.C on every rigid cell"))


@reg("s3-cor36-values")
def _(e):
    s = rigidity_scan()
    return lit(e, "$z=c-1$ and $z=a-1$",
               (s["cor"] == [], "Corollary 3.6: the rigid set and z = c-1, a-1 at (1,bc-1), "
                                "(ab-1,1) for every small content with a,b,c >= 2"))


@lru_cache(maxsize=None)
def fig2_data() -> dict:
    a, b, c = 4, 5, 4
    V = vals_of((a, b, c))
    cells = [(x, y) for x in range(a * b + 1) for y in range(b * c + 1)]
    rule_of = {xy: rules(a, b, c, *xy) for xy in cells}
    rigid = {xy for xy in cells if rule_of[xy]}
    single = {xy for xy in cells if len(V[xy]) == 1}
    per = Counter(r for xy in rigid for r in rule_of[xy])
    only_g = sorted(xy for xy in rigid if rule_of[xy] == ["G"])
    return {"V": V, "cells": cells, "rule_of": rule_of, "rigid": rigid, "single": single,
            "per": per, "only_g": only_g}


@reg("fig2-cells")
def _(e):
    d = fig2_data()
    return val(e, str(len(d["cells"]))) + [(sorted(d["V"]) == d["cells"], "every cell occurs")]


@reg("fig2-rigid")
def _(e):
    d = fig2_data()
    return val(e, str(len(d["single"]))) + [(d["single"] == d["rigid"],
                                             "(4,5,4): one value of z iff rigid by the rules")]


@reg("fig2-per-rule")
def _(e):
    p = fig2_data()["per"]
    return val(e, f"${p['E']}$, ${p['N']}$, ${p['Ch']}$ and ${p['G']}$")


@reg("fig2-gamma-only")
def _(e):
    d = fig2_data()
    og = d["only_g"]
    return val(e, " and ".join(f"${tup(t)}$" for t in og)) + [
        (all(len(d["V"][xy]) == 1 for xy in og), "the (Gamma)-only cells are rigid")]


@lru_cache(maxsize=None)
def rig_counts(kmax: int = 41) -> dict:
    """Rig_k for (2^k) by the transfer matrix of the rigid cells of (2,2,2) (rules), and the
    5 x 5 matrix T itself."""
    T = [[1 if rules(2, 2, 2, u, v) else 0 for v in range(5)] for u in range(5)]
    out = {1: 1, 2: 5}
    vec = [1] * 5
    for k in range(3, kmax + 1):
        vec = [sum(T[u][v] * vec[v] for v in range(5)) for u in range(5)]
        out[k] = sum(vec)
    return {"T": T, "R": out}


@lru_cache(maxsize=None)
def rig_brute(kmax: int) -> dict:
    """Rig_k = the psi_2-fibres of (2^k) that are single classes, from every class (PMX)."""
    out = {}
    for k in range(1, kmax + 1):
        if k == 1:
            out[1] = 1
            continue
        fib_n = Counter(x for x, _h, _m in pmx_all((2,) * k))
        out[k] = sum(1 for v in fib_n.values() if v == 1)
    return out


def gf_coeffs(num: list, den: list, N: int) -> list:
    """Power series coefficients of num/den (den[0] = 1) up to t^N."""
    out = []
    for n in range(N + 1):
        s = num[n] if n < len(num) else 0
        for i in range(1, min(n, len(den) - 1) + 1):
            s -= den[i] * out[n - i]
        out.append(s)
    return out


@reg(["s1-A-rig-counts", "fig2-transfer-counts", "s3-rig-values", "s3-oeis-values"])
def _(e):
    R = rig_counts()["R"]
    B = rig_brute(6)
    vals = [R[k] for k in range(3, 7)]
    if e["id"] == "s1-A-rig-counts":
        want = ",".join(map(str, vals))
    elif e["id"] == "fig2-transfer-counts":
        want = "$, $".join(map(str, vals))
    else:
        want = dollars(vals)
    return val(e, want) + [(all(B[k] == R[k] for k in range(1, 7)),
                            "Rig_k by the rules = the single-class fibres (PMX), k <= 6")]


@reg(["s1-A-rig-gf", "s3-rig-gf"])
def _(e):
    R = rig_counts()["R"]
    co = gf_coeffs([0, 1, 1, -2], [1, -4, -2, 4], 41)
    latex = ("t(1-t)(1+2t)/(1-4t-2t^2+4t^3)" if e["id"] == "s1-A-rig-gf"
             else "\\frac{t(1-t)(1+2t)}{1-4t-2t^2+4t^3}")
    return lit(e, latex, (all(co[k] == R[k] for k in range(1, 42)) and co[0] == 0,
                          "series coefficients = Rig_k for 1 <= k <= 41"))


@reg("s3-rig-recurrence")
def _(e):
    R = rig_counts()["R"]
    return lit(e, "\\Rig_k=4\\Rig_{k-1}+2\\Rig_{k-2}-4\\Rig_{k-3}",
               (all(R[k] == 4 * R[k - 1] + 2 * R[k - 2] - 4 * R[k - 3] for k in range(4, 42)),
                "recurrence for 4 <= k <= 41"),
               (R[3] - 4 * R[2] - 2 * R[1] != 0, "and not at k = 3 (no Rig_0)"))


@reg("s3-rig1-rig2")
def _(e):
    B = rig_brute(2)
    fib2 = Counter(x for x, _h, _m in pmx_all((2, 2)))
    return val(e, f"$\\Rig_1={B[1]}$ and $\\Rig_2={B[2]}$") + [
        (len(fib2) == 5, "(2,2) has 5 psi_2 vectors, all single classes")]


def cubic(t: Fraction) -> Fraction:
    return t ** 3 - 4 * t ** 2 - 2 * t + 4


@reg("s3-theta-bracket")
def _(e):
    lo, hi = Fraction(4249, 1000), Fraction(425, 100)
    R = rig_counts()["R"]
    return val(e, "$4.249<\\theta<4.25$") + [
        (cubic(lo) < 0 < cubic(hi), "t^3-4t^2-2t+4 changes sign on (4.249, 4.25)"),
        (cubic(Fraction(-2)) < 0 < cubic(Fraction(-1)) and
         cubic(Fraction(0)) > 0 > cubic(Fraction(1)),
         "and on (-2,-1) and (0,1): three real roots, the largest in (4.249, 4.25)"),
        (all(lo < Fraction(R[k], R[k - 1]) < hi for k in range(12, 41)),
         "4.249 < Rig_k / Rig_{k-1} < 4.25 for 12 <= k <= 40")]


@reg("s3-root-brackets")
def _(e):
    return val(e, "$(-2,-1)$, $(0,1)$ and $(4.249,4.25)$") + [
        (cubic(Fraction(-2)) < 0 < cubic(Fraction(-1)), "sign change on (-2,-1)"),
        (cubic(Fraction(0)) > 0 > cubic(Fraction(1)), "sign change on (0,1)"),
        (cubic(Fraction(4249, 1000)) < 0 < cubic(Fraction(425, 100)), "sign change on "
                                                                        "(4.249,4.25)")]


M3 = [[2, 2, 1], [2, 2, 0], [2, 0, 0]]


def mat_mul(A, B):
    return [[sum(A[i][t] * B[t][j] for t in range(len(B))) for j in range(len(B[0]))]
            for i in range(len(A))]


@reg("s3-M")
def _(e):
    T = rig_counts()["T"]
    f = [[1, 0, 0, 0, 1], [0, 1, 0, 1, 0], [0, 0, 1, 0, 0]]          # f0, f1, f2
    Tf = [[sum(T[u][v] * fi[v] for v in range(5)) for u in range(5)] for fi in f]
    # T f_j = sum_i M[i][j]... read off the coefficients on f0, f1, f2
    coef = [[Tf_j[0], Tf_j[1], Tf_j[2]] for Tf_j in Tf]
    Mcols = [[coef[j][i] for j in range(3)] for i in range(3)]
    R = rig_counts()["R"]
    v = [1, 1, 1]
    ok = True
    Mk = [[1 if i == j else 0 for j in range(3)] for i in range(3)]
    for k in range(2, 42):
        val_k = sum(w * s for w, s in zip([2, 2, 1], [sum(Mk[i][j] for j in range(3))
                                                      for i in range(3)]))
        ok &= val_k == R[k]
        Mk = mat_mul(Mk, M3)
    latex = "\\begin{smallmatrix}2&2&1\\\\2&2&0\\\\2&0&0\\end{smallmatrix}"
    return lit(e, latex, (Mcols == M3, "T f_j in the basis f_0, f_1, f_2 gives M"),
               (ok, "Rig_k = (2,2,1) M^(k-2) (1,1,1)^T for 2 <= k <= 41"))


@reg("s3-T-action")
def _(e):
    T = rig_counts()["T"]
    f0 = [1, 0, 0, 0, 1]
    Tf0 = [sum(T[u][v] * f0[v] for v in range(5)) for u in range(5)]
    return lit(e, "$\\mathbf{T}\\mathbf{f}_0=2\\mathbf{f}_0+2\\mathbf{f}_1+2\\mathbf{f}_2$",
               (Tf0 == [2, 2, 2, 2, 2], "T f_0 = (2,2,2,2,2) = 2 f_0 + 2 f_1 + 2 f_2"))


def det3(M) -> int:
    return (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1])
            - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
            + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))


@reg("s3-detM-inverse")
def _(e):
    half = [Fraction(1, 2), 0, 0]
    Mh = [sum(M3[i][j] * half[j] for j in range(3)) for i in range(3)]
    return val(e, f"$\\det\\mathbf{{M}}={det3(M3)}$ and $\\mathbf{{M}}^{{-1}}(1,1,1)^{{\\top}}="
                  f"(\\tfrac12,0,0)^{{\\top}}$") + [(Mh == [1, 1, 1], "M (1/2,0,0)^T = (1,1,1)^T")]


@reg("s3-charpoly")
def _(e):
    ok = True
    for t in range(-5, 8):
        tm = [[(t if i == j else 0) - M3[i][j] for j in range(3)] for i in range(3)]
        ok &= det3(tm) == t ** 3 - 4 * t ** 2 - 2 * t + 4
    return lit(e, "t^3-4t^2-2t+4", (ok, "det(tI - M) = t^3-4t^2-2t+4 at 13 points"))


@reg("s3-rig3-derivation")
def _(e):
    Mv = [sum(row) for row in M3]
    R = rig_counts()["R"]
    r3 = sum(w * s for w, s in zip((2, 2, 1), Mv))
    return val(e, f"(2,2,1)\\cdot{tup(Mv)}={r3}$ it gives ${R[4]}$, ${R[5]}$, ${R[6]}$")


@reg("s3-gf-numerator")
def _(e):
    R = rig_counts()["R"]
    num = [0, R[1], R[2] - 4 * R[1], R[3] - 4 * R[2] - 2 * R[1]]
    return lit(e, "t+t^2-2t^3", (num == [0, 1, 1, -2], f"numerator coefficients {num[1:]}"),
               (num == [0, 1, 1, -2] and [0, 1, 1, -2] == [0, 1, 1 - 2 * 1 + 2, -2],
                "t(1-t)(1+2t) = t + t^2 - 2t^3"))


@reg("s3-M2-positive")
def _(e):
    M2 = mat_mul(M3, M3)
    return lit(e, "$\\mathbf{M}^2$ is positive", (all(v > 0 for row in M2 for v in row),
                                                   f"M^2 = {M2} > 0 entrywise"))


@reg("s3-gamma22")
def _(e):
    g = gset(2, 2)
    ok = all((len(profiles(2, 2, u)) == 1) == (u in g) for u in range(5))
    return val(e, "\\{" + ",".join(map(str, sorted(g))) + "\\}") + [
        (ok, "|A(u)| = 1 iff u in gamma(2,2) (profiles of (2,2))")]


@reg("s3-five-nonrigid-cells")
def _(e):
    V = vals_of((2, 2, 2))
    bad = sorted(xy for xy, zs in V.items() if len(zs) > 1)
    byrule = sorted((u, v) for u in range(5) for v in range(5) if not rules(2, 2, 2, u, v))
    return val(e, dollars(tup(t) for t in bad)) + [(bad == byrule, "= the non-rigid cells by rule")]


@reg("s3-pervector-gamma23")
def _(e):
    g = gset(2, 3)
    ok = all((len(profiles(2, 3, u)) == 1) == (u in g) for u in range(7)) and \
        all((len(profiles(3, 2, u)) == 1) == (u in gset(3, 2)) for u in range(7))
    return val(e, "\\{" + ",".join(map(str, sorted(g))) + "\\}") + [
        (g == gset(3, 2), "gamma(2,3) = gamma(3,2)"), (ok, "unique profiles exactly on gamma")]


@reg(["s3-pervector-z0", "s3-pervector-z6"])
def _(e):
    V = vals_of((2, 3, 2))
    cell = (2, 1) if e["id"].endswith("z0") else (4, 5)
    (z,) = V[cell]
    rs = rules(2, 3, 2, *cell)
    want_rule = "N" if cell == (2, 1) else "Ch"
    g = gset(2, 3)
    return val(e, f"$z={z}$") + [(rs == [want_rule], f"(2,3,2) at {cell}: only {want_rule} holds"),
                                 (cell[0] not in g or cell[1] not in g, "gamma fails there")]


@reg("s3-Y26a-layer-values")
def _(e):
    bad, n = [], 0
    for (a, b, c) in SMALL_TERNARY:
        if a < 2 or c < 2:
            continue
        for (x, y), zs in vals_of((a, b, c)).items():
            xp, yp = a * b - x, b * c - y
            if xp + yp == b + 1 and xp >= 2 and yp >= 2:
                lam = c * x + a * y - a * b * c
                n += 1
                if set(zs) != {lam, lam + 1}:
                    bad.append((a, b, c, x, y))
    return lit(e, "$\\lambda$ and $\\lambda+1$", (bad == [] and n > 0,
                                                 f"first exterior layer: exactly lambda, lambda+1 "
                                                 f"on {n} cells of the small contents"))


@reg("s3-TR536-two-values")
def _(e):
    ok = True
    for i in range(2, 6):
        zs = tern_vals(i, i, i)[(i * i - i, i)]
        ok &= len(zs) >= 2
    return lit(e, "at least two values", (ok, "(i,i,i) at (i^2-i, i), 2 <= i <= 5"))


@reg(["s3-lem32-example-321", "s3-lem32-example-432"])
def _(e):
    w = [4, 3, 2, 3, 1, 2]
    n = [w.count(i) for i in range(1, 5)]
    G, Y = n[1], n[3]                       # |w|_{2..2} and |w|_{4..4}
    minor = occ(w, (2, 3, 4)) - Y * occ(w, (2, 3)) - G * occ(w, (3, 4)) + n[2] * G * Y
    if e["id"].endswith("321"):
        return val(e, f"\\cnt{{321}}={occ(w, (3, 2, 1))}")
    return val(e, f"\\cnt{{432}}={occ(w, (4, 3, 2))}") + [
        (minor == occ(w, (4, 3, 2)), f"the minor D(432312; 2,3,4) = {minor} = |w|_432")]


def bal_con(a: int, b: int, c: int, x: int, y: int) -> tuple:
    """A^bal, C^bal, A^con, C^con by the bracket forms of Section 4 (checked against the floor
    and min/max forms)."""
    qx, r = divmod(x, b)
    qy, s = divmod(y, b)
    Q, R = divmod(x, a)
    T, S = divmod(y, c)
    Ab = tuple(qx + (t > b - r) for t in range(1, b + 1))
    Cb = tuple(qy + (t <= s) for t in range(1, b + 1))
    Ac = tuple(a * (t > b - Q) + R * (t == b - Q) for t in range(1, b + 1))
    Cc = tuple(c * (t <= T) + S * (t == T + 1) for t in range(1, b + 1))
    assert Ab == tuple((x + t - 1) // b for t in range(1, b + 1))
    assert Cb == tuple((y + b - t) // b for t in range(1, b + 1))
    assert Ac == tuple(min(a, max(0, x - a * (b - t))) for t in range(1, b + 1))
    assert Cc == tuple(min(c, max(0, y - c * (t - 1))) for t in range(1, b + 1))
    return Ab, Cb, Ac, Cc


def dot(A, C) -> int:
    return sum(p * q for p, q in zip(A, C))


def thmB_zmax(a, b, c, x, y) -> int:
    qx, r = divmod(x, b)
    qy, s = divmod(y, b)
    return b * qx * qy + qx * s + qy * r + max(0, r + s - b)


def thmB_zmin(a, b, c, x, y) -> int:
    Q, R = divmod(x, a)
    T, S = divmod(y, c)
    if Q + T >= b:
        return a * c * (Q + T - b) + a * S + c * R
    return R * S if Q + T == b - 1 else 0


def is_T2(a, b, c, x, y) -> bool:
    return x % b == 0 and y % b == 0 and 1 <= x // b <= a - 1 and 1 <= y // b <= c - 1


def is_T5(a, b, c, x, y) -> bool:
    return 2 <= x <= b - 1 and y == b * c - x


def is_T5R(a, b, c, x, y) -> bool:
    return 2 <= y <= b - 1 and x == a * b - y


@lru_cache(maxsize=None)
def range_scan() -> dict:
    """Theorems B and C, Corollaries 4.4-4.6 and 4.11 on every small ternary content."""
    bad: dict = defaultdict(list)
    gaps: Counter = Counter()
    ncell = 0
    for (a, b, c) in SMALL_TERNARY:
        V = vals_of((a, b, c))
        ngap = 0
        for (x, y), zs in V.items():
            ncell += 1
            zmax, zmin = max(zs), min(zs)
            qx, r = divmod(x, b)
            qy, s = divmod(y, b)
            Q, R = divmod(x, a)
            T, S = divmod(y, c)
            lam = c * x + a * y - a * b * c
            Ab, Cb, Ac, Cc = bal_con(a, b, c, x, y)
            if zmax != thmB_zmax(a, b, c, x, y) or zmax != dot(Ab, Cb):
                bad["zmax"].append((a, b, c, x, y))
            if x * y - b * zmax != min(r * s, (b - r) * (b - s)):
                bad["minDelta"].append((a, b, c, x, y))
            if zmin != thmB_zmin(a, b, c, x, y) or zmin != dot(Ac, Cc):
                bad["zmin"].append((a, b, c, x, y))
            if zmin - lam != max(0, -lam) + (Q + T == b - 1) * min(R * S, (a - R) * (c - S)):
                bad["min321"].append((a, b, c, x, y))
            if x * y // b - zmax != min(r * s, (b - r) * (b - s)) // b or \
                    x * y // b - zmax > b // 4:
                bad["defect"].append((a, b, c, x, y))
            if ((x * y) % b == 0 and zmax * b == x * y) != (x % b == 0 or y % b == 0):
                bad["cauchy"].append((a, b, c, x, y))
            if (zmin == lam) != (Q + T >= b):
                bad["lower"].append((a, b, c, x, y))
            if b >= 2 and len(zs) >= 2:
                top_gap = zmax - max(z for z in zs if z != zmax)
                gaps[top_gap] += 1
                miss = zmax - 1 not in zs
                exc = is_T2(a, b, c, x, y) or is_T5(a, b, c, x, y) or is_T5R(a, b, c, x, y)
                if miss != exc or (miss and zmax - 2 not in zs):
                    bad["thmC"].append((a, b, c, x, y))
                ngap += miss
            if b >= 2 and len(zs) == 1 and not rules(a, b, c, x, y):
                bad["rigid"].append((a, b, c, x, y))
        if b >= 2:
            want = (a - 1) * (c - 1) + 2 * max(0, b - 2) if min(a, c) >= 2 else 0
            if ngap != want:
                bad["count"].append((a, b, c, ngap, want))
        if b >= 2 and min(a, c) >= 2:
            fl = (b // 2, -(-b // 2))
            if fl in V and x_y_ok(a, b, c, V, fl) is False:
                bad["defect_eq"].append((a, b, c))
    return {"bad": dict(bad), "gaps": gaps, "ncell": ncell}


def x_y_ok(a, b, c, V, xy) -> bool:
    x, y = xy
    zmax = max(V[xy])
    return zmax == 0 and x * y // b - zmax == b // 4


def rs_ok(key: str) -> tuple:
    s = range_scan()
    return (key not in s["bad"], f"{key} on {s['ncell']} cells of {len(SMALL_TERNARY)} contents"
                                 f"{'' if key not in s['bad'] else ': ' + str(s['bad'][key][:3])}")


@reg(["abs-cauchy-remainder", "s1-B-min-Delta"])
def _(e):
    latex = ("\\min(rs,(b-r)(b-s))" if e["id"] == "abs-cauchy-remainder"
             else "\\min\\bigl(rs,(b-r)(b-s)\\bigr)")
    return lit(e, latex, rs_ok("minDelta"), rs_ok("zmax"))


@reg("s1-B-min-321")
def _(e):
    return lit(e, "\\max(0,-\\lambda)+\\iver{Q+T=b-1}\\cdot\\min\\bigl(RS,(a-R)(c-S)\\bigr)",
               rs_ok("min321"), rs_ok("zmin"), rs_ok("lower"))


@reg("s1-B-defect-bound")
def _(e):
    return lit(e, "\\floor{b/4}", rs_ok("defect"), rs_ok("defect_eq"))


@reg(["abs-gap-two", "s1-C-gap-two"])
def _(e):
    g = range_scan()["gaps"]
    return val(e, WORDS_NUM[max(g)]) + [(set(g) == {1, 2}, f"top gaps observed: {dict(g)}"),
                                        rs_ok("thmC")]


@reg("s1-C-second-value")
def _(e):
    return lit(e, "$\\zmax-2\\in\\vals{x,y}$", rs_ok("thmC"), rs_ok("count"), rs_ok("rigid"))


@lru_cache(maxsize=None)
def alpha5() -> dict:
    w = []
    for j in range(6):
        w += [1] * 2 ** (5 - j) + [2] + [3] * 2 ** j
    a, b, c = w.count(1), w.count(2), w.count(3)
    x, y = occ(w, (1, 2)), occ(w, (2, 3))
    Ab, Cb, Ac, Cc = bal_con(a, b, c, x, y)
    As = profiles(a, b, x)
    Cs = profiles(c, b, y, increasing=False)
    dbal = x * y - b * dot(Ab, Cb)
    As_s = [A for A in As if A[-1] - A[0] <= dbal]
    Cs_s = [C for C in Cs if C[0] - C[-1] <= dbal]
    mind = min(x * y - b * dot(A, C) for A in As_s for C in Cs_s)
    cov_ok = all(x * y - b * dot(A, C) == sum((A[j] - A[i]) * (C[i] - C[j]) for i in range(b)
                                              for j in range(i + 1, b))
                 for A in As_s[::7] for C in Cs_s[::7])
    lam = c * x + a * y - a * b * c
    witness: dict = {}
    for C in [Cb, Cc] + Cs[::499]:
        for A in As:
            witness.setdefault(dot(A, C), (A, C))
    for A in As_s:
        for C in Cs_s:
            witness.setdefault(dot(A, C), (A, C))
    zmax = (x * y - mind) // b
    covered = [z for z in range(lam, zmax + 1) if z not in witness]
    outside = [z for z in witness if not lam <= z <= zmax]
    words_ok = True
    for z, (A, C) in sorted(witness.items()):
        wd = word_from_pair(A, C, a, c)
        words_ok &= (wd.count(1), wd.count(2), wd.count(3), occ(wd, (1, 2)), occ(wd, (2, 3)),
                     occ(wd, (1, 2, 3))) == (a, b, c, x, y, z)
    return {"abc": (a, b, c), "xy": (x, y), "Ab": Ab, "Cb": Cb, "Ac": Ac, "Cc": Cc,
            "dbal": dbal, "mind": mind, "zmax": zmax, "zmin": dot(Ac, Cc), "lam": lam,
            "floor": x * y // b, "QT": (x // a, y // c), "rs": (x % b, y % b),
            "covered": covered, "outside": outside, "words_ok": words_ok, "cov_ok": cov_ok}


def word_from_pair(A, C, a: int, c: int) -> list:
    """The word whose gap g holds alpha_g ones then gamma_g threes."""
    b = len(A)
    al = [A[0]] + [A[g] - A[g - 1] for g in range(1, b)] + [a - A[-1]]
    ga = [c - C[0]] + [C[g - 1] - C[g] for g in range(1, b)] + [C[-1]]
    w: list = []
    for g in range(b + 1):
        w += [1] * al[g] + [3] * ga[g]
        if g < b:
            w.append(2)
    return w


@reg(["fig3-title-zmax", "fig3-zmax", "s4-ex46-zmax"])
def _(e):
    d = alpha5()
    return val(e, str(d["zmax"])) + [(d["mind"] == d["dbal"] == 9 and d["cov_ok"],
                                      "minimum defect 9 over the pruned family (covariance bound)"),
                                     (d["zmax"] == dot(d["Ab"], d["Cb"]), "z_max = A^bal.C^bal")]


@reg(["fig3-title-zmin", "fig3-zmin", "s4-ex46-zmin", "s4-ex46-printedL"])
def _(e):
    d = alpha5()
    return val(e, str(d["zmin"])) + [(d["zmin"] == d["lam"], "z_min = lambda = cx + ay - abc")]


@reg(["fig3-Abal", "fig3-Acon", "fig3-Cbal", "fig3-Ccon"])
def _(e):
    d = alpha5()
    key = {"fig3-Abal": "Ab", "fig3-Acon": "Ac", "fig3-Cbal": "Cb", "fig3-Ccon": "Cc"}[e["id"]]
    return val(e, tup(d[key]))


@reg("fig3-ac")
def _(e):
    a, b, c = alpha5()["abc"]
    return val(e, f"$a=c={a}$") + [(a == c, "a = c")]


@reg("fig3-cell")
def _(e):
    d = alpha5()
    return val(e, f"$(x,y)={tup(d['xy'])}$ of content $(a,b,c)={tup(d['abc'])}$")


@reg(["fig3-floor", "s4-ex46-printedfloor"])
def _(e):
    d = alpha5()
    return val(e, str(d["floor"])) + [(d["floor"] > d["zmax"], "floor(xy/b) is not attained")]


@reg("s4-ex46-content")
def _(e):
    return val(e, tup(alpha5()["abc"]))


@reg("s4-ex46-pairs")
def _(e):
    return val(e, tup(alpha5()["xy"]))


@reg("s4-ex46-QT")
def _(e):
    Q, T = alpha5()["QT"]
    b = alpha5()["abc"][1]
    return val(e, str(Q)) + [(Q == T and Q + T >= b, "Q = T and Q + T >= b")]


@reg("s4-ex46-rs")
def _(e):
    r, s = alpha5()["rs"]
    return val(e, str(r)) + [(r == s and r > 0, "r = s, b divides neither x nor y")]


@reg("s4-ex46-defect")
def _(e):
    d = alpha5()
    r, s = d["rs"]
    b = d["abc"][1]
    return val(e, str(d["mind"])) + [(d["mind"] == min(r * s, (b - r) * (b - s)),
                                      "least Delta = min(rs, (b-r)(b-s))")]


@reg("s4-ex46-zmax-floor")
def _(e):
    d = alpha5()
    b = d["abc"][1]
    return val(e, f"{d['floor']}-\\floor{{{d['mind']}/{b}}}") + [
        (d["floor"] - d["mind"] // b == d["zmax"], "17173 - floor(9/6) = z_max")]


@reg("s4-ex46-interval")
def _(e):
    d = alpha5()
    return val(e, f"${d['lam']}$ to ${d['zmax']}$") + [
        (d["covered"] == [] and d["outside"] == [], "a witness pair for every value, none "
                                                    "outside"),
        (d["words_ok"], "every witness word recounted letter by letter")]


def gap_weight(A, C, a: int, c: int, interior: bool = False) -> int:
    """W(A, C) = prod_g C(alpha_g + gamma_g, alpha_g); with interior=True only gaps 1..b-1."""
    b = len(A)
    al = [A[0]] + [A[g] - A[g - 1] for g in range(1, b)] + [a - A[-1]]
    ga = [c - C[0]] + [C[g - 1] - C[g] for g in range(1, b)] + [C[-1]]
    gs = range(1, b) if interior else range(b + 1)
    return prod(comb(al[g] + ga[g], al[g]) for g in gs)


@reg(["s4-holes-222-values", "s4-holes-222-words"])
def _(e):
    cl = tern_lit(2, 2, 2)
    f = {z: m for (x, y, z), m in cl.items() if (x, y) == (2, 2)}
    if e["id"].endswith("values"):
        return val(e, " and ".join(f"${z}$" for z in sorted(f)))
    (m,) = set(f.values())
    return val(e, str(m))


@lru_cache(maxsize=None)
def ex353() -> dict:
    V = vals_of((3, 5, 3))
    return {"76": sorted(V[(7, 6)]), "77": sorted(V[(7, 7)])}


@reg("s4-holes-353-76")
def _(e):
    v = ex353()["76"]
    return val(e, f"${v[0]}$ to ${v[-1]}$") + [(v == list(range(v[0], v[-1] + 1)), "no hole")]


@reg(["s4-holes-353-content", "s4-holes-353-cell76", "s4-holes-353-cell77"])
def _(e):
    want = {"content": "(3,5,3)", "cell76": "(7,6)", "cell77": "(7,7)"}[e["id"].split("-")[-1]]
    return val(e, want) + [(len(ex353()["76"]) == 9 and len(ex353()["77"]) == 8,
                            "the two fibres of MSY04 p. 20 computed")]


@reg("s4-holes-353-77")
def _(e):
    return val(e, ",".join(map(str, ex353()["77"])))


@reg("s4-holes-353-minors")
def _(e):
    a, b, c, x, y = 3, 5, 3, 7, 7
    lam = c * x + a * y - a * b * c
    return val(e, f"{max(0, lam)}\\le z\\le{x * y // b}")


@reg("s4-holes-353-hole")
def _(e):
    v = ex353()["77"]
    holes = [z for z in range(v[0], v[-1] + 1) if z not in v]
    return val(e, ",".join(map(str, holes)))


@reg("s4-holes-353-rs")
def _(e):
    r, s = 7 % 5, 7 % 5
    return val(e, str(r)) + [(r == s, "r = s")]


@reg("s4-holes-353-zmax")
def _(e):
    v = ex353()["77"]
    return val(e, str(v[-1])) + [(v[-1] == thmB_zmax(3, 5, 3, 7, 7), "Theorem B(i)")]


@reg("s4-holes-353-zmin")
def _(e):
    v = ex353()["77"]
    Q, R = divmod(7, 3)
    T, S = divmod(7, 3)
    return val(e, str(v[0])) + [(v[0] == R * S and Q + T == 5 - 1, "z_min = RS, Q + T = b - 1")]


@reg("s4-tr536-i2")
def _(e):
    V = tern_vals(2, 2, 2)[(2, 2)]
    return val(e, "$i=2$") + [(sorted(V) == [0, 2], "(2,2,2) at (2,2): values 0 and 2")]


@lru_cache(maxsize=None)
def tr536_i4() -> list:
    return sorted(tern_vals(4, 4, 4)[(12, 4)])


@reg("s4-tr536-i4-list")
def _(e):
    v = tr536_i4()
    return val(e, ",".join(map(str, v))) + [(is_T2(4, 4, 4, 12, 4), "(12,4) is a T2 cell of "
                                                                     "(4,4,4)")]


@reg("s4-tr536-i4-missing")
def _(e):
    v = tr536_i4()
    return val(e, str(v[-1] - 1)) + [(v[-1] - 1 not in v, "z_max - 1 is missing")]


@reg("s4-tr536-i4-present")
def _(e):
    v = tr536_i4()
    return val(e, str(v[-1] - 2)) + [(v[-1] - 2 in v, "z_max - 2 occurs")]


def eta(n: int) -> int:
    return 6 if n == 2 else 2 * (n // 2) + 2


@lru_cache(maxsize=None)
def second_layer() -> dict:
    """Proposition 4.11: rho(x, y, z_max - 2) and the interior weights of its pairs, by
    enumeration of profile pairs (weights) and by TDP (class sizes)."""
    out = {"T2w": {}, "T5w": {}, "bad": []}
    for b in range(2, 8):
        a = c = 3
        x = y = b                                    # qx = qy = 1
        As, Cs = profiles(a, b, x), profiles(c, b, y, increasing=False)
        zmax = max(dot(A, C) for A in As for C in Cs)
        ws = sorted((gap_weight(A, C, a, c, interior=True) for A in As for C in Cs
                     if dot(A, C) == zmax - 2), reverse=True)
        out["T2w"][b] = ws
    for b in range(3, 8):
        a, c = 3, 3
        for x in range(2, b):
            y = b * c - x
            As, Cs = profiles(a, b, x), profiles(c, b, y, increasing=False)
            zmax = max(dot(A, C) for A in As for C in Cs)
            ws = sorted((gap_weight(A, C, a, c, interior=True) for A in As for C in Cs
                         if dot(A, C) == zmax - 2), reverse=True)
            out["T5w"][(b, x)] = ws
    for (a, b, c) in SMALL_TERNARY:
        if b < 2 or a + b + c > 11:
            continue
        cl = tern_tdp(a, b, c)
        by: dict = defaultdict(dict)
        for (x, y, z), m in cl.items():
            by[(x, y)][z] = m
        for (x, y), d in by.items():
            zmax = max(d)
            if is_T2(a, b, c, x, y):
                qx, qy = x // b, y // b
                want = eta(b) * comb(qx + c - qy - 2, qx - 1) * comb(a - qx + qy - 2, a - qx - 1)
                if zmax != b * qx * qy or zmax - 1 in d or d.get(zmax - 2) != want:
                    out["bad"].append(("T2", a, b, c, x, y))
            if min(a, c) >= 2 and b >= 3 and is_T5(a, b, c, x, y):
                if zmax != (c - 1) * x or d.get(zmax - 2) != eta(x) * comb(a + c - 4, a - 2):
                    out["bad"].append(("T5", a, b, c, x, y))
            if min(a, c) >= 2 and b >= 3 and is_T5R(a, b, c, x, y):
                if zmax != (a - 1) * y or d.get(zmax - 2) != eta(y) * comb(a + c - 4, a - 2):
                    out["bad"].append(("T5R", a, b, c, x, y))
    return out


@reg("s4-eta2")
def _(e):
    d = second_layer()
    return val(e, str(sum(d["T2w"][2]))) + [(d["bad"] == [], "Proposition 4.11 rho(z_max - 2) "
                                                               "on every T2/T5/T5^R cell")]


@reg("s4-T3-weight-b2")
def _(e):
    return val(e, str(second_layer()["T2w"][2][0])) + [(len(second_layer()["T2w"][2]) == 1,
                                                        "b = 2: one pair")]


@reg("s4-T3-weight-4")
def _(e):
    w = second_layer()["T2w"]
    return val(e, str(w[3][0])) + [(all(w[b][0] == 4 and w[b].count(4) == 1 for b in range(3, 8)),
                                    "b >= 3: the pair (q+L1, q'-L1) has weight 4")]


@reg("s4-T3-weight-1")
def _(e):
    w = second_layer()["T2w"]
    return val(e, "1") + [(all(set(w[b][1:]) <= {1} and len(w[b]) == 2 * (b // 2) - 1
                               for b in range(3, 8)), "the other 2 floor(b/2) - 2 pairs weigh 1")]


@reg("s4-T5-weights")
def _(e):
    w = second_layer()["T5w"]
    first = {x: [ws[0] for (b, xx), ws in w.items() if xx == x] for x in range(2, 7)}
    return val(e, f"${first[2][0]}$ if $x=2$ and ${first[3][0]}$ if $x\\ge3$") + [
        (set(first[2]) == {6} and all(set(first[x]) == {4} for x in range(3, 7)),
         "the pair (Ups1, c-Ups1) weighs 6 at x = 2 and 4 for x >= 3")]


@reg("s4-T5-weight-1")
def _(e):
    w = second_layer()["T5w"]
    return val(e, "1") + [(all(set(ws[1:]) <= {1} for ws in w.values()),
                           "the other pairs at z_max - 2 weigh 1")]


@reg(["s4-thmC-565", "s4-cor412-565"])
def _(e):
    return val(e, "(5,6,5)") + [(len(fig4_sets()["gap"]) == 24, "24 top-gap cells")]


@lru_cache(maxsize=None)
def fig4_sets() -> dict:
    a, b, c = 5, 6, 5
    V = vals_of((a, b, c))
    gap = {xy for xy, zs in V.items() if len(zs) >= 2 and max(zs) - 1 not in zs}
    rule = {xy for xy in V if is_T2(a, b, c, *xy) or is_T5(a, b, c, *xy) or is_T5R(a, b, c, *xy)}
    t2 = {xy for xy in gap if is_T2(a, b, c, *xy)}
    t5 = gap - t2
    single = {xy for xy, zs in V.items() if len(zs) == 1}
    two = all(max(V[xy]) - 2 in V[xy] for xy in gap)
    return {"V": V, "gap": gap, "rule": rule, "t2": t2, "t5": t5, "single": single, "two": two}


@reg(["s4-cor412-24", "fig4-total"])
def _(e):
    d = fig4_sets()
    return val(e, str(len(d["gap"]))) + [(d["gap"] == d["rule"], "gap cells = T2 u T5 u T5^R"),
                                         (d["two"], "z_max - 2 occurs at each"),
                                         (len(d["gap"]) == 4 * 4 + 2 * 4, "(a-1)(c-1) + 2(b-2)")]


@reg("fig4-t2")
def _(e):
    return val(e, str(len(fig4_sets()["t2"])))


@reg("fig4-t5")
def _(e):
    return val(e, str(len(fig4_sets()["t5"])))


@reg("s4-rem413-one")
def _(e):
    bad, n = [], 0
    for (a, b, c) in SMALL_TERNARY:
        if min(a, c) < 2:
            continue
        for (x, y), zs in vals_of((a, b, c)).items():
            xp, yp = a * b - x, b * c - y
            if xp >= 2 and yp >= 2 and xp + yp == b + 1:
                n += 1
                lam = c * x + a * y - a * b * c
                if max(zs) - lam != xp + yp - b:
                    bad.append((a, b, c, x, y))
    return val(e, "1") + [(bad == [] and n > 0, f"z_max - lambda = 1 on {n} layer cells")]


@lru_cache(maxsize=None)
def y26a_table1() -> dict:
    cl = tern_lit(2, 3, 2)
    return {z: m for (x, y, z), m in cl.items() if (x, y) == (4, 4)}


@reg(["s4-y26a-tab1-cell", "s4-y26a-tab1-content"])
def _(e):
    want = "(4,4)" if e["id"].endswith("cell") else "(2,3,2)"
    return val(e, want) + [(sorted(y26a_table1()) == [4, 5], "the fibre has the values 4, 5")]


@reg(["s4-y26a-tab1-z4", "s4-y26a-tab1-z5"])
def _(e):
    d = y26a_table1()
    z = int(e["id"][-1])
    noun = "word" if d[z] == 1 else "words"
    return val(e, f"$z={z}$ on ${d[z]}$ {noun}")


@lru_cache(maxsize=None)
def t4_data() -> dict:
    """(2,b,2) at (b,b): the profiles 1+L_m, 1-L_n of the proof of Proposition 4.13 (with the
    gap weights of their pairs), and the multiplicities of the fibre by the level model, which
    rem:exterior (rho(b,b,0) = 6 for even b) and lem:thin (rho(b,b,b) = b+4 for even b) quote;
    Proposition 4.13 itself states only the values."""
    out = {"W": {}, "bad": [], "b6": None}
    for b in range(1, 13):
        h = b // 2
        As, Cs = profiles(2, b, b), profiles(2, b, b, increasing=False)
        Lam = lambda m: tuple([-1] * m + [0] * (b - 2 * m) + [1] * m)
        idxA = {tuple(1 + v for v in Lam(m)): m for m in range(h + 1)}
        idxC = {tuple(1 - v for v in Lam(n)): n for n in range(h + 1)}
        if set(As) != set(idxA) or set(Cs) != set(idxC):
            out["bad"].append(("profiles", b))
            continue
        for A in As:
            for C in Cs:
                out["W"][(b, idxA[A], idxC[C])] = gap_weight(A, C, 2, 2)
        cl = classes_2b2(b)
        d = {z: m for (x, y, z), m in cl.items() if (x, y) == (b, b)}
        want = {b: 2 * h + 4}
        for r in range(1, h + 1):
            want[b - 2 * r] = 2 * (h - r) + 4 + 2 * (b == 2 * r)
        if d != want or sum(d.values()) != ((h + 2) * (h + 3) if b % 2 == 0 else
                                           (h + 1) * (h + 4)):
            out["bad"].append(("rho", b))
        if b == 6:
            out["b6"] = d
    return out


@reg("s4-T4-b6-values")
def _(e):
    d = t4_data()["b6"]
    vals_ok = all(set(z for (x, y, z) in classes_2b2(b) if (x, y) == (b, b)) ==
                  {b - 2 * j for j in range(b // 2 + 1)} for b in range(1, 13))
    return val(e, ",".join(map(str, sorted(d, reverse=True)))) + [
        (vals_ok, "Proposition 4.13: the values b - 2j at (b,b), 1 <= b <= 12"),
        (t4_data()["bad"] == [], "the (b,b) fibre of (2,b,2), 1 <= b <= 12: the profiles of the "
                                 "proof and the multiplicities used in rem:exterior and lem:thin")]


@reg("s4-T4-b6-missing")
def _(e):
    d = t4_data()["b6"]
    miss = [z for z in range(max(d), -1, -1) if z not in d]
    return val(e, ",".join(map(str, miss)))


# ---------------------------------------------------------------------------------------------
# (b.2) Section 5: the antidiagonal (Theorem D, Proposition 5.5, Question 5.6)
# ---------------------------------------------------------------------------------------------

DIII_B = 40


def n_lev(b: int, v: int) -> int:
    return v // 2 - max(0, v - b) + 1


@lru_cache(maxsize=None)
def thmD_2b2() -> dict:
    """Theorem D(iii) for (2,b,2), 1 <= b <= DIII_B, against PSI on every cell."""
    bad: dict = defaultdict(list)
    for b in range(1, DIII_B + 1):
        P = psi_table(2, b, 2)
        h = b // 2
        for x in range(2 * b + 1):
            for y in range(2 * b + 1):
                yp = 2 * b - y
                if x + y == 2 * b:
                    N = n_lev(b, x)
                    want = N * N + 3 * N + 2 * (x % 2 == 0)
                    if P[x][y] != want:
                        bad["diag"].append((b, x, y))
                else:
                    lo, hi = max(0, x - b, yp - b), min(b, x, yp)
                    H = range(lo, hi + 1)
                    want = (n_lev(b, x) * n_lev(b, yp) + len(H) +
                            (x % 2 == 0 and lo <= x // 2 <= hi) +
                            (yp % 2 == 0 and lo <= yp // 2 <= hi))
                    if P[x][y] != want:
                        bad["off"].append((b, x, y))
        mx = max(max(row) for row in P)
        at = sorted((x, y) for x in range(2 * b + 1) for y in range(2 * b + 1) if P[x][y] == mx)
        if mx != (h + 2) * (h + 3):
            bad["max"].append(b)
        if (b % 2 == 0 and at != [(b, b)]) or (b % 2 == 1 and at != [(b - 1, b + 1),
                                                                     (b + 1, b - 1)]):
            bad["at"].append(b)
        if b % 2 == 1 and P[b][b] != (h + 1) * (h + 4):
            bad["centre"].append(b)
        D = [P[x][2 * b - x] for x in range(2 * b + 1)]
        if any(D[2 * i] - D[2 * i + 1] != 2 for i in range(b) if 2 * i + 1 < b):
            bad["steps"].append(b)
    return dict(bad)


def dok(key: str) -> tuple:
    bad = thmD_2b2()
    return (key not in bad, f"Theorem D(iii) [{key}] for 1 <= b <= {DIII_B} against PSI"
                            f"{'' if key not in bad else ': ' + str(bad[key][:3])}")


@lru_cache(maxsize=None)
def thmD_ii() -> list:
    """Theorem D(ii): P(x,y)^2 <= P(x,ab-x) P(ab-y,y), equality iff x + y = ab, (a,b,a)."""
    bad = []
    for a in range(1, 6):
        for b in range(1, 7):
            P = psi_table(a, b, a)
            X = a * b
            for x in range(X + 1):
                for y in range(X + 1):
                    lhs, rhs = P[x][y] ** 2, P[x][X - x] * P[X - y][y]
                    if lhs > rhs or ((lhs == rhs) != (x + y == X)):
                        bad.append((a, b, x, y))
    return bad


@reg(["s1-D-max", "s1-tab-D", "s5-Diii-max"])
def _(e):
    return lit(e, "(h+2)(h+3)", dok("max"), (thmD_ii() == [], "Theorem D(ii) on (a,b,a), "
                                                               "a <= 5, b <= 6"))


@reg("s1-D-maximisers")
def _(e):
    return lit(e, "$(b,b)$ alone if $b$ is even, and exactly $(b-1,b+1)$ and $(b+1,b-1)$",
               dok("at"))


@reg("s5-Diii-formula-diag")
def _(e):
    return lit(e, "N(x)^2+3N(x)+2\\,\\iver{x\\text{ even}}", dok("diag"))


@reg("s5-Diii-formula-off")
def _(e):
    return lit(e, "N(x)\\,N(y')+\\abs{I_{x,y}}+\\iver{x\\text{ even},\\ x/2\\in I_{x,y}}+"
                  "\\iver{y'\\text{ even},\\ y'/2\\in I_{x,y}}", dok("off"))


@reg("s5-Diii-centre-odd")
def _(e):
    return lit(e, "(h+1)(h+4)", dok("centre"))


@reg("s5-Diii-steps")
def _(e):
    return lit(e, "D(2i)-D(2i+1)=2", dok("steps"))


@lru_cache(maxsize=None)
def a1a_data() -> dict:
    bad: dict = defaultdict(list)
    for a in range(1, 15):
        P = psi_table(a, 1, a)
        D = [P[x][a - x] for x in range(a + 1)]
        if D != [comb(2 * x, x) * comb(2 * a - 2 * x, a - x) for x in range(a + 1)]:
            bad["D"].append(a)
        if a >= 2 and Fraction(D[1], D[0]) != Fraction(a, 2 * a - 1):
            bad["ratio"].append(a)
        mx = max(max(r) for r in P)
        at = sorted((x, y) for x in range(a + 1) for y in range(a + 1) if P[x][y] == mx)
        if a >= 2 and (at != [(0, a), (a, 0)] or mx != comb(2 * a, a)):
            bad["max"].append(a)
    for b in range(1, 29):
        P = psi_table(1, b, 1)
        D = [P[x][b - x] for x in range(b + 1)]
        mx = max(max(r) for r in P)
        if set(D) != {2} or mx != 2:
            bad["1b1"].append(b)
    return dict(bad)


@reg("s5-a1a-D")
def _(e):
    b = a1a_data()
    return lit(e, "D(x)=\\binom{2x}{x}\\binom{2a-2x}{a-x}", ("D" not in b, "(a,1,a), a <= 14"))


@reg("s5-a1a-ratio")
def _(e):
    return lit(e, "D(1)/D(0)=a/(2a-1)", ("ratio" not in a1a_data(), "(a,1,a), 2 <= a <= 14"))


@reg("s5-a1a-max")
def _(e):
    return lit(e, "\\binom{2a}{a}", ("max" not in a1a_data(),
                                     "(a,1,a): exactly (0,a), (a,0) are largest, C(2a,a) words"))


@reg(["s5-1b1-tie", "s8-1b1-max"])
def _(e):
    latex = "D(x)=2" if e["id"] == "s5-1b1-tie" else "\\tau=2"
    return lit(e, latex, ("1b1" not in a1a_data(), "(1,b,1), b <= 28: D = 2 everywhere on the "
                                                   "antidiagonal, and the maximum is 2"))


@lru_cache(maxsize=None)
def dprime(abc: tuple) -> dict:
    a, b, c = abc
    P = psi_table(a, b, c)
    vals_ = sorted({v for row in P for v in row}, reverse=True)
    mx = vals_[0]
    at = sorted((x, y) for x in range(len(P)) for y in range(len(P[0])) if P[x][y] == mx)
    cx, cy = a * b // 2, b * c // 2
    return {"P": P, "max": mx, "at": at, "centre": P[cx][cy], "second": vals_[1],
            "total": sum(map(sum, P)) == multinomial(abc)}


@reg(["fig5-767-centre", "s1-Dprime-767-centre", "s5-Dprime-767-centre"])
def _(e):
    d = dprime((7, 6, 7))
    return val(e, str(d["centre"])) + [(d["total"], "PSI total = multinomial")]


@reg(["s1-Dprime-767-max", "s5-Dprime-767-max"])
def _(e):
    return val(e, str(dprime((7, 6, 7))["max"]))


@reg("fig5-767-max")
def _(e):
    d = dprime((7, 6, 7))
    xs = [x for x, y in d["at"]]
    return val(e, f"${d['max']}$ words at $x={xs[0]}$ and $x={xs[1]}$")


@reg(["s1-Dprime-767-points", "s5-Dprime-767-argmax"])
def _(e):
    return val(e, " and ".join(f"${tup(t)}$" for t in dprime((7, 6, 7))["at"]))


@reg("s5-Dprime-5105-argmax")
def _(e):
    return val(e, " and ".join(f"${tup(t)}$" for t in dprime((5, 10, 5))["at"]))


@reg("s5-Dprime-5105-centre")
def _(e):
    return val(e, str(dprime((5, 10, 5))["centre"]))


@reg("s5-Dprime-5105-max")
def _(e):
    return val(e, str(dprime((5, 10, 5))["max"]))


@reg("s5-Dprime-second")
def _(e):
    ok = all(dprime(t)["second"] == dprime(t)["centre"] for t in ((7, 6, 7), (5, 10, 5)))
    return lit(e, "second-largest", (ok, "the centre has the second-largest value of P in "
                                         "(7,6,7) and (5,10,5)"))


@reg("s6-Dprime-contents")
def _(e):
    lose = [t for t in ((7, 6, 7), (5, 10, 5)) if dprime(t)["max"] > dprime(t)["centre"]]
    return val(e, " and ".join(f"${tup(t)}$" for t in lose))


@lru_cache(maxsize=None)
def dprime_scan() -> dict:
    """Proposition 5.5: every content with b even, (a,c) != (1,1), a+b+c <= 20, both orders."""
    conts = [(a, b, c) for tot in range(4, 21) for b in range(2, tot, 2) for a in range(1, tot - b)
             for c in [tot - a - b] if c >= 1 and (a, c) != (1, 1)]
    fails = []
    for t in conts:
        d = dprime(t)
        a, b, c = t
        if d["at"] != [(a * b // 2, b * c // 2)]:
            fails.append(t)
    return {"n19": sum(1 for t in conts if sum(t) <= 19), "n20": len(conts), "fails": fails}


@reg(["s1-Dprime-range", "s5-Dprime-range19"])
def _(e):
    d = dprime_scan()
    return lit(e, "a+b+c\\le19", (not [t for t in d["fails"] if sum(t) <= 19],
                                  f"the centre is the unique largest fibre on all "
                                  f"{d['n19']} contents with a+b+c <= 19"))


@reg("s5-Dprime-total20")
def _(e):
    d = dprime_scan()
    f20 = sorted({tuple(sorted((t[0], t[2]))) + (t[1],) for t in d["fails"] if sum(t) == 20})
    return lit(e, "a+b+c=20", (f20 == [(5, 5, 10), (7, 7, 6)] and
                               {t for t in d["fails"]} == {(7, 6, 7), (5, 10, 5)},
                               "at a+b+c = 20 the only exceptions are (7,6,7) and (5,10,5)"))


@reg("s5-Dprime-436")
def _(e):
    return val(e, str(dprime_scan()["n19"]))


@reg("s5-Dprime-516")
def _(e):
    return val(e, str(dprime_scan()["n20"]))


# Question 5.6 (QE): the slow part is the group QE; the default mode scans a+b+c <= 30.


def qe_one(abc: tuple) -> tuple:
    a, b, c = abc
    P = psi_table(a, b, c)
    mx = max(max(row) for row in P)
    at = sorted((x, y) for x in range(len(P)) for y in range(len(P[0])) if P[x][y] == mx)
    cx, cy = a * b // 2, b * c // 2
    return abc, mx, at, P[cx][cy], sum(map(sum, P)) == multinomial(abc)


def qe_scan(tmax: int, pool=None) -> dict:
    conts = [(a, b, c) for tot in range(4, tmax + 1) for b in range(2, tot, 2)
             for a in range(1, tot - b) for c in [tot - a - b] if a <= c and (a, c) != (1, 1)]
    order = sorted(conts, key=lambda t: -(t[0] + 1) * (t[1] + 1) * (t[2] + 1) * t[0] * t[2])
    res = list(pool.map(qe_one, order, chunksize=1)) if pool is not None else \
        [qe_one(t) for t in order]
    res.sort(key=lambda r: (sum(r[0]), r[0]))
    bad, fails, margins = [], [], {}
    for (a, b, c), mx, at, pc, tot_ok in res:
        cx, cy = a * b // 2, b * c // 2
        allowed = {(cx, cy), (cx + 1, cy - 1), (cx - 1, cy + 1)}
        if not tot_ok or not set(at) <= allowed:
            bad.append(("E1", (a, b, c)))
        unique = at == [(cx, cy)]
        if ((cx % 2 == 0 or cy % 2 == 0) and not unique):
            bad.append(("E2", (a, b, c)))
        if not unique:
            fails.append((a, b, c))
            if not (a % 2 == 1 and c % 2 == 1 and b % 4 == 2 and
                    at == [(cx - 1, cy + 1), (cx + 1, cy - 1)] and mx > pc):
                bad.append(("E3", (a, b, c)))
            margins[(a, b, c)] = Fraction(mx, pc) - 1
    return {"n": len(conts), "bad": bad, "fails": fails, "margins": margins}


def island_scan(b: int, tmax: int, pool=None) -> dict:
    conts = [(a, b, c) for a in range(1, tmax, 2) for c in range(a, tmax, 2)
             if a + b + c <= tmax and (a, c) != (1, 1)]
    order = sorted(conts, key=lambda t: -(t[0] + 1) * (t[2] + 1) * t[0] * t[2])
    res = list(pool.map(qe_one, order, chunksize=1)) if pool is not None else \
        [qe_one(t) for t in order]
    bad, off = [], []
    for (a, bb, c), mx, at, pc, tot_ok in res:
        cx, cy = a * bb // 2, bb * c // 2
        if at != [(cx, cy)]:
            off.append((a, bb, c))
            if not (at == [(cx - 1, cy + 1), (cx + 1, cy - 1)] and mx > pc):
                bad.append((a, bb, c))
        if not tot_ok:
            bad.append(("total", a, bb, c))
    return {"n": len(conts), "off": off, "bad": bad}


@reg(["s5-QE-3521"], kind="full", group="QE")
def _(e):
    d = qe_full()
    return val(e, str(d["main"]["n"]))


@lru_cache(maxsize=None)
def qe_small(tmax: int) -> dict:
    return qe_scan(tmax)


@reg(["s5-QE-range45", "s9-t-AD-QE"], kind="full", group="QE",
     partial=lambda e: [(qe_small(30)["bad"] == [], "partial: E1 and E2 for a+b+c <= 30")])
def _(e):
    d = qe_full()["main"]
    return lit(e, "a+b+c\\le45", (d["bad"] == [], f"E1 and E2 on all {d['n']} contents"))


@reg("s5-QE-30", kind="full", group="QE")
def _(e):
    return val(e, str(len(qe_full()["main"]["fails"])))


@reg("s5-QE-list", kind="full", group="QE")
def _(e):
    f = sorted(qe_full()["main"]["fails"], key=lambda t: (sum(t), t))
    return val(e, f"${tup(f[0])}$ and ${tup(f[1])}$ to ${tup(f[-1])}$") + [
        (sum(f[0]) == sum(f[1]) < sum(f[2]), "the first two have the least total")]


def sci2(fr: Fraction) -> str:
    """A positive Fraction as m.d*10^{e} (two significant digits, half to even, exact)."""
    ex = 0
    while fr * Fraction(10) ** (-ex) >= 10:
        ex += 1
    while fr * Fraction(10) ** (-ex) < 1:
        ex -= 1
    mant = dec_round(fr * Fraction(10) ** (-ex), 1)
    return f"{mant}\\cdot10^{{{ex}}}"


@reg(["s5-QE-margin-hi", "s5-QE-margin-lo"], kind="full", group="QE")
def _(e):
    m = qe_full()["main"]["margins"]
    hi, lo = max(m, key=m.get), min(m, key=m.get)
    t, want_at = (hi, (7, 10, 7)) if e["id"].endswith("hi") else (lo, (11, 6, 19))
    return val(e, "1+" + sci2(m[t])) + [(t == want_at, f"attained at {t}")]


@reg("s5-QE-mod4", kind="full", group="QE",
     partial=lambda e: [(not [b for b in qe_small(30)["bad"] if b[0] == "E3"],
                         "partial: E3 for a+b+c <= 30")])
def _(e):
    d = qe_full()["main"]
    return lit(e, "b\\equiv2\\pmod4", (not [b for b in d["bad"] if b[0] == "E3"],
                                       "every failure: a, c odd, b = 2 mod 4, the two cells "
                                       "only"))


@reg("s5-QE-island10-18", kind="full", group="QE")
def _(e):
    isl = qe_full()["islands"]
    return val(e, dollars(isl[b]["n"] for b in (10, 14, 18))) + [
        (all(isl[b]["bad"] == [] for b in (10, 14, 18)), "the same holds on the islands")]


@reg("s5-QE-island6", kind="full", group="QE")
def _(e):
    isl = qe_full()["islands"]
    return val(e, f"${isl[6]['n']}$") + [(isl[6]["bad"] == [], "the same holds")]


@reg("s9-t-TE-QE")
def _(e):
    d = qe_small(30)
    return lit(e, "a+b+c\\le30", (d["bad"] == [], f"E1 and E2 on the {d['n']} contents with "
                                                  f"a+b+c <= 30"))


_QE_FULL: dict = {}


def qe_full() -> dict:
    if not _QE_FULL:
        from concurrent.futures import ProcessPoolExecutor
        with ProcessPoolExecutor(max_workers=WORKERS) as pool:
            _QE_FULL["main"] = qe_scan(45, pool)
            _QE_FULL["islands"] = {6: island_scan(6, 66, pool), 10: island_scan(10, 60, pool),
                                   14: island_scan(14, 60, pool), 18: island_scan(18, 60, pool)}
    return _QE_FULL


# ---------------------------------------------------------------------------------------------
# (b.3) Section 5: the largest Parikh classes of (2,b,2) (Theorem E)
# ---------------------------------------------------------------------------------------------

B2_DEFAULT, B2_FULL = 40, 100


def dstar(b: int) -> int:
    return (b * b + 9 * b + 36) // 14


def vfun(b: int, s: int) -> Fraction:
    return Fraction((s + 2) ** 2 // 4) - Fraction((2 * s - b - 2) * (2 * s - b + 1), 2)


def b2_one(b: int) -> tuple:
    """(b, M(b), the largest classes, the largest thin class and its classes, (b,b,b) size,
    the (x,y,z) classes, the class count and the word total) for (2,b,2), by levels."""
    cl = classes_2b2(b)
    M = max(cl.values())
    top = sorted(k for k, v in cl.items() if v == M)
    thin = [(v, k) for k, v in cl.items()
            if k[2] >= 1 and k[2] - (2 * k[0] + 2 * k[1] - 4 * b) >= 1]
    tmax = max((v for v, k in thin), default=0)
    tat = sorted(k for v, k in thin if v == tmax)
    total = sum(cl.values())
    return (b, M, top, tmax, tat, cl.get((b, b, b), 0), len(cl), total)


_B2: dict = {}


def b2_data(bmax: int) -> dict:
    need = [b for b in range(1, bmax + 1) if b not in _B2]
    if need:
        if len(need) > 45:
            from concurrent.futures import ProcessPoolExecutor
            with ProcessPoolExecutor(max_workers=WORKERS) as pool:
                for r in pool.map(b2_one, sorted(need, reverse=True), chunksize=1):
                    _B2[r[0]] = r
        else:
            for b in need:
                _B2[b] = b2_one(b)
    return {b: _B2[b] for b in range(1, bmax + 1)}


def b2_range() -> int:
    return B2_FULL if ext() else B2_DEFAULT


def zprime(b: int, k: tuple) -> int:
    x, y, z = k
    return z - (2 * x + 2 * y - 4 * b)


def table_2b2() -> dict:
    """r -> (constant term of d*(14m+r), the s with V(8m+s) = d*(14m+r)), independent of m."""
    out = {}
    for r in range(14):
        res = set()
        for m in range(1, 6):
            b = 14 * m + r
            const = dstar(b) - (14 * m * m + (2 * r + 9) * m)
            ss = tuple(s for s in range(-20, 40) if vfun(b, 8 * m + s) == dstar(b))
            res.add((const, ss))
        assert len(res) == 1, r
        out[r] = res.pop()
    return out


def predicted_top(b: int) -> list:
    """Theorem E(ii): (2X,2Y,0) with |X-Y| <= 1, V(X+Y) = d*(b), and the reversal images."""
    out = set()
    for S in range(0, 2 * b + 1):
        if vfun(b, S) != dstar(b):
            continue
        for X in (S // 2, S - S // 2):
            Y = S - X
            if abs(X - Y) <= 1 and 2 * X <= 2 * b and 2 * Y <= 2 * b:
                out.add((2 * X, 2 * Y, 0))
                out.add((2 * b - 2 * X, 2 * b - 2 * Y, 4 * b - 4 * X - 4 * Y))
    return sorted(out)


@lru_cache(maxsize=None)
def thmE_check(bmax: int) -> dict:
    D = b2_data(bmax)
    bad: dict = defaultdict(list)
    for b, (_, M, top, tmax, tat, rbbb, ncl, total) in D.items():
        if total != factorial(b + 4) // (4 * factorial(b)):
            bad["total"].append(b)
        if b >= 16 and M != dstar(b):
            bad["i"].append(b)
        if b >= 20:
            if top != predicted_top(b):
                bad["ii"].append(b)
            S = [(x + y) // 2 for x, y, z in top if z == 0]
            if not all(abs(Fraction(s) - Fraction(4 * b + 4, 7)) < Fraction(3, 4) for s in S):
                bad["window"].append(b)
            want_n = 6 if b % 14 in (0, 5, 7, 12) else None
            if len(top) not in (2, 4, 6) or (len(top) == 6) != (want_n == 6):
                bad["246"].append(b)
            if not all(z == 0 and x % 2 == 0 and y % 2 == 0 and abs(x - y) <= 2 and
                       abs(Fraction(x + y) - Fraction(8 * (b + 1), 7)) < Fraction(3, 2)
                       for x, y, z in top if z == 0):
                bad["shape"].append(b)
        some = any(k[2] == 0 or zprime(b, k) == 0 for k in top)
        every = all(k[2] == 0 or zprime(b, k) == 0 for k in top)
        if b != 4 and not some:
            bad["some"].append(b)
        if every != (b in (1, 3) or b >= 6):
            bad["every"].append(b)
        if tmax > b + 4:
            bad["thin"].append(b)
        if b % 2 == 0 and (rbbb != b + 4 or tmax != b + 4 or tat != [(b, b, b)]):
            bad["thin_eq"].append(b)
        if b >= 16:
            ts = [x + y - b for x, y, z in top if z == 0]
            if min(ts) < 3:
                bad["t3"].append(b)
            q = Fraction(M) - Fraction(b * b + 9 * b, 14)
            want = [Fraction(2), Fraction(16, 7), Fraction(17, 7), Fraction(17, 7),
                    Fraction(16, 7), Fraction(2), Fraction(18, 7)][b % 7]
            if q != want:
                bad["iv"].append(b)
    return {"D": D, "bad": dict(bad), "bmax": bmax}


def eok(*keys) -> list:
    d = thmE_check(b2_range())
    return [(k not in d["bad"], f"Theorem E [{k}] for b <= {d['bmax']} by enumeration of levels"
                                f"{'' if k not in d['bad'] else ': ' + str(d['bad'][k][:5])}")
            for k in keys]


@reg(["abs-2b2-formula", "s1-E-formula", "s1-tab-E", "s5-dstar"])
def _(e):
    latex = {"abs-2b2-formula": "\\lfloor(b^2+9b+36)/14\\rfloor",
             "s1-E-formula": "\\floor{(b^2+9b+36)/14}", "s1-tab-E": "\\floor{(b^2+9b+36)/14}",
             "s5-dstar": "\\floor*{\\frac{b^2+9b+36}{14}}"}[e["id"]]
    return lit(e, latex, *eok("i", "total"))


@reg(["s1-E-count", "s5-E-246"])
def _(e):
    return lit(e, "two, four or six", *eok("246", "ii"))


@reg("s1-E-shape")
def _(e):
    return lit(e, "$\\abs{x-y}\\le2$ and $\\abs{x+y-8(b+1)/7}<3/2$", *eok("shape", "ii"))


@reg("s5-E-window")
def _(e):
    return lit(e, "<3/4", *eok("window"))


@reg("s5-E-window-others")
def _(e):
    """Proof of Theorem E: the window candidates |s-(4r+4)/7| < 3/4 outside Table 3
    (tab:2b2), and the value V(8m+s) - d*(14m+r) there, for m = 1..5 (it depends only on
    (r,s))."""
    tb = table_2b2()
    others, diffs = [], set()
    for r in range(14):
        for s in range(-20, 40):
            if abs(Fraction(s) - Fraction(4 * r + 4, 7)) < Fraction(3, 4) and s not in tb[r][1]:
                others.append((r, s))
                diffs |= {vfun(14 * m + r, 8 * m + s) - dstar(14 * m + r) for m in range(1, 6)}
    items = [f"$(r,s)={tup(others[0])}$"] + [f"${tup(o)}$" for o in others[1:]] if others else []
    return val(e, and_list(items) if items else "") + [
        (len(others) == 4, f"four window candidates outside the table: {others}"),
        (diffs == {Fraction(-1)}, f"V(8m+s) - d*(14m+r) = -1 at each of them: {sorted(diffs)}"),
        (all(len(tb[r][1]) + sum(1 for o in others if o[0] == r) <= 2 for r in range(14)),
         "at most two s in the window for each r")]


@reg("s5-exterior-bb0")
def _(e):
    """rem:exterior: at (b,b) of (2,b,2), lambda = 0; rho(b,b,0) = 6 for even b, and no class
    z = lambda for odd b (levels, b <= 24, and b <= 40 with --full)."""
    top = 40 if ext() else 24
    even = {classes_2b2(b).get((b, b, 0), 0) for b in range(2, top + 1, 2)}
    odd = {classes_2b2(b).get((b, b, 0), 0) for b in range(1, top + 1, 2)}
    (v,) = even if len(even) == 1 else (None,)
    return val(e, f"\\rho(b,b,0)={v}") + [
        (all(2 * b + 2 * b - 4 * b == 0 for b in range(1, top + 1)), "lambda(b,b) = 0"),
        (odd == {0}, f"no class (b,b,0) for odd b <= {top}"),
        (t4_data()["bad"] == [], "the whole (b,b) fibre, 1 <= b <= 12, by profiles and levels")]


@reg("s5-E-mod14")
def _(e):
    six = [b for b in range(20, 401) if len(predicted_top(b)) == 6]
    return lit(e, "b\\equiv0,5,7,12\\pmod{14}", *eok("246"),
               (all((b % 14 in (0, 5, 7, 12)) == (b in six) for b in range(20, 401)),
                "by the formula of E(ii), 20 <= b <= 400"))


@reg("s1-E-exact-set")
def _(e):
    D = thmE_check(b2_range())["D"]
    eq = [b for b, r in D.items() if r[1] == dstar(b)]
    want = [10, 13] + list(range(16, max(D) + 1))
    return val(e, "$b=10$, $b=13$ and $b\\ge16$") + [(eq == want, f"M(b) = d*(b) exactly for "
                                                               f"b in {{10, 13, 16..{max(D)}}}")]


@reg(["s5-cor-set"])
def _(e):
    D = thmE_check(b2_range())["D"]
    eq = [b for b, r in D.items() if r[1] == dstar(b)]
    return lit(e, "b\\in\\{10,13\\}", (eq == [10, 13] + list(range(16, max(D) + 1)),
                                       "Corollary 5.10 on the enumerated range"))


@reg("s5-cor-values")
def _(e):
    D = thmE_check(b2_range())["D"]
    return val(e, f"d^*(10)={D[10][1]}") + [(dstar(10) == D[10][1] and dstar(13) == D[13][1] == 23,
                                            "d*(10) = M(10), d*(13) = M(13) = 23")]


@reg(["s1-E-exhaustive-range", "s9-t-B2-range", "s9-E-cases"])
def _(e):
    latex = "16\\le b\\le19" if e["id"] == "s1-E-exhaustive-range" else "b\\le19"
    D = thmE_check(b2_range())["D"]
    return lit(e, latex, (all(D[b][1] == dstar(b) for b in range(16, 20)),
                          "M(b) = d*(b) for 16 <= b <= 19 by exhaustive enumeration"),
               *eok("every", "some"))


@reg("s1-E-small-range")
def _(e):
    D = thmE_check(b2_range())["D"]
    return lit(e, "b\\le15", (all(D[b][1] > dstar(b) or b in (10, 13) for b in range(1, 16)),
                              "for b <= 15 the formula holds only at b = 10, 13"))


@reg("s5-E-every-set")
def _(e):
    return lit(e, "b\\in\\{1,3\\}", *eok("every"))


@reg("s5-E-some-every")
def _(e):
    D = thmE_check(b2_range())["D"]
    top4 = D[4][2]
    return lit(e, "b\\ne4", *eok("some"), (not any(k[2] == 0 or zprime(4, k) == 0 for k in top4),
                                           "at b = 4 no largest class has z = 0 or z' = 0"))


@reg("s5-E-kappa")
def _(e):
    vals_ = []
    for r in range(7):
        b = 21 + r
        q = Fraction(thmE_check(b2_range())["D"][b][1]) - Fraction(b * b + 9 * b, 14)
        vals_.append(q)
    want = dollars(str(v) for v in vals_)
    ok = all(Fraction(dstar(b)) - Fraction(b * b + 9 * b, 14) == vals_[b % 7]
             for b in range(16, 20000))
    return val(e, want) + eok("iv") + [(ok, "the residues repeat with period 7, b < 20000")]


@reg("s5-E-asymp")
def _(e):
    ok = all(abs(Fraction(dstar(b)) - Fraction(b * b, 14)) <= Fraction(9 * b + 36, 14)
             for b in range(16, 2000))
    return lit(e, "b^2/14+O(b)", (ok, "|d*(b) - b^2/14| <= (9b+36)/14"), *eok("i"))


@reg("s5-E-check-range", kind="full", group="base",
     partial=lambda e: eok("i", "ii", "every", "some"))
def _(e):
    return lit(e, "every $b\\le40$, and $b\\le100$", *eok("i", "ii", "every", "some"),
               (b2_range() == 100, "enumerated for every b <= 100"))


@reg("s5-E-81200")
def _(e):
    D = thmE_check(b2_range())["D"]
    top16 = D[16][2]
    k = (8, 12, 0)
    x, y = 8, 12
    X, Y, t = x // 2, y // 2, x + y - 16
    sigma = X + Y
    outside = not (0 <= t <= min(X, Y) - 1 and 2 * sigma >= 16)
    return val(e, f"${tup(k)}$") + [(k in top16, "(8,12,0) is a largest class of (2,16,2)"),
                                    (outside, "it lies outside case (b) of Lemma 5.12")]


@reg("s5-E-dstar16")
def _(e):
    D = thmE_check(b2_range())["D"]
    return val(e, f"d^*(16)={dstar(16)}") + [(D[16][1] == dstar(16), "M(16) = d*(16)")]


@reg("s5-E-approx")
def _(e):
    D = thmE_check(b2_range())["D"]
    ok = all(abs(Fraction(x + y, 2) - Fraction(4 * (b + 1), 7)) < 2
             for b in range(16, max(D) + 1) for x, y, z in D[b][2] if z == 0)
    return lit(e, "4(b+1)/7", (ok, "z = 0 maximisers have (x+y)/2 within 2 of 4(b+1)/7"))


@reg(["s5-E-b21", "s5-E-b21-images"])
def _(e):
    top = thmE_check(b2_range())["D"][21][2]
    z0 = sorted((k for k in top if k[2] == 0), key=lambda k: (k[0], k[1]))
    z0 = [z0[1], z0[2], z0[0]] if len(z0) == 3 else z0
    order = [(12, 12, 0), (12, 14, 0), (14, 12, 0)]
    if e["id"].endswith("images"):
        im = [(42 - x, 42 - y, 84 - 2 * x - 2 * y) for x, y, z in order]
        return val(e, dollars(tup(k) for k in im)) + [(sorted(top) == sorted(order + im),
                                                       "the six largest classes of (2,21,2)")]
    return val(e, dollars(tup(k) for k in order)) + [(sorted(k for k in top if k[2] == 0) ==
                                                      sorted(order), "the z = 0 maximisers")]


@reg("s5-tab-const")
def _(e):
    tb = table_2b2()
    return val(e, " & ".join(f"${tb[r][0]}$" for r in range(14))) + [
        (all(tb[r][0] == (r * r + 9 * r + 36) // 14 for r in range(14)),
         "the constant term is floor((r^2+9r+36)/14)")]


@reg("s5-tab-row")
def _(e):
    tb = table_2b2()
    D = thmE_check(b2_range())["D"]
    ok = all(sorted({(x + y) // 2 for x, y, z in D[b][2] if z == 0}) ==
             [8 * (b // 14) + s for s in tb[b % 14][1]] for b in range(20, max(D) + 1))
    return val(e, "$s$ & " + " & ".join("$" + ",".join(map(str, tb[r][1])) + "$"
                                       for r in range(14))) + [
        (ok, "the sigma values of the enumerated maximisers, 20 <= b <= max")]


@reg("s5-tab-param")
def _(e):
    return lit(e, "$b=14m+r$", (all(len(table_2b2()[r][1]) in (1, 2) for r in range(14)),
                                "V(8m+s) - d*(14m+r) depends only on (r,s), m = 1..5"))


@reg("s5-M1-15")
def _(e):
    D = thmE_check(b2_range())["D"]
    return val(e, dollars(D[b][1] for b in range(1, 16)))


@reg(["s5-max16", "s5-max17", "s5-max18", "s5-max19"])
def _(e):
    b = int(e["id"][-2:])
    D = thmE_check(b2_range())["D"][b]
    z0 = sorted((x, y) for x, y, z in D[2] if z == 0)
    rest = sorted(k for k in D[2] if k[2] != 0)
    imgs = sorted((2 * b - x, 2 * b - y, 4 * b - 2 * x - 2 * y) for x, y in z0)
    return val(e, f"for $b={b}$ (${D[1]}$ words) " + ", ".join(f"${tup(t)}$" for t in z0)) + [
        (rest == imgs, "the other largest classes are their reversal images")]


@reg("s5-b4")
def _(e):
    D = thmE_check(b2_range())["D"][4]
    (k,) = D[2]
    return val(e, f"${tup(k)}$, with ${D[1]}$ words")


@reg("s5-b2b5-sizes")
def _(e):
    D = thmE_check(b2_range())["D"]
    return val(e, f"at ${D[2][1]}$ and ${D[5][1]}$ words")


@reg("s5-b2b5-ties")
def _(e):
    D = thmE_check(b2_range())["D"]
    thin2 = [k for k in D[2][2] if k[2] >= 1 and zprime(2, k) >= 1]
    thin5 = [k for k in D[5][2] if k[2] >= 1 and zprime(5, k) >= 1]
    z05 = [k for k in D[5][2] if k[2] == 0]
    return val(e, f"${tup(thin2[0])}$") + [
        (thin2 == [(2, 2, 2)], "b = 2: the thin largest class is (2,2,2)"),
        (thin5 == [(4, 6, 4), (5, 5, 5), (6, 4, 4)] and z05, "b = 5: (4,6,4), (5,5,5), (6,4,4) "
                                                             "tie with z = 0 classes")]


@reg("s5-AD-range")
def _(e):
    return lit(e, "$b\\le20$, and $b\\le40$", *eok("i", "every"),
               (b2_range() >= 40, "this check enumerates b <= 40 in the default mode"))


@reg(["s5-232-classes", "s5-232-words", "s5-AAP08"])
def _(e):
    cl = tern_lit(2, 3, 2)
    w, n = sum(cl.values()), len(cl)
    want = {"s5-232-classes": str(n), "s5-232-words": str(w),
            "s5-AAP08": f"${w}$ words of $(2,3,2)$ in ${n}$ classes"}[e["id"]]
    pm = pmx_all((2, 3, 2))
    return val(e, want) + [(len(pm) == n, "the Parikh-matrix classes = the (x,y,z) classes")]


@reg("s5-thin-bound")
def _(e):
    return lit(e, "b+4", *eok("thin"))


@reg("s5-thin-eq")
def _(e):
    return lit(e, "\\rho(b,b,b)=b+4", *eok("thin_eq"))


@reg("s5-t3")
def _(e):
    return lit(e, "t\\ge3", *eok("t3"))


@reg("s5-parabola")
def _(e):
    ok = True
    for b in range(1, 401):
        sst = Fraction(4 * b + 4, 7)
        for s in range(-5, 2 * b + 6):
            ok &= vfun(b, s) <= Fraction(b * b + 9 * b + 36, 14) - Fraction(7, 4) * (s - sst) ** 2
            if vfun(b, s) == dstar(b):
                ok &= abs(s - sst) < Fraction(3, 4)
            ok &= vfun(b, s) <= dstar(b) and vfun(b, s).denominator == 1
    return lit(e, "\\frac{b^2+9b+36}{14}-\\frac74\\Bigl(\\sigma-\\frac{4b+4}{7}\\Bigr)^2",
               (ok, "Lemma 5.13 for 1 <= b <= 400 and every relevant sigma"))


@reg("s5-2649")
def _(e):
    ok = all(Fraction(dstar(b)) >= Fraction(b * b + 9 * b + 23, 14) for b in range(1, 5000))
    bound = Fraction(36 - 23, 14) / Fraction(7, 4)
    return val(e, f"{bound}<9/16") + [(bound < Fraction(9, 16), "26/49 < 9/16"),
                                      (ok, "d*(b) >= (b^2+9b+23)/14, b < 5000")]


@reg("s5-d20")
def _(e):
    lhs = Fraction(26 ** 2, 16) + 1
    return val(e, f"{dstar(20)}=d^*(20)") + [(lhs < dstar(20), "26^2/16 + 1 < d*(20)"),
                                            (thmE_check(b2_range())["D"][20][1] == 44,
                                             "M(20) = 44")]


@reg("s5-thresholds")
def _(e):
    tb = table_2b2()
    first = max(Fraction(r - 2 * s, 2) for r in range(14) for s in tb[r][1])
    second = max(Fraction(2 * s - r - s // 2 + 1, 2) for r in range(14) for s in tb[r][1])
    second6 = max(Fraction(2 * s - r - s // 2 + 1, 2) for r in range(6, 14) for s in tb[r][1])
    return val(e, f"at most ${second}$") + [(first <= 0, "the first bound is at most 0"),
                                           (second6 <= 1, "the second at most 1 if r >= 6")]


@reg("s5-r-six")
def _(e):
    tb = table_2b2()
    six = [r for r in range(14) if sum(1 if s % 2 == 0 else 2 for s in tb[r][1]) * 2 == 6]
    return val(e, "r\\in\\{" + ",".join(map(str, six)) + "\\}")


@reg("s5-d16-19")
def _(e):
    D = thmE_check(b2_range())["D"]
    return val(e, and_list([f"${D[b][1]}$" for b in range(16, 20)])) + [
        (all(D[b][1] == dstar(b) for b in range(16, 20)), "= d*(b)")]


@reg("s8-2b2-tau")
def _(e):
    D = thmE_check(b2_range())["D"]
    return val(e, f"{comb(4, 2)}=\\tau") + [(all(D[b][1] > 6 for b in range(3, max(D) + 1)),
                                             "M(b) > 6 = C(4,2) for every b >= 3 enumerated")]


# ---------------------------------------------------------------------------------------------
# (b.4) Section 6: the golden-ratio threshold (Theorem F) and the centre (Theorem G)
# ---------------------------------------------------------------------------------------------

GOLD_A = 10            # class counts by GAP for a <= GOLD_A (19 with group X)


def gold_amax() -> int:
    return 19 if ext() else GOLD_A


@lru_cache(maxsize=None)
def a2c_top(a: int, c: int) -> tuple:
    """(beta, the largest classes) of (a,2,c) by GAP."""
    cl = a2c_classes(a, c)
    top = max(cl.values())
    return top, tuple(sorted(k for k, v in cl.items() if v == top))


@lru_cache(maxsize=None)
def golden_scan(amax: int) -> dict:
    """Theorem F(iii)-(iv) on a <= amax, a <= c <= threshold(a) + 2, by GAP."""
    bad: dict = defaultdict(list)
    for a in range(1, amax + 1):
        for c in range(a, threshold(a) + 3):
            beta, at = a2c_top(a, c)
            tau = comb(a + c, a)
            fmax = max(f_bound(a, c, j) for j in range(c + 1))
            if (beta == tau) != (c * (c - 1) <= a * (a + c - 1)) or beta < tau:
                bad["iv"].append((a, c))
            if beta != fmax:
                bad["iii"].append((a, c))
    return dict(bad)


def gok(key: str) -> tuple:
    b = golden_scan(gold_amax())
    return (key not in b, f"Theorem F({key}) by GAP, a <= {gold_amax()}, a <= c <= "
                          f"threshold + 2{'' if key not in b else ': ' + str(b[key][:4])}")


@reg(["abs-golden-criterion", "s1-F-criterion", "s1-tab-F", "s6-thmF-criterion"])
def _(e):
    exact = all((c * (c - 1) <= a * (a + c - 1)) == (c <= threshold(a))
                for a in range(1, 91) for c in range(a, 200))
    return lit(e, "c(c-1)\\le a(a+c-1)", gok("iv"), (exact, "the threshold sequence = the "
                                                            "integer criterion, a <= 90"))


@reg("s1-F-boundary-max")
def _(e):
    return lit(e, "\\max_{0\\le j\\le c}\\sum_{i=j}^{\\min(2j,c)}\\binom{a+c-i}{a}", gok("iii"),
               (all(f_bound(a, c, j) == p0(a, c, 2 * j) for a in range(1, 8) for c in range(a, 20)
                    for j in range(c + 1)), "f(j) = P_0(2j)"),
               (all(a2c_fibre(a, c, 0, 2 * c - m) == p0(a, c, m) for a in range(1, 7)
                    for c in range(a, 12) for m in range(2 * c + 1)),
                "P_0(m) = P(0, 2c - m) by GAP (Proposition 6.4)"))


def cstar_le(a: int, c: int) -> bool:
    """c <= c*(a) exactly: 2c - a - 1 <= sqrt(5a^2 - 2a + 1)."""
    t = 2 * c - a - 1
    return t < 0 or t * t <= 5 * a * a - 2 * a + 1


@reg(["s1-F-cstar", "s6-thmF-cstar"])
def _(e):
    latex = ("\\bigl(a+1+\\sqrt{5a^2-2a+1}\\bigr)/2" if e["id"] == "s1-F-cstar"
             else "\\bigl((a+1)+\\sqrt{5a^2-2a+1}\\bigr)/2")
    ok = all(cstar_le(a, c) == (c * (c - 1) <= a * (a + c - 1))
             for a in range(1, 300) for c in range(a, 2 * a + 3))
    ok2 = all((Decimal(c) <= cstar(a)) == cstar_le(a, c) for a in range(1, 60)
              for c in range(a, 2 * a + 3) if (2 * c - a - 1) ** 2 != 5 * a * a - 2 * a + 1)
    return lit(e, latex, (ok, "c <= c*(a) iff c(c-1) <= a(a+c-1), a < 300 (exact)"),
               (ok2, "and with c*(a) at 60 digits"))


@lru_cache(maxsize=None)
def cstar_gaps() -> dict:
    ok, eq = True, []
    for a in range(1, 20001):
        d = cstar(a) - PHI * a
        ok &= GAP_LO < d <= GAP_HI
        if abs(d - GAP_HI) < Decimal(10) ** -50:
            eq.append(a)
    return {"ok": ok, "eq": eq}


@reg(["s1-F-interval", "s6-thmF-gap", "fig7-bounds"])
def _(e):
    g = cstar_gaps()
    return lit(e, "\\bigl((1-1/\\sqrt5)/2,(3-\\sqrt5)/2\\bigr]",
               (g["ok"], "c*(a) - phi a in the interval for 1 <= a <= 20000 (60 digits)"),
               (g["eq"] == [1], "the upper end is attained at a = 1 only"))


@reg("s6-thmF-gap-decimals")
def _(e):
    lo, hi = str(GAP_LO)[:5], str(GAP_HI)[:5]
    return val(e, f"({lo}\\ldots,{hi}\\ldots]")


@reg(["fig7-bound-hi-label", "fig7-bound-lo-label"])
def _(e):
    latex = "$(3-\\sqrt5)/2$" if "hi" in e["id"] else "$(1-1/\\sqrt5)/2$"
    v = GAP_HI if "hi" in e["id"] else GAP_LO
    m = re.search(r"axis cs:300,([0-9.]+)", e["anchor"])
    pos = Decimal(m.group(1)) if m else None
    near = pos is not None and abs(pos - v) < Decimal("0.01")
    return lit(e, latex, (near, f"the label sits next to the line at {dec_decimal(v, 6)}"))


@lru_cache(maxsize=None)
def ties_1e6() -> list:
    return golden_ties(10 ** 6)


def fib_ties(nmax: int) -> list:
    return [(fib(n) * fib(n + 1), fib(n) * fib(n + 2)) for n in range(1, nmax + 1, 2)]


@reg(["abs-golden-ties", "s1-F-ties-form"])
def _(e):
    t = ties_1e6()
    latex = ("(F_nF_{n+1},F_nF_{n+2})" if e["id"] == "abs-golden-ties"
             else "(\\Fib{n}\\Fib{n+1},\\Fib{n}\\Fib{n+2})")
    return lit(e, latex, (t == [p for p in fib_ties(40) if p[0] <= 10 ** 6],
                          f"the {len(t)} ties with a <= 10^6 are (F_nF_{{n+1}}, F_nF_{{n+2}}), "
                          f"n odd"))


@reg(["s1-F-ties-list", "s6-thmF-ties"])
def _(e):
    t = ties_1e6()[:5]
    items = [f"${tup(p)}$" for p in t]
    want = and_list(items) if e["id"] == "s1-F-ties-list" else \
        "$(a,c)=" + tup(t[0]) + "$, " + ", ".join(items[1:])
    return val(e, want)


@reg("fig7-ties-a")
def _(e):
    t = [p for p in ties_1e6() if p[0] <= 19]
    return val(e, " and ".join(f"${tup(p)}$" for p in t))


@reg("fig7-ties-b")
def _(e):
    t = [p for p in ties_1e6() if p[0] <= 2000]
    return val(e, "$a=" + ",".join(str(p[0]) for p in t) + "$")


@reg("fig7-ties-n")
def _(e):
    t = [p for p in ties_1e6() if p[0] <= 2000]
    ns = [n for n in range(1, 30) if (fib(n) * fib(n + 1), fib(n) * fib(n + 2)) in t]
    return val(e, "$n=" + ",".join(map(str, ns)) + "$")


@reg("s6-pell-search")
def _(e):
    t = ties_1e6()
    return lit(e, "a\\le10^6", (t == [p for p in fib_ties(40) if p[0] <= 10 ** 6],
                                "no other tie with a <= 10^6"))


def five_at_ties(pairs) -> bool:
    ok = True
    for a, c in pairs:
        beta, at = a2c_top(a, c)
        want = sorted([(0, 2 * c, 0), (0, 2 * c - 2, 0), (2 * a, 0, 0), (2 * a, 2, 2 * a),
                       (a, c, 0)])
        ok &= beta == comb(a + c, a) and list(at) == want
    return ok


@reg(["s1-F-five", "s6-thmF-five", "fig7-five"])
def _(e):
    pairs = [(1, 2), (6, 10)] + ([(40, 65)] if ext() else [])
    want = "exactly five classes" if e["id"] == "s6-thmF-five" else "five"
    return val(e, want) + [(five_at_ties(pairs), f"five largest classes of size tau at {pairs}, "
                                                 f"the five of Theorem F(v)")]


@reg("s6-ex-222")
def _(e):
    beta, at = a2c_top(2, 2)
    return val(e, ", ".join(f"${tup(k)}$" for k in at) + f", of ${beta}$ words")


@reg("s6-ex-6210")
def _(e):
    beta, at = a2c_top(6, 10)
    return val(e, f"{WORDS_NUM[len(at)]} largest classes of ${beta}$ words")


@reg("s6-thmF-exception")
def _(e):
    exc = []
    for a in range(1, 11):
        for c in range(a, 15):
            cl = a2c_classes(a, c)
            beta = max(cl.values())
            for (x, y, z), m in cl.items():
                if 0 < x < 2 * a and 0 < y < 2 * c and x * y == 2 * z and m >= beta:
                    exc.append((a, c, (x, y, z)))
    return val(e, "the class $(x,y,z)=(2,2,2)$ of the content $(2,2,2)$") + [
        (exc == [(2, 2, (2, 2, 2))], f"the interior Cauchy-surface classes reaching beta: {exc}")]


@reg("s6-cauchy-820")
def _(e):
    cl = a2c_classes(24, 2)
    return val(e, f"${cl[(24, 2, 24)]}>\\tau={comb(26, 24)}$") + [
        (0 < 24 < 48 and 0 < 2 < 4 and 24 * 2 == 2 * 24,
         "(24,2,24) is an interior class of (24,2,2) on the Cauchy surface xy = 2z"),
        (sum(cl.values()) == comb(28, 2) * comb(26, 2), "GAP total = the words of (24,2,2)"),
        (cl[(24, 2, 24)] > comb(26, 24), "more than tau words")]


@lru_cache(maxsize=None)
def gold_hist() -> Counter:
    hist: Counter = Counter()
    for s in range(2, 51):
        for a in range(1, s):
            c = s - a
            if a > c:
                continue
            beta, at = a2c_top(a, c)
            hist[len(at)] += 1 if a == c else 2
    return hist


@reg("s6-hist-counts")
def _(e):
    h = gold_hist()
    return val(e, f"$2$ for ${h[2]}$ contents, $3$ for ${h[3]}$, $4$ for ${h[4]}$ and $5$ for "
                  f"${h[5]}$") + [(set(h) == {2, 3, 4, 5}, "no other number of largest classes")]


@reg("s6-hist-range")
def _(e):
    return lit(e, "a+c\\le50", (sum(gold_hist().values()) == 1225, "the scan covers a + c <= 50"))


@reg("s6-hist-total")
def _(e):
    n = sum(gold_hist().values())
    return val(e, f"${n}$") + [(n < 10 ** 4, "a four-digit number, printed without grouping")]


@reg("s6-zeta")
def _(e):
    ok = True
    for a in range(1, 5):
        c = 3000
        j = 0
        while comb(a + c - 2 * j - 1, a) + comb(a + c - 2 * j - 2, a) > comb(a + c - j, a):
            j += 1
        t = Decimal(2) ** (Decimal(1) / a)
        zeta = (t - 1) / (2 * t - 1)
        ok &= abs(Decimal(j) / c - zeta) < Decimal("0.002")
    a = 10 ** 4
    t = Decimal(2) ** (Decimal(1) / a)
    ok2 = abs(a * (t - 1) / (2 * t - 1) - Decimal(2).ln()) < Decimal("0.001")
    return lit(e, "\\zeta_a=(2^{1/a}-1)/(2^{1+1/a}-1)",
               (ok, "j*/c within 0.002 of zeta_a at c = 3000, a <= 4 (consistency of a proved "
                    "limit)"), (ok2, "a zeta_a -> ln 2"))


@reg("s6-lucas-mod5")
def _(e):
    seq = [lucas(k) % 5 for k in range(40)]
    per = next(p for p in range(1, 20) if all(seq[i] == seq[i + p] for i in range(40 - p)))
    k3 = [k for k in range(1, 40) if lucas(k) % 5 == 4]
    return val(e, f"period ${per}$, starting ${','.join(map(str, seq[:4]))}$") + [
        (all(k % 4 == 3 for k in k3), "L_k = 4 mod 5 iff k = 3 mod 4")]


@reg("s6-cstar1")
def _(e):
    return val(e, f"\\cstar(1)={cstar(1).to_integral_value()}") + [(cstar(1) == 2, "exact")]


def centre_closed(a: int, c: int) -> int:
    m0 = (a + c) // 2
    return (m0 + 1) * comb(m0, a // 2) * comb(-(-(a + c) // 2), -(-a // 2))


def centre_double(a: int, c: int) -> int:
    return sum(comb(p + q, p) ** 2 * binom0(a + c - 2 * p - 2 * q, a - 2 * p)
               for p in range(a // 2 + 1) for q in range(c // 2 + 1))


def centre_cases(a: int, c: int) -> int:
    m0 = (a + c) // 2
    if a % 2 == 0 and c % 2 == 0:
        return (m0 + 1) * comb(m0, a // 2) ** 2
    if a % 2 == 1 and c % 2 == 1:
        return (m0 + 1) * comb(m0, (a - 1) // 2) * comb(m0, (a + 1) // 2)
    ev = a if a % 2 == 0 else c
    return (m0 + 1) * comb(m0, ev // 2) * comb(m0 + 1, ev // 2)


@lru_cache(maxsize=None)
def thmG_scan() -> dict:
    bad: dict = defaultdict(list)
    for a in range(1, 26):
        for c in range(1, 26):
            P = psi_table(a, 2, c)
            mx = max(max(r) for r in P)
            at = [(x, y) for x in range(2 * a + 1) for y in range(2 * c + 1) if P[x][y] == mx]
            if (a, c) != (1, 1) and at != [(a, c)]:
                bad["unique"].append((a, c))
            if P[a][c] != mx:
                bad["max"].append((a, c))
            if centre_closed(a, c) != P[a][c]:
                bad["closed"].append((a, c))
            if centre_double(a, c) != P[a][c]:
                bad["double"].append((a, c))
            if centre_cases(a, c) != P[a][c]:
                bad["cases"].append((a, c))
    return dict(bad)


def Gok(*keys) -> list:
    b = thmG_scan()
    return [(k not in b, f"Theorem G [{k}] against PSI, 1 <= a, c <= 25"
                         f"{'' if k not in b else ': ' + str(b[k][:4])}") for k in keys]


@reg("s1-G-centre-value")
def _(e):
    return lit(e, "\\Bigl(\\floor*{\\frac{a+c}{2}}+1\\Bigr)\\binom{\\floor{(a+c)/2}}{\\floor{a/2}}"
                  "\\binom{\\ceil{(a+c)/2}}{\\ceil{a/2}}", *Gok("closed", "unique", "max"))


@reg("s6-thmG-closed")
def _(e):
    return lit(e, "(m_0+1)\\binom{m_0}{\\lfloor a/2\\rfloor}\\binom{\\lceil(a+c)/2\\rceil}"
                  "{\\lceil a/2\\rceil}", *Gok("closed", "unique"))


@reg("s6-thmG-doublesum")
def _(e):
    return lit(e, "\\sum_{p,q\\ge0}\\binom{p+q}{p}^{2}\\binom{a+c-2p-2q}{a-2p}", *Gok("double"))


@reg("s6-thmG-cases")
def _(e):
    return lit(e, "$(m_0+1)\\tbinom{m_0}{a/2}^2$ if $a$ and $c$ are even, $(m_0+1)\\tbinom{m_0}"
                  "{(a-1)/2}\\tbinom{m_0}{(a+1)/2}$ if both are odd, and $(m_0+1)\\tbinom{m_0}"
                  "{e/2}\\tbinom{m_0+1}{e/2}$", *Gok("cases"),
               (all(centre_closed(a, c) == centre_closed(c, a) for a in range(40)
                    for c in range(40)), "symmetric in a and c"))


@reg(["s6-thmG-11", "s1-G-tie-11"])
def _(e):
    P = psi_table(1, 2, 1)
    anti = [(x, 2 - x) for x in range(3)]
    mx = max(max(r) for r in P)
    at = [(x, y) for x in range(3) for y in range(3) if P[x][y] == mx]
    if e["id"] == "s1-G-tie-11":
        return val(e, WORDS_NUM[len(at)]) + [(at == anti, "the antidiagonal points")]
    return val(e, ", ".join(f"${tup(t)}$" for t in at[:-1]) + f" and ${tup(at[-1])}$ all have "
                  f"${mx}$ words") + [(at == anti, "exactly the antidiagonal points")]


@reg("s6-centreaa")
def _(e):
    ok = True
    for a in range(2, 31):
        P = psi_table(a, 2, a)
        D = [P[x][2 * a - x] for x in range(2 * a + 1)]
        ok &= D[a] == (a + 1) * comb(a, a // 2) ** 2 and all(D[x] < D[a] for x in range(2 * a + 1)
                                                               if x != a)
    return lit(e, "D(a)=(a+1)\\binom{a}{\\lfloor a/2\\rfloor}^2", (ok, "2 <= a <= 30 by PSI"))


@reg("s6-D-a4")
def _(e):
    P = psi_table(4, 2, 4)
    return val(e, "$" + ",".join(str(P[x][8 - x]) for x in range(9)) + "$")


@reg("s6-D-a4-centre")
def _(e):
    P = psi_table(4, 2, 4)
    return val(e, f"${P[4][4]}=5\\cdot6^2$") + [(P[4][4] == 5 * 6 ** 2, "= 5 * 6^2")]


@reg("s6-D-a6")
def _(e):
    P = psi_table(6, 2, 6)
    D = [P[x][12 - x] for x in range(13)]
    return val(e, f"$D(4)={D[4]}>D(5)={D[5]}<D(6)={D[6]}=7\\cdot20^2$") + [
        (D[4] > D[5] < D[6] == 7 * 20 ** 2, "the inequalities and 7 * 20^2")]


@reg("s6-qbinom")
def _(e):
    coeffs = Counter(sum(A) for A in combinations_with_replacement(range(3), 3))
    seq = [coeffs[i] for i in range(7)]
    words = Counter(occ(w, (1, 2)) for w in set(permutations_words((1, 1, 2, 2, 2))))
    return val(e, "$" + ",".join(map(str, seq)) + "$") + [
        (seq == [words[i] for i in range(7)], "the |w|_12 counts of the words of (2,3)")]


def permutations_words(letters: tuple):
    from itertools import permutations
    return permutations(letters)


# ---------------------------------------------------------------------------------------------
# (b.5) Appendix A: the Cauchy-surface lemma and its certificate (CERT)
# ---------------------------------------------------------------------------------------------


def cert_sides(mu: int, nu: int, h: int) -> dict:
    """The two sides of (C-a), (C-b), (C-b') at h."""
    U = lambda n: cert_U(mu, n)
    lhs_b = sum(U(k) for k in range(nu - h - 1, nu))
    rhs_bp = sum(U(nu) - U(k) for k in range(nu - h, nu))
    return {"a": (sum(U(k) for k in range(nu - 2 * h, nu - h + 1)), comb(mu + nu + 1, mu)),
            "b": (lhs_b, rhs_bp + comb(mu + nu, mu - 1)), "bp": (lhs_b, rhs_bp)}


@reg(["appA-tabC1-nu" + str(nu) for nu in range(2, 15)])
def _(e):
    nu = int(e["id"].split("nu")[1])
    rows = cert_C1_rows()
    cells = [str(nu)]
    for mu in (2, 3, 4):
        if mu in rows[nu]:
            cells += [str(v) if v >= 0 else f"${v}$" for v in rows[nu][mu]]
        else:
            cells += [""] * 4
    return val(e, norm(" & ".join(cells)))


def cert_cases() -> tuple:
    rows = cert_C1_rows()
    n_ab = n_bp = 0
    bad = []
    for nu, d in rows.items():
        for mu, (h, ca, cb, cbp) in d.items():
            if (mu, nu) != (2, 3):
                if ca >= 0 and cb >= 0:
                    n_ab += 1
                else:
                    bad.append((mu, nu))
            elif not (ca < 0 and cb < 0):
                bad.append((mu, nu, "expected to fail"))
            if cbp >= 0:
                n_bp += 1
            else:
                bad.append((mu, nu, "bp"))
    return n_ab, n_bp, bad


@reg("appA-C1-cases")
def _(e):
    n_ab, n_bp, bad = cert_cases()
    return val(e, f"${n_ab + n_bp}$ cases") + [(bad == [], "(C-a), (C-b) hold except at (2,3); "
                                                            "(C-b') holds everywhere")]


@reg(["appA-C1-range", "s6-hmintwo-finite"])
def _(e):
    rows = cert_C1_rows()
    pairs = sorted((mu, nu) for nu, d in rows.items() for mu in d)
    ok = pairs == sorted((mu, nu) for mu in (2, 3, 4) for nu in range(mu, 15))
    want = "$\\mu\\le\\nu\\le14$" if e["id"] == "appA-C1-range" else \
        "$\\mu\\in\\{2,3,4\\}$ and $\\mu\\le\\nu\\le14$"
    _, _, bad = cert_cases()
    return val(e, want) + [(ok, "the table covers mu in {2,3,4}, mu <= nu <= 14"),
                           (bad == [], "(C-b) at h_min there, except (2,3)")]


def c3_threshold(mu0: int, t1: int) -> int:
    """The least nu with t = (nu+1)/mu0 >= t1."""
    return mu0 * t1 - 1


@reg(["appA-C1-asymptotic", "s6-hmintwo-ranges"])
def _(e):
    th = {mu: c3_threshold(mu, t) for mu, t in ((4, 4), (3, 5), (2, 8))}
    sep = " and " if e["id"] == "appA-C1-asymptotic" else ", and "
    want = (f"for $\\mu=4$ with $\\nu\\ge{th[4]}$, for $\\mu=3$ with $\\nu\\ge{th[3]}$" + sep +
            f"for $\\mu=2$ with $\\nu\\ge{th[2]}$")
    ok = all(cert_slacks(mu, nu, cert_hmin(mu, nu))[1] >= 0
             for mu in range(2, 30) for nu in range(mu, 400) if cert_hmin(mu, nu) >= 2)
    return val(e, want) + [(all(cert_C3(m, t)[0] > 0 and cert_C3(m, t)[1] > cert_C3(m, t)[3]
                                for m, t in ((5, 3), (4, 4), (3, 5), (2, 8))),
                            "[C3] holds at the four pairs"),
                           (ok, "consistency: (C-b) at h_min >= 2 for 2 <= mu < 30, nu < 400")]


@reg(["appA-C1-entry", "s6-colsbig-23-bp"])
def _(e):
    lhs, rhs = cert_sides(2, 3, cert_hmin(2, 3))["bp"]
    return val(e, f"${lhs}\\ge{rhs}$") + [(lhs >= rhs, "(C-b') holds at (2,3)")]


@reg("s6-colsbig-23-fail")
def _(e):
    s = cert_sides(2, 3, cert_hmin(2, 3))
    (la, ra), (lb, rb) = s["a"], s["b"]
    return val(e, f"${la}\\ge{ra}$") + [((la, ra) == (lb, rb) and la < ra,
                                         "(C-a) and (C-b) both read 14 >= 15 and fail")]


@reg(["appA-C1-mu2h1", "s6-colsbig-mu2h1"])
def _(e):
    nus = [nu for nu in range(2, 200) if cert_hmin(2, nu) == 1]
    ok = all((cert_u(2, nu - 1) + cert_u(2, nu - 2) <= cert_u(2, nu + 1)) == (nu <= 6)
             for nu in range(2, 200))
    if e["id"] == "appA-C1-mu2h1":
        want = "$\\nu\\in\\{" + ",".join(str(n) for n in nus if n >= 4) + "\\}$"
        return val(e, want) + [(nus == [3, 4, 5, 6], "h_min(2,nu) = 1 exactly for 3 <= nu <= 6")]
    return val(e, f"${nus[0]}\\le\\nu\\le{nus[-1]}$") + [
        (nus == list(range(nus[0], nus[-1] + 1)) and ok, "u(nu-1)+u(nu-2) = nu^2 <= u(nu+1) "
                                                          "iff nu <= 6")]


@reg(["s6-colsbig-23-E1", "s6-colsbig-23-E2"])
def _(e):
    _, E1, E2, _, _ = cert_C2()
    if e["id"].endswith("E1"):
        return val(e, "$E_1(J)=" + ",".join(str(E1[J]) for J in range(3, 7)) + "$")
    return val(e, "$E_2(J)=" + ",".join(str(E2[J]) for J in range(2, 6)) + "$") + [
        (min(E2) >= 0, "E_2 >= 0 for J <= 40")]


@reg("appA-C2-E20")
def _(e):
    return val(e, f"$E_2(0)={cert_C2()[2][0]}$")


@reg("appA-C2-K")
def _(e):
    _, _, _, kp, _ = cert_C2()
    js = sorted(j for j in kp if kp[j])
    return val(e, dollars(kp[j] for j in js) + f" at $j={','.join(map(str, js))}$")


@reg("appA-C2-h")
def _(e):
    _, _, _, _, hb = cert_C2()
    return val(e, f"$\\binom{{5}}{{1}}={hb}$ at $j=3$ and ${-hb}$ at $j=4$") + [
        (hb == comb(2 + 3, 2 - 1), "C(mu+nu, mu-1) at (2,3)")]


@reg("appA-C2-u")
def _(e):
    us = [cert_u(2, 6 - i) for i in range(3, 7)]
    return val(e, "$u(6-i)=" + ",".join(map(str, us)) + "$")


@reg("appA-C2-tail")
def _(e):
    e_, E1, E2, _, _ = cert_C2()
    return lit(e, "$e_J=J+1>0$", (all(e_[J] == J + 1 for J in range(7, 41)), "e_J = J + 1, "
                                                                              "7 <= J <= 40"),
               (all(E1[J] > 0 for J in range(5, 41)), "E_1(J) > 0 for J >= 5"))


@reg(["appA-tabC2-row1", "appA-tabC2-row2", "appA-tabC2-row3"])
def _(e):
    e_, E1, E2, _, _ = cert_C2()
    row = {"1": ("$e_J$", e_), "2": ("$E_1(J)$", E1), "3": ("$E_2(J)$", E2)}[e["id"][-1]]
    cells = [str(v) if v >= 0 else f"${v}$" for v in row[1][:8]]
    return val(e, row[0] + " & " + " & ".join(cells))


@reg(["appA-C3-pairs", "s6-hmintwo-pairs"])
def _(e):
    pairs = [(5, 3), (4, 4), (3, 5), (2, 8)]
    ok = True
    for m0, t1 in pairs:
        th1, lam2, lam1, m2, m1 = cert_C3(m0, t1)
        ok &= th1 > 0 and lam2 > m2 and (lam2 - m2) * t1 >= m1 + lam1
    if e["id"] == "appA-C3-pairs":
        want = "$(\\mu_0,t_1)\\in\\{" + ",".join(tup(p) for p in pairs) + "\\}$"
    else:
        want = "$(\\mu_0,t_1)=" + tup(pairs[0]) + "$, " + ", ".join(f"${tup(p)}$"
                                                                   for p in pairs[1:])
    return val(e, want) + [(ok, "the three conditions of [C3] at each pair"),
                           (ln2_below(ETA), "ln 2 < 0.6932 (series with an exact tail bound)")]


@reg(["appA-tabC3-53", "appA-tabC3-44", "appA-tabC3-35", "appA-tabC3-28"])
def _(e):
    m0, t1 = int(e["id"][-2]), int(e["id"][-1])
    th1, lam2, lam1, m2, m1 = cert_C3(m0, t1)
    return val(e, f"${tup((m0, t1))}$ & {dec_round(lam2 - m2, 4)} & "
                  f"{dec_round((lam2 - m2) * t1 - m1 - lam1, 4)}")


@reg("s6-colone-23")
def _(e):
    eq, bad = [], []
    for a in range(2, 16):
        for c in range(3, 30):
            K = a2c_class(a, c, 2, 2 * c - 4, 2 * (c - 2))
            P0 = p0(a, c, 2)
            if K > P0:
                bad.append((a, c))
            if K == P0:
                eq.append((a, c))
    return val(e, f"$(a,c)={tup(eq[0])}$") + [(bad == [] and eq == [(2, 3)],
                                               "K(1,2) <= P_0(2), equality only at (2,3), "
                                               "a < 16, c < 30")]


def colone_e(nu: int, c: int) -> list:
    """e_j = p^{(2h)}_j - (coefficient of l_j in K(1,nu)), mu = 1, h = floor(nu/2)."""
    h = nu // 2
    out = []
    for j in range(c + 1):
        p = sum(comb(j - i, 0) for i in range(h, min(2 * h, j) + 1))
        k = 0
        if nu <= j <= min(2 * nu, c):
            k += 2 * nu - j + 1                      # u(2 nu - j) with mu = 1
        if j == nu:
            k += 1
        if j == nu + 1:
            k -= 1
        out.append(p - k)
    return out


@reg("s6-colone-nu2-e")
def _(e):
    ev = colone_e(2, 12)
    return val(e, f"$e_1={ev[1]}$, $e_2={ev[2]}$, $e_3={ev[3]}$, $e_4={ev[4]}$") + [
        (all(ev[j] == 2 for j in range(5, 13)) and ev[0] == 0, "e_0 = 0, e_j = 2 for "
                                                                 "5 <= j <= c")]


@reg("s6-colone-nu2-E")
def _(e):
    ev = colone_e(2, 12)
    E1, E2 = [], []
    for v in ev:
        E1.append((E1[-1] if E1 else 0) + v)
        E2.append((E2[-1] if E2 else 0) + E1[-1])
    return val(e, "$E_1=" + ",".join(map(str, E1[:4])) + "$ and $E_2=" +
               ",".join(map(str, E2[:4])) + "$") + [
        (all(E1[J] >= 1 and E2[J] >= 1 for J in range(4, 13)), "both >= 1 for 4 <= J <= c")]


def sha256_of(rel: str) -> str:
    with open(os.path.join(ROOT, rel), "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


@reg("appA-sha-certificate")
def _(e):
    return val(e, sha256_of("notes/r7-scripts/proof-golden/lemmaB_certificate.py"))


@reg("appA-sha-core")
def _(e):
    return val(e, sha256_of("notes/r7-scripts/proof-golden/a2c_core.py"))


# ---------------------------------------------------------------------------------------------
# (b.6) Section 7: uniform contents (Theorem H, Propositions 7.x, C1, C4)
# ---------------------------------------------------------------------------------------------


def uni(n: int, k: int) -> tuple:
    return (n,) * k


@lru_cache(maxsize=None)
def ezu(n: int, k: int) -> int:
    return ez(uni(n, k))


@lru_cache(maxsize=None)
def zsu(n: int, k: int, u: int) -> int:
    """|Z_k(S_u)| for (n^k)."""
    return z_relaxed(uni(n, k), u)


def rk(n: int, k: int, u: int) -> Fraction:
    return Fraction(zsu(n, k, u), ezu(n, k))


def rk_p(n: int, k: int, p: int) -> Fraction:
    """r_k({A}) for one projection with A_1 = p."""
    return Fraction(ins_from(uni(n, k), {p: 1}), ezu(n, k))


def proj_set(n: int, u: int) -> list:
    return profiles(n, n, u)


@lru_cache(maxsize=None)
def sandwich_ok(nmax: int, kmax: int) -> bool:
    """Theorem H(ii) for every one-projection S = {A}, A_1 = p <= n-1 (every S is a positive
    combination of these): r_{2i+1} <= r_k <= r_{2i} for k >= 2i, equality only at k = 2i+1,
    respectively k = 2i."""
    for n in range(1, nmax + 1):
        for p in range(n):
            r = {k: rk_p(n, k, p) for k in range(2, kmax + 1)}
            for i in range(1, kmax // 2 + 1):
                for k in range(2 * i, kmax + 1):
                    if 2 * i + 1 <= kmax:
                        if not (r[2 * i + 1] <= r[k]) or (r[2 * i + 1] == r[k]) != (k == 2 * i + 1):
                            return False
                    if not (r[k] <= r[2 * i]) or (r[k] == r[2 * i]) != (k == 2 * i):
                        return False
    return True


@reg(["s1-H-sandwich", "s7-H-ii-chain"])
def _(e):
    latex = ("r_3<r_5<r_7<\\cdots<r_6<r_4<r_2" if e["id"] == "s1-H-sandwich" else
             "r_3(\\mathcal S)<r_5(\\mathcal S)<r_7(\\mathcal S)<\\cdots<r_6(\\mathcal S)<"
             "r_4(\\mathcal S)<r_2(\\mathcal S)")
    return lit(e, latex, (sandwich_ok(6, 16), "the sandwich for n <= 6, k <= 16, every A_1"),
               (sandwich_ok(1, 40), "and for n = 1, k <= 40"))


@lru_cache(maxsize=None)
def n2_oneend(kmax: int) -> dict:
    out = {}
    for k in range(3, kmax + 1):
        for u in range(4):
            out[(k, u)] = rk(2, k, u)
    return out


def n2_ok(kmax: int = 60) -> tuple:
    d = n2_oneend(kmax)
    lim = Fraction(50, 53)
    ok = all(v <= lim for v in d.values()) and [ku for ku, v in d.items() if v == lim] == [(4, 2)]
    return (ok, f"r_k(S_u) <= 50/53 for 3 <= k <= {kmax}, 0 <= u <= 3, equality only at "
                f"(k,u) = (4,2)")


@reg(["s1-H-50-53", "s7-H-iii-5053", "s7-ntwo-5053"])
def _(e):
    return lit(e, "\\frac{50}{53}", n2_ok())


@reg("s8-oneend-5053-slash")
def _(e):
    return lit(e, "50/53", n2_ok())


@reg("fig8-r4-n2")
def _(e):
    return val(e, f"r_4={rk(2, 4, 2)}") + [n2_ok()]


@reg("s7-C1-5053")
def _(e):
    return lit(e, "$r_k(\\mathcal S_2)\\le50/53$", n2_ok())


@reg("s7-H-iii-eq")
def _(e):
    return lit(e, "with equality only for $k=4$ and area $2$ at the relaxed edge", n2_ok())


@reg("s7-ntwo-final")
def _(e):
    d = n2_oneend(60)
    ok = all(d[(k, u)] <= d[(4, u)] for k in range(3, 61) for u in range(4))
    return lit(e, "$r_k(\\mathcal S_u)\\le r_4(\\mathcal S_u)\\le50/53$",
               (ok, "r_k(S_u) <= r_4(S_u), 3 <= k <= 60"), n2_ok())


@reg("s7-ntwo-areas")
def _(e):
    return val(e, "$\\abs{Z_4(\\mathcal S_u)}=" + ",".join(str(zsu(2, 4, u)) for u in range(4)) +
               "$")


@reg("s7-ntwo-values")
def _(e):
    z00 = ins_from(uni(2, 4), {0: 1})
    z11 = ins_from(uni(2, 4), {1: 1})
    pm = [m for x, h, m in pmx_all(uni(2, 4)) if x[1:] == (0, 4)]
    return val(e, f"$\\abs{{Z_4(\\{{(0,0)\\}})}}={z00}$, $\\abs{{Z_4(\\{{(1,1)\\}})}}={z11}$ and "
                  f"$\\abs{{Z_4}}={ezu(2, 4)}$") + [
        (kern_count(2, 4, 0) == z00 and kern_count(2, 4, 1) == z11 and
         kern_count(2, 4, 2) == ezu(2, 4), "Proposition 7.3 gives the same three values"),
        (sorted(pm) == sorted([zsu(2, 4, u) for u in range(4)] + [ezu(2, 4)]),
         "the fibres (u,0,4) of (2^4) by PMX")]


@reg("s7-221-identity")
def _(e):
    ok = True
    for N in range(2, 401):
        s1 = sum(comb(N - r + 4, 4) for r in range(1, N + 1))
        s2 = sum(comb(r + 1, 2) * comb(N - r + 2, 2) for r in range(1, N + 1))
        ok &= s1 == s2 == comb(N + 4, 5)
    return lit(e, "\\binom{N'+4}{5}", (ok, "both sums equal C(N'+4, 5) for 2 <= N' <= 400"))


@lru_cache(maxsize=None)
def end221() -> dict:
    tails = [t for k in range(4, 8) for t in product((1, 2, 3), repeat=k - 3)]
    best = None
    all_gt = True
    for t in tails:
        n = (2, 2, 1) + t
        z = ez(n)
        zs = z_relaxed(n, 2)
        all_gt &= zs > z
        if best is None or Fraction(zs, z) < Fraction(best[1], best[2]):
            best = (n, zs, z)
    return {"n": len(tails), "best": best, "all_gt": all_gt}


@reg("s7-221-ratio")
def _(e):
    d = end221()
    n, zs, z = d["best"]
    return val(e, f"${zs}/{z}$") + [(d["all_gt"], "|Z*| > |Z(n)| on every tail"),
                                    (True, f"attained at {n}; in lowest terms "
                                           f"{Fraction(zs, z)}")]


@reg("s7-221-tails")
def _(e):
    return val(e, f"${end221()['n']}$")


@reg("s7-transfer")
def _(e):
    ok = all(kern_count(n, k, p) == ins_from(uni(n, k), {p: 1})
             for n in range(1, 5) for k in range(2, 13) for p in range(n + 1))
    return lit(e, "(nk)!\\int_0^1\\vartheta_{A_1}(v)\\,g_k(v)\\,dv",
               (ok, "Proposition 7.3 (KERN, exact) = INS for n <= 4, k <= 12, every A_1"))


@reg("s7-cor77-Z3")
def _(e):
    return lit(e, "\\binom{2n}{n}", (all(ezu(n, 3) == comb(2 * n, n) for n in range(1, 12)),
                                     "|Z_3| = C(2n,n), n <= 11"))


@reg("s7-cor77-k3")
def _(e):
    ok = all(ins_from(uni(n, 3), {p: 1}) == comb(n + p, n) for n in range(1, 10)
             for p in range(n + 1))
    return lit(e, "\\binom{n+A_1}{n}", (ok, "n <= 9, every A_1, by INS"),
               (all(kern_count(n, 3, p) == comb(n + p, n) for n in range(1, 6)
                    for p in range(n + 1)), "and by KERN"))


@reg("s7-cor77-k2")
def _(e):
    ok = all(ins_from(uni(n, 2), {p: 1}) == 1 for n in range(1, 8) for p in range(n + 1))
    mw = True
    for n in range(1, 7):
        for u in range(n * n + 1):
            words = sum(1 for A in combinations_with_replacement(range(n + 1), n) if sum(A) == u)
            mw &= zsu(n, 2, u) == words == len(proj_set(n, u))
    return lit(e, "$\\abs{Z_2(\\{A\\})}=1$", (ok, "INS"), (mw, "|Z_2(S_u)| = the Mann-Whitney "
                                                             "frequency, n <= 6"))


def partitions_count(u: int) -> int:
    p = [1] + [0] * u
    for part in range(1, u + 1):
        for s in range(part, u + 1):
            p[s] += p[s - part]
    return p[u]


@reg("s7-overlap-k3")
def _(e):
    ok = all(zsu(n, 3, u) == partitions_count(u) + (n if u == n else 0)
             for n in range(1, 9) for u in range(n + 1))
    P = {n: psi_table(n, n, n) for n in range(1, 6)}
    rev = all(zsu(n, 3, u) == P[n][n * n - u][n * n] for n in range(1, 6) for u in range(n * n))
    return lit(e, "that number plus $n$ if $u=n$", (ok, "|Z_3(S_u)| = p(u) (+ n if u = n), "
                                                       "n <= 8"),
               (rev, "= the fibre (n^2-u, n^2) of (n,n,n) by PSI, n <= 5"))


@reg("s7-gshape-deg")
def _(e):
    ok = all(len(kern_g(n, k)) - 1 == n * (k - 2) for n in range(1, 6) for k in range(2, 12))
    return val(e, "$n(k-2)$") + [(ok, "deg g_k = n(k-2), n <= 5, k <= 11")]


@reg("s7-gshape-lead")
def _(e):
    ok = True
    for n in range(1, 6):
        for k in range(2, 10):
            g = list(kern_g(n, k))
            d, al = len(g) - 1, g[-1]
            Kg = list(kern_g(n, k + 2))
            want = Fraction(al * (-1) ** n * n, factorial(n - 1) * factorial(n) * (2 * n + d) *
                            (n + d))
            ok &= len(Kg) - 1 == 2 * n + d and Kg[-1] == want
    pos = all(p_eval(list(kern_g(n, k)), Fraction(t, 10)) > 0 for n in range(1, 5)
              for k in range(2, 10) for t in range(1, 11))
    zero = all(p_eval(list(kern_g(n, k)), 0) == 0 for n in range(1, 5) for k in range(3, 10))
    return lit(e, "\\frac{\\alpha(-1)^nn}{(n-1)!\\,n!\\,(2n+d)(n+d)}",
               (ok, "the leading coefficient of K g, n <= 5, k <= 9"),
               (pos and zero, "g_k > 0 on (0,1] (sampled) and g_k(0) = 0 for k >= 3"))


@reg("s7-cp")
def _(e):
    ok = True
    for n in range(1, 7):
        for p in range(n + 1):
            cp = Fraction(factorial(n) * factorial(n - 1), factorial(p) * factorial(2 * n - 1 - p))
            for t in range(1, 10):
                v = Fraction(t, 10)
                ok &= p_eval(theta(n, p), v) == \
                    cp * ((1 - v) / v) ** (n - p) * p_eval(theta(n, n), v)
    return lit(e, "c_p=\\frac{n!\\,(n-1)!}{p!\\,(2n-1-p)!}", (ok, "theta_p / theta_n at nine "
                                                                  "points, n <= 6"))


@reg("s7-n1-formula")
def _(e):
    E = euler_numbers(40)
    ok = all(ins_from(uni(1, k), {0: 1}) == k * E[k - 1] - E[k] for k in range(2, 31))
    return lit(e, "k\\Euler{k-1}-\\Euler{k}", (ok, "|Z_k({(0)})| = kE_{k-1} - E_k, k <= 30 (INS)"),
               (all(ezu(1, k) == E[k] for k in range(2, 31)), "|Z_k| = E_k"))


def atan_bounds(xinv: int, terms: int) -> tuple:
    """Bounds on arctan(1/xinv) from the alternating series (exact Fractions)."""
    s = Fraction(0)
    for i in range(terms):
        s += Fraction((-1) ** i, (2 * i + 1) * xinv ** (2 * i + 1))
    nxt = Fraction(1, (2 * terms + 1) * xinv ** (2 * terms + 1))
    return (s, s + nxt) if terms % 2 == 0 else (s - nxt, s)


def pi_bounds() -> tuple:
    a_lo, a_hi = atan_bounds(5, 60)
    b_lo, b_hi = atan_bounds(239, 30)
    return 16 * a_lo - 4 * b_hi, 16 * a_hi - 4 * b_lo


@lru_cache(maxsize=None)
def n1_limit_ok() -> bool:
    lo, hi = pi_bounds()
    Llo, Lhi = lo / 2 - 1, hi / 2 - 1
    ok = Lhi - Llo < Fraction(1, 10 ** 60)
    for k in range(3, 62):
        r = Fraction(ins_from(uni(1, k), {0: 1}), ezu(1, k))
        ok &= (r < Llo) if k % 2 else (r > Lhi)
    return ok


@reg(["s7-n1-limit", "s7-que-n1"])
def _(e):
    return lit(e, "$\\pi/2-1$", (n1_limit_ok(), "odd r_k < pi/2 - 1 < even r_k, 3 <= k <= 61, "
                                               "pi bracketed by Machin's series (consistency of "
                                               "the known limit)"))


@reg("s8-n1-limit")
def _(e):
    return lit(e, "\\pi/2-1", (n1_limit_ok(), "odd r_k < pi/2 - 1 < even r_k, 3 <= k <= 61"))


@reg("s7-n1-limits")
def _(e):
    return lit(e, "$\\rodd=\\reven=\\pi/2-1$", (n1_limit_ok(), "consistency of the known limits"),
               (sandwich_ok(1, 40), "the n = 1 sandwich, k <= 40"))


def partitions_of(n: int, maxpart: int | None = None):
    maxpart = n if maxpart is None else maxpart
    if n == 0:
        yield ()
        return
    for first in range(min(n, maxpart), 0, -1):
        for rest in partitions_of(n - first, first):
            yield (first,) + rest


def r3_terms(n: int) -> list:
    """C(2n - kappa_1, n) for the partitions kappa of n in reverse lexicographic order."""
    return sorted((comb(2 * n - kap[0], n) for kap in partitions_of(n)))


@lru_cache(maxsize=None)
def r3(n: int) -> Fraction:
    """sum over the partitions of n of C(2n - kappa_1, n) / C(2n, n), grouped by kappa_1."""
    p_le = [[0] * (n + 1) for _ in range(n + 1)]          # p_le[m][s]: parts <= m, sum s
    for m in range(n + 1):
        p_le[m][0] = 1
        for s in range(1, n + 1):
            p_le[m][s] = p_le[m - 1][s] + (p_le[m][s - m] if m and s >= m else 0) if m else 0
    tot = sum((p_le[m][n] - p_le[m - 1][n]) * comb(2 * n - m, n) for m in range(1, n + 1))
    return Fraction(tot, comb(2 * n, n))


def L_n(n: int) -> Fraction:
    return Fraction(1, 2) + Fraction((n // 2) * (n - 1), 2 * (2 * n - 1))


@reg("s7-r3-formula")
def _(e):
    ok = all(r3(n) == rk(n, 3, n * n - n) for n in range(1, 13))
    return lit(e, "\\sum_{\\kappa\\vdash n}\\binom{2n-\\kappa_1}{n}\\big/\\binom{2n}{n}",
               (ok, "= |Z_3(S_{n^2-n})| / |Z_3| by INS, n <= 12"))


@reg("s7-r3-n4")
def _(e):
    ok = all((r3(n) > 1) == (n >= 4) for n in range(1, 51))
    return val(e, "$n\\ge4$") + [(ok, "r_3(n) > 1 iff n >= 4, n <= 50")]


@reg("s7-r3-n6")
def _(e):
    ok = all((L_n(n) > 1) == (n >= 6) for n in range(1, 51))
    lt2 = all(sum(Fraction(comb(2 * n - kap[0], n), comb(2 * n, n)) for kap in partitions_of(n)
                  if kap[0] <= 2) == L_n(n) for n in range(1, 21))
    return val(e, "$n\\ge6$") + [(ok, "L(n) > 1 iff n >= 6, n <= 50"),
                                 (lt2, "L(n) = the terms with kappa_1 <= 2, n <= 20")]


@reg("s7-r3-values")
def _(e):
    return val(e, ", ".join(f"$r_3({n})={r3(n)}$" for n in range(1, 5)) +
               f" and $r_3(5)={r3(5)}$")


@reg("s7-r3-3")
def _(e):
    return val(e, f"$r_3(3)={r3(3)}$") + [(r3(3) == rk(3, 3, 6), "= r_3(S_6) by INS")]


@reg("s7-r3-L")
def _(e):
    return lit(e, "L(n)=1/2+\\floor{n/2}(n-1)/(2(2n-1))",
               (all(L_n(n) == Fraction(1, 2) + Fraction(comb(2 * n - 2, n), comb(2 * n, n)) *
                    (n // 2) for n in range(2, 51)), "C(2n-2,n)/C(2n,n) = (n-1)/(2(2n-1))"))


@reg("s7-r3-L45")
def _(e):
    return val(e, f"$L(4)={L_n(4)}$, $L(5)={L_n(5)}$")


@reg("s7-r3-binoms")
def _(e):
    return val(e, "$\\binom{2n}{n}=" + ",".join(str(comb(2 * n, n)) for n in range(1, 6)) + "$")


@reg("s7-r3-sums")
def _(e):
    sums = [Fraction(sum(r3_terms(n)), comb(2 * n, n)) for n in range(1, 6)]
    raw5 = f"{sum(r3_terms(5))}/{comb(10, 5)}"
    return val(e, ", ".join(f"${s}$" for s in sums[:3]) + f", ${sums[3]}$ and ${raw5}={sums[4]}$")


@reg("s7-r3-terms")
def _(e):
    return val(e, "; ".join("$" + ",".join(map(str, r3_terms(n))) + "$" for n in range(1, 6)))


S6 = ((0, 3, 3), (1, 2, 3), (2, 2, 2))


@reg("s7-n3-S6")
def _(e):
    s = proj_set(3, 6)
    return val(e, "\\{" + ",".join(tup(A) for A in s) + "\\}") + [(tuple(s) == S6,
                                                                   "the projections of area 6")]


@reg(["s7-n3-Z5", "s7-35-Z5"])
def _(e):
    return val(e, f"$\\abs{{Z_5}}={ezu(3, 5)}$") + [(kern_count(3, 5, 3) == ezu(3, 5), "KERN")]


@reg("s7-n3-Z7")
def _(e):
    return val(e, f"$\\abs{{Z_7}}={ezu(3, 7)}$") + [(kern_count(3, 7, 3) == ezu(3, 7), "KERN")]


@reg("s7-n3-Z7S6")
def _(e):
    z = zsu(3, 7, 6)
    k = sum(kern_count(3, 7, A[0]) for A in S6)
    return val(e, f"$\\abs{{Z_7(\\mathcal S_6)}}={z}$") + [(k == z, "KERN"),
                                                            (z > ezu(3, 7), "r_7(S_6) > 1")]


@reg("s7-n3-Z4")
def _(e):
    return val(e, f"\\abs{{Z_4}}={ezu(3, 4)}")


@reg("s7-n3-r4")
def _(e):
    z, Z = zsu(3, 4, 6), ezu(3, 4)
    return val(e, f"\\abs{{Z_4(\\mathcal S_6)}}={z}") + [(z > Z, "r_4(S_6) > 1")]


@reg("s7-n3-r5")
def _(e):
    z, Z = zsu(3, 5, 6), ezu(3, 5)
    return val(e, f"$r_5(\\mathcal S_6)={z}/{Z}<1$") + [(z < Z, "< 1")]


@reg("s7-35-nine")
def _(e):
    v = [zsu(3, 5, u) for u in range(9)]
    pm = sorted(m for x, h, m in pmx_all(uni(3, 5)) if x[1:] == (0, 9, 0) and x[0] < 9)
    return val(e, dollars(v)) + [(pm == sorted(v), "= the fibres (u,0,9,0) of (3^5) by PMX")]


@reg("s7-35-below")
def _(e):
    v = [zsu(3, 5, u) for u in range(9)]
    return val(e, f"${ezu(3, 5)}$") + [(max(v) < ezu(3, 5), "all one-end relaxations below "
                                                            "|Z_5|")]


@lru_cache(maxsize=None)
def twoend_35() -> dict:
    rel = [None] + alt_rel(5)[1:-1] + [None]
    d = down_count(uni(3, 5), rel, track=(0, 3))
    return d


@reg(["s7-n3-6093", "s7-722-fibre"])
def _(e):
    d = twoend_35()
    best = max(d.values())
    at = sorted(k for k, v in d.items() if v == best)
    cls = pmx_fibre(uni(3, 5), (6, 0, 9, 3))
    if e["id"] == "s7-n3-6093":
        return val(e, f"${d[(6, 3)]}$") + [(d[(6, 3)] > ezu(3, 5), "more than |Z_5|"),
                                           (len(cls) == 1 and cls[0][1] == d[(6, 3)],
                                            "one class, by PMX")]
    return val(e, "$(6,0,9,3)$") + [(at == [(6, 3)], "the largest fibre (u,0,9,u') of (3^5), "
                                                     "Z_5 included")]


@reg("s7-722-mirror")
def _(e):
    cls = pmx_fibre(uni(3, 5), (3, 9, 0, 6))
    return val(e, "$(3,9,0,6)$") + [(len(cls) == 1 and cls[0][1] == twoend_35()[(6, 3)],
                                     "one class of the same size, by PMX")]


def k722() -> int:
    return 40 if ext() else 20


@reg(["s7-722-u6", "s7-722-range", "s7-722-modes"])
def _(e):
    K = k722()
    ok = all(max(range(9), key=lambda u: zsu(3, k, u)) == 6 and
             sorted(zsu(3, k, u) for u in range(9))[-1] > sorted(zsu(3, k, u) for u in range(9))[-2]
             for k in range(3, K + 1))
    want = {"s7-722-u6": "exactly at $u=6$", "s7-722-range": "$3\\le k\\le40$",
            "s7-722-modes": "$k\\le20$ by default, $k\\le40$ with \\texttt{-{}-full}"}[e["id"]]
    res = lit(e, want, (ok, f"r_k(S_u) largest exactly at u = 6, 3 <= k <= {K}"))
    if e["id"] != "s7-722-u6":
        res.append((K == 40 or not ext(), "the full range is k <= 40"))
    return res


@lru_cache(maxsize=None)
def classes_33() -> dict:
    cl = tern_lit(3, 3, 3)
    top = max(cl.values())
    at = sorted(k for k, v in cl.items() if v == top)
    return {"words": sum(cl.values()), "n": len(cl), "top": top, "at": at,
            "pm": len(pmx_all((3, 3, 3)))}


@reg("s7-33-words")
def _(e):
    return val(e, f"${classes_33()['words']}$")


@reg("s7-33-classes")
def _(e):
    d = classes_33()
    return val(e, f"${d['n']}$") + [(d["pm"] == d["n"], "= the Parikh-matrix classes (PMX)")]


@reg("s7-33-top")
def _(e):
    d = classes_33()
    return val(e, f"${d['top']}=\\abs{{Z_3}}=\\binom63$") + [(d["top"] == ezu(3, 3) == comb(6, 3),
                                                             "= |Z_3| = C(6,3)")]


@reg("s7-33-six")
def _(e):
    return val(e, f"exactly {WORDS_NUM[len(classes_33()['at'])]} classes")


@reg("s7-33-list")
def _(e):
    at = classes_33()["at"]
    alt = {(9, 0, 0), (0, 9, 0)}
    rest = [k for k in at if k not in alt]
    order = sorted(rest, key=lambda k: (-k[0], k[2]))
    return val(e, "$(x,y,z)=" + tup(order[0]) + "$, " +
               ", ".join(f"${tup(k)}$" for k in order[1:])) \
        + [(alt <= set(at), "Z_3 and Z'_3 are among them")]


@lru_cache(maxsize=None)
def twoend_2k(k: int) -> dict:
    rel = [None] + alt_rel(k)[1:-1] + [None]
    return down_count(uni(2, k), rel, track=(0, k - 2))


def twoend_best(k: int) -> tuple:
    d = twoend_2k(k)
    altB = 4 if (k - 2) % 2 == 0 else 0
    rel = {ab: v for ab, v in d.items() if ab[0] != 4 and ab[1] != altB}
    best = max(rel.values())
    return best, sorted(ab for ab, v in rel.items() if v == best)


@reg(["s7-twoend-range", "s8-twoend-lose-range", "s7-twoend-modes"])
def _(e):
    K = 12
    ok = True
    for k in range(4, K + 1):
        best, at = twoend_best(k)
        ok &= best < ezu(2, k) and at == [(2, 2)]
    want = {"s7-twoend-range": "$4\\le k\\le12$", "s8-twoend-lose-range": "4\\le k\\le12",
            "s7-twoend-modes": "$k\\le9$ by default, $k\\le12$ with \\texttt{-{}-full}"}[e["id"]]
    return lit(e, want, (ok, "the largest two-end relaxation of (2^k) has area 2 at both ends and "
                             "fewer words than Z_k, 4 <= k <= 12 (DOWN; Z'_k by reversal)"))


@reg("s7-twoend-values")
def _(e):
    b4, b5 = twoend_best(4)[0], twoend_best(5)[0]
    return val(e, f"${b4}<{ezu(2, 4)}$ for $k=4$ and ${b5}<{ezu(2, 5)}$ for $k=5$")


@reg(["s7-twoend-classes", "s7-twoend-k3", "s8-twoend-tie-k3"])
def _(e):
    cl = tern_lit(2, 2, 2)
    c22 = sorted(k for k in cl if k[:2] == (2, 2))
    sizes = {cl[k] for k in c22}
    if e["id"] == "s7-twoend-classes":
        return val(e, "$(x,y,z)=" + tup(c22[0]) + "$ and $" + tup(c22[1]) + "$")
    if e["id"] == "s7-twoend-k3":
        (s,) = sizes
        return val(e, f"${s}=\\abs{{Z_3}}$") + [(s == ezu(2, 3), "a tie with |Z_3|")]
    return val(e, "k=3") + [(sizes == {ezu(2, 3)}, "both classes tie with |Z_3| at k = 3")]


def bracket(fr_lo: Fraction, fr_hi: Fraction, digits: int) -> str:
    lo, hi = trunc_dec(fr_lo, digits), ceil_dec(fr_hi, digits)
    return f"({dec_round(lo, digits)},{dec_round(hi, digits)})"


def r_S(n: int, k: int, S) -> Fraction:
    return Fraction(sum(ins_from(uni(n, k), {A[0]: 1}) for A in S), ezu(n, k))


@reg("s7-br-n2")
def _(e):
    S2 = proj_set(2, 2)
    r59, r60 = r_S(2, 59, S2), r_S(2, 60, S2)
    return val(e, f"$(r_{{59}},r_{{60}})\\subset{bracket(r59, r60, 9)}$") + [
        (r59 < r60, "r_59 < r_60"), (r59 == rk(2, 59, 2), "S_2 = the area-2 projections")]


@reg("s7-br-n3a")
def _(e):
    r15, r14 = r_S(3, 15, S6), r_S(3, 14, S6)
    return val(e, f"$(r_{{15}},r_{{14}})\\subset{bracket(r15, r14, 9)}$") + [(r15 < r14,
                                                                             "r_15 < r_14")]


@reg("s7-br-n3b")
def _(e):
    r29, r30 = r_S(3, 29, S6), r_S(3, 30, S6)
    return val(e, f"$(r_{{29}},r_{{30}})\\subset{bracket(r29, r30, 10)}$") + [(r29 < r30,
                                                                              "r_29 < r_30")]


@reg("s7-br-k30")
def _(e):
    ok = all(kern_count(3, k, 3) == ezu(3, k) for k in (29, 30))
    return lit(e, "up to $k=30$", (ok, "|Z_29|, |Z_30| of (3^k) by KERN = INS"))


@reg("s7-C1-bracket")
def _(e):
    S2 = proj_set(2, 2)
    return val(e, "$" + bracket(r_S(2, 59, S2), r_S(2, 60, S2), 9) + "$")


@reg("fig8-r2")
def _(e):
    vals_ = [r_S(n, 2, proj_set(n, n * n - n)) for n in (2, 3, 4)]
    return val(e, and_list([f"${v}$" for v in vals_]))


@reg("fig8-r3-n4")
def _(e):
    return val(e, f"$r_3={r_S(4, 3, proj_set(4, 12))}$") + [
        (all(r_S(4, k, proj_set(4, 12)) > 1 for k in range(3, 16)), "r_k > 1 for 3 <= k <= 15")]


@reg("fig8-n3")
def _(e):
    r = {k: r_S(3, k, S6) for k in range(2, 16)}
    above = [k for k in range(3, 16) if r[k] > 1]
    return val(e, "$r_3,r_5<1<r_k$ for $k=4$ and $6\\le k\\le 15$") + [
        (r[3] < 1 and r[5] < 1 and above == [4] + list(range(6, 16)),
         f"n = 3: r_k > 1 exactly for k in {above}")]


@reg("fig8-range")
def _(e):
    src = read(os.path.join(PAPER, "figures", "fig8.tex"))
    rows = fig_tables()["fig8_r.dat"][1]
    return lit(e, "$3\\le k\\le 15$",
               (src.count("restrict x to domain=3:15") == 3 and rows[-1][0] == "15",
                "fig8.tex plots the three series on 3 <= k <= 15; the data reach k = 15"))


# The permutations (1^k)

@lru_cache(maxsize=None)
def perm_data(kmax: int = 8) -> dict:
    E = euler_numbers(kmax)
    out = {}
    for k in range(2, kmax + 1):
        cl = pmx_all((1,) * k)
        fib_n = Counter(x for x, h, m in cl)
        top = cl[0][2]
        at = sorted(x for x, h, m in cl if m == top)
        out[k] = {"determines": all(v == 1 for v in fib_n.values()) and len(fib_n) == 2 ** (k - 1),
                  "top": top, "at": at, "E": E[k],
                  "alt": sorted({alt_psi2((1,) * k, True), alt_psi2((1,) * k, False)})}
    return out


@reg(["s1-perm-Ek", "s1-tab-Ek"])
def _(e):
    d = perm_data()
    ok = all(v["determines"] and v["top"] == v["E"] and v["at"] == v["alt"] for v in d.values())
    latex = "$\\Euler{k}$"
    return lit(e, latex, (ok, "(1^k), 2 <= k <= 8: psi_2 determines the matrix, the largest class "
                              "has E_k words, exactly at the two alternating vectors"))


@reg("s1-perm-E5")
def _(e):
    d = perm_data()[5]
    return val(e, str(d["top"])) + [(d["top"] == euler_numbers(5)[5], "= E_5")]


@reg("s1-perm-alternating-vectors")
def _(e):
    d = perm_data()[5]
    return val(e, " and ".join(f"${tup(x)}$" for x in sorted(d["at"], reverse=True)))


# The central fibre of (2^k): Theorem H(i)

def realise(n, projs) -> list:
    """Lemma 2.2: a word with the projection projs[i] on edge i (letters 1..k)."""
    w = [1] * n[0]
    for i, A in enumerate(projs, start=1):
        pos_i = [p for p, ch in enumerate(w) if ch == i]
        inserts = []
        for t, At in enumerate(A):
            at = pos_i[At] if At < len(pos_i) else len(w)
            inserts.append((at, t))
        for at, t in sorted(inserts, key=lambda q: (q[0], -q[1]), reverse=True):
            w.insert(at, i + 1)
    return w


def proj_of(w, i: int) -> tuple:
    out, seen = [], 0
    for ch in w:
        if ch == i:
            seen += 1
        elif ch == i + 1:
            out.append(seen)
    return tuple(out)


PQ = {"P": (1, 1), "Q": (0, 2)}


def qp_set(label: str) -> frozenset:
    return frozenset(i for i in range(1, len(label)) if label[i - 1] == "Q" and label[i] == "P")


@lru_cache(maxsize=None)
def label_scan(k: int) -> dict:
    """Every label word of the central fibre of (2^k): realise a word, check its projections and
    the rule of Theorem H(i) for every entry with l - j >= 2; group by the QP set."""
    rule_ok = True
    entries_by_J: dict = defaultdict(set)
    for lab in product("PQ", repeat=k - 1):
        lab = "".join(lab)
        w = realise((2,) * k, [PQ[ch] for ch in lab])
        rule_ok &= all(proj_of(w, i + 1) == PQ[lab[i]] for i in range(k - 1))
        rule_ok &= all(occ(w, (i, i + 1)) == 2 for i in range(1, k))
        J = qp_set(lab)
        ent = []
        for j in range(1, k + 1):
            for l in range(j + 2, k + 1):
                v = occ(w, interval_word(j, l))
                want = 0 if any(j <= i <= l - 2 for i in J) else 2
                rule_ok &= v == want
                ent.append(v)
        entries_by_J[J].add(tuple(ent))
    distinct = all(len(s) == 1 for s in entries_by_J.values())
    nJ = len(entries_by_J)
    no_adj = all(not any(i in J and i + 1 in J for i in J) for J in entries_by_J)
    return {"ok": rule_ok and distinct and no_adj, "nJ": nJ,
            "distinct": len({next(iter(s)) for s in entries_by_J.values()}) == nJ}


def central_kmax() -> int:
    return 12 if ext() else 10


@reg(["s1-H-Fk", "s7-H-i-Fk"])
def _(e):
    K = central_kmax()
    ok = all(len(pmx_fibre((2,) * k, (2,) * (k - 1))) == fib(k) for k in range(2, K + 1))
    ok2 = all(label_scan(k)["nJ"] == fib(k) and label_scan(k)["distinct"] for k in range(2, 9))
    return lit(e, "$\\Fib{k}$", (ok, f"the central fibre of (2^k) has F_k classes, 2 <= k <= {K} "
                                     f"(PMX)"),
               (ok2, "the QP sets of the label words: F_k sets, distinct entries, k <= 8"))


@reg("s1-H-entries")
def _(e):
    return lit(e, "$0$ or $2$", (all(label_scan(k)["ok"] for k in range(2, 9)),
                                 "every entry with l - j >= 2 is 0 or 2 by the QP rule, every "
                                 "label word, k <= 8"))


@reg("s7-H-i-entries")
def _(e):
    return lit(e, "$\\cntr{j}{l}=0$ if $\\QP(w)$ meets $\\interval{j}{l-2}$, and $\\cntr{j}{l}=2$ "
                  "otherwise", (all(label_scan(k)["ok"] for k in range(2, 9)),
                                "the rule on a realised word of every label word, k <= 8"))


def theta_of(n, higher: tuple) -> frozenset:
    """The QP set of a central-fibre class from its higher entries (PMX order)."""
    k = len(n)
    idx = [(j, l) for j in range(k) for l in range(j + 2, k)]
    d = dict(zip(idx, higher))
    return frozenset(j + 1 for j in range(k - 2) if d[(j, j + 2)] == 0)


@lru_cache(maxsize=None)
def fprime(k: int) -> dict:
    n = (2,) * k
    cl = pmx_all(n)
    e = ezu(2, k)
    top = cl[0][2]
    tops = [(x, h) for x, h, m in cl if m == top]
    cent = [(theta_of(n, h), m) for h, m in pmx_fibre(n, (2,) * (k - 1))]
    return {"cl": cl, "e": e, "top": top, "tops": tops, "central": cent}


def jstr(J) -> str:
    return "\\emptyset" if not J else "\\{" + ",".join(map(str, sorted(J))) + "\\}"


@reg("s7-Fp-23")
def _(e):
    d = fprime(3)
    alt = {alt_psi2((2,) * 3, True), alt_psi2((2,) * 3, False)}
    cent_tops = sorted(jstr(J) for J, m in d["central"] if m == d["top"])
    others = [x for x, h in d["tops"] if x not in alt and x != (2, 2)]
    return val(e, f"${d['top']}$") + [(cent_tops == ["\\emptyset", "\\{1\\}"] and others == [] and
                                       len(d["tops"]) == 4 and d["top"] == d["e"],
                                       "(2^3): Z_3, Z'_3, Theta_{} and Theta_{1}, 6 words each")]


@reg("s7-Fp-24")
def _(e):
    d = fprime(4)
    return val(e, f"${d['top']}$") + [(all(x == (2, 2, 2) for x, h in d["tops"]) and
                                       len(d["tops"]) == 2, "two classes, in the central fibre")]


@reg(["s7-Fp-24Z", "s7-Fp-25Z"])
def _(e):
    k = 4 if "24" in e["id"] else 5
    return val(e, f"$\\abs{{Z_{k}}}={ezu(2, k)}$") + [(fprime(k)["top"] > ezu(2, k),
                                                      "the central classes beat Z_k")]


@reg("s7-Fp-24labels")
def _(e):
    d = fprime(4)
    Js = sorted((J for J, m in d["central"] if m == d["top"]), key=sorted)
    w = realise((2,) * 4, [PQ[ch] for ch in "QPQ"])        # QP set {1}
    rc = [5 - ch for ch in reversed(w)]
    lab = "".join("P" if proj_of(rc, i) == (1, 1) else "Q" for i in range(1, 4))
    return val(e, " and ".join(f"$\\Theta_{{{jstr(J)}}}$" for J in Js) +
               ", exchanged by the mirror map") + [
        (qp_set("QPQ") == frozenset({1}) and qp_set(lab) == frozenset({2}),
         "the mirror map (reverse-complement) maps Theta_{1} to Theta_{2}")]


@reg("s7-Fp-25")
def _(e):
    d = fprime(5)
    Js = [J for J, m in d["central"] if m == d["top"]]
    return val(e, f"${d['top']}$") + [(len(d["tops"]) == 1 and Js == [frozenset({2})],
                                       "one largest class, Theta_{2}")]


@reg("s7-Fp-698")
def _(e):
    c = sorted((m for J, m in fprime(5)["central"]), reverse=True)
    return val(e, f"${c[1]}$")


@reg(["s1-H-2k-lose", "s8-central-beats-k45"])
def _(e):
    lose = [k for k in range(3, 8) if fprime(k)["top"] > ezu(2, k)]
    return val(e, "k=" + ",".join(map(str, lose)))


@reg("s1-tab-2k-values")
def _(e):
    return val(e, f"${fprime(4)['top']}>{ezu(2, 4)}$, ${fprime(5)['top']}>{ezu(2, 5)}$")


def c1_ok(k: int, classes) -> tuple:
    """C1 at k from a list of (size, psi_2) of every class with at least R_k words."""
    n = (2,) * k
    e, R = ezu(2, k), zsu(2, k, 2)
    alt = sorted({alt_psi2(n, True), alt_psi2(n, False)})
    Z, Zp = alt_psi2(n, True), alt_psi2(n, False)
    endrel = sorted({(2,) + Z[1:], Z[:-1] + (2,), (2,) + Zp[1:], Zp[:-1] + (2,)})
    top = sorted(x for s, x in classes if s >= e)
    sizes_top = {s for s, x in classes if s >= e}
    rest = sorted((s for s, x in classes if s < e), reverse=True)
    second = sorted(x for s, x in classes if s < e and s == (rest[0] if rest else -1))
    ok = top == alt and sizes_top == {e} and rest and rest[0] == R and second == endrel
    return ok, (f"(2^{k}): only Z_k, Z'_k have >= |Z_k| = {e} words, and the second largest are "
                f"exactly the four one-end relaxations with area 2 ({R} words)")


@lru_cache(maxsize=None)
def c1_own(k: int) -> tuple:
    cl = pmx_all((2,) * k)
    return c1_ok(k, [(m, x) for x, h, m in cl])


def c1_partial(e) -> list:
    return [c1_own(6), c1_own(7)]


@reg(["s9-t-SW-C1"])
def _(e):
    return lit(e, "k\\le7", c1_own(6), c1_own(7))


def c4_rule(n) -> str:
    if n in ((2,) * 4, (2,) * 5) or n[:3] == (2, 2, 1) or n[-3:] == (1, 2, 2):
        return "BEATEN"
    return "ALT"


def c4_reps(k: int) -> list:
    reps, seen = [], set()
    for n in product((1, 2), repeat=k):
        if tuple(reversed(n)) in seen:
            continue
        seen.add(n)
        reps.append(n)
    return reps


@lru_cache(maxsize=None)
def c4_own(n) -> str:
    cl = pmx_all(n)
    e = ez(n)
    alt = {alt_psi2(n, True), alt_psi2(n, False)}
    alt_ok = all(sum(1 for x, h, m in cl if x == a) == 1 for a in alt)
    alt_sz = all(m == e for x, h, m in cl if x in alt)
    other = max((m for x, h, m in cl if x not in alt), default=0)
    assert alt_ok and alt_sz, n
    return "BEATEN" if other > e else ("TIE" if other == e else "ALT")


@lru_cache(maxsize=None)
def c4_own_scan(kmax: int) -> tuple:
    ok, counts = True, {}
    for k in range(4, kmax + 1):
        reps = c4_reps(k)
        kinds = Counter(c4_own(n) for n in reps)
        ok &= all(c4_own(n) == c4_rule(n) for n in reps)
        counts[k] = (len(reps), kinds["ALT"], kinds["BEATEN"], kinds["TIE"])
        ok &= kinds["TIE"] == 0
    return ok, counts


def c4_partial(e) -> list:
    ok, counts = c4_own_scan(6)
    return [(ok, f"partial: C4 for 4 <= k <= 6 by PMX, every class ({counts})")]


@reg("s9-t-SW-C4")
def _(e):
    ok, counts = c4_own_scan(5)
    return lit(e, "k\\le5", (ok, f"C4 for 4 <= k <= 5 by PMX ({counts})"))


@reg(["s1-tab-C4-exceptions", "s7-C4-exceptions"])
def _(e):
    beaten = [k for k in range(3, 8) if fprime(k)["top"] > ezu(2, k)]
    want = "$(2^4)$ or $(2^5)$" if e["id"] == "s1-tab-C4-exceptions" else "$(2^4)$ nor $(2^5)$"
    ok, _ = c4_own_scan(6)
    return lit(e, want, (beaten == [4, 5], "(2^4) and (2^5) are the uniform exceptions, k <= 7"),
               (ok, "C4 rule for 4 <= k <= 6"))


# The slow groups C1, C4 and PM: the computing functions of check_article2_data.py (MITM,
# SPLIT, the C4 classifier and its prefix-matrix DP), called here with this file's own
# acceptance logic.

_AD = {}


def AD():
    if "m" not in _AD:
        sys.path.insert(0, HERE)
        import check_article2_data as m          # noqa: E402  (computing functions only)
        _AD["m"] = m
    return _AD["m"]


_FULL: dict = {}


def c1_mitm(kmax: int = 12) -> dict:
    """C1 for 3 <= k <= kmax by MITM (every psi_2 fibre) and SPLIT (the classes of every fibre
    with >= R_k words and an entry 2; the others are single trace classes by Lemma 2.6)."""
    if "C1" in _FULL:
        return _FULL["C1"]
    from concurrent.futures import ProcessPoolExecutor
    m = AD()
    out = {}
    with ProcessPoolExecutor(max_workers=WORKERS) as pool:
        for k in range(3, kmax + 1):
            t0 = time.perf_counter()
            n = (2,) * k
            e, R = ezu(2, k), zsu(2, k, 2)
            big, total, nfib, best, best_x = m.mitm_all(n, R, pool)
            classes = [(s, x) for s, x in big if 2 not in x]
            jobs = [(n, x) for s, x in big if 2 in x]
            for x, sizes in pool.map(m.split_job, jobs, chunksize=4):
                classes += [(s, x) for s in sizes if s >= R]
            sound = total == multinomial(n) and nfib == 5 ** (k - 1)
            if k >= 6:
                ok, label = c1_ok(k, classes)
            else:
                ok, label = True, f"(2^{k}) (no C1 claim)"
            out[k] = (ok and sound, label + f"; MITM total {'ok' if sound else 'WRONG'}",
                      classes)
            note(f"C1 (2^{k}) by MITM + SPLIT: {'ok' if ok and sound else 'FAIL'}; "
                 f"{len(big)} fibres >= R; {time.perf_counter() - t0:.1f} s")
    _FULL["C1"] = out
    return out


def c1_full_checks(lo: int, hi: int) -> list:
    d = c1_mitm()
    return [(d[k][0], d[k][1] + " [MITM]") for k in range(lo, hi + 1)]


@reg(["abs-C1-range", "s9-t-AD-C1"], kind="full", group="C1", partial=c1_partial)
def _(e):
    return lit(e, "k\\le12", *c1_full_checks(6, 12))


@reg(["s1-H-2k-range", "s1-tab-2k-range", "s8-C1-range"], kind="full", group="C1",
     partial=c1_partial)
def _(e):
    return lit(e, "6\\le k\\le12", *c1_full_checks(6, 12))


@reg(["s7-Fp-range", "s7-C1-range"], kind="full", group="C1", partial=c1_partial)
def _(e):
    return lit(e, "$6\\le k\\le12$", *c1_full_checks(6, 12))


@reg("s9-onemethod-C1", kind="full", group="C1", partial=c1_partial)
def _(e):
    return lit(e, "10\\le k\\le12", *c1_full_checks(10, 12))


@reg("s7-Fp-C1modes", kind="full", group="C1", partial=c1_partial)
def _(e):
    return lit(e, "$k\\le9$ by default, $k\\le12$ with \\texttt{-{}-full}",
               *c1_full_checks(6, 12))


def pm_full() -> dict:
    """C1 for 3 <= k <= 9 and C4 for 4 <= k <= 8 from every Parikh class (the prefix-matrix DP
    of check_article2_data.py, independent of MITM and SPLIT)."""
    if "PM" in _FULL:
        return _FULL["PM"]
    m = AD()
    out = {"C1": {}, "C4": {}}
    for k in range(6, 10):
        t0 = time.perf_counter()
        by = m.pm_by_fibre((2,) * k)
        cls = [(s, x) for x, sizes in by.items() for s in sizes]
        out["C1"][k] = c1_ok(k, cls)
        note(f"PM (2^{k}): {len(cls)} classes; C1 {'ok' if out['C1'][k][0] else 'FAIL'}; "
             f"{time.perf_counter() - t0:.1f} s")
    for k in range(4, 9):
        t0 = time.perf_counter()
        reps = c4_reps(k)
        bad = []
        for n in reps:
            _, kind, e_, best, sound = m.pm_c4(n)
            if kind != c4_rule(n) or not sound or e_ != ez(n):
                bad.append(n)
        out["C4"][k] = (bad == [], f"C4 rule for all {len(reps)} contents with k = {k} [PM]")
        note(f"PM C4 k = {k}: {len(reps)} contents, {len(bad)} disagreements; "
             f"{time.perf_counter() - t0:.1f} s")
    _FULL["PM"] = out
    return out


@reg("s7-Fp-PM", kind="full", group="PM", partial=c1_partial)
def _(e):
    d = pm_full()["C1"]
    return lit(e, "confirms $k\\le9$ with \\texttt{-{}-full}", *[(d[k][0], d[k][1] + " [PM]")
                                                                 for k in range(6, 10)])


@reg("s9-twomethods-C1", kind="full", group="PM", partial=c1_partial)
def _(e):
    d = pm_full()["C1"]
    res = [(d[k][0], d[k][1] + " [PM]") for k in range(6, 10)]
    if group_on("C1"):
        res += c1_full_checks(6, 9)
    return lit(e, "k\\le9", *res)


@reg("s7-C4-PM", kind="full", group="PM", partial=c4_partial)
def _(e):
    d = pm_full()["C4"]
    return lit(e, "section [PM] recomputes $k\\le8$ from all classes",
               *[d[k] for k in range(4, 9)])


@reg("s9-twomethods-C4", kind="full", group="PM", partial=c4_partial)
def _(e):
    d = pm_full()["C4"]
    res = [d[k] for k in range(4, 9)]
    if group_on("C4"):
        res += c4_full_checks(4, 8)
    return lit(e, "k\\le8", *res)


def c4_full() -> dict:
    """C4 for 4 <= k <= 11 by the classifier of check_article2_data.py (MITM over the fibres with
    at least |Z(n)| words, SPLIT unless the fibre is one trace class)."""
    if "C4" in _FULL:
        return _FULL["C4"]
    from concurrent.futures import ProcessPoolExecutor
    m = AD()
    out = {}
    with ProcessPoolExecutor(max_workers=WORKERS) as pool:
        for k in range(4, 12):
            t0 = time.perf_counter()
            reps = c4_reps(k)
            res = list(pool.map(m.c4_classify, reps, chunksize=2))
            kinds = Counter(kind for _, kind, _, _ in res)
            bad = [n for n, kind, e_, _ in res if kind != c4_rule(n) or e_ != ez(n)]
            out[k] = {"n": len(reps), "kinds": kinds, "bad": bad}
            note(f"C4 k = {k}: {len(reps)} contents, ALT {kinds['ALT']}, not ALT "
                 f"{kinds['BEATEN']}, TIE {kinds['TIE']}, {len(bad)} disagreements; "
                 f"{time.perf_counter() - t0:.1f} s")
    _FULL["C4"] = out
    return out


def c4_full_checks(lo: int, hi: int) -> list:
    d = c4_full()
    return [(d[k]["bad"] == [] and d[k]["kinds"]["TIE"] == 0,
             f"C4 rule for all {d[k]['n']} contents with k = {k}, no tie [MITM]")
            for k in range(lo, hi + 1)]


@reg(["s1-tab-C4-range", "s8-C4-range"], kind="full", group="C4", partial=c4_partial)
def _(e):
    return lit(e, "4\\le k\\le11", *c4_full_checks(4, 11))


@reg("s7-C4-range", kind="full", group="C4", partial=c4_partial)
def _(e):
    return lit(e, "$4\\le k\\le11$", *c4_full_checks(4, 11))


@reg("s9-t-AD-C4", kind="full", group="C4", partial=c4_partial)
def _(e):
    return lit(e, "k\\le11", *c4_full_checks(4, 11))


@reg("s9-onemethod-C4", kind="full", group="C4", partial=c4_partial)
def _(e):
    return lit(e, "9\\le k\\le11", *c4_full_checks(9, 11))


@reg("s7-C4-modes", kind="full", group="C4", partial=c4_partial)
def _(e):
    return lit(e, "$k\\le8$ by default, $k\\le11$ with \\texttt{-{}-full}", *c4_full_checks(4, 11))


@reg("s7-C4-2130", kind="full", group="C4")
def _(e):
    n = sum(v["n"] for v in c4_full().values())
    return val(e, f"${n}$") + [(n < 10 ** 4, "a four-digit number, printed without grouping")] + \
        c4_full_checks(4, 11)


@reg("s7-C4-491", kind="full", group="C4")
def _(e):
    d = c4_full()
    n = sum(v["kinds"]["BEATEN"] for v in d.values())
    return val(e, f"${n}$") + c4_full_checks(4, 11)


# ---------------------------------------------------------------------------------------------
# (b.7) process numbers (wall-clock times, counts of logged runs) and a cited constant
# ---------------------------------------------------------------------------------------------
#
# These cannot be recomputed.  The check confirms only that the log or note the registry cites
# exists and contains the number, so that every printed number stays traceable.  A log written
# by notes/article2-scripts/article2-check/run_logged.sh records the SHA-256 of the check it ran;
# for those logs the check also confirms that it is the SHA-256 of the current file, so that a
# quoted time belongs to the version of the check that is shipped, and that the run exited 0.

RUN_ALL_LOG = "notes/article2-scripts/data-ports/run_all_2026-10-21.log"
A2_LOG_DIR = "notes/article2-scripts/article2-check"


def log_text(rel: str) -> str:
    path = os.path.join(ROOT, rel)
    return read(path) if os.path.exists(path) else ""


def summary_time(check: str) -> str | None:
    m = re.search(r"^\s+ok\s+" + re.escape(check) + r"\s+([0-9.]+) s$", log_text(RUN_ALL_LOG),
                  re.M)
    return m.group(1) if m else None


PROCESS_DEFAULT = {"s9-t-RG-default": "check_rigidity.py",
                   "s9-t-RX-default": "check_r2_extrema.py",
                   "s9-t-TG-default": "check_top_gap.py",
                   "s9-t-AN-default": "check_antidiagonal.py",
                   "s9-t-B2-default": "check_2b2.py", "s9-t-GO-default": "check_r7_golden.py",
                   "s9-t-HC-default": "check_h1_centre.py", "s9-t-SW-default": "check_r7_switch.py",
                   "s9-t-LR-default": "check_lr_sandwich.py",
                   "s9-t-AD-default": "check_article2_data.py",
                   "s9-t-R5-default": "check_r5_opening.py",
                   "s9-t-TE-default": "check_r7_ternary.py",
                   "s9-t-MC-default": "check_r7_mechanism.py",
                   "s9-t-GE-default": "check_r7_general.py",
                   "s9-t-TD-default": "check_ternary_defect.py"}


@reg(list(PROCESS_DEFAULT), kind="process")
def _(e):
    t = summary_time(PROCESS_DEFAULT[e["id"]])
    return [(t == e["value"], f"the Summary line of {RUN_ALL_LOG} gives {t} s for "
                              f"{PROCESS_DEFAULT[e['id']]}")]


@reg("s9-suite-time", kind="process")
def _(e):
    txt = log_text(RUN_ALL_LOG)
    m = re.search(r"^\s*([0-9.]+) real", txt.split("Summary", 1)[-1], re.M)
    return [(m is not None and Fraction(m.group(1)) == Fraction(e["value"]) and
             "All 33 passed." in txt, f"{RUN_ALL_LOG}: All 33 passed, {m and m.group(1)} real")]


PROCESS_FULL = {"s9-t-RG-full": ("notes/article2-scripts/proof-rigidity/out/"
                                 "check_rigidity_full.txt",
                                 r"check_rigidity: \d+ checks, 0 failures, ([0-9.]+) s"),
                "s9-t-TG-full": ("notes/article2-scripts/proof-topgap/"
                                 "check-top-gap-full-2026-10-21.log",
                                 r"check_top_gap: \d+ checks, 0 failures, ([0-9.]+) s"),
                "s9-t-AN-full": ("notes/article2-scripts/proof-antidiagonal/check_full.log",
                                 r"check_antidiagonal: \d+ checks, 0 failures, ([0-9.]+) s"),
                "s9-t-B2-full": ("notes/article2-scripts/proof-2b2/check_2b2_full.log",
                                 r"check_2b2: \d+ checks, 0 failures, ([0-9.]+) s"),
                "s9-t-HC-full": ("notes/article2-scripts/proof-h1/check_full.log",
                                 r"check_h1_centre: \d+ checks, 0 failures, ([0-9.]+) s")}


@reg(list(PROCESS_FULL), kind="process")
def _(e):
    rel, pat = PROCESS_FULL[e["id"]]
    m = re.search(pat, log_text(rel))
    return [(m is not None and m.group(1) == e["value"], f"{rel}: {m and m.group(0)}")]


AD_FULL_LOGS = "notes/article2-scripts/data-ports/check_article2_data_full_*.log"


@reg("s9-t-AD-full", kind="process")
def _(e):
    tot, n = Fraction(0), 0
    for path in sorted(glob.glob(os.path.join(ROOT, AD_FULL_LOGS))):
        m = re.search(r"^check_article2_data: \d+ checks, 0 failures, ([0-9.]+) s", read(path),
                      re.M)
        if m:
            tot += Fraction(m.group(1))
            n += 1
    return [(n == 5 and tot == Fraction(e["value"]), f"the five --full logs sum to {float(tot)} s")]


@reg("s9-t-AD-parts", kind="process")
def _(e):
    n = len(glob.glob(os.path.join(ROOT, AD_FULL_LOGS)))
    return [(WORDS_NUM.get(n) == e["value"], f"{n} logged --full runs of check_article2_data.py")]


def logged_run(rel: str, check: str, pattern: str):
    """A log of run_logged.sh: (the match of `pattern` in it or None, provenance conditions).
    The conditions: the log's sha256 line is that of the current checks/<check>, and the run
    exited with status 0."""
    txt = log_text(rel)
    sha = sha256_of(f"checks/{check}")
    m = re.search(pattern, txt, re.M)
    return m, [(f"sha256: {sha}  checks/{check}" in txt,
                f"{rel} is a run of the current checks/{check} (SHA-256 {sha[:16]}...)"),
               (re.search(r"^exit 0$", txt, re.M) is not None, f"{rel}: exit status 0")]


@reg("s9-t-RX-full", kind="process")
def _(e):
    rel = f"{A2_LOG_DIR}/check_r2_extrema_full.log"
    m, conds = logged_run(rel, "check_r2_extrema.py", r"^\s+total ([0-9.]+) s$")
    txt = log_text(rel)
    return [(m is not None and m.group(1) == e["value"], f"{rel}: total {m and m.group(1)} s"),
            ("[--full]" in txt and re.search(r"^OK +R2: .*: \d+ checks passed$", txt, re.M)
             is not None, f"{rel}: a --full run that passed")] + conds


@reg("s9-t-LR-full", kind="process")
def _(e):
    rel = f"{A2_LOG_DIR}/check_lr_sandwich_full.log"
    m, conds = logged_run(rel, "check_lr_sandwich.py",
                          r"^check_lr_sandwich: \d+ checks, 0 failures, ([0-9.]+) s$")
    return [(m is not None and m.group(1) == e["value"], f"{rel}: {m and m.group(0)}"),
            ("== check_lr_sandwich (full mode)" in log_text(rel), f"{rel}: a --full run")] + conds


# The times of this check itself (Table 5) come from logged runs of the same file, which cannot
# be the run in progress: they are registered only after those runs, so these entries are
# optional (a missing one is reported, not failed).  A2_PARTS are the three parts of --full.
A2_PARTS = ("base", "C1", "C4,PM,QE")
A2_TIME_LOGS = {"default": f"{A2_LOG_DIR}/check_article2_default.log",
                "base": f"{A2_LOG_DIR}/check_article2_full_base.log",
                "C1": f"{A2_LOG_DIR}/check_article2_full_C1.log",
                "C4,PM,QE": f"{A2_LOG_DIR}/check_article2_full_C4_PM_QE.log"}
OPTIONAL_IDS = {"s9-t-A2-default", "s9-t-A2-full", "s9-t-A2-parts"}


def a2_logged(part: str):
    rel = A2_TIME_LOGS[part]
    m, conds = logged_run(rel, "check_article2.py",
                          r"^check_article2: \d+ checks, 0 failures, ([0-9.]+) s$")
    tail = "" if part == "default" else f" --full --only={part}"
    conds.append((re.search(r"^command: .*checks/check_article2\.py" + re.escape(tail) + r"\s*$",
                            log_text(rel), re.M) is not None,
                  f"{rel} is the run 'check_article2.py{tail}'"))
    return m, conds


@reg("s9-t-A2-default", kind="process")
def _(e):
    m, conds = a2_logged("default")
    return [(m is not None and m.group(1) == e["value"],
             f"{A2_TIME_LOGS['default']}: {m and m.group(0)}")] + conds


@reg("s9-t-A2-full", kind="process")
def _(e):
    tot, found, conds = Fraction(0), 0, []
    for part in A2_PARTS:
        m, c = a2_logged(part)
        conds += c
        if m:
            tot += Fraction(m.group(1))
            found += 1
    return [(found == len(A2_PARTS) and tot == Fraction(e["value"]),
             f"the {len(A2_PARTS)} --full logs of this check sum to {float(tot)} s")] + conds


@reg("s9-t-A2-parts", kind="process")
def _(e):
    return [(WORDS_NUM.get(len(A2_PARTS)) == e["value"],
             f"--full of this check is logged in {len(A2_PARTS)} parts (run_logged.sh)")]


@reg("appA-runtime-full", kind="process")
def _(e):
    rel = "notes/article2-scripts/s6-golden/lemmaB_certificate_60_1000_70.appA-2026-10-22.log"
    m = re.search(r"^real ([0-9.]+)", log_text(rel), re.M)
    return [(m is not None and f"${round(float(m.group(1)))}$~s" == e["value"],
             f"{rel}: real {m and m.group(1)} s")]


@reg("appA-runtime-items", kind="process")
def _(e):
    rel = "notes/article2-scripts/s6-golden/time_certificate_items.log"
    m = re.search(r"\[C1\]-\[C3\] together: ([0-9.]+) s; failures: 0", log_text(rel))
    return [(m is not None and float(m.group(1)) < 0.001, f"{rel}: {m and m.group(0)}")]


@reg(["s7-n1-2pi", "s8-interior-limit"], kind="cited")
def _(e):
    latex = "$2/\\pi$" if e["id"] == "s7-n1-2pi" else "2/\\pi"
    return lit(e, latex)


# ---------------------------------------------------------------------------------------------
# (c) the figure data, regenerated
# ---------------------------------------------------------------------------------------------

FIGDATA = os.path.join(PAPER, "figures", "data")


def fig_tables() -> dict:
    """name -> (header, rows), every row a tuple of strings, by this file's own code."""
    T: dict = {}
    s = lambda *v: tuple(str(t) for t in v)
    # Figure 1: (3,2,7)
    t = T327()
    X, Y = 6, 14
    T["fig1_P.dat"] = (["y", "x", "P", "single"],
                       [s(y, x, t["P"][(x, y)], int(len(t["by"][(x, y)]) == 1))
                        for x in range(X + 1) for y in range(Y + 1)])
    T["fig1_frame.dat"] = (["y", "x"], [s(0.5, 0.5), s(Y - 0.5, 0.5), s(Y - 0.5, X - 0.5),
                                        s(0.5, X - 0.5), s(0.5, 0.5)])
    T["fig1_classmax.dat"] = (["y", "x", "z", "size"],
                              [s(y, x, z, t["cl"][(x, y, z)]) for (x, y, z) in t["at"]])
    (cx,) = t["centre"]
    T["fig1_centre.dat"] = (["y", "x", "P"], [s(cx[1], cx[0], t["P"][cx])])
    d = t["by"][cx]
    T["fig1_split.dat"] = (["z", "rho"], [s(z, d[z]) for z in sorted(d)])
    T["fig1_holes.dat"] = (["z", "zero"], [s(z, 0) for z in range(max(d) + 1) if z not in d])
    # Figure 2: (4,5,4) and (2,2,2)

    def fill(rs):
        if not rs:
            return 0
        if "E" in rs:
            return 2
        if "N" in rs or "Ch" in rs:
            return 1
        return 3

    f2 = fig2_data()
    assert f2["single"] == f2["rigid"]
    a, b, c = 4, 5, 4
    T["fig2_cells.dat"] = (["x", "y", "fill"], [s(x, y, fill(f2["rule_of"][(x, y)]))
                                               for y in range(b * c + 1) for x in range(a * b + 1)])
    T["fig2_gamma.dat"] = (["x", "y"], [s(*xy) for xy in sorted(f2["cells"])
                                        if "G" in f2["rule_of"][xy]])
    V222 = vals_of((2, 2, 2))
    assert {xy for xy, zs in V222.items() if len(zs) == 1} == \
        {(u, v) for u in range(5) for v in range(5) if rules(2, 2, 2, u, v)}
    T["fig2_T.dat"] = (["u", "v", "fill"], [s(u, v, fill(rules(2, 2, 2, u, v)))
                                           for v in range(5) for u in range(5)])
    T["fig2_Tgamma.dat"] = (["u", "v"], [s(u, v) for u in range(5) for v in range(5)
                                         if "G" in rules(2, 2, 2, u, v)])
    # Figure 3: alpha_5
    al = alpha5()
    T["fig3_profiles.dat"] = (["t", "Abal", "Cbal", "Acon", "Ccon"],
                              [s(i + 1, al["Ab"][i], al["Cb"][i], al["Ac"][i], al["Cc"][i])
                               for i in range(al["abc"][1])])
    # Figure 4: (5,6,5)
    f4 = fig4_sets()
    assert f4["gap"] == f4["rule"] and f4["two"]

    def fill4(xy):
        if xy in f4["single"]:
            return 1
        if xy in f4["t2"]:
            return 2
        if xy in f4["t5"]:
            return 3
        return 0

    T["fig4_cells.dat"] = (["x", "y", "fill"], [s(x, y, fill4((x, y))) for y in range(31)
                                               for x in range(31)])
    T["fig4_t2.dat"] = (["x", "y"], [s(*xy) for xy in sorted(f4["t2"])])
    T["fig4_t5.dat"] = (["x", "y"], [s(*xy) for xy in sorted(f4["t5"])])
    # Figure 5
    for bb in (8, 9):
        P = psi_table(2, bb, 2)
        T[f"fig5_b{bb}.dat"] = (["x", "xc", "D"], [s(x, x - bb, P[x][2 * bb - x])
                                                   for x in range(2 * bb + 1)])
    P = dprime((7, 6, 7))["P"]
    T["fig5_767.dat"] = (["x", "D"], [s(x, P[x][42 - x]) for x in range(21 - 4, 21 + 5)])
    # Figure 6
    cs = set()
    for key, w in FIG6.items():
        _, xyz, (v1, v2), path = word_info(w)
        T[f"fig6_path_{key}.dat"] = (["p", "q"], [s(*pt) for pt in path])
        T[f"fig6_points_{key}.dat"] = (["p", "q", "name"], [s(*v1, "$v_1$"), s(*v2, "$v_2$")])
        T[f"fig6_rect_{key}.dat"] = (["p", "q"], [s(*v1), s(v2[0], v1[1]), s(*v2), s(v1[0], v2[1]),
                                                  s(*v1)])
        cs.add(((v1[0] + v2[0]) / 2, (v1[1] + v2[1]) / 2))
    (cc,) = cs
    T["fig6_centre.dat"] = (["p", "q"], [s(*cc)])
    # Figure 7
    grid = [Fraction(20 + i, 20) for i in range(361)]
    curve = []
    for g in grid:
        av = Decimal(g.numerator) / Decimal(g.denominator)
        curve.append(s(dec_decimal(av, 2), dec_decimal(cstar(av), 6)))
    T["fig7_cstar.dat"] = (["a", "c"], curve)
    T["fig7_region.dat"] = (["a", "c"], curve + [s(dec_decimal(Decimal(av), 2),
                                                   dec_decimal(Decimal(av), 6))
                                                 for av in range(19, 0, -1)])
    T["fig7_phi.dat"] = (["a", "c"], [s(av, dec_decimal(PHI * av, 6)) for av in (1, 19)])
    T["fig7_diag.dat"] = (["a", "c"], [s(0, 0), s(20, 20)])
    T["fig7_thr.dat"] = (["a", "c"], [s(av, threshold(av)) for av in range(1, 20)])
    ties = [p for p in ties_1e6() if p[0] <= 2000]
    T["fig7_ties_a.dat"] = (["a", "c"], [s(*p) for p in ties if p[0] <= 19])
    samples = list(range(1, 61))
    m = 1
    while round(60 * 1.05 ** m) <= 3000:
        if round(60 * 1.05 ** m) > samples[-1]:
            samples.append(round(60 * 1.05 ** m))
        m += 1
    samples = sorted(set(samples + [3000] + [p[0] for p in ties]))
    T["fig7_gap.dat"] = (["a", "d"], [s(av, dec_decimal(cstar(av) - PHI * av, 6))
                                      for av in samples])
    T["fig7_ties_b.dat"] = (["a", "d"], [s(p[0], dec_decimal(cstar(p[0]) - PHI * p[0], 6))
                                         for p in ties])
    T["fig7_bounds.dat"] = (["a", "lo", "hi"], [s(av, dec_decimal(GAP_LO, 6),
                                                  dec_decimal(GAP_HI, 6)) for av in (1, 3000)])
    # Figure 8
    rows = []
    for k in range(2, 16):
        rows.append(s(k, *[dec_round(r_S(n, k, proj_set(n, n * n - n)), 6) for n in (2, 3, 4)]))
    T["fig8_r.dat"] = (["k", "r2", "r3", "r4"], rows)
    return T


def parse_dat(path: str) -> tuple:
    lines = [ln.rstrip("\n") for ln in read(path).split("\n")]
    lines = [ln for ln in lines if ln.strip() and not ln.startswith("#")]
    return lines[0].split(), [tuple(ln.split()) for ln in lines[1:]]


_FIG: dict = {}


def fig_results() -> dict:
    if not _FIG:
        tabs = fig_tables()
        files = sorted(os.path.basename(p) for p in glob.glob(os.path.join(FIGDATA, "*.dat")))
        _FIG["files"] = files
        _FIG["missing_gen"] = [f for f in files if f not in tabs]
        _FIG["missing_file"] = [f for f in tabs if f not in files]
        res = {}
        for f in files:
            if f not in tabs:
                continue
            header, rows = parse_dat(os.path.join(FIGDATA, f))
            want_h, want_r = tabs[f]
            diff = [i for i, (r1, r2) in enumerate(zip(rows, want_r)) if r1 != r2]
            ok = header == want_h and len(rows) == len(want_r) and not diff
            example = f" e.g. {rows[diff[0]]} vs {want_r[diff[0]]}" if diff else ""
            res[f] = (ok, f"{f}: header {header == want_h}, {len(rows)} rows (want {len(want_r)}), "
                          f"{len(diff)} differing rows{example}")
        _FIG["res"] = res
    return _FIG


def sec_figures() -> None:
    head("c  figure data: every paper2/figures/data/*.dat regenerated and compared")
    d = fig_results()
    CHK.eq(d["missing_gen"], [], "every .dat file has a generator here")
    CHK.eq(d["missing_file"], [], "every generated table exists as a .dat file")
    for f, (ok, msg) in sorted(d["res"].items()):
        CHK.ok(ok, msg)
    note(f"{len(d['res'])} data files regenerated")


@reg(["fig1-P-table", "fig1-bar-labels", "fig2-map-data", "fig2-T-data", "fig3-bars",
      "fig4-map-data", "fig5-b8-data", "fig5-b9-data", "fig5-767-data", "fig7-curve-data",
      "fig8-data"])
def _(e):
    f = os.path.basename(e["value"])
    res = fig_results()["res"]
    out = [(e["value"] == "figures/data/" + f and f in res, f"{e['value']} is a data file")]
    if f in res:
        out.append(res[f])
    if e["id"] == "fig7-curve-data":
        out += [res[g] for g in ("fig7_region.dat", "fig7_phi.dat", "fig7_diag.dat",
                                 "fig7_gap.dat")]
    return out


@reg("fig5-767-range")
def _(e):
    rows = fig_tables()["fig5_767.dat"][1]
    return val(e, f"${rows[0][0]}\\le x\\le {rows[-1][0]}$")


@reg("fig5-b8-max")
def _(e):
    P = psi_table(2, 8, 2)
    D = [P[x][16 - x] for x in range(17)]
    mx = max(D)
    return val(e, str(mx)) + [([x for x in range(17) if D[x] == mx] == [8], "the unique maximum "
                                                                           "at the centre x = 8")]


@reg("fig5-b9-centre")
def _(e):
    P = psi_table(2, 9, 2)
    return val(e, str(P[9][9]))


@reg("fig5-b9-max")
def _(e):
    P = psi_table(2, 9, 2)
    D = [P[x][18 - x] for x in range(19)]
    at = [x for x in range(19) if D[x] == max(D)]
    return val(e, f"${max(D)}$ is attained at $x={at[0]}$ and $x={at[1]}$") + [(len(at) == 2,
                                                                                "exactly two")]


@reg("fig7-thr")
def _(e):
    th = [threshold(a) for a in range(1, 20)]
    ok_cls = all((a2c_top(a, c)[0] == comb(a + c, a)) == (c <= th[a - 1])
                 for a in range(1, gold_amax() + 1) for c in range(a, th[a - 1] + 2))
    return val(e, "$" + ",".join(map(str, th[:5])) + ",\\dots," + ",".join(map(str, th[-2:])) +
               "$") + [(ok_cls, f"beta = tau exactly up to the threshold by GAP, a <= "
                                f"{gold_amax()}")]


@reg("fig7-thr-range")
def _(e):
    rows = fig_tables()["fig7_thr.dat"][1]
    return val(e, f"$a={rows[0][0]},\\dots,{rows[-1][0]}$")


# ---------------------------------------------------------------------------------------------
# (m) the methods of this file against each other
# ---------------------------------------------------------------------------------------------


def sec_methods() -> None:
    head("m  the methods of this file validated against each other on small contents")
    for abc in ((1, 1, 1), (2, 2, 2), (3, 2, 3), (2, 3, 2), (1, 4, 2), (3, 3, 1), (2, 4, 3),
                (3, 2, 7), (4, 3, 2)):
        lit_ = tern_lit(*abc)
        CHK.eq(tern_tdp(*abc), lit_, f"TDP = LIT on every class of {abc}")
        CHK.eq(tern_gap(*abc), lit_, f"GAP = LIT on every class of {abc}")
        P = psi_table(*abc)
        CHK.ok(all(P[x][y] == m for (x, y), m in fibres(lit_).items()) and
               sum(map(sum, P)) == multinomial(abc), f"PSI = LIT on every fibre of {abc}")
        vs: dict = {}
        for (x, y, z) in lit_:
            vs.setdefault((x, y), set()).add(z)
        CHK.eq({k: frozenset(v) for k, v in vs.items()}, tern_vals(*abc),
               f"TDP value sets = LIT on {abc}")
        pm = sorted(m for _x, _h, m in pmx_all(abc))
        CHK.eq(pm, sorted(lit_.values()), f"PMX = LIT (the Parikh classes) on {abc}")
    for a in range(1, 5):
        for c in range(1, 7):
            CHK.eq(a2c_classes(a, c), tern_tdp(a, 2, c), f"GAP (a,2,c) = TDP at {(a, 2, c)}")
    for b in range(0, 9):
        CHK.eq(classes_2b2(b), tern_tdp(2, b, 2), f"levels (2,b,2) = TDP at b = {b}")
    for n in ((2, 2, 2), (2, 2, 2, 2), (3, 3, 3), (2, 1, 2, 2), (1, 2, 2, 1, 2), (2, 2, 1, 3, 1),
              (1, 1, 1, 1, 1)):
        k = len(n)
        cl = pmx_all(n)
        for first in (True, False):
            x = alt_psi2(n, first)
            sizes = [m for xx, h, m in cl if xx == x]
            rel = alt_rel(k, first)
            CHK.ok(sizes == [down_count(n, rel)[()]] and (not first or sizes == [ez(n)]),
                   f"INS = DOWN = PMX for the alternating class of {n} (edge 1 "
                   f"{'full' if first else 'empty'})")
        rel = [None] + alt_rel(k)[1:]
        d = down_count(n, rel, track=(0,))
        fib_ = Counter()
        for xx, h, m in cl:
            if xx[1:] == alt_psi2(n)[1:]:
                fib_[xx[0]] += m
        CHK.ok(all(z_relaxed(n, u) == d[(u,)] == fib_[u] for u in range(n[0] * n[1] + 1)),
               f"INS = DOWN = PMX for every one-end relaxation of {n}")
    E = euler_numbers(9)
    from itertools import permutations as perms
    for m in range(1, 9):
        alt = sum(1 for p_ in perms(range(m)) if all((p_[i] < p_[i + 1]) == (i % 2 == 0)
                                                     for i in range(m - 1)))
        CHK.eq(E[m], alt, f"E_{m} = the alternating permutations of [{m}]")
    for w in ((1, 2, 1, 3, 2, 3), (3, 2, 1, 1, 2), (4, 3, 2, 3, 1, 2)):
        for pat in ((1, 2), (2, 3), (1, 2, 3), (3, 2, 1), (4, 3, 2)):
            brute = sum(1 for idx in combinations(range(len(w)), len(pat))
                        if tuple(w[i] for i in idx) == pat)
            CHK.eq(occ(w, pat), brute, f"occ({w}, {pat}) = brute force")
    note("TDP, GAP, PSI, PMX, LIT, INS, DOWN, the (a,2,c) gap model and the (2,b,2) levels agree")


# ---------------------------------------------------------------------------------------------
# (b) the runner
# ---------------------------------------------------------------------------------------------


def sec_recompute(entries: list[dict]) -> dict:
    head("b  every registry entry recomputed (default), at full range (--full), or listed")
    by_id = {e["id"]: e for e in entries}
    CHK.eq(sorted(set(by_id) - set(RC)), [], "every registry entry has a recomputation here")
    CHK.eq(sorted(set(RC) - set(by_id) - OPTIONAL_IDS), [],
           "every recomputation here belongs to an entry")
    absent = sorted(OPTIONAL_IDS - set(by_id))
    if absent:
        note(f"optional entries not registered (this check's own logged times): {absent}")
    status: dict = {}
    t_group: Counter = Counter()
    for e in entries:
        if e["id"] not in RC:
            continue
        kind, group, fn, partial = RC[e["id"]]
        t0 = time.perf_counter()
        if kind in ("process", "cited"):
            if not group_on("base"):
                continue
            res = fn(e)
            st = kind
        elif kind == "full":
            if group_on(group) and FULL:
                res = fn(e)
                st = f"recomputed [{group}]"
            else:
                if not group_on("base"):
                    continue
                CHK.ok(group in GROUPS, f"{e['id']}: registered with the --full group {group}")
                res = partial(e) if partial else []
                st = f"deferred to --full [{group}]" + (" (partial range now)" if partial else "")
        else:
            if not group_on("base"):
                continue
            res = fn(e)
            st = "recomputed"
        good = True
        for cond, label in res:
            good &= CHK.ok(cond, f"{e['id']}: {label}")
        status[e["id"]] = (st, good)
        t_group[group if kind == "full" else kind] += time.perf_counter() - t0
    kinds = Counter(st.split(" [")[0].split(" (")[0] for st, _ in status.values())
    note(f"entries: {dict(sorted(kinds.items()))}; failing: "
         f"{sorted(i for i, (st, g) in status.items() if not g)}")
    note("time by kind/group: " + ", ".join(f"{k} {v:.1f} s" for k, v in sorted(t_group.items())))
    return status


def main() -> int:
    mode = "--full" if FULL else "default"
    only = f", only {','.join(sorted(ONLY))}" if ONLY else ""
    print(f"check_article2 ({mode}{only}): every number of paper2/numbers.json", flush=True)
    entries = load_registry()
    timings = {}
    if group_on("base"):
        for name, fn in (("a", lambda: sec_anchors(entries)), ("d", sec_tex), ("e", sec_bib),
                         ("m", sec_methods), ("c", sec_figures)):
            t0 = time.perf_counter()
            fn()
            timings[name] = time.perf_counter() - t0
    t0 = time.perf_counter()
    status = sec_recompute(entries)
    timings["b"] = time.perf_counter() - t0
    unrec = sorted((i, st) for i, (st, g) in status.items() if st in ("process", "cited"))
    deferred = sorted(i for i, (st, g) in status.items() if st.startswith("deferred"))
    if unrec:
        head("not recomputed (process numbers and a cited constant; provenance checked only)")
        for i, st in unrec:
            note(f"{i}: {st}, value {next(e['value'] for e in entries if e['id'] == i)!r}")
    if deferred:
        note(f"{len(deferred)} entries deferred to --full (registered, partial ranges run): "
             f"{', '.join(deferred)}")
    note("section times: " + ", ".join(f"({k}) {v:.1f} s" for k, v in timings.items()))
    secs = time.perf_counter() - START
    print(f"check_article2: {CHK.count} checks, {len(CHK.failures)} failures, {secs:.1f} s",
          flush=True)
    return 1 if CHK.failures else 0


if __name__ == "__main__":
    sys.exit(main())
