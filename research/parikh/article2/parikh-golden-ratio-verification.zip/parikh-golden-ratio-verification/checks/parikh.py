"""Shared definitions for the checks, implemented from scratch.

Source: C. Yamba, *Parikh Matrices and Permutation Statistics*, Stockholm University,
Examensarbeten i matematik 2006:8. Page references are "printed p. / PDF p."
(PDF page = printed page + 4).

Conventions
-----------
* A word is a tuple of positive integers over the ordered alphabet {1 < 2 < ... < k}.
* A permutation of [n] is a tuple in one-line notation, e.g. (2, 4, 5, 6, 3, 1).
* Subwords are scattered (subsequences), never contiguous factors.
* Bit vectors are tuples of 0/1. As in the thesis, 0 marks a descent and 1 an ascent.
* Matrices are lists of lists, 0-indexed internally; docstrings use the thesis's
  1-indexed m_{i,j}.

Standard library only.
"""

from __future__ import annotations

import sys
from fractions import Fraction
from itertools import combinations, permutations, product
from math import factorial, prod

# ---------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------


class Checker:
    """Records checks; `finish()` prints a summary and returns the exit status."""

    def __init__(self, title: str) -> None:
        self.title = title
        self.passed = 0
        self.failures: list[str] = []
        print(f"== {title}")

    def check(self, label: str, got, want) -> bool:
        if got == want:
            self.passed += 1
            return True
        self.failures.append(f"{label}\n      expected: {want!r}\n      got:      {got!r}")
        return False

    def ok(self, label: str, condition: bool, detail: str = "") -> bool:
        if condition:
            self.passed += 1
            return True
        self.failures.append(f"{label}" + (f"\n      {detail}" if detail else ""))
        return False

    def note(self, text: str) -> None:
        print(f"   {text}")

    def finish(self) -> int:
        if self.failures:
            print(f"FAIL {self.title}: {len(self.failures)} failure(s), {self.passed} passed")
            for f in self.failures[:20]:
                print(f"   - {f}")
            if len(self.failures) > 20:
                print(f"   ... and {len(self.failures) - 20} more")
            return 1
        print(f"OK   {self.title}: {self.passed} checks passed")
        return 0


def max_n_from_argv(default: int = 8) -> int:
    """Read `--max-n N` from the command line."""
    argv = sys.argv[1:]
    if "--max-n" in argv:
        return int(argv[argv.index("--max-n") + 1])
    return default


# ---------------------------------------------------------------------------
# Words, subwords and Parikh matrices (Sections 1-3)
# ---------------------------------------------------------------------------


def occ(w: tuple[int, ...], u: tuple[int, ...]) -> int:
    """|w|_u: occurrences of u as a scattered subword of w (Def 1.1, Def 2.7).

    Generic dynamic programme: dp[t] = number of ways to embed u[:t] in the prefix
    of w read so far.
    """
    dp = [1] + [0] * len(u)
    for ch in w:
        for t in range(len(u), 0, -1):
            if u[t - 1] == ch:
                dp[t] += dp[t - 1]
    return dp[len(u)]


def interval(i: int, j: int) -> tuple[int, ...]:
    """a_{i,j} = i (i+1) ... j, a word of consecutive letters (Def 2.6)."""
    return tuple(range(i, j + 1))


def identity(d: int) -> list[list[int]]:
    return [[int(r == c) for c in range(d)] for r in range(d)]


def matmul(a: list[list[int]], b: list[list[int]]) -> list[list[int]]:
    n, m, p = len(a), len(b), len(b[0])
    return [[sum(a[r][t] * b[t][c] for t in range(m)) for c in range(p)] for r in range(n)]


def generator(letter: int, k: int) -> list[list[int]]:
    """psi_{M_k}(a_l): the (k+1)x(k+1) identity plus a 1 at (l, l+1) (Def 2.8)."""
    g = identity(k + 1)
    g[letter - 1][letter] = 1
    return g


def parikh_matrix_product(w: tuple[int, ...], k: int) -> list[list[int]]:
    """psi_{M_k}(w) as the literal matrix product of Def 2.8."""
    m = identity(k + 1)
    for letter in w:
        m = matmul(m, generator(letter, k))
    return m


def parikh_matrix_counts(w: tuple[int, ...], k: int) -> list[list[int]]:
    """The matrix Theorem 2.10 describes: m_{i,j+1} = |w|_{a_{i,j}}, unit diagonal, 0 below.

    Uses the generic `occ`. Slow but independent of the product definition.
    """
    m = identity(k + 1)
    for i in range(1, k + 1):
        for j in range(i, k + 1):
            m[i - 1][j] = occ(w, interval(i, j))
    return m


def parikh_matrix_fast(w: tuple[int, ...], k: int) -> list[list[int]]:
    """Same matrix as `parikh_matrix_counts`, in O(k * |w|) per row.

    For a fixed first letter i, scan w; on reading letter c >= i, the number of
    occurrences of i..c gains the number of occurrences of i..(c-1) seen so far
    (with i..(i-1) the empty word, counted once). Cross-checked against `occ` in
    check_section2.py.
    """
    m = identity(k + 1)
    for i in range(1, k + 1):
        cnt = [0] * (k + 2)  # cnt[c] = |prefix|_{i..c}; cnt[i-1] = 1 (empty word)
        cnt[i - 1] = 1
        for c in w:
            if c >= i:
                cnt[c] += cnt[c - 1]
        for j in range(i, k + 1):
            m[i - 1][j] = cnt[j]
    return m


def diagonal(m: list[list[int]], d: int) -> tuple[int, ...]:
    """The d-th diagonal, counting the main diagonal as the first: (m_{i, i+d-1})_i."""
    size = len(m)
    return tuple(m[r][r + d - 1] for r in range(size - d + 1))


def psi(w: tuple[int, ...], j: int, k: int) -> tuple[int, ...]:
    """Parikh vector of order j (Def 3.1): (|w|_{a_{1,j}}, |w|_{a_{2,j+1}}, ..., |w|_{a_{k-j+1,k}})."""
    return tuple(occ(w, interval(i, i + j - 1)) for i in range(1, k - j + 2))


def parikh_vector(w: tuple[int, ...], k: int) -> tuple[int, ...]:
    """Classical Parikh vector (Def 2.4): letter counts."""
    return tuple(w.count(a) for a in range(1, k + 1))


# ---------------------------------------------------------------------------
# Permutations (Sections 1, 4, 6)
# ---------------------------------------------------------------------------


def perms(n: int):
    return permutations(range(1, n + 1))


def positions(p: tuple[int, ...]) -> list[int]:
    """pos[v] = 1-indexed position of the value v in p (pos[0] unused)."""
    pos = [0] * (len(p) + 1)
    for idx, v in enumerate(p, start=1):
        pos[v] = idx
    return pos


def psi2_perm(p: tuple[int, ...]) -> tuple[int, ...]:
    """psi_2 on S_n: bit i is |p|_{i(i+1)}, i.e. 1 iff i appears before i+1."""
    pos = positions(p)
    return tuple(int(pos[i] < pos[i + 1]) for i in range(1, len(p)))


def descent_set(p: tuple[int, ...]) -> frozenset[int]:
    """D(p) = {i : p_i > p_{i+1}} (Def 1.2 / Def 4.1)."""
    return frozenset(i for i in range(1, len(p)) if p[i - 1] > p[i])


def phi_B(S, n: int) -> tuple[int, ...]:
    """phi_B : P([n-1]) -> Z_2^{n-1}; 0 at positions in S, 1 elsewhere (Def 1.3 / Def 4.2)."""
    return tuple(0 if i in S else 1 for i in range(1, n))


def phi_B_inv(v: tuple[int, ...]) -> frozenset[int]:
    return frozenset(i for i, b in enumerate(v, start=1) if b == 0)


def descent_vector(p: tuple[int, ...]) -> tuple[int, ...]:
    """D_{phi_B}(p) = phi_B(D(p)): 0 at a descent, 1 at an ascent."""
    return phi_B(descent_set(p), len(p))


def inverse(p: tuple[int, ...]) -> tuple[int, ...]:
    """The inverse permutation (Def 6.13): the value at position v is the position of v in p."""
    return tuple(positions(p)[1:])


def bit_vectors(length: int):
    return product((0, 1), repeat=length)


def leq(u: tuple[int, ...], v: tuple[int, ...]) -> bool:
    """u <= v coordinatewise (Def 6.1)."""
    return all(a <= b for a, b in zip(u, v))


def subsets(S) -> list[frozenset[int]]:
    s = sorted(S)
    return [frozenset(c) for r in range(len(s) + 1) for c in combinations(s, r)]


# ---------------------------------------------------------------------------
# Descent-set enumeration (Section 4)
# ---------------------------------------------------------------------------


def multinomial(parts: list[int]) -> int:
    return factorial(sum(parts)) // prod(factorial(x) for x in parts)


def block_sizes(S, n: int) -> list[int]:
    """For S = {s_1 < ... < s_r} in [n-1]: [s_1, s_2 - s_1, ..., n - s_r]."""
    cuts = [0] + sorted(S) + [n]
    return [cuts[t + 1] - cuts[t] for t in range(len(cuts) - 1)]


def alpha(S, n: int) -> int:
    """Prop 4.6: alpha(S) = multinomial(n; s_1, s_2 - s_1, ..., n - s_r)."""
    return multinomial(block_sizes(S, n))


def beta_pie(S, n: int) -> int:
    """(4.8-9): beta(S) = sum over T subset of S of (-1)^{|S - T|} alpha(T)."""
    S = frozenset(S)
    return sum((-1) ** (len(S) - len(T)) * alpha(T, n) for T in subsets(S))


def det(matrix: list[list[Fraction]]) -> Fraction:
    """Determinant by Gaussian elimination over the rationals."""
    a = [row[:] for row in matrix]
    size = len(a)
    result = Fraction(1)
    for c in range(size):
        pivot = next((r for r in range(c, size) if a[r][c] != 0), None)
        if pivot is None:
            return Fraction(0)
        if pivot != c:
            a[c], a[pivot] = a[pivot], a[c]
            result = -result
        result *= a[c][c]
        for r in range(c + 1, size):
            f = a[r][c] / a[c][c]
            if f:
                for t in range(c, size):
                    a[r][t] -= f * a[c][t]
    return result


def beta_det(S, n: int) -> int:
    """Stanley's determinant: beta_n(S) = n! det[1/(s_{j+1} - s_i)!]_{0<=i,j<=r},
    with s_0 = 0, s_{r+1} = n and 1/m! = 0 for m < 0 (thesis printed p. 25 / PDF p. 29)."""
    s = [0] + sorted(S) + [n]
    r = len(s) - 2
    mat = [
        [Fraction(1, factorial(s[j + 1] - s[i])) if s[j + 1] >= s[i] else Fraction(0)
         for j in range(r + 1)]
        for i in range(r + 1)
    ]
    value = factorial(n) * det(mat)
    assert value.denominator == 1
    return int(value)


# ---------------------------------------------------------------------------
# Multiset words, inversions and q-analogues (Section 7)
# ---------------------------------------------------------------------------


def multiset_words(counts: list[int]) -> list[tuple[int, ...]]:
    """All words with counts[a-1] copies of each letter a (S_n(M) for M = {1^{c_1}, 2^{c_2}, ...})."""
    out: list[tuple[int, ...]] = []
    remaining = list(counts)
    n = sum(counts)
    word: list[int] = []

    def rec() -> None:
        if len(word) == n:
            out.append(tuple(word))
            return
        for a, c in enumerate(remaining, start=1):
            if c:
                remaining[a - 1] -= 1
                word.append(a)
                rec()
                word.pop()
                remaining[a - 1] += 1

    rec()
    return out


def inversions(w: tuple[int, ...]) -> int:
    """i(w): pairs i < j with w_i > w_j (Def 7.1)."""
    return sum(1 for x in range(len(w)) for y in range(x + 1, len(w)) if w[x] > w[y])


def poly_add(a: list[int], b: list[int]) -> list[int]:
    out = [0] * max(len(a), len(b))
    for i, x in enumerate(a):
        out[i] += x
    for i, x in enumerate(b):
        out[i] += x
    return out


def poly_mul(a: list[int], b: list[int]) -> list[int]:
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return out


def poly_shift(a: list[int], s: int) -> list[int]:
    return [0] * s + a


def q_binomial(n: int, k: int) -> list[int]:
    """Coefficients of the Gaussian binomial [n choose k]_q, by the q-Pascal recurrence
    [n,k] = [n-1,k-1] + q^k [n-1,k]."""
    if k < 0 or k > n:
        return [0]
    if k == 0 or k == n:
        return [1]
    return poly_add(q_binomial(n - 1, k - 1), poly_shift(q_binomial(n - 1, k), k))


def q_multinomial(parts: list[int]) -> list[int]:
    """[n; a_1, ..., a_m]_q as a product of Gaussian binomials."""
    out = [1]
    rest = sum(parts)
    for a in parts:
        out = poly_mul(out, q_binomial(rest, a))
        rest -= a
    return out


def distribution(values) -> list[int]:
    """Coefficient list of sum q^value over the given values."""
    values = list(values)
    out = [0] * (max(values) + 1 if values else 1)
    for v in values:
        out[v] += 1
    return out


def trim(a: list[int]) -> list[int]:
    a = list(a)
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return a
