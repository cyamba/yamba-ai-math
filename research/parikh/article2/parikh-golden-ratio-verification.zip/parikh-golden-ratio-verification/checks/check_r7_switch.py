"""R7, the {1,2} switch: checks for notes/proof-r7-switch.md.

Python standard library only; deterministic; accepts and ignores unknown arguments
(run_all.py passes e.g. --max-n).  Exit status is non-zero on any failure.

Nothing is imported from notes/: every quantity is recomputed here by code written for this
check, and every value quoted from the note is re-typed below.

Notation (thesis conventions): letters 1 < ... < k, content n = (n_1, ..., n_k), scattered
subwords, |w|_{j..l} = number of occurrences of j(j+1)...l.  Edge i joins i and i+1;
psi_2(w) = (|w|_{12}, ..., |w|_{(k-1)k}).  The projection of w on edge i is
lam = (lam_1 <= ... <= lam_{n_{i+1}}), lam_t = number of i's before the t-th (i+1).
For (2^m): l(w), f(w) = positions of the last and first copy of the letter m;
cum_S(t) = #{w in S : l(w) <= t}; Z^v_m (Z^p_m) = the alternating class in which m is a valley
(a peak), x_{m-1} = 0 (= 4).

Methods
  BF    every word of a content, with all |w|_{j..l} updated incrementally, letter by letter
        (|wa|_{j..a} = |w|_{j..a} + |w|_{j..a-1}); classes = equal keys.  For reversal the same
        search also counts the decreasing words l(l-1)...j, which are the occurrences in the
        mirror image.
  TR    size of a trace class (given projections): linear extensions, by a DP over the count
        vectors of placed letters.
  REC   one-dimensional recursions for the alternating classes of (2^m) (position of the
        last copy of a valley, of the first copy of a peak), and gluing of a 4-letter block.
  ALPH  alphabet DP for (2^m): the letters are inserted in the order 1..m; the state is the
        gap profile of the lower letters around the two copies of the current letter, the
        vectors F_j(s) (occurrences of j..i ending at the s-th copy of i) and the entries so
        far.  Validated against BF for m <= 5.
  LOG   for computations too long to repeat here (C1-fin for 8 <= k <= 12, the C4 scan, the
        Proposition 8.10 certificate at b = 6, P-DOM(8)), the note's tables are compared
        with the saved outputs in notes/r7-scripts/proof-switch/out/.

Sections
  [1]  section 1: the 2 x 2 projection table; realisation of every projection tuple and the
       full psi_2 box; no coordinate 2 => one trace class => one Parikh class ((2^m), m <= 5);
       Lemma 1.1 (reversal and reverse-complement; MSY04's inverse-matrix identity).
  [2]  section 2: Lemma 2.1 (three cut rules, class by class) and Corollary 2.2 on every
       content with 3 <= k <= 6, n_i <= 3, total <= 8; the count 22,911 of qualifying fibres
       for total <= 9; Remark (2).
  [3]  section 3: Theorem 3.1 by BF for k <= 5; S6 decompositions; the trace-class count of
       Remark (2) for k <= 12; best central classes for k <= 10 and central fibre sizes for
       k <= 12 (ALPH restricted to the labels P, Q); Sim20's recursive rule on palindromes.
  [4]  section 4: the identities of Theorem 4.1 for N' <= 400; BF for total <= 9 (R is one
       class, the formula); TR on the 120 tails with n_i <= 3, k <= 7 (|R| > e(Z), the formula
       with the distribution of tau counted by TR, the minimum 371/357).
  [5]  section 5: Theorem 5.1 by BF (k = 4, 5); Corollary 5.2 (isolated contents,
       4 <= k <= 7, total <= 9); Corollary 5.3 ((2^4), (2^5)).
  [6]  section 6: e(Z_k), R_k for k <= 12; S6 by BF; C1-fin for k = 6, 7 (ALPH); LOG for
       the whole table (the only check of C1-fin for 8 <= k <= 12).
  [7]  section 7: Lemma 7.1 (a), (a'), (b), (c) by BF for m <= 5; Lemma 7.2 for m <= 5;
       Theorem 7.3(a) for k <= 60; the proof certificate of Theorem 7.3 (Step 5 identity at
       e in [2, 100]) and its guards; Theorem 7.3(b) for 5 <= k <= 10 (and the six-way tie at
       k = 8); Corollary 7.4 for 5 <= k <= 10.
  [8]  section 8: P-DOM tables for m <= 7 (BF m <= 5, ALPH m = 6, 7; LOG for m = 8); Lemma 8.1;
       Lemma 8.4
       for m <= 40; Lemma 8.3 / Proposition 8.5 class by class for m <= 7; Proposition 8.6;
       the hypothesis of Proposition 8.9 for m <= 31 and the likelihood-ratio claim for
       m <= 26; the Proposition 8.10 certificate for b <= 5 (and LOG for b = 6) and its
       conclusion on every class for m <= 7; the coarse table of section 8.5 for M = 4, 5, 6.
  [9]  section 9: C4 by BF for k = 4, 5; the counts of the scan table; LOG for k <= 11.
"""

from __future__ import annotations

import sys
import time
from fractions import Fraction
from functools import lru_cache
from itertools import combinations_with_replacement, product
from math import comb, factorial
from pathlib import Path

T0 = time.time()
FAIL: list = []
NCHECK = [0]
OUT = Path(__file__).resolve().parent.parent / "notes" / "r7-scripts" / "proof-switch" / "out"


def ok(cond, msg):
    NCHECK[0] += 1
    if not cond:
        FAIL.append(msg)
        print("  FAIL:", msg, flush=True)
    return cond


def section(title):
    print(f"[{time.time() - T0:6.1f} s] {title}", flush=True)


# ---------------------------------------------------------------------------------------------
# BF: literal enumeration with incremental interval counts
# ---------------------------------------------------------------------------------------------


def key_pairs(k):
    """(j, l), 1 <= j < l <= k, ordered by l - j and then j: psi_2 first."""
    return [(j, j + d) for d in range(1, k) for j in range(1, k - d + 1)]


def bf(n, words=False, mirror=False):
    """Enumerate every word of content n.

    Returns a dict key -> size, or (if words) a list of (word, key).  The key lists |w|_{j..l}
    in the order of key_pairs(k).  With mirror=True each entry is (word or None, key, mkey),
    where mkey is the key of the mirror image (reversal), computed from the decreasing words
    of w."""
    k = len(n)
    N = sum(n)
    rem = list(n)
    c = [[0] * (k + 2) for _ in range(k + 2)]  # c[j][l] = |prefix|_{j..l}, j <= l
    dcn = [[0] * (k + 2) for _ in range(k + 2)]  # dcn[l][j] = |prefix|_{l(l-1)...j}, j <= l
    pairs = key_pairs(k)
    w = [0] * N
    sizes = {}
    out = []

    def rec(pos):
        if pos == N:
            key = tuple([c[j][l] for j, l in pairs])
            if mirror:
                mkey = tuple([dcn[l][j] for j, l in pairs])
                out.append((tuple(w) if words else None, key, mkey))
            elif words:
                out.append((tuple(w), key))
            else:
                sizes[key] = sizes.get(key, 0) + 1
            return
        for a in range(1, k + 1):
            if rem[a - 1]:
                rem[a - 1] -= 1
                w[pos] = a
                for j in range(1, a):
                    c[j][a] += c[j][a - 1]
                c[a][a] += 1
                if mirror:
                    for l in range(a + 1, k + 1):
                        dcn[l][a] += dcn[l][a + 1]
                    dcn[a][a] += 1
                rec(pos + 1)
                if mirror:
                    dcn[a][a] -= 1
                    for l in range(a + 1, k + 1):
                        dcn[l][a] -= dcn[l][a + 1]
                c[a][a] -= 1
                for j in range(1, a):
                    c[j][a] -= c[j][a - 1]
                rem[a - 1] += 1

    rec(0)
    return out if (words or mirror) else sizes


def direct_key(w, k):
    """|w|_{j..l} by the definition (dynamic count over positions), in key_pairs order."""
    out = []
    for j, l in key_pairs(k):
        cnt = [0] * (l - j + 2)
        cnt[0] = 1
        for a in w:
            if j <= a <= l:
                cnt[a - j + 1] += cnt[a - j]
        out.append(cnt[l - j + 1])
    return tuple(out)


def proj(w, i):
    """Projection of w on edge i: lam_t = number of i's before the t-th (i+1)."""
    seen, lam = 0, []
    for a in w:
        if a == i:
            seen += 1
        elif a == i + 1:
            lam.append(seen)
    return tuple(lam)


def projs(w, k):
    return tuple(proj(w, i) for i in range(1, k))


def psi2(key, k):
    return key[: k - 1]


def multinomial(n):
    out = factorial(sum(n))
    for a in n:
        out //= factorial(a)
    return out


def last_pos(w, a):
    return max(i for i, b in enumerate(w) if b == a) + 1


def first_pos(w, a):
    return w.index(a) + 1


# ---------------------------------------------------------------------------------------------
# TR: size of a trace class by a DP over count vectors
# ---------------------------------------------------------------------------------------------


def trace_count(n, lams, stat=None):
    """Number of words of content n with projections lams (lams[i] for edge i+1).  With
    stat = (letter, 'first'|'last'), returns a dict position -> count instead."""
    k = len(n)
    # right[a][r] = number of copies of a+1 that precede the r-th copy of a (r 1-based)
    right = [[sum(1 for s in lams[a] if s < r) for r in range(n[a] + 1)] if a < k - 1 else None
             for a in range(k)]
    start = tuple([0] * k)
    layer = {(start, 0): 1}
    N = sum(n)
    for pos in range(1, N + 1):
        new = {}
        for (cv, sp), m in layer.items():
            for a in range(k):
                r = cv[a] + 1
                if r > n[a]:
                    continue
                if a > 0 and cv[a - 1] != lams[a - 1][r - 1]:
                    continue
                if a < k - 1 and cv[a + 1] != right[a][r]:
                    continue
                cv2 = cv[:a] + (r,) + cv[a + 1:]
                sp2 = sp
                if stat is not None and a + 1 == stat[0]:
                    if (stat[1] == "first" and r == 1) or (stat[1] == "last" and r == n[a]):
                        sp2 = pos
                kk = (cv2, sp2)
                new[kk] = new.get(kk, 0) + m
        layer = new
    if stat is None:
        return sum(layer.values())
    outd = {}
    for (cv, sp), m in layer.items():
        outd[sp] = outd.get(sp, 0) + m
    return outd


def alt_lams(n, first_full):
    """Projections of the alternating class with edge 1 full (first_full) or empty."""
    out, full = [], first_full
    for i in range(len(n) - 1):
        out.append(tuple([n[i]] * n[i + 1]) if full else tuple([0] * n[i + 1]))
        full = not full
    return out


def alt_psi2(n, first_full):
    out, full = [], first_full
    for i in range(len(n) - 1):
        out.append(n[i] * n[i + 1] if full else 0)
        full = not full
    return tuple(out)


# ---------------------------------------------------------------------------------------------
# REC: alternating classes of (2^m)
# ---------------------------------------------------------------------------------------------


def alt_profiles(mmax):
    """V[j][p] = #words of Z^v_j with the last j at position p; U[j][p] = #words of Z^p_j with
    the first j at position p (j = 1..mmax; Z^v_1 = Z^p_1 = {11})."""
    V = {1: {2: 1}}
    U = {1: {1: 1}}
    for j in range(1, mmax):
        L = 2 * j
        # Z^p_{j+1}: both (j+1)'s in gaps g1 <= g2 with g1 >= p (p = last j in a word of Z^v_j)
        Un = {}
        for p, cnt in V[j].items():
            for g1 in range(p, L + 1):
                Un[g1 + 1] = Un.get(g1 + 1, 0) + cnt * (L - g1 + 1)
        # Z^v_{j+1}: both (j+1)'s in gaps g1 <= g2 <= f - 1 (f = first j in a word of Z^p_j)
        Vn = {}
        for f, cnt in U[j].items():
            for g2 in range(0, f):
                Vn[g2 + 2] = Vn.get(g2 + 2, 0) + cnt * (g2 + 1)
        U[j + 1], V[j + 1] = Un, Vn
    return V, U


def nondec_count(length, lo, hi):
    """Number of nondecreasing sequences of the given length with values in [lo, hi]."""
    if length == 0:
        return 1
    return comb(hi - lo + length, length) if hi >= lo else 0


def glue_after(p, q, L, B):
    """Shuffles of a word of length L with a word of length B in which the p-th letter of the
    first precedes the q-th letter of the second: #{nondecreasing x(1..B) in [0, L] : x(q) >= p}."""
    return sum(nondec_count(q - 1, 0, a) * nondec_count(B - q, a, L) for a in range(p, L + 1))


def ez_and_r(kmax):
    """dict k -> (e(Z_k), R_k), 3 <= k <= kmax, by gluing the last two letters to Z^v_{k-2}:
    alternating block mm(m-1)(m-1) (first (m-1) at q = 3); area-2 block: P = (m-1)mm(m-1)
    (q = 1) and Q = m(m-1)(m-1)m (q = 2)."""
    V, U = alt_profiles(kmax)
    out = {}
    for k in range(3, kmax + 1):
        L = 2 * (k - 2)
        ez = sum(c * glue_after(p, 3, L, 4) for p, c in V[k - 2].items())
        r = sum(c * (glue_after(p, 1, L, 4) + glue_after(p, 2, L, 4)) for p, c in V[k - 2].items())
        out[k] = (ez, r)
    return out


# ---------------------------------------------------------------------------------------------
# ALPH: all Parikh classes of (2^m) with the joint profile of (f, l) of the letter m
# ---------------------------------------------------------------------------------------------

LAMS2 = ((0, 0), (0, 1), (0, 2), (1, 1), (1, 2), (2, 2))  # Z0, A1, Q, P, A3, Z4


@lru_cache(maxsize=None)
def insert_pair(g, lam):
    """Letters <= i form [g0 lower] i [g1 lower] i [g2 lower]; insert two copies of i+1 with
    projection lam (the t-th copy after exactly lam_t copies of i).  Returns a tuple of
    ((h0, h1, h2), multiplicity): the numbers of letters <= i before, between and after the
    two copies of i+1.  Lower letters commute with i+1, so every split of a gap counts once."""
    g0, g1, g2 = g
    gaps = (g0, g1, g2)
    before = [0, g0 + 1, g0 + g1 + 2]          # letters <= i before gap gamma
    after = [g1 + g2 + 2, g2 + 1, 0]           # letters <= i after gap gamma
    a, b = lam
    out = {}
    if a == b:
        G = gaps[a]
        for x in range(G + 1):
            for y in range(G - x + 1):
                z = G - x - y
                h = (before[a] + x, y, z + after[a])
                out[h] = out.get(h, 0) + 1
    else:
        Ga, Gb = gaps[a], gaps[b]
        middle = sum(gaps[a + 1:b]) + (b - a)  # lower letters strictly between, plus the i's
        for x in range(Ga + 1):
            for y in range(Gb + 1):
                h = (before[a] + x, (Ga - x) + middle + y, (Gb - y) + after[b])
                out[h] = out.get(h, 0) + 1
    return tuple(out.items())


@lru_cache(maxsize=None)
def insert_pair_fl(g, lam):
    """As insert_pair, but returns ((f, l), multiplicity) for the new letter's two copies."""
    out = {}
    for (h0, h1, h2), mult in insert_pair(g, lam):
        fl = (h0 + 1, h0 + h1 + 2)
        out[fl] = out.get(fl, 0) + mult
    return tuple(out.items())


def alph_classes(m):
    """dict key -> {(f, l): count} for every Parikh class of (2^m) (m >= 2); key in the order
    of key_pairs(m).  State after letters 1..i: (g, F, entries) with F_j = (F_j(1), F_j(2))."""
    D = {((0, 0, 0), (), ()): 1}
    order = []  # (j, l) of the entries in DP order
    out = {}
    for i in range(1, m):
        last = i == m - 1
        new = {}
        for (g, F, ent), mult in D.items():
            pref = [(0, f1, f1 + f2) for (f1, f2) in F]
            for lam in LAMS2:
                Fn = tuple((ps[lam[0]], ps[lam[1]]) for ps in pref) + (lam,)
                ent2 = ent + tuple(a + b for (a, b) in Fn)
                if last:
                    d = out.setdefault(ent2, {})
                    for fl, mm in insert_pair_fl(g, lam):
                        d[fl] = d.get(fl, 0) + mult * mm
                else:
                    for h, mm in insert_pair(g, lam):
                        st = (h, Fn, ent2)
                        new[st] = new.get(st, 0) + mult * mm
        order += [(j, i + 1) for j in range(1, i + 1)]
        D = new
    pos = {jl: t for t, jl in enumerate(order)}
    idx = [pos[jl] for jl in key_pairs(m)]
    return {tuple(ent[t] for t in idx): prof for ent, prof in out.items()}


# ---------------------------------------------------------------------------------------------
# [1] Section 1
# ---------------------------------------------------------------------------------------------


def contents(kmin, kmax, nmax, total):
    for k in range(kmin, kmax + 1):
        for n in product(range(1, nmax + 1), repeat=k):
            if sum(n) <= total:
                yield n


def parikh_matrix(w, k):
    """The (k+1) x (k+1) Parikh matrix as a product of the generators I + E_{a,a+1}."""
    M = [[int(i == j) for j in range(k + 1)] for i in range(k + 1)]
    for a in w:  # right multiplication by I + E_{a-1, a} (0-based rows/cols)
        for i in range(k + 1):
            M[i][a] += M[i][a - 1]
    return M


def sec1():
    section("[1] section 1: projections, realisation, Lemma 1.1")
    # (a) the 2 x 2 table
    table = {(2, 2, 1, 1): (0, (0, 0)), (2, 1, 2, 1): (1, (0, 1)), (2, 1, 1, 2): (2, (0, 2)),
             (1, 2, 2, 1): (2, (1, 1)), (1, 2, 1, 2): (3, (1, 2)), (1, 1, 2, 2): (4, (2, 2))}
    for w, (area, lam) in table.items():
        ok(direct_key(w, 2)[0] == area and proj(w, 1) == lam, f"2x2 table at {w}")
    ok(sorted(set(proj(w, 1) for w, _ in bf((2, 2), words=True))) == sorted(LAMS2), "six projections")
    # (b) every projection tuple is realised; psi_2 image = full box
    nc = 0
    for n in contents(2, 4, 3, 9):
        k = len(n)
        W = bf(n, words=True)
        P = {projs(w, k) for w, _ in W}
        X = {psi2(key, k) for _, key in W}
        want = 1
        for i in range(k - 1):
            want *= comb(n[i] + n[i + 1], n[i])
        box = 1
        for i in range(k - 1):
            box *= n[i] * n[i + 1] + 1
        ok(len(P) == want and len(X) == box, f"realisation {n}")
        nc += 1
    print(f"  (b) {nc} contents (2 <= k <= 4, n_i <= 3, total <= 9): all projection tuples and the"
          f" whole psi_2 box are realised")
    # (c) (2^m), m <= 5: a fibre with no coordinate 2 is one trace class and one Parikh class
    for m in range(2, 6):
        fib = {}
        for w, key in BF2[m]:
            x = psi2(key, m)
            if 2 in x:
                continue
            d = fib.setdefault(x, [set(), set()])
            d[0].add(projs(w, m))
            d[1].add(key)
        ok(all(len(a) == 1 and len(b) == 1 for a, b in fib.values()), f"no-2 fibres m={m}")
    print("  (c) (2^m), m <= 5: every psi_2 fibre without a coordinate 2 is one trace class"
          " and one Parikh class")
    # (d) Lemma 1.1: reversal (via decreasing words) and reverse-complement
    nc = nw = 0
    for n in contents(3, 5, 3, 8):
        k = len(n)
        R = bf(n, mirror=True)
        nw += len(R)
        f, sizes = {}, {}
        good = True
        for _, key, mkey in R:
            sizes[key] = sizes.get(key, 0) + 1
            if f.setdefault(key, mkey) != mkey:
                good = False
        ok(good, f"reversal well defined on classes {n}")
        ok(all(sizes[f[key]] == sizes[key] for key in f), f"reversal keeps sizes {n}")
        ok(all(psi2(f[key], k) == tuple(n[i] * n[i + 1] - key[i] for i in range(k - 1)) for key in f),
           f"reversal complements psi_2 {n}")
        za, zb = alt_psi2(n, True), alt_psi2(n, False)
        ok(all(psi2(f[key], k) == zb for key in f if psi2(key, k) == za), f"rho Z = Z' {n}")
        nc += 1
    print(f"  (d) reversal: {nc} contents (3 <= k <= 5, n_i <= 3, total <= 8), {nw} words:"
          f" classes map onto classes, psi_2 complemented, rho Z = Z'")
    # the decreasing-word counts are the counts of the mirror image, and MSY04 Thm 3:
    # M(w)^{-1} = alternate Parikh matrix of the mirror image
    for n in ((2, 1, 2), (1, 2, 2, 1), (2, 2, 2)):
        k = len(n)
        for w, key, mkey in bf(n, words=True, mirror=True):
            rw = tuple(reversed(w))
            ok(direct_key(rw, k) == mkey, f"mirror counts {w}")
            A = parikh_matrix(w, k)
            B = parikh_matrix(rw, k)
            Alt = [[(-1) ** (i + j) * B[i][j] for j in range(k + 1)] for i in range(k + 1)]
            prod_ = [[sum(A[i][t] * Alt[t][j] for t in range(k + 1)) for j in range(k + 1)]
                     for i in range(k + 1)]
            ok(prod_ == [[int(i == j) for j in range(k + 1)] for i in range(k + 1)],
               f"MSY04 Thm 3 at {w}")
    print("  (d) M(w) times the alternate matrix of M(mirror(w)) is I on (2,1,2), (1,2,2,1), (2,2,2)")
    nc = 0
    for n in contents(3, 5, 3, 7):
        k = len(n)
        nr = tuple(reversed(n))
        f, sizes, sizes_r = {}, {}, {}
        good = True
        for w, key in bf(n, words=True):
            wh = tuple(k + 1 - a for a in reversed(w))
            kh = direct_key(wh, k)
            sizes[key] = sizes.get(key, 0) + 1
            sizes_r[kh] = sizes_r.get(kh, 0) + 1
            if f.setdefault(key, kh) != kh:
                good = False
        ok(good and all(sizes[key] == sizes_r[f[key]] for key in f), f"reverse-complement {n}")
        ok(all(psi2(f[key], k) == tuple(reversed(psi2(key, k))) for key in f), f"rc psi_2 {n}")
        ok({psi2(f[key], k) for key in f if psi2(key, k) in (alt_psi2(n, True), alt_psi2(n, False))}
           <= {alt_psi2(nr, True), alt_psi2(nr, False)}, f"rc alternating {n}")
        nc += 1
    print(f"  (d) reverse-complement: {nc} contents (total <= 7): classes of n map onto classes of"
          f" n reversed, psi_2 reversed, alternating to alternating")


# ---------------------------------------------------------------------------------------------
# [2] Section 2
# ---------------------------------------------------------------------------------------------


def qualifies(n, x):
    """No two linked non-cut edges (cut edge: x_e in {0, n_e n_{e+1}}; edges e, e+1 are
    linked iff the letter e+1 is not a cut letter, i.e. n_{e+1} != 1)."""
    k = len(n)
    noncut = [x[e] not in (0, n[e] * n[e + 1]) for e in range(k - 1)]
    return not any(noncut[e] and noncut[e + 1] and n[e + 1] != 1 for e in range(k - 2))


def sec2():
    section("[2] section 2: Lemma 2.1, Corollary 2.2")
    nc = nw = nf = 0
    for n in contents(3, 6, 3, 8):
        k = len(n)
        sizes = bf(n)
        nw += sum(sizes.values())
        nc += 1
        pos = {jl: t for t, jl in enumerate(key_pairs(k))}
        good = True
        for key in sizes:
            def v(j, l):
                return n[j - 1] if j == l else key[pos[(j, l)]]
            for j in range(1, k + 1):
                for l in range(j + 2, k + 1):
                    val = v(j, l)
                    for e in range(j, l):
                        xe = v(e, e + 1)
                        if xe == 0 and val != 0:
                            good = False
                        if xe == n[e - 1] * n[e] and val != v(j, e) * v(e + 1, l):
                            good = False
                    for mm in range(j + 1, l):
                        if n[mm - 1] == 1 and val != v(j, mm) * v(mm, l):
                            good = False
        ok(good, f"cut rules {n}")
        fib = {}
        for key in sizes:
            fib.setdefault(psi2(key, k), []).append(key)
        for x, keys in fib.items():
            if qualifies(n, x):
                nf += 1
                ok(len(keys) == 1, f"Corollary 2.2 {n} {x}")
    print(f"  {nc} contents (3 <= k <= 6, n_i <= 3, total <= 8), {nw} words: the three cut rules"
          f" hold on every class; {nf} qualifying fibres, each one Parikh class")
    # the range quoted in the note (t1_cut.py): total <= 9
    nc = nw = nf = 0
    for n in contents(3, 6, 3, 9):
        k = len(n)
        nc += 1
        nw += multinomial(n)
        for x in product(*[range(n[i] * n[i + 1] + 1) for i in range(k - 1)]):
            nf += qualifies(n, x)
    ok((nc, nw, nf) == (267, 2960436, 22911), f"t1_cut range counts {(nc, nw, nf)}")
    print(f"  total <= 9 (t1_cut.py's range): {nc} contents, {nw} words, {nf} qualifying fibres"
          f" (every box vector is realised, [1](b))")
    # Remark (2): (1,2,1), x = (1,1)
    W = [(w, key) for w, key in bf((1, 2, 1), words=True) if psi2(key, 3) == (1, 1)]
    ok(sorted(w for w, _ in W) == [(2, 1, 3, 2), (2, 3, 1, 2)] and {key for _, key in W} == {(1, 1, 0)},
       "Remark (2): (1,2,1), x = (1,1)")
    ok(not qualifies((1, 2, 1), (1, 1)), "Remark (2): edges linked")
    print("  Remark (2): (1,2,1) at x = (1,1) is {2132, 2312}, one class (|w|_123 = 0), although"
          " its two non-cut edges are linked")


# ---------------------------------------------------------------------------------------------
# [3] Section 3: the central fibre of (2^k)
# ---------------------------------------------------------------------------------------------

PQ = {(1, 1): "P", (0, 2): "Q"}


def qp_set(s):
    return tuple(i + 1 for i in range(len(s) - 1) if s[i] == "Q" and s[i + 1] == "P")


def fib(k):
    a, b = 1, 1
    for _ in range(k - 1):
        a, b = b, a + b
    return a


def central_dp(k, by_T=True):
    """Central fibre of (2^k): dict T -> class size (sum of the trace classes of the label
    words with QP-descent set T), by the gap-profile DP restricted to the labels P, Q.  With
    by_T=False returns the fibre size."""
    D = {((0, 0, 0), (), ""): 1}  # (g, T so far, last label)
    for i in range(1, k):
        new = {}
        for (g, T, last), mult in D.items():
            for lam, lab in ((((1, 1)), "P"), (((0, 2)), "Q")):
                T2 = T + (i - 1,) if (by_T and last == "Q" and lab == "P") else T
                for h, mm in insert_pair(g, lam):
                    st = (h, T2, lab if by_T else "")
                    new[st] = new.get(st, 0) + mult * mm
        D = new
    out = {}
    for (g, T, last), mult in D.items():
        out[T] = out.get(T, 0) + mult
    return out if by_T else sum(out.values())


def sec3():
    section("[3] section 3: Theorem 3.1 (central fibre)")
    for k in range(2, 6):
        groups = {}
        labels = set()
        good = True
        pos = {jl: t for t, jl in enumerate(key_pairs(k))}
        for w, key in BF2[k]:
            if psi2(key, k) != (2,) * (k - 1):
                continue
            s = "".join(PQ[l] for l in projs(w, k))
            labels.add(s)
            for j in range(1, k + 1):
                for l in range(j + 2, k + 1):
                    want = 0 if "QP" in s[j - 1:l - 1] else 2
                    if key[pos[(j, l)]] != want:
                        good = False
            groups.setdefault(qp_set(s), set()).add(key)
        ok(good, f"QP rule k={k}")
        ok(len(labels) == 2 ** (k - 1), f"every label word realised k={k}")
        ok(all(len(v) == 1 for v in groups.values()), f"C_T is one class k={k}")
        ok(len({next(iter(v)) for v in groups.values()}) == len(groups) == fib(k), f"F_k classes k={k}")
    print("  k <= 5 (BF): every higher entry follows the QP rule (0 or 2); the classes are the C_T;"
          " F_k of them; all 2^(k-1) label words occur")
    # S6 decompositions (trace classes by label word)
    tr = {}
    for k in (3, 4, 5):
        for w, key in BF2[k]:
            if psi2(key, k) == (2,) * (k - 1):
                s = "".join(PQ[l] for l in projs(w, k))
                tr[s] = tr.get(s, 0) + 1
    want = {"PP": 1, "PQ": 4, "QQ": 1, "QP": 6, "PQP": 41, "QQP": 15, "QPQ": 41, "QPP": 15,
            "PQPQ": 464, "PQPP": 155, "QQPQ": 155, "QQPP": 70, "QPQP": 698}
    ok(all(tr[s] == v for s, v in want.items()), "S6 trace classes")
    ok(tr["PPP"] + tr["PPQ"] + tr["PQQ"] + tr["QQQ"] == 20, "C_empty at k = 4")
    print("  S6: PP+PQ+QQ = 1+4+1, QP = 6; PQP+QQP = QPQ+QPP = 41+15, C_empty(4) = 20;"
          " PQPQ+PQPP+QQPQ+QQPP = 464+155+155+70, QPQP = 698")
    # Remark (2): number of label words with QP-descent set T
    for k in range(3, 13):
        cnt = {}
        for s in product("PQ", repeat=k - 1):
            T = qp_set(s)
            cnt[T] = cnt.get(T, 0) + 1
        good = True
        for T, c in cnt.items():
            if not T:
                good &= c == k
                continue
            Ls = [T[0]] + [T[i + 1] - T[i] for i in range(len(T) - 1)] + [k - 1 - T[-1]]
            f = Ls[0] * Ls[-1]
            for L in Ls[1:-1]:
                f *= L - 1
            good &= c == f
        ok(good and len(cnt) == fib(k), f"Remark (2) k={k}")
    print("  Remark (2): the number of label words in C_T is L_0 (L_1 - 1)...(L_{d-1} - 1) L_d"
          " (k if T is empty), for 3 <= k <= 12")
    # best central classes (k <= 10) and central fibre sizes (k <= 12)
    best = {4: 56, 5: 844, 6: 15450, 7: 471674, 8: 15892120, 9: 815999564, 10: 43566347530}
    for k in range(3, 11):
        cl = central_dp(k)
        ok(len(cl) == fib(k), f"central DP classes k={k}")
        if k <= 5:
            byT = {}
            for s, v in tr.items():
                if len(s) == k - 1:
                    byT[qp_set(s)] = byT.get(qp_set(s), 0) + v
            ok(byT == cl, f"central DP = BF at k={k}")
        if k in best:
            ok(max(cl.values()) == best[k], f"best central class k={k}")
    fibre = {3: 12, 4: 132, 5: 2372, 6: 62304, 7: 2261668, 8: 108184432, 9: 6600715188,
             10: 500046044352, 11: 46059875586796, 12: 5068945239589696}
    for k, v in fibre.items():
        ok(central_dp(k, by_T=False) == v, f"central fibre size k={k}")
    print("  best central class 56, 844, 15450, 471674, 15892120, 815999564, 43566347530"
          " (k = 4..10); central fibre sizes for k <= 12 equal the largest fibres in the c1 logs")
    # Sim20 (special words = palindromes with every letter twice): entries 0 or 2 and the
    # recursive rule; every label word is realised by a palindrome u.mirror(u)
    for k in range(3, 6):
        pos = {jl: t for t, jl in enumerate(key_pairs(k))}
        good = True
        pal_labels = set()
        for w, key in BF2[k]:
            if w != tuple(reversed(w)):
                continue
            pal_labels.add("".join(PQ.get(l, "?") for l in projs(w, k)))
            good &= psi2(key, k) == (2,) * (k - 1)
            for j in range(1, k + 1):
                for l in range(j + 2, k + 1):
                    v = key[pos[(j, l)]]
                    good &= v in (0, 2)
                    if l - j >= 3:
                        good &= (v == 2) == (key[pos[(j, l - 1)]] == 2 and key[pos[(j + 1, l)]] == 2)
        ok(good and len(pal_labels) == 2 ** (k - 1), f"Sim20 palindromes k={k}")
    print("  palindromes of (2^k), k <= 5: in the central fibre, entries 0 or 2, Sim20's recursive"
          " rule, and every label word occurs")


# ---------------------------------------------------------------------------------------------
# [4] Section 4: Theorem 4.1, (2,2,1,tail)
# ---------------------------------------------------------------------------------------------


def f4(r, Np):
    return comb(Np - r + 4, 4) - comb(r + 1, 2) * comb(Np - r + 2, 2)


def F4(tau, Np):
    return sum(f4(r, Np) for r in range(1, tau + 1))


def sec4():
    section("[4] section 4: Theorem 4.1")
    good = True
    for Np in range(2, 401):
        run, Fs = 0, []
        for r in range(1, Np + 1):
            run += f4(r, Np)
            Fs.append(run)
        good &= Fs[-1] == 0 and all(v > 0 for v in Fs[:-1])
        sg = [f4(r, Np) > 0 for r in range(1, Np + 1)]
        good &= sg == sorted(sg, reverse=True)
    ok(good, "F(N') = 0, F > 0 on [1, N'-1], one sign change of f, N' <= 400")
    print("  2 <= N' <= 400: F(N') = 0, F(tau) > 0 for 1 <= tau <= N'-1, f changes sign once")
    # BF: R is one class, |R| > |Z|, |R| - |Z| = sum over Y'' of F(tau)
    nb = 0
    for k in range(4, 8):
        for tail in product(range(1, 4), repeat=k - 3):
            n = (2, 2, 1) + tail
            if sum(n) > 9:
                continue
            xZ = alt_psi2(n, True)
            xR = (2,) + xZ[1:]
            sizes = bf(n)
            R = [s for key, s in sizes.items() if psi2(key, k) == xR]
            Z = [s for key, s in sizes.items() if psi2(key, k) == xZ]
            Np = 1 + sum(tail)
            taus = trace_count(tail, alt_lams(tail, False), stat=(1, "first")) if len(tail) > 1 \
                else {1: 1}
            pred = sum(c * F4(t, Np) for t, c in taus.items())
            ok(len(R) == 1 and len(Z) == 1 and R[0] > Z[0] and R[0] - Z[0] == pred, f"T4a BF {n}")
            nb += 1
    print(f"  BF, {nb} contents (2,2,1,tail), total <= 9: R is one Parikh class, |R| > e(Z), and"
          f" |R| - e(Z) = sum F(tau)")
    # TR on the 120 tails
    worst = None
    nt = 0
    for k in range(4, 8):
        for tail in product(range(1, 4), repeat=k - 3):
            n = (2, 2, 1) + tail
            Zl = alt_lams(n, True)
            ez = trace_count(n, Zl)
            R = sum(trace_count(n, [lam] + Zl[1:]) for lam in ((1, 1), (0, 2)))
            Np = 1 + sum(tail)
            taus = trace_count(tail, alt_lams(tail, False), stat=(1, "first")) if len(tail) > 1 \
                else {1: 1}
            ok(R > ez and R - ez == sum(c * F4(t, Np) for t, c in taus.items()), f"T4a TR {n}")
            q = Fraction(R, ez)
            if worst is None or q < worst[0]:
                worst = (q, n, R, ez)
            nt += 1
    ok(nt == 120 and worst[1:] == ((2, 2, 1, 1, 3), 371, 357), f"T4a minimum {worst}")
    print(f"  TR, the {nt} tails with n_i <= 3, k <= 7: |R| > e(Z) and the formula hold; smallest"
          f" ratio {worst[2]}/{worst[3]} = {float(worst[0]):.4f} at {worst[1]}")


# ---------------------------------------------------------------------------------------------
# [5] Section 5: largest trace classes; isolated contents
# ---------------------------------------------------------------------------------------------


def sec5():
    section("[5] section 5: Theorem 5.1, Corollaries 5.2, 5.3")
    nc = nw = 0
    for n in contents(4, 5, 3, 8):
        k = len(n)
        tr = {}
        for w, _ in bf(n, words=True):
            p = projs(w, k)
            tr[p] = tr.get(p, 0) + 1
        nw += sum(tr.values())
        mx = max(tr.values())
        top = sorted(p for p, s in tr.items() if s == mx)
        alts = sorted({tuple(alt_lams(n, True)), tuple(alt_lams(n, False))})
        ok(top == alts and trace_count(n, alt_lams(n, True)) == mx, f"Theorem 5.1 {n}")
        nc += 1
    print(f"  Theorem 5.1, BF on {nc} contents with k = 4, 5, n_i <= 3, total <= 8 ({nw} words):"
          f" the largest trace classes are exactly Z(n) and Z'(n)")
    nc = 0
    for k in range(4, 8):
        for n in product((1, 2), repeat=k):
            if sum(n) > 9 or any(n[i] == n[i + 1] == 2 for i in range(k - 1)):
                continue
            sizes = bf(n)
            mx = max(sizes.values())
            top = sorted(psi2(key, k) for key, s in sizes.items() if s == mx)
            ok(top == sorted({alt_psi2(n, True), alt_psi2(n, False)}), f"Corollary 5.2 {n}")
            nc += 1
    print(f"  Corollary 5.2: {nc} isolated {{1,2}}-contents with 4 <= k <= 7, total <= 9: the"
          f" alternating pair are the only largest Parikh classes")
    for m in (4, 5):
        traces, sizes = {}, {}
        for w, key in BF2[m]:
            traces.setdefault(key, set()).add(projs(w, m))
            sizes[key] = sizes.get(key, 0) + 1
        ez = sizes_alt = None
        alts = {alt_psi2((2,) * m, True), alt_psi2((2,) * m, False)}
        ez = max(s for key, s in sizes.items() if psi2(key, m) in alts)
        bad = [key for key, s in sizes.items()
               if len(traces[key]) == 1 and psi2(key, m) not in alts and s >= ez]
        ok(not bad, f"Corollary 5.3 m={m}")
    print("  Corollary 5.3: in (2^4) and (2^5) every non-alternating single-trace class is < e(Z)")


# ---------------------------------------------------------------------------------------------
# [6] Section 6: small k and C1 for 6 <= k <= 12
# ---------------------------------------------------------------------------------------------

# the note's section 6 table: k -> (e(Z), R (end-relaxed), runner-up, fibres >= R, of which split)
TABLE6 = {3: (6, 4, 4, 13, 9), 4: (53, 50, 53, 11, 9), 5: (840, 680, 840, 29, 27),
          6: (18717, 16098, 16098, 41, 39), 7: (585984, 490728, 490728, 59, 57),
          8: (24004425, 20326650, 20326650, 105, 103),
          9: (1258008192, 1060140888, 1060140888, 181, 179),
          10: (81754904025, 69036903930, 69036903930, 323, 321),
          11: (6463563321600, 5453267773800, 5453267773800, 645, 643),
          12: (610397072367165, 515181809220930, 515181809220930, 1279, 1277)}
RATIO6 = {3: "0.666667", 4: "0.943396", 5: "0.809524", 6: "0.860074", 7: "0.837443", 8: "0.846788",
          9: "0.842714", 10: "0.844437", 11: "0.843694", 12: "0.844011"}


def end_relaxed_psi2(k):
    a, b = alt_psi2((2,) * k, True), alt_psi2((2,) * k, False)
    return sorted({(2,) + a[1:], (2,) + b[1:], a[:-1] + (2,), b[:-1] + (2,)})


def class_sizes_2m(m):
    """dict key -> size for every Parikh class of (2^m)."""
    if m in BF2:
        out = {}
        for _, key in BF2[m]:
            out[key] = out.get(key, 0) + 1
        return out
    return {key: sum(p.values()) for key, p in ALPH[m].items()}


def sec6():
    section("[6] section 6: e(Z), R, S6, C1-fin")
    er = ez_and_r(12)
    V, U = alt_profiles(12)
    for k, (ez, R, ru, nf, ns) in TABLE6.items():
        ok(er[k] == (ez, R) and sum(V[k].values()) == ez == sum(U[k].values()), f"e(Z), R at k={k}")
        ok(f"{R / ez:.6f}" == RATIO6[k], f"ratio at k={k}")
    ok((ez_and_r(5)[5][1], ez_and_r(4)[4][1]) == (680, 50), "R_4, R_5")
    print("  e(Z_k) and R_k for 3 <= k <= 12 match the table (two recursions), ratios as printed")
    # S6 by BF
    alts = {k: {alt_psi2((2,) * k, True), alt_psi2((2,) * k, False)} for k in range(2, 13)}
    s3 = class_sizes_2m(3)
    top3 = sorted(psi2(key, 3) for key, s in s3.items() if s == 6)
    nxt3 = sorted(psi2(key, 3) for key, s in s3.items() if s == 4)
    ok(max(s3.values()) == 6 and top3 == [(0, 4), (2, 2), (2, 2), (4, 0)], "S6 k=3 top")
    ok(sorted(set(s3.values()))[-2] == 4 and nxt3 == [(0, 2), (1, 3), (2, 0), (2, 4), (3, 1), (4, 2)],
       "S6 k=3 runner-up: six classes of size 4")
    s4 = class_sizes_2m(4)
    ok(sorted((s, psi2(key, 4)) for key, s in s4.items() if s >= 53)
       == [(53, (0, 4, 0)), (53, (4, 0, 4)), (56, (2, 2, 2)), (56, (2, 2, 2))], "S6 k=4")
    ok(sorted(psi2(key, 4) for key, s in s4.items() if s == 50) == end_relaxed_psi2(4)
       and sorted(set(s4.values()))[-3] == 50, "k=4: end-relaxed 50 next")
    s5 = class_sizes_2m(5)
    ok(sorted((s, psi2(key, 5)) for key, s in s5.items() if s >= 698)
       == [(698, (2, 2, 2, 2)), (840, (0, 4, 0, 4)), (840, (4, 0, 4, 0)), (844, (2, 2, 2, 2))], "S6 k=5")
    ok(sorted(psi2(key, 5) for key, s in s5.items() if s == 680)
       == sorted(end_relaxed_psi2(5) + [(2, 0, 4, 2), (2, 4, 0, 2)]),
       "k=5: size 680 = the four end-relaxed and the two two-end-relaxed classes")
    print("  S6 (BF): (2^3) four classes of size 6, then six classes of size 4 (the four end-relaxed"
          " and (3,1), (1,3)); (2^4) 56, 56 > 53; (2^5) 844 > 840, then 698")
    # C1-fin for k = 6, 7 from ALPH
    for k in (6, 7):
        s = class_sizes_2m(k)
        ez, R = er[k]
        top = sorted((v, psi2(key, k)) for key, v in s.items() if v >= ez)
        ok(top == sorted((ez, x) for x in alts[k]), f"C1-fin top k={k}")
        rest = sorted((v for key, v in s.items() if psi2(key, k) not in alts[k]), reverse=True)
        sec_ = sorted(psi2(key, k) for key, v in s.items() if v == R)
        ok(rest[0] == R and sec_ == end_relaxed_psi2(k), f"C1-fin second k={k}")
    print("  C1-fin k = 6, 7 (ALPH): only the alternating pair reach e(Z); the four end-relaxed"
          " classes are exactly the second-largest")
    # LOG: the table against the saved outputs for 3 <= k <= 12
    import re
    txt = ""
    for name in ("c1_certify_k3_11.txt", "c1_certify_k12.txt"):
        p = OUT / name
        if ok(p.exists(), f"missing {p}"):
            txt += p.read_text()
    blocks = re.split(r"\n(?=\(2\^)", txt)
    seen = set()
    for b in blocks:
        mm = re.match(r"\(2\^(\d+)\).*?e\(Z\) = (\d+), end-relaxed R = (\d+)", b)
        if not mm:
            continue
        k = int(mm.group(1))
        ez, R = int(mm.group(2)), int(mm.group(3))
        fl = re.search(r"fibres >= floor: (\d+), of which split: (\d+)", b)
        lf = re.search(r"largest psi_2 fibre (\d+) at \(([\d, ]+)\)", b)
        ok((ez, R) == TABLE6[k][:2] and (int(fl.group(1)), int(fl.group(2))) == TABLE6[k][3:],
           f"log vs table at k={k}")
        ok(set(lf.group(2).replace(" ", "").split(",")) == {"2"}, f"largest fibre central k={k}")
        if k >= 6:
            ok(b.count("CERTIFIED") == 2, f"log certifies k={k}")
        seen.add(k)
    ok(seen == set(range(3, 13)), f"logs cover k = 3..12: {sorted(seen)}")
    print("  LOG: out/c1_certify_k3_11.txt and out/c1_certify_k12.txt agree with the table"
          " (e(Z), R, fibres >= R and split), the centre is the largest fibre, k >= 6 certified")


# ---------------------------------------------------------------------------------------------
# [7] Section 7: gluing; end defects lose
# ---------------------------------------------------------------------------------------------


@lru_cache(maxsize=None)
def shuffle_joint(A, B, q, r):
    """Counter of (x(q), x(r)) over all nondecreasing x(1..B) in [0, A] (literal listing)."""
    out = {}
    for x in combinations_with_replacement(range(A + 1), B):
        kk = (x[q - 1], x[r - 1])
        out[kk] = out.get(kk, 0) + 1
    return out


def S_lit(A, B, p, q, r, t):
    """#shuffles with x(q) >= p and r + x(r) <= t (p-th of the first word before the q-th of
    the second; the r-th of the second at position <= t)."""
    return sum(c for (a, b), c in shuffle_joint(A, B, q, r).items() if a >= p and r + b <= t)


def S0_lit(A, B, f, lp, r, t):
    """#shuffles with x(lp) <= f - 1 and r + x(r) <= t."""
    return sum(c for (a, b), c in shuffle_joint(A, B, lp, r).items() if a <= f - 1 and r + b <= t)


@lru_cache(maxsize=None)
def S_table(A, B, q, r, zero):
    """T[p][t] = S_lit(A, B, p, q, r, t) (zero=False) or S0_lit(A, B, p, q, r, t) (zero=True),
    for 0 <= p <= A + 1 and 0 <= t <= A + B, from the literal joint counter."""
    J = shuffle_joint(A, B, q, r)
    T = []
    for p in range(A + 2):
        row = [0] * (A + B + 1)
        for (a, b), c in J.items():
            if (a <= p - 1) if zero else (a >= p):
                if r + b <= A + B:
                    row[r + b] += c
        for t in range(1, A + B + 1):
            row[t] += row[t - 1]
        T.append(row)
    return T


def restrict(w, lo, hi):
    return tuple(a - lo + 1 for a in w if lo <= a <= hi)


def key_of_word(w, k):
    if k == 1:
        return ()
    return KEY[k][w] if k in KEY else direct_key(w, k)


def classes_words(m):
    cl = {}
    for w, key in BF2[m]:
        cl.setdefault(key, []).append(w)
    return cl


def Dfun(e, p):
    return comb(p + 1, 2) * comb(2 * e - p + 2, 2) - comb(2 * e - p + 4, 4)


def sec7():
    section("[7] section 7: Lemma 7.1, Lemma 7.2, Theorem 7.3, Corollary 7.4")
    # N_{A,B}(p, q) = S(p, q, r; A+B)
    good = True
    for A in range(1, 7):
        for B in range(1, 5):
            for p in range(1, A + 1):
                for q in range(1, B + 1):
                    N = sum(comb(p - 1 + j, j) * comb(A - p + B - j, A - p) for j in range(q))
                    good &= N == S_lit(A, B, p, q, 1, A + B)
    ok(good, "formula for N_{A,B}(p,q)")
    # Lemma 7.1 by BF
    npairs = 0
    for m in range(3, 6):
        cl = classes_words(m)
        ncl = {j: (1 if j == 1 else len(classes_words(j))) for j in range(1, m)}
        for e in range(1, m):
            for c in (0, 4):
                img = set()
                cnt = 0
                for key, ws in cl.items():
                    if psi2(key, m)[e - 1] != c:
                        continue
                    cnt += 1
                    L = {restrict(w, 1, e) for w in ws}
                    R = {restrict(w, e + 1, m) for w in ws}
                    kl = {key_of_word(u, e) for u in L}
                    kr = {key_of_word(v, m - e) for v in R}
                    # (a): restrictions are whole classes, D is the full product
                    okL = len(kl) == 1 and (e == 1 or len(L) == sum(
                        1 for w2, k2 in BF2[e] if k2 == next(iter(kl))))
                    okR = len(kr) == 1 and (m - e == 1 or len(R) == sum(
                        1 for w2, k2 in BF2[m - e] if k2 == next(iter(kr))))
                    ok(okL and okR, f"Lemma 7.1(a) m={m} e={e}")
                    img.add((next(iter(kl)), next(iter(kr))))
                    # (b), (c): the shuffle formula for cum_D(t)
                    HL, HR = {}, {}
                    for u in L:
                        pu = last_pos(u, e) if c == 4 else first_pos(u, e)
                        HL[pu] = HL.get(pu, 0) + 1
                    for v in R:
                        s1 = first_pos(v, 1) if c == 4 else last_pos(v, 1)
                        rr = last_pos(v, m - e)
                        HR[(s1, rr)] = HR.get((s1, rr), 0) + 1
                    A, B = 2 * e, 2 * (m - e)
                    lastm = {}
                    for w in ws:
                        lp = last_pos(w, m)
                        lastm[lp] = lastm.get(lp, 0) + 1
                    run = 0
                    tabs = {qr: S_table(A, B, qr[0], qr[1], c == 0) for qr in HR}
                    for t in range(1, 2 * m + 1):
                        run += lastm.get(t, 0)
                        pred = sum(a * b * tabs[qr][p][t] for p, a in HL.items() for qr, b in HR.items())
                        if pred != run:
                            ok(False, f"Lemma 7.1(b/c) m={m} e={e} t={t}")
                            break
                    npairs += 1
                # (a'): one class for every pair (D_L, D_R)
                ok(len(img) == cnt == ncl[e] * ncl[m - e], f"Lemma 7.1(a') m={m} e={e} c={c}")
    print(f"  Lemma 7.1 (BF, m <= 5): (a), (a') on every edge and both areas; (b), (c) on"
          f" {npairs} (class, extreme edge) pairs, every t")
    # Lemma 7.2 by BF
    blockw = {0: lambda a: (a + 1, a + 1, a, a), 4: lambda a: (a, a, a + 1, a + 1)}
    n72 = 0
    for m in range(3, 6):
        cl = classes_words(m)
        prof = {key: [sum(1 for w in ws if last_pos(w, m) <= t) for t in range(2 * m + 1)]
                for key, ws in cl.items()}
        for key, ws in cl.items():
            x = psi2(key, m)
            if x[m - 3] not in (0, 4) or x[m - 2] not in (1, 3):
                continue
            u = restrict(ws[0], 1, m - 2)
            def Dc(c):
                v = blockw[c](m - 1)
                w2 = u + v if x[m - 3] == 4 else v + u
                return direct_key(w2, m)
            if x[m - 3] == 4:
                ok(len(ws) < len(cl[Dc(0)]), f"Lemma 7.2 size m={m}")
                ref = Dc(0)
            else:
                ok(len(ws) < len(cl[Dc(4)]), f"Lemma 7.2 size m={m}")
                ref = Dc(0) if x[m - 2] == 1 else Dc(4)
            ok(all(a <= b for a, b in zip(prof[key], prof[ref])), f"Lemma 7.2 profile m={m}")
            n72 += 1
    print(f"  Lemma 7.2 (BF, m <= 5): sizes and profiles on all {n72} qualifying classes")
    # Theorem 7.3(a), k <= 60, and the ratios quoted
    er = ez_and_r(60)
    ok(all(er[k][1] < er[k][0] for k in range(3, 61)), "R_k < e(Z_k), k <= 60")
    rq = {3: "0.666667", 4: "0.943396", 5: "0.809524", 6: "0.860074", 60: "0.843915"}
    ok(all(f"{er[k][1] / er[k][0]:.6f}" == v for k, v in rq.items()), "R_k/e(Z_k) quoted")
    print("  Theorem 7.3(a): R_k < e(Z_k) for 3 <= k <= 60; ratios 0.666667, 0.943396, 0.809524,"
          " 0.860074, ..., 0.843915 (k = 60)")
    # the proof certificate (Step 5) and the guards of Theorem 7.3
    good = True
    for e in range(2, 101):
        lhs = sum((p - 1) * comb(2 * e - p, 2) * Dfun(e, p) for p in range(2, 2 * e - 1))
        num = (e - 1) * e * (e + 1) * (e + 2) * (2 * e - 3) * (2 * e - 1) * (2 * e + 1) * (2 * e + 3)
        good &= num % 840 == 0 and lhs == num // 840 and num > 0
        Kp = [0]
        for s in range(1, 2 * e - 2):
            Kp.append(Kp[-1] + s * Dfun(e, s + 1))  # K_e(s) = sum_{p=2}^{s+1} (p-1) D_e(p)
        good &= sum((2 * e - 2 - s) * Kp[s] for s in range(1, 2 * e - 2)) == lhs
        if e >= 3:
            sg = [Dfun(e, p) >= 0 for p in range(1, 2 * e + 1)]
            good &= sg == sorted(sg) and Dfun(e, 2) < 0 and Kp[1] < 0 and Kp[2 * e - 3] > 0
            ks = [Kp[s] >= 0 for s in range(1, 2 * e - 2)]
            good &= ks == sorted(ks)
    ok(good, "Theorem 7.3 Step 5 identity and the sign pattern, 2 <= e <= 100")
    print("  Theorem 7.3 proof certificate: sum_p (p-1) C(2e-p,2) D_e(p) = (e-1)e(e+1)(e+2)(2e-3)"
          "(2e-1)(2e+1)(2e+3)/840 and the exchange of sums, for every e in [2, 100] (degree <= 8);"
          " D_e and K_e single-crossing, D_e(2) < 0, K_e(2e-3) > 0 (3 <= e <= 100)")
    V, U = alt_profiles(60)
    good = True
    for k in range(3, 61):
        e = k - 2
        ez, R = er[k]
        good &= sum(c * Dfun(e, p) for p, c in V[e].items()) == ez - R
        if e < 3:
            continue
        cumD = {}
        run = 0
        for t in range(0, 2 * e):
            run += V[e - 2].get(t, 0)
            cumD[t] = run
        Kp = [0]
        for s in range(1, 2 * e - 2):
            Kp.append(Kp[-1] + s * Dfun(e, s + 1))
        good &= sum((2 * e - 2 - f) * cumD[f - 1] * Kp[f] for f in range(1, 2 * e - 2)) == ez - R
    ok(good, "e(Z) - R = sum V D = sum phi K, k <= 60")
    print("  guards: e(Z_k) - R_k = sum_p V_e(p) D_e(p) (3 <= k <= 60) = sum_f phi(f) K_e(f)"
          " (5 <= k <= 60)")
    # Theorem 7.3(b) for 5 <= k <= 10, every class D of (2^{k-4})
    W4 = BF2[4]
    blocks = {d: [first_pos(w, 1) for w, key in W4 if psi2(key, 4) == (0, 4, d)] for d in (0, 2)}
    tie8 = None
    for k in range(5, 11):
        mm = k - 4
        L = 2 * mm
        if mm == 1:
            profs = {(): {2: 1}}
        else:
            profs = {}
            for key, pr in CLASS_FL[mm].items():
                d = {}
                for (f, l), c in pr.items():
                    d[l] = d.get(l, 0) + c
                profs[key] = d
        G = {(p, q): glue_after(p, q, L, 8) for p in range(1, L + 1) for q in range(1, 9)}
        GB = {d: {p: sum(G[(p, q)] for q in blocks[d]) for p in range(1, L + 1)} for d in (0, 2)}
        worst = None
        allgood = True
        sizes_k = {}
        for key, a in profs.items():
            s0 = sum(c * GB[0][p] for p, c in a.items())
            s2 = sum(c * GB[2][p] for p, c in a.items())
            sizes_k[key] = (s0, s2)
            allgood &= s2 < s0
            r = Fraction(s2, s0)
            if worst is None or r > worst[0]:
                worst = (r, [key])
            elif r == worst[0]:
                worst[1].append(key)
        ok(allgood, f"Theorem 7.3(b) k={k}")
        if k == 5:
            s5 = class_sizes_2m(5)
            ok(sizes_k[()] == (s5[next(kk for kk in s5 if psi2(kk, 5) == (4, 0, 4, 0))],
                               s5[next(kk for kk in s5 if psi2(kk, 5) == (4, 0, 4, 2))]), "7.3(b) vs BF k=5")
        if k == 6:
            s6 = class_sizes_2m(6)
            good6 = True
            for key, (s0, s2) in sizes_k.items():
                x1 = key[0]
                good6 &= [v for kk, v in s6.items() if psi2(kk, 6) == (x1, 4, 0, 4, 0)] == [s0]
                good6 &= [v for kk, v in s6.items() if psi2(kk, 6) == (x1, 4, 0, 4, 2)] == [s2]
            ok(good6, "7.3(b) gluing vs ALPH at k=6 (each D (x) tau is one class)")
        if k == 8:
            tie8 = worst
        print(f"  Theorem 7.3(b) k={k}: all {len(profs)} classes D: |D(x)(4,0,4,2)| < |D(x)(4,0,4,0)|;"
              f" largest ratio {float(worst[0]):.6f} ({len(worst[1])} classes)")
    ok(tie8[0] == Fraction(51482, 56793) and len(tie8[1]) == 6
       and sorted(psi2(kk, 4) for kk in tie8[1])
       == [(0, 0, 0), (0, 1, 0), (1, 0, 0), (1, 1, 0), (1, 2, 0), (2, 1, 0)], f"k=8 tie {tie8}")
    ok(sum(1 for kk in CLASS_FL[4] if psi2(kk, 4) == (2, 1, 0)) == 2, "two classes with psi_2 (2,1,0)")
    # Corollary 7.4
    s5 = class_sizes_2m(5)
    two5 = sorted(v for kk, v in s5.items() if psi2(kk, 5) in ((2, 0, 4, 2), (2, 4, 0, 2)))
    ok(two5 == [680, 680] and er[5][1] == 680, "k=5: the two-end relaxed classes tie R_5 = 680")
    two = {}
    for k in range(6, 11):
        mm = k - 4
        L = 2 * mm
        xD = (2,) + tuple(0 if (mm - 1 - i) % 2 == 1 else 4 for i in range(1, mm - 1))
        # D: psi_2 (2, alternating, ending with 0 at edge mm-1), so that edge mm = 4 alternates
        cand = [kk for kk in CLASS_FL[mm] if psi2(kk, mm) == xD]
        ok(len(cand) == 1, f"Corollary 7.4 D at k={k}: {xD}")
        a = {}
        for (f, l), c in CLASS_FL[mm][cand[0]].items():
            a[l] = a.get(l, 0) + c
        s2 = sum(c * sum(glue_after(p, q, L, 8) for q in blocks[2]) for p, c in a.items())
        two[k] = s2
        ok(s2 < er[k][1], f"Corollary 7.4 k={k}")
    s6 = class_sizes_2m(6)
    ok(sorted(v for kk, v in s6.items() if psi2(kk, 6) in ((2, 4, 0, 4, 2), (2, 0, 4, 0, 2)))
       == [12692, 12692] == [two[6]] * 2, "k=6: 12692")
    print(f"  Corollary 7.4: two-end relaxed classes {two} < R_k (k = 6..10); at k = 5 they tie"
          f" R_5 = 680, so k >= 6 is needed")


# ---------------------------------------------------------------------------------------------
# [8] Section 8: P-DOM
# ---------------------------------------------------------------------------------------------


def zv_psi2(m):
    return tuple(0 if (m - 1 - i) % 2 == 0 else 4 for i in range(1, m))


def zp_psi2(m):
    return tuple(4 - x for x in zv_psi2(m))


def restrict_key(key, m, lo, hi):
    """Key of the restriction to the letters lo..hi (relabelled 1..hi-lo+1)."""
    if hi == lo:
        return ()
    pos = {jl: t for t, jl in enumerate(key_pairs(m))}
    return tuple(key[pos[(j + lo - 1, l + lo - 1)]] for j, l in key_pairs(hi - lo + 1))


def cum_last(prof, m):
    """cum(t) = #{w : l(w) <= t}, t = 0..2m, from a {(f, l): count} profile."""
    a = [0] * (2 * m + 1)
    for (f, l), c in prof.items():
        a[l] += c
    for t in range(1, 2 * m + 1):
        a[t] += a[t - 1]
    return a


def upp_first(prof, m):
    """upp(s) = #{w : f(w) >= s}, s = 0..2m+1."""
    a = [0] * (2 * m + 2)
    for (f, l), c in prof.items():
        a[f] += c
    for s in range(2 * m, -1, -1):
        a[s] += a[s + 1]
    return a


def joint4(A, q, r):
    """Closed form: {(a, b): #nondecreasing x(1..4) in [0, A] with x(q) = a, x(r) = b}."""
    out = {}
    for a in range(A + 1):
        for b in range(A + 1):
            if q < r and b >= a:
                c = nondec_count(q - 1, 0, a) * nondec_count(r - q - 1, a, b) * nondec_count(4 - r, b, A)
            elif q > r and a >= b:
                c = nondec_count(r - 1, 0, b) * nondec_count(q - r - 1, b, a) * nondec_count(4 - q, a, A)
            else:
                c = 0
            if c:
                out[(a, b)] = c
    return out


def S4_tables(A, q, r):
    """(T, T0): T[p][t] = #{x(q) >= p, r + x(r) <= t}, T0[f][t] = #{x(q) <= f-1, r + x(r) <= t}."""
    J = joint4(A, q, r)
    T = [[0] * (A + 5) for _ in range(A + 2)]
    T0 = [[0] * (A + 5) for _ in range(A + 2)]
    for p in range(A + 2):
        for (a, b), c in J.items():
            if a >= p:
                T[p][r + b] += c
            if a <= p - 1:
                T0[p][r + b] += c
        for t in range(1, A + 5):
            T[p][t] += T[p][t - 1]
            T0[p][t] += T0[p][t - 1]
    return T, T0


def ext_count(f, l, N, tau, t):
    """Insert two copies of a new top letter into a word of length N whose previous top letter
    is at positions f < l: #{gaps g1 <= g2 of edge type tau with g2 <= t - 2} (closed forms)."""
    T = t - 2
    if T < 0:
        return 0
    if tau == "Z0":
        a = min(f - 1, T)
        return comb(a + 2, 2) if a >= 0 else 0
    if tau == "A1":
        hi = min(l - 1, T)
        return f * (hi - f + 1) if hi >= f else 0
    if tau == "Q":
        hi = min(N, T)
        return f * (hi - l + 1) if hi >= l else 0
    if tau == "P":
        hi = min(l - 1, T)
        return comb(hi - f + 2, 2) if hi >= f else 0
    if tau == "A3":
        hi = min(N, T)
        return (l - f) * (hi - l + 1) if hi >= l else 0
    if tau == "Z4":
        hi = min(N, T)
        return comb(hi - l + 2, 2) if hi >= l else 0
    raise ValueError(tau)


TYPE_OF = {(0, 0): "Z0", (0, 1): "A1", (0, 2): "Q", (1, 1): "P", (1, 2): "A3", (2, 2): "Z4"}


def updp_threshold(nuB, nuA, L, zero):
    """max over up-sets U of nu_B(U) - nu_A(U).  c = 4: order (s up, r down): U is given by
    thresholds theta(r) in [1, L+1], nondecreasing in r, U = {(s, r) : s >= theta(r)};
    c = 0: order (s down, r down): U = {(s, r) : s <= theta(r)}, theta nonincreasing in r.
    DP over the rows r = 1..L (a row-threshold parametrisation)."""
    diff = {}
    for (s, r), c in nuB.items():
        diff[(s, r)] = diff.get((s, r), 0) + c
    for (s, r), c in nuA.items():
        diff[(s, r)] = diff.get((s, r), 0) - c
    if zero:  # s -> L + 1 - s turns (s down) into (s up)
        diff = {(L + 1 - s, r): v for (s, r), v in diff.items()}
    best = [0] * (L + 2)  # best[theta] over rows so far, theta(r) = theta, prefix-max later
    for r in range(1, L + 1):
        suf = [0] * (L + 3)
        for s in range(L, 0, -1):
            suf[s] = suf[s + 1] + diff.get((s, r), 0)
        cur = [0] * (L + 2)
        run = None
        for th in range(1, L + 2):
            run = best[th] if run is None else max(run, best[th])
            cur[th] = run + suf[th]
        best = cur
    return max(best[1:])


NCLASS = {2: 5, 3: 30, 4: 173, 5: 993, 6: 5702, 7: 32745}
PDOM_VIOL = {  # m -> sorted [(psi_2, size, ((t, excess), ...))]
    2: [((2,), 2, ((4, 1),))],
    3: [((2, 0), 4, ((2, 1), (3, 1)))],
    4: [((2, 2, 2), 56, ((7, 3), (8, 3))), ((2, 2, 2), 56, ((8, 3),))],
    5: [((2, 2, 2, 0), 267, ((2, 3),)), ((2, 2, 2, 0), 463, ((2, 3), (3, 9))),
        ((2, 2, 2, 2), 844, ((10, 4),))],
    6: [((2, 2, 2, 2, 0), 5880, ((2, 4),))],
    7: [],
}


def sec8():
    section("[8] section 8: P-DOM")
    V, U = alt_profiles(41)
    # (a) the P-DOM tables, m <= 7
    viol = {}
    for m in range(2, 8):
        CL = CLASS_FL[m]
        ok(sum(sum(p.values()) for p in CL.values()) == factorial(2 * m) // 2 ** m, f"total m={m}")
        zk = [kk for kk in CL if psi2(kk, m) == zv_psi2(m)]
        ok(len(zk) == 1, f"Z^v unique m={m}")
        cz = cum_last(CL[zk[0]], m)
        run = 0
        good = True
        for t in range(1, 2 * m + 1):
            run += V[m].get(t, 0)
            good &= cz[t] == run
        ok(good, f"Z^v profile = REC, m={m}")
        vs = []
        for kk, pr in CL.items():
            cd = cum_last(pr, m)
            ex = tuple((t, cd[t] - cz[t]) for t in range(1, 2 * m + 1) if cd[t] > cz[t])
            if ex:
                vs.append((psi2(kk, m), cd[2 * m], ex))
        viol[m] = sorted(vs)
        ok(len(CL) == NCLASS[m] and viol[m] == PDOM_VIOL[m], f"P-DOM table m={m}: {viol[m]}")
    print("  (a) P-DOM(m), m = 2..7 (BF m <= 5, ALPH m = 6, 7): 5, 30, 173, 993, 5702, 32745"
          " classes; violations exactly as in the table of section 8.3; none at m = 7")
    pth = OUT / "pdom_alph_m8.txt"
    txt = pth.read_text() if pth.exists() else ""
    ok("m=8: 188045 classes, 81729648000 words, e(Z) = 24004425; P-DOM violations: 0" in txt
       and "CERTIFIED" in txt and "exit 0" in txt, "LOG pdom_alph_m8.txt")
    print("  LOG m = 8: out/pdom_alph_m8.txt reports 188045 classes, no violation, CERTIFIED")
    # (2^4): C_{2} (|w|_123 = 2) violates at t = 7, 8 and C_{1} only at t = 8
    pos4 = {jl: t for t, jl in enumerate(key_pairs(4))}
    for kk, pr in CLASS_FL[4].items():
        if psi2(kk, 4) == (2, 2, 2) and sum(pr.values()) == 56:
            cd = cum_last(pr, 4)
            T2 = kk[pos4[(1, 3)]] == 2  # |w|_123 = 2 iff T = {2}
            ok((cd[7] > 53) == T2 and cd[8] == 56, "m=4 violators identified")
    # (2^3): the central classes satisfy P-DOM with equality at t = 6 (uniqueness needs more)
    cz3 = cum_last(CLASS_FL[3][next(kk for kk in CLASS_FL[3] if psi2(kk, 3) == zv_psi2(3))], 3)
    cen = [cum_last(pr, 3) for kk, pr in CLASS_FL[3].items() if psi2(kk, 3) == (2, 2)]
    ok(len(cen) == 2 and all(all(a <= b for a, b in zip(c, cz3)) and c[6] == cz3[6] == 6 for c in cen),
       "(2^3) central classes: cum <= cum_Zv with equality at t = 6")
    # (2^5): the (2,2,2,0) violators restrict to C_{2} (size 463) and C_{1} (size 267) of (2^4);
    # (2^6): the violator restricts to the class of size 844 of (2^5)
    s4 = class_sizes_2m(4)
    s5 = class_sizes_2m(5)
    for m, x, size, want in ((5, (2, 2, 2, 0), 463, "C2"), (5, (2, 2, 2, 0), 267, "C1"),
                             (6, (2, 2, 2, 2, 0), 5880, "844")):
        ks = [kk for kk, pr in CLASS_FL[m].items() if psi2(kk, m) == x and sum(pr.values()) == size]
        r = restrict_key(ks[0], m, 1, m - 1) if len(ks) == 1 else None
        if want == "844":
            ok(r is not None and s5[r] == 844, "m=6 violator restricts to the 844 class")
        else:
            ok(r is not None and s4[r] == 56 and (r[3] == 2) == (want == "C2"), f"m=5 violator {size}")
    print("  (2^4): C_{2} exceeds at t = 7, 8 and C_{1} at t = 8 only; (2^5): the violators of size"
          " 463 and 267 are C_{2} and C_{1} glued with x_4 = 0; (2^6): the violator is the 844-class"
          " glued with x_5 = 0; (2^3): both central classes satisfy P-DOM, equality at t = 6")
    # (b) Lemma 8.1 by BF (reversal on classes from the decreasing-word counts)
    for m in range(2, 6):
        rho = {}
        for _, key, mkey in bf((2,) * m, mirror=True):
            rho[key] = mkey
        good = True
        for kk, pr in CLASS_FL[m].items():
            cd = cum_last(pr, m)
            ur = upp_first(CLASS_FL[m][rho[kk]], m)
            good &= all(ur[s] == cd[2 * m + 1 - s] for s in range(1, 2 * m + 1))
        zk = next(kk for kk in CLASS_FL[m] if psi2(kk, m) == zv_psi2(m))
        ok(good and psi2(rho[zk], m) == zp_psi2(m), f"Lemma 8.1 m={m}")
    print("  (b) Lemma 8.1 (BF, m <= 5): upp_{rho D}(s) = cum_D(2m+1-s) for every class; rho Z^v = Z^p")
    # (c) Lemma 8.4 (PV), 2 <= m <= 40
    good = True
    for m in range(2, 41):
        L = 2 * (m - 1)
        run = 0
        for t in range(1, 2 * m + 1):
            run += V[m].get(t, 0)
            cp = sum(c * comb(t - p, 2) for p, c in V[m - 1].items() if t - p >= 2)
            good &= cp <= run
        good &= run == sum(c * comb(2 * m - p, 2) for p, c in V[m - 1].items())
    ok(good, "PV, m <= 40")
    print("  (c) Lemma 8.4 (PV): cum_{Z^p_m} <= cum_{Z^v_m} for 2 <= m <= 40")
    # (d) Lemma 8.3 / Proposition 8.5, class by class, m <= 7
    nd = 0
    for m in range(3, 8):
        CL, CLm = CLASS_FL[m], CLASS_FL[m - 1]
        zv = cum_last(CL[next(kk for kk in CL if psi2(kk, m) == zv_psi2(m))], m)
        zp = cum_last(CL[next(kk for kk in CL if psi2(kk, m) == zp_psi2(m))], m)
        ok(all(a <= b for a, b in zip(zp, zv)), f"PV m={m}")
        zv1 = cum_last(CLm[next(kk for kk in CLm if psi2(kk, m - 1) == zv_psi2(m - 1))], m - 1)
        zp1 = upp_first(CLm[next(kk for kk in CLm if psi2(kk, m - 1) == zp_psi2(m - 1))], m - 1)
        ez = zv[2 * m]
        for kk, pr in CL.items():
            x = psi2(kk, m)[m - 2]
            if x not in (0, 4):
                continue
            km = restrict_key(kk, m, 1, m - 1)
            cd = cum_last(pr, m)
            if x == 4 and all(a <= b for a, b in zip(cum_last(CLm[km], m - 1), zv1)):
                ok(all(a <= b for a, b in zip(cd, zp)), f"Lemma 8.3 (x=4) m={m}")
                nd += 1
            if x == 0 and all(a <= b for a, b in zip(upp_first(CLm[km], m - 1), zp1)):
                ok(all(a <= b for a, b in zip(cd, zv)), f"Lemma 8.3 (x=0) m={m}")
                nd += 1
            if cd[2 * m] >= ez:
                ok(psi2(kk, m) in (zv_psi2(m), zp_psi2(m)), f"Prop 8.5 uniqueness m={m}")
    print(f"  (d) Lemma 8.3 / Proposition 8.5, class by class for 3 <= m <= 7: {nd} classes with an"
          f" extreme last edge whose left class is dominated are dominated; the classes of size"
          f" e(Z) with an extreme last edge are Z^v, Z^p")
    # (e) Proposition 8.6
    for m in range(2, 8):
        CL = CLASS_FL[m]
        c2 = sorted(pr.get((1, 2), 0) for pr in CL.values())
        c2 = [v for v in c2 if v]
        lower = sorted(class_sizes_2m(m - 1).values()) if m - 1 >= 2 else [1]
        zv = cum_last(CL[next(kk for kk in CL if psi2(kk, m) == zv_psi2(m))], m)
        ez1 = sum(V[m - 1].values())
        ok(c2 == lower and zv[2] == ez1, f"Prop 8.6 m={m}")
    print("  (e) Proposition 8.6 (m <= 7): the nonzero values cum_D(2) are exactly the class sizes of"
          " (2^{m-1}); cum_{Z^v_m}(2) = e(Z_{m-1})")
    return V, U


BLOCK_FAIL = {4: {2: 1, 3: 6, 4: 2, 5: 75}, 0: {2: 2, 3: 0, 4: 23, 5: 1}}
BLOCK_N = {2: 3, 3: 14, 4: 55, 5: 217}


def sec8b(V, U):
    # (f) the hypothesis of Proposition 8.9 (R_m, R'_m), m <= 31, and the LR claim, m <= 26
    good = True
    for A in range(1, 9):  # the closed form joint4 against the literal listing
        for q in range(1, 5):
            for r in range(1, 5):
                if q != r:
                    good &= joint4(A, q, r) == shuffle_joint(A, 4, q, r)
    ok(good, "joint4 closed form")
    er = ez_and_r(31)
    worst = Fraction(0)
    good = goodr = goodd = goodlr = True
    for m in range(3, 32):
        e = m - 2
        A = 2 * e
        Tz, _ = S4_tables(A, 3, 2)
        TP, TP0 = S4_tables(A, 1, 3)
        TQ, TQ0 = S4_tables(A, 2, 4)
        _, T0P = S4_tables(A, 4, 3)  # R': P = (m-1)mm(m-1): last (m-1) at 4, last m at 3
        _, T0Q = S4_tables(A, 3, 4)  # R': Q = m(m-1)(m-1)m: last (m-1) at 3, last m at 4
        cz, cr, cr2 = [0] * (2 * m + 1), [0] * (2 * m + 1), [0] * (2 * m + 1)
        run = 0
        for t in range(1, 2 * m + 1):
            cz[t] = sum(c * Tz[p][t] for p, c in V[e].items())
            cr[t] = sum(c * (TP[p][t] + TQ[p][t]) for p, c in V[e].items())
            cr2[t] = sum(c * (T0P[f][t] + T0Q[f][t]) for f, c in U[e].items())
            run += V[m].get(t, 0)
            good &= cz[t] == run
            goodr &= cr[t] <= cz[t] and cr2[t] <= cz[t]
            if cz[t]:
                worst = max(worst, Fraction(cr[t], cz[t]), Fraction(cr2[t], cz[t]))
            Dt = [Tz[p][t] - TP[p][t] - TQ[p][t] for p in range(1, A + 1)]
            nz = [d for d in Dt if d]
            ch = sum(1 for i in range(len(nz) - 1) if (nz[i] > 0) != (nz[i + 1] > 0))
            goodd &= ch == 0 or (ch == 1 and nz[0] < 0)
            goodd &= sum((p - 1) * comb(2 * e - p, 2) * Dt[p - 1] for p in range(2, A + 1)) >= 0
        good &= cr[2 * m] == cr2[2 * m] == er[m][1] and cz[2 * m] == er[m][0]
        if m <= 26:
            az = [cz[t] - cz[t - 1] for t in range(1, 2 * m + 1)]
            ar = [cr[t] - cr[t - 1] for t in range(1, 2 * m + 1)]
            first = next(i for i in range(len(az)) if az[i] > 0)
            goodlr &= all(ar[i] == 0 for i in range(first))
            rt = [Fraction(ar[i], az[i]) for i in range(len(az)) if az[i] > 0]
            goodlr &= all(rt[i] <= rt[i + 1] for i in range(len(rt) - 1))
            ct = [Fraction(cr[t], cz[t]) for t in range(1, 2 * m + 1) if cz[t]]
            goodlr &= all(ct[i] <= ct[i + 1] for i in range(len(ct) - 1))
    ok(good, "gluing = REC for Z^v_m; |R_m| = |R'_m| = R_m (m <= 31)")
    ok(goodr and worst == Fraction(50, 53), f"Prop 8.9 hypothesis, max ratio {worst}")
    ok(goodd, "D_t single-crossing and the reduced inequality (m <= 31)")
    ok(goodlr, "likelihood-ratio order (m <= 26)")
    print("  (f) Proposition 8.9's hypothesis: cum_{R_m}, cum_{R'_m} <= cum_{Z^v_m} at every t for"
          " 3 <= m <= 31 (largest ratio 50/53); D_t single-crossing and the reduced inequality >= 0"
          " (m <= 31); a_R/a_Zv and cum_R/cum_Zv nondecreasing (m <= 26)")
    # (g) the certificate of Proposition 8.10, b <= 5 (BF), both gluing areas
    PASS = {}
    for c in (4, 0):
        for b in range(2, 6):
            L = 2 * b
            xa = alt_psi2((2,) * b, c == 0)  # c = 4: x_1 = 0 (first letter a peak); c = 0: x_1 = 4
            nuA, cls = {}, {}
            for w, key in BF2[b]:
                s1 = first_pos(w, 1) if c == 4 else last_pos(w, 1)
                r = last_pos(w, b)
                x = psi2(key, b)
                if x == xa:
                    nuA[(s1, r)] = nuA.get((s1, r), 0) + 1
                if any(xi in (0, 4) for xi in x):
                    continue
                d = cls.setdefault(key, {})
                d[(s1, r)] = d.get((s1, r), 0) + 1
            fails = []
            for key, nu in cls.items():
                exc = updp_threshold(nu, nuA, L, c == 0)
                PASS[(c, b, key)] = exc <= 0
                if exc > 0:
                    fails.append((psi2(key, b), sum(nu.values())))
            ok(len(cls) == BLOCK_N[b] and len(fails) == BLOCK_FAIL[c][b], f"Prop 8.10 counts c={c} b={b}")
            matched = (c == 4 and b % 2 == 0) or (c == 0 and b % 2 == 1)
            if matched:
                want = {2: [((2,), 2)], 3: [], 4: [((2, 2, 2), 56)] * 2, 5: [((2, 2, 2, 2), 844)]}[b]
                ok(sorted(fails) == want, f"Prop 8.10 matched failures c={c} b={b}: {fails}")
    print("  (g) Proposition 8.10 certificate, b <= 5 (BF, row-threshold DP over up-sets): block"
          " classes 3, 14, 55, 217; failing: c = 4: 1, 6, 2, 75; c = 0: 2, 0, 23, 1; matched"
          " failures exactly {P, Q}, the two central classes of size 56, the central class 844")
    # b = 6 from the saved outputs of block_dominance.py
    for name, line in (("block_dominance_b6.txt",
                        "[x_e = 4] b=6 (matched): 854 block classes (all edges non-extreme), |A| = 18717;"
                        " fail the 2-D test: 0"),
                       ("block_dominance_b6_zero.txt",
                        "[x_e = 0] b=6 (mismatched): 854 block classes (all edges non-extreme), |A| = 18717;"
                        " fail the 2-D test: 263")):
        pth = OUT / name
        txt = pth.read_text() if pth.exists() else ""
        ok(line in txt and "CERTIFIED" in txt and "exit 0" in txt, f"LOG {name}")
    print("  LOG b = 6: out/block_dominance_b6.txt (c = 4: 854 classes, none fails) and"
          " out/block_dominance_b6_zero.txt (c = 0: 263 fail), both CERTIFIED")
    # the conclusion of Proposition 8.10 on every qualifying class, m <= 7 (b <= 5)
    nq = 0
    for m in range(3, 8):
        CL = CLASS_FL[m]
        pos = {jl: t for t, jl in enumerate(key_pairs(m))}
        for kk, pr in CL.items():
            x = psi2(kk, m)
            ext = [e for e in range(1, m) if x[e - 1] in (0, 4)]
            if not ext or ext[-1] > m - 2:
                continue
            e = ext[-1]
            c, b = x[e - 1], m - e
            if b > 5 or not ((c == 4 and b % 2 == 0) or (c == 0 and b % 2 == 1)):
                continue
            Bk = restrict_key(kk, m, e + 1, m)
            if not PASS[(c, b, Bk)]:
                continue
            Ak = next(key for _, key in BF2[b] if psi2(key, b) == alt_psi2((2,) * b, c == 0))
            posb = {jl: t for t, jl in enumerate(key_pairs(b))}
            glued = []
            for j, l in key_pairs(m):
                if l <= e:
                    glued.append(kk[pos[(j, l)]])
                elif j >= e + 1:
                    glued.append(Ak[posb[(j - e, l - e)]])
                elif c == 0:
                    glued.append(0)
                else:
                    left = 2 if j == e else kk[pos[(j, e)]]
                    right = 2 if l == e + 1 else Ak[posb[(1, l - e)]]
                    glued.append(left * right)
            glued = tuple(glued)
            ok(glued in CL, f"Prop 8.10: glued class exists m={m}")
            cd, cg = cum_last(pr, m), cum_last(CL[glued], m)
            ok(all(a <= b2 for a, b2 in zip(cd, cg)), f"Prop 8.10 conclusion m={m} {x}")
            nq += 1
    print(f"  (g) Proposition 8.10's conclusion cum_D <= cum_(D_L (x)_c A) on all {nq} qualifying"
          f" classes with 3 <= m <= 7 and b <= 5")
    # (h) section 8.5: coarse extensions, M = 4, 5, 6
    good = True
    for N in range(2, 9):
        for f in range(1, N):
            for l in range(f + 1, N + 1):
                for t in range(0, N + 3):
                    cnt = {}
                    for g1 in range(N + 1):
                        for g2 in range(g1, N + 1):
                            if g2 + 2 <= t:
                                lam = ((g1 >= f) + (g1 >= l), (g2 >= f) + (g2 >= l))
                                cnt[TYPE_OF[lam]] = cnt.get(TYPE_OF[lam], 0) + 1
                    good &= all(ext_count(f, l, N, tau, t) == cnt.get(tau, 0) for tau in TYPE_OF.values())
    ok(good, "coarse-extension closed forms")
    table = {4: (0.589, 0.589, 0.864, 0.737, 1.283), 5: (0.618, 0.618, 0.858, 0.618, 1.274),
             6: (0.606, 0.606, 0.701, 0.606, 1.036)}
    for M, want in table.items():
        N = 2 * M
        CL = CLASS_FL[M]
        czv = [0] * (N + 3)
        run = 0
        for t in range(N + 3):
            run += V[M + 1].get(t, 0)
            czv[t] = run
        zv = cum_last(CL[next(kk for kk in CL if psi2(kk, M) == zv_psi2(M))], M)
        zp = upp_first(CL[next(kk for kk in CL if psi2(kk, M) == zp_psi2(M))], M)
        fl_pairs = sorted({fl for pr in CL.values() for fl in pr})
        taus = ("A1", "A3", "P", "Q", "Z0", "Z4")
        E = {fl: {tau: [ext_count(fl[0], fl[1], N, tau, t) for t in range(N + 3)] for tau in taus}
             for fl in fl_pairs}
        best = {tau: 0.0 for tau in taus + ("P+Q",)}
        goodz = True
        above = []  # (tau, psi_2, size, t) with ratio > 1 for tau in {Z0, Z4}
        for kk, pr in CL.items():
            vec = {tau: [0] * (N + 3) for tau in taus}
            for fl, c in pr.items():
                Ef = E[fl]
                for tau in taus:
                    row, src = vec[tau], Ef[tau]
                    for t in range(2, N + 3):
                        row[t] += c * src[t]
            vec["P+Q"] = [a + b for a, b in zip(vec["P"], vec["Q"])]
            dom = all(a <= b for a, b in zip(cum_last(pr, M), zv))
            domr = all(a <= b for a, b in zip(upp_first(pr, M), zp))
            for tau, row in vec.items():
                r = max(row[t] / czv[t] for t in range(2, N + 3))
                best[tau] = max(best[tau], r)
                if (tau == "Z4" and dom) or (tau == "Z0" and domr):
                    goodz &= r <= 1
                if tau in ("Z0", "Z4"):
                    above += [(tau, psi2(kk, M), sum(pr.values()), t) for t in range(2, N + 3)
                              if row[t] > czv[t]]
        got = tuple(round(best[tau], 3) for tau in ("A1", "A3", "P", "Q", "P+Q"))
        ok(got == want and goodz, f"section 8.5 table M={M}: {got}")
        want_above = {4: [("Z0", (2, 2, 2), 56, 2), ("Z0", (2, 2, 2), 56, 2), ("Z0", (2, 2, 2), 56, 3)],
                      5: [("Z0", (2, 2, 2, 2), 844, 2)], 6: []}[M]
        ok(sorted(above) == want_above, f"section 8.5 Z0/Z4 above 1, M={M}: {above}")
    print("  (h) section 8.5: the coarse-extension table for M = 4, 5, 6 (A1, A3, P, Q, P+Q); Z4 (Z0)"
          " <= 1 for every class satisfying P-DOM(M) (its reversed form); above 1 only for Z0: the"
          " central classes 56, 56 at M = 4 (t = 2; t = 3 for one) and 844 at M = 5 (t = 2)")


# ---------------------------------------------------------------------------------------------
# [9] Section 9: C4
# ---------------------------------------------------------------------------------------------


def c4_rule(n):
    if n in ((2, 2, 2, 2), (2, 2, 2, 2, 2)):
        return "BEATEN"
    return "BEATEN" if (n[:3] == (2, 2, 1) or n[-3:] == (1, 2, 2)) else "ALT"


def sec9():
    section("[9] section 9: C4")
    for k, want in ((4, {"ALT": 7, "TIE": 0, "BEATEN": 3}), (5, {"ALT": 15, "TIE": 0, "BEATEN": 5})):
        cnt = {"ALT": 0, "TIE": 0, "BEATEN": 0}
        seen = set()
        for n in product((1, 2), repeat=k):
            if tuple(reversed(n)) in seen:
                continue
            seen.add(n)
            sizes = class_sizes_2m(k) if n == (2,) * k else bf(n)
            alts = {alt_psi2(n, True), alt_psi2(n, False)}
            ez = trace_count(n, alt_lams(n, True))
            other = max((s for key, s in sizes.items() if psi2(key, k) not in alts), default=0)
            ok(all(s == ez for key, s in sizes.items() if psi2(key, k) in alts), f"C4 e(Z) {n}")
            kind = "BEATEN" if other > ez else ("TIE" if other == ez else "ALT")
            cnt[kind] += 1
            ok(kind == c4_rule(n), f"C4 rule {n}: {kind}")
        ok(cnt == want, f"C4 counts k={k}: {cnt}")
    print("  BF, k = 4, 5: 10 and 20 contents up to reversal, (7, 0, 3) and (15, 0, 5)"
          " (ALT, TIE, BEATEN), every one as the rule predicts")
    # the counts of the scan table: contents up to reversal, and how many the rule calls BEATEN
    want = {4: (10, 3), 5: (20, 5), 6: (36, 8), 7: (72, 16), 8: (136, 31), 9: (272, 62),
            10: (528, 122), 11: (1056, 244)}
    tot = [0, 0]
    for k, (nc, nb) in want.items():
        seen, beaten = set(), 0
        for n in product((1, 2), repeat=k):
            if tuple(reversed(n)) in seen:
                continue
            seen.add(n)
            beaten += c4_rule(n) == "BEATEN"
        ok((len(seen), beaten) == (nc, nb), f"C4 table k={k}")
        tot[0] += nc
        tot[1] += nb
    ok(tot == [2130, 491], "C4 totals")
    print("  table: 10, 20, 36, 72, 136, 272, 528, 1056 contents (2130), of which 3, 5, 8, 16, 31, 62,"
          " 122, 244 (491) start with (2,2,1), end with (1,2,2) or are (2^4), (2^5)")
    pth = OUT / "c4_scan_k4_11.txt"
    txt = pth.read_text() if pth.exists() else ""
    good = "disagreements with C4: 0" in txt
    for k, (nc, nb) in want.items():
        good &= (f"k={k}: {nc} contents up to reversal: {{'ALT': {nc - nb}, 'TIE': 0, 'BEATEN': {nb}}}"
                 in txt)
    ok(good, "LOG c4_scan_k4_11.txt")
    print("  LOG: out/c4_scan_k4_11.txt reports exactly these counts, no TIE, 0 disagreements")


# ---------------------------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------------------------

BF2: dict = {}
KEY: dict = {}
ALPH: dict = {}
CLASS_FL: dict = {}


def setup():
    section("setup: BF for (2^m), m <= 5; ALPH for m = 6, 7 (validated against BF for m <= 5)")
    for m in range(2, 6):
        BF2[m] = bf((2,) * m, words=True)
        KEY[m] = {w: key for w, key in BF2[m]}
        d = {}
        for w, key in BF2[m]:
            e = d.setdefault(key, {})
            fl = (first_pos(w, m), last_pos(w, m))
            e[fl] = e.get(fl, 0) + 1
        CLASS_FL[m] = d
        ok(alph_classes(m) == d, f"ALPH = BF at m={m}")
    for m in (6, 7):
        ALPH[m] = alph_classes(m)
        CLASS_FL[m] = ALPH[m]
    ok(all(len(BF2[m]) == factorial(2 * m) // 2 ** m for m in BF2), "BF word counts")


def main():
    setup()
    for fn in (sec1, sec2, sec3, sec4, sec5, sec6, sec7):
        try:
            fn()
        except Exception as exc:  # an exception is a failure
            ok(False, f"{fn.__name__} raised {exc!r}")
    try:
        V, U = sec8()
        sec8b(V, U)
    except Exception as exc:
        ok(False, f"sec8 raised {exc!r}")
    try:
        sec9()
    except Exception as exc:
        ok(False, f"sec9 raised {exc!r}")
    dt = time.time() - T0
    if FAIL:
        print(f"check_r7_switch: {len(FAIL)} FAILURES out of {NCHECK[0]} checks ({dt:.1f} s)")
        return 1
    print(f"check_r7_switch: all {NCHECK[0]} checks passed ({dt:.1f} s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
