"""R7, content (a,2,c): checks for notes/proof-r7-golden.md (Theorem G and its proof).

Python standard library only; deterministic; accepts and ignores unknown arguments
(run_all.py passes e.g. --max-n).  Exit status is non-zero on any failure.  About 18 s with
Python 3.11, 34 s with the system Python 3.9.

Letters 1 < 2 < 3, content (a,2,c), x = |w|_12, y = |w|_23, z = |w|_123 (scattered);
rho(x,y,z) = size of a Parikh class, P(x,y) = sum_z rho (psi_2-fibre), T = C(a+c,a).
Nothing is imported from notes/: every formula of the note used here is re-typed from the note,
and the certificate [C1]-[C3] of notes/r7-scripts/proof-golden/lemmaB_certificate.py is
re-implemented.

Methods
  BF   every word of the content is generated and its counts are taken by one left-to-right
       scan; the scan equals the literal definition (index tuples) for a + c <= 6.
  GAP  w = u0 2 u1 2 u2 with u_g in {1,3}*, a_g 1's and c_g 3's in u_g: weight
       C(a0+c0,a0) C(a1+c1,a1) C(a2+c2,a2), x = 2a0+a1, y = c1+2c2, z = a0 c1 + x c2.
       A direct count, equal to BF on every class for a + c <= 13.
  NOTE the note's closed forms: F(m), f(j), j*, formula (2.1), the predicted maximum B and
       maximiser set of Theorem G.5, and the coefficient sequences of section 5.

Sections (bounds as run)
  [1] words, a + c <= 9: Lemma 2.1 (x = p1+p2, y = 2c-q1-q2, xy - 2z = (p2-p1)(q2-q1) >= 0),
      MSY04's form xy - 2z = |w|_2132 + |w|_2312, the number of words per pair of points,
      Lemma A per path (one pair per path and class with N > 0), the symmetries R, C, RC of
      s.1.2 and |w|_321 = 2ac - ay - cx + z.
  [2] BF == GAP on every class, a + c <= 13, the class checks of [3] on the BF tables, (2.1)
      against BF, and the examples (2,2,2), (3,2,7), (4,2,4).
  [3] classes from GAP: every content with a <= c, a + c <= 50, and every content with
      a > c, a + c <= 30, plus (40,2,65) and (65,2,40).  Theorem G.1 (H3 on the four edges;
      boundary fibres are single classes with z = 0, ay, 0, cx), G.3 (largest class = largest
      boundary fibre = f(j*)), G.5 (maximiser sets), G.6 (five maximisers at ties), Lemma A,
      Lemma B, the Cauchy bound, H1 (CONJECTURE; consistency only), the maximiser-count
      histogram for a + c <= 50 (a > c by RC, checked directly for a + c <= 30), formula (2.1)
      on every interior cell with xy even (a + c <= 24), the examples of s.0 and s.8.
  [4] section 3 and Parts 4 and 6: (3.1), monotone R(j), unimodality with at most one tie,
      the j* formula, Cor. 3.3, Prop. 3.4, Part 4 in exact integer form (1 <= a, c <= 90);
      floor(c*) and c* - phi a in the stated interval (60-digit Decimal, a <= 20000); the tie
      set for a <= 10^6; X^2 - 5Y^2 = -4 for Y <= 2*10^5 and its descent; Lucas/Fibonacci
      identities; Remark 3.5 (numerical consistency only).
  [5] section 5: the column basis, g and Gamma, (E1)-(E3) and (2.2) (a + c <= 24), Lemma 5.2,
      Lemma 5.3 (coefficients mu <= 12; contents a + c <= 50), Lemma 5.4 (the corrected D(S)
      statements and the two counterexamples to the old wording; contents a + c <= 50),
      Lemma 5.5 (closed forms, window identity, convexity, strict witnesses for mu <= 8,
      nu <= 30, all h; contents a + c <= 26), Lemmas 5.6-5.9 (mu <= 60, nu <= 600, including
      (T2) and the Step-2 inequality in its region), Lemma 5.10 (contents a + c <= 50).
  [6] the exact certificate [C1]-[C3] (integers and Fractions; ln 2 < 6932/10000 by a series
      bound), and the numbers quoted for it in the note.
  [7] the exploration statements of s.8 (explore_local count and first centre, explore_exits2
      centres, the (24,2,2) class by brute force, the last-letter recursion, a + c <= 18).
"""

from __future__ import annotations

import sys
import time
from decimal import Decimal, getcontext
from fractions import Fraction as Fr
from itertools import combinations
from math import comb, isqrt

FAIL: list = []
NCHECK = [0]


def check(cond, msg):
    NCHECK[0] += 1
    if not cond:
        FAIL.append(msg)
        if len(FAIL) <= 40:
            print("FAIL:", msg)


def C(n, k):
    """Binomial with the note's convention: 0 unless 0 <= k <= n."""
    return comb(n, k) if 0 <= k <= n else 0


# ============================================================== words (BF)
def scan(w):
    """(|w|_12, |w|_23, |w|_123) by one left-to-right scan."""
    n1 = n12 = n2 = n23 = n123 = 0
    for ch in w:
        if ch == 1:
            n1 += 1
        elif ch == 2:
            n12 += n1
            n2 += 1
        else:
            n123 += n12
            n23 += n2
    return n12, n23, n123


def literal(w):
    """The same counts from the definition (index tuples)."""
    n = len(w)
    x = sum(1 for i, j in combinations(range(n), 2) if (w[i], w[j]) == (1, 2))
    y = sum(1 for i, j in combinations(range(n), 2) if (w[i], w[j]) == (2, 3))
    z = sum(1 for i, j, k in combinations(range(n), 3) if (w[i], w[j], w[k]) == (1, 2, 3))
    return x, y, z


def sub(w, u):
    """Number of occurrences of u as a scattered subword of w."""
    cnt = [1] + [0] * len(u)
    for ch in w:
        for k in range(len(u), 0, -1):
            if u[k - 1] == ch:
                cnt[k] += cnt[k - 1]
    return cnt[-1]


def words(a, c):
    """Every word with a 1's, two 2's and c 3's, each exactly once."""
    m = a + c
    for ones in combinations(range(m), a):
        u = [3] * m
        for k in ones:
            u[k] = 1
        u = tuple(u)
        for s1 in range(m + 1):
            for s2 in range(s1, m + 1):
                yield u[:s1] + (2,) + u[s1:s2] + (2,) + u[s2:]


def keys(a, c):
    return 2 * c + 1, 2 * a * c + 1          # Y1, Z1: key = (x*Y1 + y)*Z1 + z


def bf_classes(a, c):
    Y1, Z1 = keys(a, c)
    rho = {}
    for w in words(a, c):
        x, y, z = scan(w)
        k = (x * Y1 + y) * Z1 + z
        rho[k] = rho.get(k, 0) + 1
    return rho


def gap_classes(a, c):
    """Direct count over w = u0 2 u1 2 u2 (see the module docstring)."""
    Y1, Z1 = keys(a, c)
    Bt = [[comb(i + j, i) for j in range(c + 1)] for i in range(a + 1)]
    rho = {}
    get = rho.get
    for a0 in range(a + 1):
        for a1 in range(a - a0 + 1):
            a2 = a - a0 - a1
            x = 2 * a0 + a1
            B0, B1, B2 = Bt[a0], Bt[a1], Bt[a2]
            step = Z1 + a0                     # c1 -> c1 + 1: y += 1, z += a0
            for c2 in range(c + 1):
                w2 = B2[c2]
                k0 = (x * Y1 + 2 * c2) * Z1 + x * c2
                cc = c - c2
                for c1 in range(cc + 1):
                    k = k0 + c1 * step
                    rho[k] = get(k, 0) + B0[cc - c1] * B1[c1] * w2
    return rho


def decode(k, a, c):
    Y1, Z1 = keys(a, c)
    xy, z = divmod(k, Z1)
    x, y = divmod(xy, Y1)
    return x, y, z


def key_of(a, c, x, y, z):
    Y1, Z1 = keys(a, c)
    return (x * Y1 + y) * Z1 + z


# ============================================================== the note's formulas
def F(a, c, m):
    """P(0, 2c-m) = sum_{i=ceil(m/2)}^{min(m,c)} C(a+c-i, a)   (H3, Proposition 3.1)."""
    if m < 0 or m > 2 * c:
        return 0
    return sum(C(a + c - i, a) for i in range((m + 1) // 2, min(m, c) + 1))


def f_list(a, c):
    return [F(a, c, 2 * j) for j in range(c + 1)]


def jstar(a, c):
    """Theorem G.2: min{ j >= 0 : C(a+c-2j-1,a) + C(a+c-2j-2,a) <= C(a+c-j,a) }."""
    N = a + c
    return next(j for j in range(c + 1) if C(N - 2 * j - 1, a) + C(N - 2 * j - 2, a) <= C(N - j, a))


def predict(a, c):
    """(B, sorted maximisers) as stated in Theorem G.3-G.5 (a > c by reverse-complement)."""
    if a > c:
        B, mx = predict(c, a)
        return B, sorted((y, x, z) for (x, y, z) in mx)
    T = C(a + c, a)
    lhs, rhs = c * (c - 1), a * (a + c - 1)
    if lhs < rhs:
        mx = [(0, 2 * c, 0), (2 * a, 0, 0), (a, c, 0)]
        if (a, c) == (2, 2):
            mx.append((2, 2, 2))
        return T, sorted(mx)
    if lhs == rhs:
        return T, sorted([(0, 2 * c, 0), (0, 2 * c - 2, 0), (2 * a, 0, 0), (2 * a, 2, 2 * a),
                          (a, c, 0)])
    js = jstar(a, c)
    f = f_list(a, c)
    mx = [(0, 2 * c - 2 * js, 0), (2 * a, 2 * js, 2 * a * js)]
    if js < c and f[js + 1] == f[js]:
        mx += [(0, 2 * c - 2 * js - 2, 0), (2 * a, 2 * js + 2, 2 * a * (js + 1))]
    return f[js], sorted(mx)


def K21(a, c, P, Q):
    """Formula (2.1) at the doubled centre (P, Q) = (2 mu, 2 nu): the class
    (x, y, z) = (P, 2c - Q, P(2c - Q)/2) on the Cauchy surface."""
    tot = 0
    if P % 2 == 0:
        mu = P // 2
        for i in range((Q + 1) // 2, min(Q, c) + 1):
            tot += C(mu + Q - i, mu) * C(a - mu + c - i, a - mu)
    if Q % 2 == 0:
        nu = Q // 2
        for j in range(P // 2 + 1, min(P, a) + 1):
            tot += C(P - j + nu, nu) * C(a - j + c - nu, c - nu)
    return tot


def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def lucas(n):
    a, b = 2, 1
    for _ in range(n):
        a, b = b, a + b
    return a


# ============================================================== [1] word level
def section1(WMAX=9):
    t0 = time.time()
    nw = 0
    for s in range(2, WMAX + 1):
        for a in range(1, s):
            c = s - a
            pairs = {}
            perpath = {}
            for w in words(a, c):
                nw += 1
                x, y, z = scan(w)
                if s <= 6:
                    check(literal(w) == (x, y, z), f"[1] scan {w}")
                i1 = w.index(2)
                i2 = w.index(2, i1 + 1)
                p1, q1 = w[:i1].count(1), w[:i1].count(3)
                p2, q2 = w[:i2].count(1), w[:i2].count(3)
                check(x == p1 + p2 and y == 2 * c - q1 - q2, f"[1] x,y {w}")
                d, e = p2 - p1, q2 - q1
                check(d >= 0 and e >= 0 and x * y - 2 * z == d * e, f"[1] N = de {w}")
                check(x * y - 2 * z == sub(w, (2, 1, 3, 2)) + sub(w, (2, 3, 1, 2)), f"[1] MSY04 {w}")
                pairs[(p1, q1, p2, q2)] = pairs.get((p1, q1, p2, q2), 0) + 1
                if d * e > 0:                                       # Lemma A: one pair per path
                    kp = (tuple(ch for ch in w if ch != 2), x, y, z)
                    perpath[kp] = perpath.get(kp, 0) + 1
                zr = 2 * a * c - a * y - c * x + z
                check(sub(w, (3, 2, 1)) == zr, f"[1] 321 {w}")
                check(scan(w[::-1]) == (2 * a - x, 2 * c - y, zr), f"[1] R {w}")
                wc = tuple(4 - ch for ch in w)                     # 1 <-> 3, content (c,2,a)
                check(scan(wc) == (2 * c - y, 2 * a - x, zr), f"[1] C {w}")
                check(scan(wc[::-1]) == (y, x, z), f"[1] RC {w}")
            # words per pair of points P1 <= P2: paths through both points
            tot = 0
            for p1 in range(a + 1):
                for q1 in range(c + 1):
                    for p2 in range(p1, a + 1):
                        for q2 in range(q1, c + 1):
                            ex = C(p1 + q1, p1) * C(p2 - p1 + q2 - q1, p2 - p1) * C(a - p2 + c - q2, a - p2)
                            tot += ex
                            check(pairs.get((p1, q1, p2, q2), 0) == ex, f"[1] pair count {(a, c, p1, q1, p2, q2)}")
            check(tot == C(a + c + 2, 2) * C(a + c, a), f"[1] total {(a, c)}")
            check(all(v == 1 for v in perpath.values()), f"[1] Lemma A per path {(a, c)}")
    print(f"[1] word level: {nw} words, a + c <= {WMAX}: Lemma 2.1, xy-2z = |w|2132+|w|2312, "
          f"pair counts, Lemma A per path, R, C, RC, |w|321 ({time.time() - t0:.1f} s)")


# ============================================================== class-level checks
def class_checks(a, c, rho, stats, label):
    """All class-level statements of Theorem G and Lemmas A, B for one content."""
    Y1, Z1 = keys(a, c)
    T = C(a + c, a)
    A2, C2 = 2 * a, 2 * c
    P = {}
    Pget = P.get
    M, argM = 0, []
    mA, vA0 = 0, 0          # max over N > 0 classes other than (a,c,0); size of (a,c,0)
    mB, argB = 0, []        # interior classes with N = 0
    total = 0
    bad = 0
    for k, v in rho.items():
        xy, z = divmod(k, Z1)
        x, y = divmod(xy, Y1)
        P[xy] = Pget(xy, 0) + v
        total += v
        if v >= M:
            if v > M:
                M, argM = v, [(x, y, z)]
            else:
                argM.append((x, y, z))
        N = x * y - 2 * z
        if N > 0:
            if x == a and y == c and z == 0:
                vA0 = v
            elif v > mA:
                mA = v
        elif N == 0:
            if 0 < x < A2 and 0 < y < C2:
                if v > mB:
                    mB, argB = v, [(x, y, z)]
                elif v == mB:
                    argB.append((x, y, z))
        else:
            bad += 1                                        # Cauchy bound violated
        if x == 0 or x == A2 or y == 0 or y == C2:
            zexp = 0 if x == 0 else (a * y if x == A2 else (0 if y == 0 else c * x))
            if z != zexp:
                bad += 1                                    # boundary fibre not one class
    tag = f"{label} {(a, c)}"
    check(bad == 0, f"{tag}: Cauchy bound or boundary single-class")
    check(total == C(a + c + 2, 2) * T, f"{tag}: total")
    # H3 on the four edges (Theorem G.1)
    for m in range(C2 + 1):
        Fm = F(a, c, m)
        check(Pget(0 * Y1 + (C2 - m), 0) == Fm, f"{tag}: H3 x=0 m={m}")
        check(Pget(A2 * Y1 + m, 0) == Fm, f"{tag}: H3 x=2a y={m}")
    for n in range(A2 + 1):
        Fn = F(c, a, n)
        check(Pget((A2 - n) * Y1 + 0, 0) == Fn, f"{tag}: H3 y=0 n={n}")
        check(Pget(n * Y1 + C2, 0) == Fn, f"{tag}: H3 y=2c n={n}")
    bmax = max(Pget(x * Y1 + y, 0) for x in range(A2 + 1) for y in range(C2 + 1)
               if x in (0, A2) or y in (0, C2))
    B, pmx = predict(a, c)
    check(B == bmax, f"{tag}: B != largest boundary fibre")
    if a <= c:
        check(B == max(f_list(a, c)) == f_list(a, c)[jstar(a, c)], f"{tag}: B != f(j*)")
    check(M == B and sorted(argM) == pmx, f"{tag}: maximum {M} {sorted(argM)} vs {B} {pmx}")
    # Lemma A
    check(vA0 == T and mA < T, f"{tag}: Lemma A (mA={mA}, (a,c,0)={vA0}, T={T})")
    # Lemma B
    if (a, c) == (2, 2):
        check(mB == B == 6 and argB == [(2, 2, 2)], f"{tag}: Lemma B exception")
    else:
        check(mB < B, f"{tag}: Lemma B ({mB} >= {B})")
    # H1 (CONJECTURE; consistency only)
    if (a, c) != (1, 1):
        cen = P[a * Y1 + c]
        check(all(v < cen for k, v in P.items() if k != a * Y1 + c), f"{tag}: H1")
    stats.setdefault("hist", {})
    stats["hist"][len(argM)] = stats["hist"].get(len(argM), 0) + 1
    if a + c <= 30 and mB:
        r = Fr(mB, bmax)
        if r > stats.get("ratio", Fr(0)):
            stats["ratio"], stats["ratio_at"] = r, [(a, c)]
        elif r == stats.get("ratio"):
            stats["ratio_at"].append((a, c))
    return P, M, sorted(argM)


def k21_against_table(a, c, rho):
    for x in range(1, 2 * a):
        for y in range(1, 2 * c):
            if (x * y) % 2 == 0:
                v = rho.get(key_of(a, c, x, y, x * y // 2), 0)
                check(K21(a, c, x, 2 * c - y) == v, f"[2.1] {(a, c, x, y)}")


# ============================================================== [2], [3]
def section23(BFMAX=13, GMAX=50, GALL=30, K21MAX=24, LOCALMAX=30):
    t0 = time.time()
    stats_bf = {}
    for s in range(2, BFMAX + 1):
        for a in range(1, s):
            c = s - a
            bf = bf_classes(a, c)
            gp = gap_classes(a, c)
            check(bf == gp, f"[2] BF != GAP {(a, c)}")
            class_checks(a, c, bf, stats_bf, "[2] BF")
            k21_against_table(a, c, bf)
            if (a, c) == (2, 2):
                mx = sorted(decode(k, a, c) for k, v in bf.items() if v == 6)
                check(max(bf.values()) == 6 and mx == [(0, 4, 0), (2, 2, 0), (2, 2, 2), (4, 0, 0)],
                      "[2] (2,2,2) example")
            if (a, c) == (3, 7):
                M = max(bf.values())
                mx = sorted(decode(k, a, c) for k, v in bf.items() if v == M)
                check(M == 140 and C(10, 3) == 120 and f_list(3, 7)[1] == 140
                      and mx == [(0, 12, 0), (6, 2, 6)], "[2] (3,2,7) example")
            if (a, c) == (4, 4):                       # s.8: the line x + y = 4
                check([bf.get(key_of(4, 4, *t), 0) for t in ((4, 0, 0), (2, 2, 2), (0, 4, 0))]
                      == [21, 22, 21], "[2] (4,2,4) line")
    print(f"[2] BF == GAP on every class and Theorem G checks on BF tables, a + c <= {BFMAX} "
          f"({time.time() - t0:.1f} s)")

    t0 = time.time()
    stats = {}
    hist_lt, hist_eq, hist_gt, hist_lt30 = {}, {}, {}, {}
    local_fail = 0
    first_local = None
    for s in range(2, GMAX + 1):
        for a in range(1, s):
            c = s - a
            if a > c and s > GALL:
                continue
            rho = gap_classes(a, c)
            P, M, mx = class_checks(a, c, rho, stats, "[3]")
            h = hist_lt if a < c else (hist_eq if a == c else hist_gt)
            h[len(mx)] = h.get(len(mx), 0) + 1
            if a < c and s <= GALL:
                hist_lt30[len(mx)] = hist_lt30.get(len(mx), 0) + 1
            if s <= K21MAX:
                k21_against_table(a, c, rho)
            if (a, c) == (6, 10):
                check(M == 8008 == C(16, 6) and len(mx) == 5, "[3] (6,2,10) example")
            if (a, c) == (24, 2):
                check(rho.get(key_of(24, 2, 24, 2, 24)) == 820 and C(26, 2) == 325,
                      "[3] (24,2,2) example")
            if s <= LOCALMAX:
                # s.8, explore_local.py: interior integer centres (p,q) with no 8-neighbour of
                # smaller distance to the boundary and K >= K(p,q)
                def K(p, q):
                    return rho.get(key_of(a, c, 2 * p, 2 * c - 2 * q, p * (2 * c - 2 * q)), 0)
                for p in range(1, a):
                    for q in range(1, c):
                        v = K(p, q)
                        dd = min(p, a - p, q, c - q)
                        ok = False
                        for dp in (-1, 0, 1):
                            for dq in (-1, 0, 1):
                                p2, q2 = p + dp, q + dq
                                if (dp, dq) != (0, 0) and 0 <= p2 <= a and 0 <= q2 <= c \
                                        and min(p2, a - p2, q2, c - q2) < dd and K(p2, q2) >= v:
                                    ok = True
                        if not ok:
                            local_fail += 1
                            if first_local is None:
                                first_local = ((a, c), (p, q), v)
    for a, c in ((40, 65), (65, 40)):                  # a tie beyond a + c <= 50 (Theorem G.6)
        rho = gap_classes(a, c)
        M = max(rho.values())
        mx = sorted(decode(k, a, c) for k, v in rho.items() if v == M)
        B, pmx = predict(a, c)
        check(M == B == C(105, 40) and mx == pmx and len(mx) == 5, f"[3] tie {(a, c)}")
    # histogram over all 1,225 contents with a + c <= 50: a > c by reverse-complement (RC maps
    # the classes of (a,2,c) onto those of (c,2,a), s.1.2 and [1]); checked directly for
    # a + c <= 30 below.
    full = {}
    for k_ in set(hist_lt) | set(hist_eq):
        full[k_] = 2 * hist_lt.get(k_, 0) + hist_eq.get(k_, 0)
    check(full == {2: 878, 3: 310, 4: 33, 5: 4} and sum(full.values()) == 1225,
          f"[3] histogram a + c <= 50: {full}")
    check(hist_lt30 == hist_gt, f"[3] RC histogram a + c <= {GALL}: {hist_lt30} {hist_gt}")
    check(stats["ratio"] == 1 and stats["ratio_at"] == [(2, 2)],
          f"[3] max interior N=0 / boundary max: {stats['ratio']} at {stats['ratio_at']}")
    check(local_fail == 14846 and first_local == ((3, 5), (1, 3), 38),
          f"[7] explore_local count {local_fail}, first {first_local}")
    print(f"[3] classes from GAP: a <= c, a + c <= {GMAX}; a > c, a + c <= {GALL}; (40,65), "
          f"(65,40): Theorem G, Lemmas A, B, H1; histogram {dict(sorted(full.items()))}; "
          f"(2.1) == classes, a + c <= {K21MAX} ({time.time() - t0:.1f} s)")
    print(f"[7] explore_local (a + c <= {LOCALMAX}): {local_fail} centres, first {first_local}; "
          f"max interior-N=0/boundary ratio (a + c <= 30) = {stats['ratio']} at {stats['ratio_at']}")


# ============================================================== [4] section 3, Parts 4 and 6
def section4(AMAX=90, CSTAR=20000, TIE=10 ** 6, PELL=2 * 10 ** 5):
    t0 = time.time()
    for a in range(1, AMAX + 1):
        for c in range(1, AMAX + 1):
            N = a + c
            T = C(N, a)
            col = [C(N - i, a) for i in range(c + 1)]
            suf = [0] * (c + 2)
            for i in range(c, -1, -1):
                suf[i] = suf[i + 1] + col[i]

            def Fm(m):
                return suf[(m + 1) // 2] - suf[min(m, c) + 1]
            f = [Fm(2 * j) for j in range(c + 1)]
            if c <= 25 and a <= 25:
                check(f == [sum(C(N - i, a) for i in range(j, min(2 * j, c) + 1)) for j in range(c + 1)],
                      f"[4] f def {(a, c)}")
            check(f[0] == T, f"[4] f(0) {(a, c)}")
            num = [C(N - 2 * j - 1, a) + C(N - 2 * j - 2, a) for j in range(c + 1)]
            den = [C(N - j, a) for j in range(c + 1)]
            for j in range(c):
                check(f[j + 1] - f[j] == num[j] - den[j], f"[4] (3.1) {(a, c, j)}")
                if num[j] > 0:
                    check(num[j + 1] * den[j] < num[j] * den[j + 1], f"[4] R decreasing {(a, c, j)}")
                else:
                    check(num[j + 1] == 0, f"[4] R stays 0 {(a, c, j)}")
            js = jstar(a, c)
            check(js == min(j for j in range(c + 1) if num[j] <= den[j]), f"[4] j* {(a, c)}")
            check(f[js] == max(f) and all(f[j] < f[js] for j in range(js)), f"[4] first max {(a, c)}")
            for j in range(js):
                check(f[j + 1] > f[j], f"[4] increase {(a, c, j)}")
            if js < c:
                check(f[js + 1] <= f[js] and ((f[js + 1] == f[js]) == (num[js] == den[js])),
                      f"[4] tie {(a, c)}")
            for j in range(js + 1, c):
                check(f[j + 1] < f[j], f"[4] decrease {(a, c, j)}")
            # Corollary 3.3
            check(f[1] - f[0] == C(N - 2, a) - C(N - 1, a - 1), f"[4] 3.3(i) {(a, c)}")
            if c >= 2:
                check(C(N - 2, a) * a * (N - 1) == c * (c - 1) * C(N - 1, a - 1), f"[4] ratio {(a, c)}")
            lhs, rhs = c * (c - 1), a * (a + c - 1)
            check((f[1] > T) == (lhs > rhs), f"[4] f(1) > T iff {(a, c)}")
            if lhs <= rhs:
                check(all(f[j] < T for j in range(2, c + 1)), f"[4] 3.3(ii) {(a, c)}")
                check(f[1] < T or (lhs == rhs and f[1] == T), f"[4] 3.3(ii) f(1) {(a, c)}")
                check((f[1] == T) == (lhs == rhs), f"[4] 3.3(ii) eq {(a, c)}")
            Bf = max(f)
            check(all(Fm(m) < Bf for m in range(1, 2 * c + 1, 2)), f"[4] 3.3(iii) {(a, c)}")
            # Proposition 3.4 and Part 4 (exact integer form)
            if a <= c:
                Fca = [F(c, a, n) for n in range(2 * a + 1)]
                check(Fca[0] == T and all(v < T for v in Fca[1:]), f"[4] 3.4 {(a, c)}")
                B = max(Bf, max(Fca))
                t = 2 * c - a - 1
                le_cstar = t <= 0 or t * t <= 5 * a * a - 2 * a + 1
                check((B == T) == (lhs <= rhs) == le_cstar, f"[4] Part 4 {(a, c)}")
                if lhs > rhs:
                    check(B == f[js] > T, f"[4] B > T {(a, c)}")
    print(f"[4] section 3, Prop. 3.4, Part 4: 1 <= a, c <= {AMAX} ({time.time() - t0:.1f} s)")

    t0 = time.time()
    getcontext().prec = 60
    s5 = Decimal(5).sqrt()
    phi = (1 + s5) / 2
    lo, hi = (1 - 1 / s5) / 2, (3 - s5) / 2
    eps = Decimal(10) ** -50
    for a in range(1, CSTAR + 1):
        D = 5 * a * a - 2 * a + 1
        cs = ((a + 1) + Decimal(D).sqrt()) / 2
        diff = cs - phi * a
        if a == 1:
            check(abs(diff - hi) < eps and cs == 2, "[4] c*(1) = 2, maximum")
        else:
            check(lo + eps < diff < hi - eps, f"[4] c* - phi a interval {a}")
        c0 = (a + 1 + isqrt(D)) // 2                     # floor(c*)
        check(c0 * (c0 - 1) <= a * (a + c0 - 1) and (c0 + 1) * c0 > a * (a + c0), f"[4] floor c* {a}")
    ties = []
    for a in range(1, TIE + 1):
        D = 5 * a * a - 2 * a + 1
        r = isqrt(D)
        if r * r == D and (a + 1 + r) % 2 == 0:
            ties.append((a, (a + 1 + r) // 2))
    fibties = [(fib(n) * fib(n + 1), fib(n) * fib(n + 2)) for n in range(1, 40, 2)]
    check(ties == [p for p in fibties if p[0] <= TIE] and len(ties) == 8, f"[4] tie set {ties}")
    for n in range(1, 40, 2):
        a, c = fib(n) * fib(n + 1), fib(n) * fib(n + 2)
        check(c * (c - 1) == a * (a + c - 1) and c - a == fib(n) ** 2 and a + c == fib(n) * fib(n + 3)
              and 2 * c - a - 1 == fib(2 * n + 1) and 5 * a - 1 == lucas(2 * n + 1), f"[4] Part 6 n={n}")
    sols = []
    for Y in range(1, PELL + 1):
        X2 = 5 * Y * Y - 4
        X = isqrt(X2)
        if X * X == X2:
            sols.append((X, Y))
    check(sols == [(lucas(k), fib(k)) for k in range(1, 60, 2) if fib(k) <= PELL],
          f"[4] X^2-5Y^2=-4 {sols[:5]}")
    for (X, Y), (X0, Y0) in zip(sols[1:], sols):
        check(((3 * X - 5 * Y) // 2, (3 * Y - X) // 2) == (X0, Y0) and (X - Y) % 2 == 0, f"[4] descent {X, Y}")
    check([lucas(k) % 5 for k in range(40)] == [2, 1, 3, 4] * 10, "[4] Lucas mod 5")
    u, v = 2, 0                                          # (u + v sqrt5)/2 = phi^n
    for n in range(80):
        check((u, v) == (lucas(n), fib(n)), f"[4] Binet-type {n}")
        check(n == 0 or fib(n - 1) * fib(n + 1) - fib(n) ** 2 == (-1) ** n, f"[4] Cassini {n}")
        check(fib(2 * n + 1) == fib(n) ** 2 + fib(n + 1) ** 2, f"[4] F(2n+1) {n}")
        check((u + 5 * v) % 2 == 0 and (u + v) % 2 == 0, f"[4] Z[phi] {n}")
        u, v = (u + 5 * v) // 2, (u + v) // 2
    # Remark 3.5: numerical consistency only (the remark is a limit statement)
    for a in (1, 2, 3, 4):
        th = (2 ** (1 / a) - 1) / (2 ** (1 + 1 / a) - 1)
        check(abs(jstar(a, 20000) / 20000 - th) < 1e-3, f"[4] Remark 3.5 a={a}")
        # R(j) -> 2((1-2 theta)/(1-theta))^a equals 1 exactly at theta_a
        check(abs(2 * ((1 - 2 * th) / (1 - th)) ** a - 1) < 1e-12, f"[4] theta_a root a={a}")
    th2 = (2 ** 0.5 - 1) / (2 ** 1.5 - 1)
    th4 = (2 ** 1e-4 - 1) / (2 ** (1 + 1e-4) - 1)
    check((2 ** 1 - 1) / (2 ** 2 - 1) == 1 / 3 and abs(th2 - 0.2265) < 1e-4
          and abs(th4 * 1e4 / 0.6931471805599453 - 1) < 1e-3, "[4] theta_1, theta_2, theta_a ~ ln2/a")
    print(f"[4] c* (a <= {CSTAR}), ties (a <= {TIE}): {ties[:5]}...; X^2-5Y^2=-4 (Y <= {PELL}); "
          f"Remark 3.5 ({time.time() - t0:.1f} s)")


# ============================================================== section 5 helpers
def g(n, mu):
    return C(mu + n, mu) if n >= 0 else 0


def Gm(n, mu):
    return C(mu + n + 1, mu + 1) if n >= 0 else 0


def cond_ii(mu, nu, h):
    return g(nu - h, mu) + g(nu - h - 1, mu) <= g(nu + 1, mu)


def hmin(mu, nu):
    h = 0
    while not cond_ii(mu, nu, h):
        h += 1
    return h


def cond_a(mu, nu, h):
    return sum(Gm(k, mu) for k in range(nu - 2 * h, nu - h + 1)) >= C(mu + nu + 1, mu)


def sides_b(mu, nu, h):
    lhs = sum(Gm(k, mu) for k in range(nu - h - 1, nu))
    rhs = sum(Gm(nu, mu) - Gm(k, mu) for k in range(nu - h, nu))
    return lhs, rhs


def cond_b(mu, nu, h):
    lhs, rhs = sides_b(mu, nu, h)
    return lhs >= rhs + C(mu + nu, mu - 1)


def cond_bp(mu, nu, h):
    lhs, rhs = sides_b(mu, nu, h)
    return lhs >= rhs


def coeffs(mu, Q, m, J):
    """d_j, 0 <= j <= J, of F(m) - Ktilde in the column basis b_j (column mu, centre (mu, Q/2)):
    F(m) by (E1); V by (E2); for even Q the bound (E3) for H.  Independent of a and c."""
    lo = (m + 1) // 2
    d = [0] * (J + 1)
    # f_j = sum_{i=lo}^{min(m,j)} C(mu-1+j-i, mu-1) = pr[j-lo] - pr[j-min(m,j)-1], where pr are
    # running sums of r[t] = C(mu-1+t, mu-1) (computed by addition, not by the hockey stick)
    pr, run = [], 0
    for t in range(J + 1):
        run += C(mu - 1 + t, mu - 1)
        pr.append(run)
    for j in range(lo, J + 1):
        top = min(m, j)
        d[j] += pr[j - lo] - (pr[j - top - 1] if j - top - 1 >= 0 else 0)
    for i in range((Q + 1) // 2, Q + 1):
        if i <= J:
            d[i] -= g(Q - i, mu)
    if Q % 2 == 0:
        nu = Q // 2
        hc = C(mu + nu, mu - 1)
        d[nu] -= hc
        d[nu + 1] += hc
    return d


def prefix(d):
    D, D2, s1, s2 = [], [], 0, 0
    for v in d:
        s1 += v
        s2 += s1
        D.append(s1)
        D2.append(s2)
    return D, D2


def T2_holds(mu, nu, h):
    """(T2) of Lemma 5.9, cross-multiplied (all factors positive)."""
    L = (nu - h) * (nu - h + 1) * 6 * (mu + nu) * (h + 1) * (nu + 1)
    R = (mu + 1) * (2 * (nu - h + 1) + mu) * mu * (h * (h + 2) * (h + 1) * (nu + 1) + 6 * (mu + nu))
    return nu - h + 1 > 0 and L >= R


def in_step2_region(mu, nu):
    return mu >= 5 or (mu == 4 and nu >= 15) or (mu == 3 and nu >= 14) or (mu == 2 and nu >= 15)


# ============================================================== [5] section 5
def section5(EMAX=24, L53=50, L55=26, MU=60, NU=600, L510=50):
    t0 = time.time()
    # s.5.2: the column basis
    for al in range(1, 7):
        for c in range(1, 16):
            b = [C(al + c - j, al) for j in range(c + 1)] + [0, 0]
            for j in range(c + 1):
                d2 = b[j] - 2 * b[j + 1] + b[j + 2]
                exp = C(al - 2 + c - j, al - 2) if j <= c - 2 else (al - 1 if j == c - 1 else 1)
                check(b[j] >= b[j + 1] and d2 == exp and d2 >= 0 and (al < 2 or d2 > 0),
                      f"[5] basis {(al, c, j)}")
    for mu in range(1, 9):
        for n in range(-5, 41):
            check(g(n + 1, mu) - 2 * g(n, mu) + g(n - 1, mu) >= 0, f"[5] g convex {(mu, n)}")
            check(Gm(n + 1, mu) - 2 * Gm(n, mu) + Gm(n - 1, mu) >= 0, f"[5] Gamma convex {(mu, n)}")
            check(g(n + 1, mu) >= g(n, mu) and Gm(n + 1, mu) >= Gm(n, mu), f"[5] monotone {(mu, n)}")
            check(sum(g(k, mu) for k in range(0, n + 1)) == Gm(n, mu), f"[5] hockey {(mu, n)}")
    # Lemma 5.1: (E1)-(E3) for every content a + c <= EMAX, every integer column
    ne = 0
    for s in range(3, EMAX + 1):
        for a in range(2, s):
            c = s - a
            for mu in range(1, a):
                al = a - mu
                b = [C(al + c - j, al) for j in range(c + 1)] + [0, 0]
                for m in range(2 * c + 1):
                    lo = (m + 1) // 2
                    e1 = sum(sum(C(mu - 1 + j - i, mu - 1) for i in range(lo, min(m, j) + 1)) * b[j]
                             for j in range(c + 1))
                    check(e1 == F(a, c, m), f"[5] E1 {(a, c, mu, m)}")
                for Q in range(1, 2 * c):
                    V = sum(g(Q - i, mu) * b[i] for i in range((Q + 1) // 2, min(Q, c) + 1))
                    H = K21(a, c, 2 * mu, Q) - V
                    if Q % 2:
                        check(H == 0, f"[5] H half {(a, c, mu, Q)}")
                    else:
                        nu = Q // 2
                        bound = C(mu + nu, mu - 1) * (b[nu] - b[nu + 1])
                        check(0 <= H <= bound and (mu > 1 or H == bound), f"[5] E3 {(a, c, mu, Q)}")
                    ne += 1
    # Lemma 5.2 on deterministic sequences
    for al in range(1, 4):
        for c in range(1, 8):
            b = [C(al + c - j, al) for j in range(c + 1)] + [0, 0]
            for seed in range(5):
                d = [((j * j * 3 + 5 * j + seed) % 7) - 3 for j in range(c + 1)]
                D, D2 = prefix(d)
                s0 = sum(d[j] * b[j] for j in range(c + 1))
                s1 = sum((b[J] - b[J + 1]) * D[J] for J in range(c + 1))
                s2 = sum((b[J] - 2 * b[J + 1] + b[J + 2]) * D2[J] for J in range(c + 1))
                check(s0 == s1 == s2, f"[5] Lemma 5.2 {(al, c, seed)}")
    n22 = 0
    for s in range(2, EMAX + 1):
        for a in range(1, s):
            c = s - a
            for P in range(1, 2 * a):
                for Q in range(1, 2 * c):
                    if P % 2 == 0 or Q % 2 == 0:
                        k0 = K21(a, c, P, Q)
                        check(k0 == K21(a, c, 2 * a - P, 2 * c - Q) == K21(c, a, Q, P), f"[5] (2.2) {(a, c, P, Q)}")
                        n22 += 1
    print(f"[5] column basis, g/Gamma, (E1)-(E3) on {ne} (content, column, height), a + c <= {EMAX}; "
          f"Lemma 5.2; (2.2) on {n22} interior centres ({time.time() - t0:.1f} s)")

    t0 = time.time()
    # Lemma 5.3, coefficient level and content level
    for mu in range(1, 13):
        for k in range(0, mu):
            D, _ = prefix(coeffs(mu, 2 * k + 1, 0, 2 * k + 6))
            check(all(v >= 0 for v in D) and all(D[J] > 0 for J in range(k + 1, len(D))),
                  f"[5] 5.3 coeff {(mu, k)}")
    n53 = 0
    for s in range(3, L53 + 1):
        for a in range(2, s):
            c = s - a
            T = C(a + c, a)
            for mu in range(1, a):
                for k in range(0, min(mu - 1, c - 1) + 1):
                    check(K21(a, c, 2 * mu, 2 * k + 1) < T, f"[5] 5.3 {(a, c, mu, k)}")
                    n53 += 1
    # Lemma 5.4, content level (mu = 1)
    n54 = 0
    for s in range(3, L53 + 1):
        for a in range(2, s):
            c = s - a
            T = C(a + c, a)
            for Q in range(2, 2 * c):                 # nu = Q/2 in [1, c)
                K = K21(a, c, 2, Q)
                n54 += 1
                if Q == 2:
                    check(K == 3 * C(a + c - 2, a - 1) and K <= T and ((K == T) == (a == c == 2)),
                          f"[5] 5.4 nu=1 {(a, c)}")
                elif Q == 4:
                    F2 = F(a, c, 2)
                    check(K <= F2 and ((K == F2) == ((a, c) == (2, 3))), f"[5] 5.4 nu=2 {(a, c)}")
                elif Q % 2 == 0:
                    check(K < F(a, c, 2 * ((Q // 2) // 2)), f"[5] 5.4 nu>=3 {(a, c, Q)}")
                else:
                    l = (Q - 1) // 2
                    check(K < F(a, c, 2 * ((l + 1) // 2)), f"[5] 5.4 half {(a, c, Q)}")
    check(K21(2, 3, 2, 4) == F(2, 3, 2) == 9 and C(5, 2) == 10, "[5] 5.4 (2,3) values")
    # Lemma 5.4, the corrected statements on D(S) (prefix sums in the basis beta_s = b_{nu+s})
    for nu in range(2, 31):
        h = nu // 2
        d = coeffs(1, 2 * nu, 2 * h, 3 * nu + 10)
        D, D2 = prefix(d)

        def DS(S):
            J = nu + S
            return D[J] if J >= 0 else 0
        if nu == 2:
            check([DS(S) for S in (-2, -1, 0, 1, 2)] == [0, 1, -1, 0, 1]
                  and [D2[nu + S] for S in (-1, 0, 1, 2)] == [1, 0, 0, 1] and min(D2) >= 0
                  and [d[nu + S] for S in (-1, 0, 1, 2, 3)] == [1, -2, 1, 1, 2], "[5] 5.4 nu=2 sequences")
            continue
        check(all(DS(S) == 0 for S in range(-nu - 2, h - nu)) and DS(h - nu) == 1
              and all(DS(S) > 0 for S in range(h - nu, 0)), f"[5] 5.4 S<0 nu={nu}")
        q0 = (h + 1) * (h - 2) // 2 if nu % 2 == 0 else (h + 2) * (h - 1) // 2
        check(DS(0) == q0 and q0 >= 0, f"[5] 5.4 D(0) nu={nu}")
        for S in range(1, nu + 1):
            q = (S - h) * (S - h + 1) // 2 if nu % 2 == 0 else (S - h) * (S - h - 1) // 2
            check(DS(S) == q, f"[5] 5.4 quadratic nu={nu} S={S}")
        check(all(DS(S + 1) >= DS(S) for S in range(nu, 2 * nu + 5)), f"[5] 5.4 beyond nu={nu}")
        check(min(D) >= 0, f"[5] 5.4 D >= 0 nu={nu}")
    check(prefix(coeffs(1, 6, 2, 30))[0][3 + 5] == 5 and (5 - 1) * (5 - 2) // 2 == 6,
          "[5] 5.4 old wording fails at nu=3, S=5 (D = 5 < 6)")
    check(all(prefix(coeffs(1, 8, 4, 30))[0][J] == 0 for J in (0, 1)), "[5] 5.4 D(-4) = D(-3) = 0 at nu=4")
    for l in range(1, 31):
        h = (l + 1) // 2
        d = coeffs(1, 2 * l + 1, 2 * h, 3 * l + 10)
        D, _ = prefix(d)

        def DS(S):
            J = l + 1 + S
            return D[J] if J >= 0 else 0
        check(all(DS(S) == 0 for S in range(-l - 3, h - l - 1)) and all(DS(S) > 0 for S in range(h - l - 1, 2 * l + 5)),
              f"[5] 5.4 half signs l={l}")
        for S in range(0, l + 1):
            q2 = S * S - (2 * h - 3) * S + h * h - h + 2 if l == 2 * h - 1 else S * S - (2 * h - 1) * S + h * h + h + 2
            check(2 * DS(S) == q2, f"[5] 5.4 half quadratic l={l} S={S}")
        check(all(DS(S + 1) >= DS(S) for S in range(l, 2 * l + 5)), f"[5] 5.4 half beyond l={l}")
    check(prefix(coeffs(1, 3, 2, 30))[0][2 + 3] == 6 and (9 + 3 + 2) // 2 == 7,
          "[5] 5.4 old wording fails at l=1, S=3 (D = 6, quadratic 7)")
    print(f"[5] Lemma 5.3 ({n53} content cases), Lemma 5.4 ({n54} content cases), a + c <= {L53}; "
          f"D(S) statements of Lemma 5.4 ({time.time() - t0:.1f} s)")

    t0 = time.time()
    # Lemma 5.5: closed forms, window identity, convexity of D°, the criterion's conclusion
    for mu in range(1, 9):
        for nu in range(mu, 31):
            hc = C(mu + nu, mu - 1)
            for h in range(0, nu + 1):
                J = 2 * nu + 2 * h + 8
                d = coeffs(mu, 2 * nu, 2 * h, J)
                D, D2 = prefix(d)
                lhs, rhs = sides_b(mu, nu, h)
                check(D2[nu] == sum(Gm(k, mu) for k in range(nu - 2 * h, nu - h + 1)) - C(mu + nu + 1, mu)
                      == sum(Gm(nu - i, mu) for i in range(h, 2 * h + 1)) - g(nu, mu) - hc,
                      f"[5] 5.5 D2(nu) {(mu, nu, h)}")
                check(D2[nu + h] == lhs - rhs - hc
                      == sum(Gm(k, mu) for k in range(nu - h, nu + 1))
                      - ((h + 1) * Gm(nu, mu) - sum(Gm(k, mu) for k in range(nu - h - 1, nu))) - hc,
                      f"[5] 5.5 D2(nu+h) {(mu, nu, h)}")
                Do = [D[j] + (hc if j == nu else 0) for j in range(len(D))]
                check(Do[nu + h] == 0 and Do[nu + h + 1] == g(nu + 1, mu) - g(nu - h, mu) - g(nu - h - 1, mu),
                      f"[5] 5.5 window {(mu, nu, h)}")
                check(all(Do[j + 1] - 2 * Do[j] + Do[j - 1] >= 0 for j in range(max(nu, 1), J)),
                      f"[5] 5.5 convex {(mu, nu, h)}")
                if cond_ii(mu, nu, h) and cond_a(mu, nu, h) and cond_b(mu, nu, h):
                    check(min(D2) >= 0 and D[J] > 0, f"[5] 5.5(1) conclusion {(mu, nu, h)}")
                l = nu
                dh = coeffs(mu, 2 * l + 1, 2 * h + 1, J)
                Dh, D2h = prefix(dh)
                check(D2h[l + h + 1] == lhs - rhs and D2h[l] == sum(Gm(l - i, mu) for i in range(h + 1, 2 * h + 2))
                      and Dh[l + h + 1] == 0 and Dh[l + h + 2] == g(l + 1, mu) - g(l - h, mu) - g(l - h - 1, mu),
                      f"[5] 5.5 half closed forms {(mu, nu, h)}")
                if cond_ii(mu, l, h) and cond_bp(mu, l, h):
                    check(min(D2h) >= 0 and Dh[J] > 0, f"[5] 5.5(2) conclusion {(mu, nu, h)}")
                if h <= nu - 1:
                    check(D2[h] == 1 and D2h[h + 1] == 1, f"[5] 5.5 strict witness {(mu, nu, h)}")
    n55 = 0
    crit = {}
    for mu in range(1, L55):
        for nu in range(mu, L55):
            for h in range(0, nu + 1):
                ii = cond_ii(mu, nu, h)
                crit[(mu, nu, h)] = (ii and cond_a(mu, nu, h) and cond_b(mu, nu, h), ii and cond_bp(mu, nu, h))
    for s in range(3, L55 + 1):
        for a in range(2, s):
            c = s - a
            for mu in range(1, a):
                for nu in range(mu, c):
                    Kc = K21(a, c, 2 * mu, 2 * nu)
                    Kh = K21(a, c, 2 * mu, 2 * nu + 1)
                    for h in range(0, nu + 1):
                        int_ok, half_ok = crit[(mu, nu, h)]
                        if int_ok:
                            Fv = F(a, c, 2 * h)
                            check(Kc <= Fv and (a < mu + 2 or h > nu - 1 or Kc < Fv), f"[5] 5.5(1) {(a, c, mu, nu, h)}")
                            n55 += 1
                        if half_ok:
                            Fv = F(a, c, 2 * h + 1)
                            check(Kh <= Fv and (a < mu + 2 or h > nu - 1 or Kh < Fv), f"[5] 5.5(2) {(a, c, mu, nu, h)}")
                            n55 += 1
    print(f"[5] Lemma 5.5: closed forms (mu <= 8, nu <= 30, all h), content level {n55} cases "
          f"(a + c <= {L55}) ({time.time() - t0:.1f} s)")

    t0 = time.time()
    # Lemmas 5.6-5.9 over mu <= MU, nu <= NU
    s5 = Fr(0)
    npairs = n2 = 0
    for mu in range(1, MU + 1):
        check(hmin(mu, mu) == 0, f"[5] hmin(mu,mu) {mu}")
        for nu in range(mu, NU + 1):
            npairs += 1
            h = hmin(mu, nu)
            check(cond_a(mu, nu, 0) and cond_b(mu, nu, 0) and cond_bp(mu, nu, 0), f"[5] 5.6 {(mu, nu)}")
            check(cond_ii(mu, nu, 0) == (mu * (mu + nu) >= nu * (nu + 1)), f"[5] (5.2) {(mu, nu)}")
            if h == 0:
                continue
            # h >= 1 implies nu > phi*mu - 0.73, i.e. 2 nu + 1.46 - mu > sqrt5 mu
            t = Fr(2 * nu - mu) + Fr(146, 100)
            check(t > 0 and t * t > 5 * mu * mu, f"[5] golden bound {(mu, nu)}")
            check(g(nu - h + 1, mu) + g(nu - h, mu) > g(nu + 1, mu), f"[5] (F2) {(mu, nu)}")
            S = nu + mu + 1
            check(2 * (S - h) ** mu > S ** mu and 10000 * h * mu < 6932 * S, f"[5] 5.8(i) {(mu, nu)}")
            if h >= 2:
                check(nu + 1 > 3 * mu, f"[5] 5.8(ii) {(mu, nu)}")
            if mu >= 3 or (mu == 2 and nu >= 6):
                check(h <= nu - mu - 1 and cond_a(mu, nu, h), f"[5] 5.8(iii) {(mu, nu)}")
            if h == 1 and mu >= 3:
                check(cond_a(mu, nu, 1) and cond_b(mu, nu, 1), f"[5] 5.7 {(mu, nu)}")
            if h == 1 and mu == 2:
                check(3 <= nu <= 6 and ((cond_a(2, nu, 1) and cond_b(2, nu, 1)) == (nu != 3)), f"[5] 5.7 mu=2 {nu}")
            if mu == 2:
                check((h == 1) == (3 <= nu <= 6), f"[5] hmin(2,nu) {nu}")
            if mu >= 2 and (mu, nu) != (2, 3):
                check(cond_a(mu, nu, h) and cond_b(mu, nu, h) and cond_bp(mu, nu, h), f"[5] criterion {(mu, nu)}")
            if h >= 2:
                n2 += 1
                # Lemma 5.9, Step 1: exact identity
                lhs, rhs = sides_b(mu, nu, h)
                left = (h + 1) * Gm(nu - h - 1, mu)
                right = sum((h - 2 * s) * (g(nu - s, mu) - g(nu - h + s, mu)) for s in range(0, (h + 1) // 2)) \
                    + C(mu + nu, mu - 1)
                check(left - right == lhs - rhs - C(mu + nu, mu - 1), f"[5] 5.9 step 1 {(mu, nu)}")
                pair_sum = sum((h - 2 * s) * (g(nu - s, mu) - g(nu - h + s, mu)) for s in range(0, (h + 1) // 2))
                check(6 * pair_sum <= h * (h + 1) * (h + 2) * (g(nu, mu) - g(nu - 1, mu))
                      and 6 * sum((h - 2 * s) ** 2 for s in range(0, (h + 1) // 2)) == h * (h + 1) * (h + 2),
                      f"[5] 5.9 convexity {(mu, nu)}")
                check(g(nu, mu) * (nu - h + 1) < (2 * (nu - h + 1) + mu) * g(nu - h, mu), f"[5] 5.9 r_h {(mu, nu)}")
                G0 = g(nu - h, mu)
                check(Gm(nu - h - 1, mu) * (mu + 1) == (nu - h) * G0
                      and (g(nu, mu) - g(nu - 1, mu)) * (mu + nu) == g(nu, mu) * mu
                      and C(mu + nu, mu - 1) * (nu + 1) == g(nu, mu) * mu, f"[5] 5.9 ratios {(mu, nu)}")
                if in_step2_region(mu, nu):
                    check(T2_holds(mu, nu, h), f"[5] (T2) {(mu, nu)}")
                    tt = Fr(nu + 1, mu)
                    eta = Fr(6932, 10000) * (1 + tt)
                    L = tt - (tt + 1 + eta) / (mu + 1)
                    R = (2 + 1 / (tt - eta / mu)) * (eta * (eta + 2) / (6 * (1 + tt - Fr(1, mu))) + 1 / (3 * tt))
                    check(eta > h and tt - eta / mu > 0 and L >= R, f"[5] Step 2 eta {(mu, nu)}")
                elif mu >= 2:
                    check(mu in (2, 3, 4) and nu <= 14, f"[5] h >= 2 outside region and box {(mu, nu)}")
    # small facts used inside the proofs of Lemmas 5.7-5.9
    check(Fr(3, 4) ** 2 + Fr(3, 4) ** 3 == Fr(63, 64), "[5] 5.8(ii) 63/64")
    for mu in range(1, MU + 1):
        check((g(mu + 2, mu) - g(mu + 1, mu) >= g(mu, mu)) == (mu * mu - 2 * mu - 2 >= 0)
              and g(mu + 2, mu) - g(mu + 1, mu) == C(2 * mu + 1, mu - 1), f"[5] 5.8(iii) step {mu}")
        for w in range(mu, 4 * mu + 60):
            check(2 * Gm(w, mu) >= g(w + 2, mu), f"[5] 5.8(iii) 2 Gamma(w) >= g(w+2) {(mu, w)}")
    # mu = 2: 1 - 2^(-1/2) < 0.2929 (exactly: 0.7071^2 < 1/2), and 0.2929 (nu+3) <= nu - 3 for nu >= 6
    check(all(2929 * (nu + 3) <= 10000 * (nu - 3) for nu in range(6, NU + 1))
          and Fr(7071, 10000) ** 2 < Fr(1, 2), "[5] 5.8(iii) mu = 2")
    for mu in range(3, MU + 1):
        check(all((mu - 1) * (nu - 3) >= 4 for nu in range(5, NU + 1))
              and all(nu * (nu + 1) <= mu * (mu + nu) or nu * nu - 2 * nu - 9 > 0 for nu in range(mu, NU + 1)),
              f"[5] 5.7 algebra {mu}")
    # (T2) => (b) under (F2), every h >= 1 (mu <= 10, nu <= 40)
    for mu in range(1, 11):
        for nu in range(mu, 41):
            for h in range(1, nu + 1):
                if g(nu - h + 1, mu) + g(nu - h, mu) > g(nu + 1, mu) and T2_holds(mu, nu, h):
                    check(cond_b(mu, nu, h), f"[5] T2 => b {(mu, nu, h)}")
    print(f"[5] Lemmas 5.6-5.9 on {npairs} pairs (mu <= {MU}, nu <= {NU}), {n2} with h_min >= 2 "
          f"({time.time() - t0:.1f} s)")

    t0 = time.time()
    # Lemma 5.10 at content level
    n510 = 0
    hm = {}
    for s in range(4, L510 + 1):
        for a in range(3, s):
            c = s - a
            for mu in range(2, a):
                for nu in range(mu, c):
                    if (mu, nu) not in hm:
                        hm[(mu, nu)] = hmin(mu, nu)
                    m = 0 if (mu, nu) == (2, 3) else 2 * hm[(mu, nu)]
                    K = K21(a, c, 2 * mu, 2 * nu)
                    Fv = F(a, c, m)
                    check(K <= Fv and (a < mu + 2 or K < Fv), f"[5] 5.10 {(a, c, mu, nu)}")
                    Kh = K21(a, c, 2 * mu, 2 * nu + 1)
                    Fh = F(a, c, 2 * hm[(mu, nu)] + 1)
                    check(Kh <= Fh and (a < mu + 2 or Kh < Fh), f"[5] 5.10 half {(a, c, mu, nu)}")
                    n510 += 2
    print(f"[5] Lemma 5.10: {n510} (content, centre) cases, a + c <= {L510} ({time.time() - t0:.1f} s)")


# ============================================================== [6] certificate
def section6():
    t0 = time.time()
    n1 = 0
    for mu in (2, 3, 4):
        for nu in range(mu, 15):
            h = hmin(mu, nu)
            if (mu, nu) != (2, 3):
                check(cond_ii(mu, nu, h) and cond_a(mu, nu, h) and cond_b(mu, nu, h), f"[C1] {(mu, nu, h)}")
                n1 += 1
            check(cond_ii(mu, nu, h) and cond_bp(mu, nu, h), f"[C1] half {(mu, nu, h)}")
            n1 += 1
    lhs, rhs = sides_b(2, 3, 1)
    check(hmin(2, 3) == 1 and sum(Gm(k, 2) for k in (1, 2)) == 14 and C(6, 2) == 15
          and lhs == 14 and rhs + C(5, 1) == 15 and rhs == 10
          and not cond_a(2, 3, 1) and not cond_b(2, 3, 1) and cond_bp(2, 3, 1), "[C1] (2,3) numbers")
    # [C2]: centre (2,3), m = 0
    d = coeffs(2, 6, 0, 40)
    D, D2 = prefix(d)
    check(D[3:7] == [-5, -1, 2, 8] and D2[2:6] == [10, 5, 4, 6] and D2[0] == 1 and min(D2) >= 0
          and all(d[j] > 0 for j in range(7, 41)), "[C2] (2,3), m = 0")
    # [C3]: ln 2 < 6932/10000 (ln 2 = sum 1/(k 2^k); tail after K terms < 1/((K+1) 2^K))
    Kt = 40
    ln2_upper = sum(Fr(1, k * 2 ** k) for k in range(1, Kt + 1)) + Fr(1, (Kt + 1) * 2 ** Kt)
    cl = Fr(6932, 10000)
    check(ln2_upper < cl, "[C3] ln 2 < 0.6932")
    want = {(5, 3): ("0.5147", "0.2053"), (4, 4): ("0.4659", "0.5719"),
            (3, 5): ("0.3836", "0.5930"), (2, 8): ("0.2486", "0.6063")}
    for (mu0, t1), (ws, wv) in want.items():
        t1 = Fr(t1)
        delta1 = t1 * (1 - cl / mu0) - cl / mu0
        kap = (1 + t1) / (1 + t1 - Fr(1, mu0))
        A2 = (2 + 1 / delta1) * kap * cl * cl / 6
        A1 = (2 + 1 / delta1) * (kap * cl * (cl + 2) / 6 + 1 / (3 * t1))
        L2 = 1 - (1 + cl) / (mu0 + 1)
        L1 = (1 + cl) / (mu0 + 1)
        val = (L2 - A2) * t1 - A1 - L1
        check(delta1 > 0 and L2 > A2 and val >= 0, f"[C3] {(mu0, t1)}")
        check(f"{float(L2 - A2):.4f}" == ws and f"{float(val):.4f}" == wv,
              f"[C3] quoted numbers {(mu0, t1)}: {float(L2 - A2):.4f} {float(val):.4f}")
    print(f"[6] certificate: [C1] {n1} cases, (2,3) numbers; [C2]; [C3] four inequalities and the "
          f"quoted slopes/values; ln 2 < 0.6932 ({time.time() - t0:.1f} s)")


# ============================================================== [7] exploration statements
def section7():
    t0 = time.time()
    # explore_exits2.py 10 60: no admissible M at the centres (2,10) and (3,10)
    def valid(p2, q2, M, LIM):
        if p2 % 2 == 0:
            p = p2 // 2
            for k in range(1 if q2 % 2 == 0 else 0, LIM):
                qq2 = 2 * k + q2 % 2
                c = (q2 + qq2) // 2
                if F(p, c, qq2) > F(p, c, M):
                    return False
        if q2 % 2 == 0:
            q = q2 // 2
            for k in range(1 if p2 % 2 == 0 else 0, LIM):
                pp2 = 2 * k + p2 % 2
                a = (p2 + pp2) // 2
                if F(q, a, pp2) > F(a, q, M):
                    return False
        return True
    check(not any(valid(4, 20, M, 60) for M in range(21)) and not any(valid(6, 20, M, 60) for M in range(21))
          and [M for M in range(19) if valid(4, 18, M, 60)] == [4], "[7] explore_exits2 centres")
    # the (24,2,2) class (24,2,24) by brute force
    n = 0
    cnt = 0
    for w in words(24, 2):
        n += 1
        if scan(w) == (24, 2, 24):
            cnt += 1
    check(n == C(28, 2) * C(26, 2) and cnt == 820 > C(26, 24) == 325, "[7] (24,2,2) by brute force")
    # last-letter recursion K_{a,c} = K_{a-1,c} + K_{a,c-1} at interior Cauchy centres
    tabs = {}
    for s in range(2, 19):
        for a in range(1, s):
            tabs[(a, s - a)] = gap_classes(a, s - a)

    def Kt(a, c, P, Q):
        if not (0 <= P <= 2 * a and 0 <= Q <= 2 * c) or (a, c) not in tabs:
            return 0
        x, y = P, 2 * c - Q
        return tabs[(a, c)].get(key_of(a, c, x, y, x * y // 2), 0)
    nr = 0
    for (a, c) in tabs:
        if a >= 2 and c >= 2:
            for P in range(1, 2 * a):
                for Q in range(1, 2 * c):
                    if (P * (2 * c - Q)) % 2 == 0:
                        check(Kt(a, c, P, Q) == Kt(a - 1, c, P, Q) + Kt(a, c - 1, P, Q), f"[7] recursion {(a, c, P, Q)}")
                        nr += 1
    print(f"[7] explore_exits2 centres (2,10), (3,10); (24,2,24) = 820 over {n} words; "
          f"last-letter recursion on {nr} interior centres (a + c <= 18) ({time.time() - t0:.1f} s)")


def main():
    t0 = time.time()
    section1()
    section23()
    section4()
    section5()
    section6()
    section7()
    print(f"check_r7_golden: {NCHECK[0]} checks, {len(FAIL)} failures, {time.time() - t0:.1f} s")
    if FAIL:
        sys.exit(1)


if __name__ == "__main__":
    main()
