"""check_top_gap: the top of a ternary fibre.

Theorem C of notes/article2-design.md (section 3) and the theorems T2-T5 of
notes/ternary-defect-theorems.md (sections 2-5) (Phase 0 gate, sections [1]-[6]); since the
Phase 1a finaliser (20-21 October 2026), also every claim and every quoted number of
notes/proof-top-gap-rigidity.md: Theorem 1 (three cases at the top of a fibre), Theorem A(i),
Theorem C, the lemmas of its proof, its worked examples and the source tables it quotes
(sections [7]-[13], described after the Phase 0 outcome below).

Python standard library only; deterministic; exact integer arithmetic (no floats anywhere).
Unknown command-line arguments are ignored (run_all.py passes e.g. --max-n); --full selects the
slow ranges shown in brackets below. Exit status is non-zero on any failure. The last line is
"check_top_gap: N checks, F failures, T s". A passing run is evidence on the stated finite
ranges (VERIFIED), not a proof.

Setting
-------
Content (a,b,c), a,b,c >= 1, over 1 < 2 < 3; x = |w|_12, y = |w|_23, z = |w|_123 (scattered
subwords); rho(x,y,z) = number of words; Z(x,y) = set of attained z; x = b qx + r and
y = b qy + s with 0 <= r, s < b. Profiles (notes/proof-r2-extrema.md Lemma 1.1): A_t = number of
1's before the t-th 2 (weakly increasing, in [0,a]); C_t = number of 3's after it (weakly
decreasing, in [0,c]); x = sum A, y = sum C, z = A.C. Gap occupancies a_0 = A_1,
a_g = A_(g+1) - A_g, a_b = a - A_b; c_0 = c - C_1, c_g = C_g - C_(g+1), c_b = C_b; the number of
words with profile pair (A,C) is W(A,C) = prod_g C(a_g + c_g, a_g).
eta_n = 6 if n = 2 and 2 floor(n/2) + 2 if n >= 3 (H_n in the ternary note).
L_m = ((-1)^m, 0^(b-2m), 1^m) for 0 <= m <= floor(b/2) (ternary note, section 2).

Claims tested (re-typed from the notes; nothing is imported from notes/)
-----------------------------------------------------------------------
 (C)   b >= 2, |Z(x,y)| >= 2: z_max - 1 is missing from Z(x,y) iff
         (T2)  r = s = 0, 1 <= qx <= a-1 and 1 <= qy <= c-1; or
         (T5)  2 <= x <= b-1 and y = bc - x; or
         (T5R) 2 <= y <= b-1 and x = ab - y;
       and in each of these cases z_max - 2 is in Z(x,y).
 (T2)  x = bp, y = bq, 1 <= p < a, 1 <= q < c: max Z = bpq, bpq-1 is not attained, bpq-2 is,
       and the profile pairs with A.C = bpq-2 are exactly (p+L_m, q-L_1) and (p+L_1, q-L_m),
       1 <= m <= floor(b/2).
 (T3)  rho(bp, bq, bpq-2) = eta_b C(p+c-q-2, p-1) C(a-p+q-2, a-p-1).
 (T4)  content (2,b,2), x = y = b, h = floor(b/2): Z(b,b) = {b-2r : 0 <= r <= h};
       rho(b,b,b) = 2h+4; rho(b,b,b-2r) = 2(h-r) + 4 + 2[b even and r = h] for 1 <= r <= h;
       sum_z rho(b,b,z) = (h+2)(h+3) if b = 2h and (h+1)(h+4) if b = 2h+1.
 (T5)  a,c >= 2, 2 <= r < b, x = r, y = bc - r: max Z = (c-1)r, (c-1)r - 1 is not attained,
       rho(r, bc-r, (c-1)r-2) = eta_r C(a+c-4, a-2).
 (T5R) the reversal image, tested directly: x = ab - r, y = r: max Z = (a-1)r, (a-1)r - 1 is
       not attained, rho(ab-r, r, (a-1)r-2) = eta_r C(a+c-4, a-2).
 (Rev) word reversal sends (x,y,z) to (ab-x, bc-y, abc-ay-cx+z), so it maps the fibre of each
       triple bijectively onto the fibre of its image (the triple map is an involution).

Methods (each computes the fibres from scratch; none uses a claim under test)
------------------------------------------------------------------------------
 WE   word enumeration: every word of every content with a+b+c <= NWE [9; full 12]; x, y, z
      by parikh.occ (the only helper reused from checks/parikh.py: word-level subword counts).
 WDP  last-letter recursion over words: appending 1, 2 or 3 to a prefix of content (n1,n2,n3)
      changes (x,y,z) by (0,0,0), (n1,0,0) or (0,n2,x). Exact rho for every content with
      a+b+c <= NDP [12; full 22, raised from 15]. Compared with WE on every triple for a+b+c <= NWE.
 PE   profile enumeration: every weakly monotone pair (A,C), z = A.C, weight W(A,C).
      Validated (a) word by word against WE: x = sum A, y = sum C, z = A.C, and the number of
      words with each profile pair equals W(A,C), for every monotone pair (a+b+c <= NWE);
      (b) the W-weighted PE distribution equals WDP on every triple, a+b+c <= NPE [12; full 13].
 PBS  profile bitset DP: Z(x,y) for every (x,y) by a transfer over positions t = 1..b with
      state (A_t, C_t) and one big-int bitset indexed by (sum A, sum C, A.C). Equal to the PE
      sets (all pairs) for a,c <= PEZ_AC, b <= PEZ_B [5, 6; full 6, 7], and to the WDP sets on
      every content that both cover.

Sections and ranges (default [--full])
--------------------------------------
 [1] WE, a+b+c <= 9 [12]: Lemma 1.1(a) per word, W(A,C) per monotone pair, the reversal
     formula per word, fibre bijection of (Rev) per triple.
 [2] WDP, a+b+c <= 12 [22]: WDP = WE (a+b+c <= 9 [12]); WDP = weighted PE (a+b+c <= 12 [13]);
     (Rev) as rho(t) = rho(image of t) for every triple; (C) at word level on every cell with
     |Z| >= 2 of every content with b >= 2; T2/T3, T5, T5R, T4 at word level on every
     content of the range that satisfies their hypotheses.
 [3] PBS: (C) at profile level, 1 <= a,c <= 5, 2 <= b <= 6 [1 <= a,c <= 7, 2 <= b <= 9].
 [4] T2/T3 at profile level (all pairs of the two profile sets, weights W):
     2 <= a,c <= 6, 2 <= b <= 8 [2 <= a,c <= 7, 2 <= b <= 10].
 [5] T4: profile level 1 <= b <= 24 [40] (every monotone profile with entries in {0,1,2}, all
     pairs, weights W); word level 1 <= b <= 7 [10] by WE.
 [6] T5 and T5R at profile level: 2 <= a,c <= 6, 3 <= b <= 8 [2 <= a,c <= 7, 3 <= b <= 10],
     every 2 <= r <= b-1.

 Also checked in [3]: every (x,y) of the box [0,ab] x [0,bc] has a nonempty Z(x,y).

Phase 0 outcome (20 October 2026, sections [1]-[6] only, Python 3.11.9; also runs under 3.9)
--------------------------------------------------------------------------------------------
No claim failed; no statement was corrected. Default: 46,600 checks, about 2 s. --full:
353,458 checks, about 30 s; log in notes/article2-scripts/top_gap/full-run-2026-10-20.log.
(The --full word range of [2] has since been raised from a+b+c <= 15 to 22; see below.)
VERIFIED (evidence, not proof) on these exact ranges:
 (C)   profile level: every cell with |Z| >= 2 of every content 1 <= a,c <= 7, 2 <= b <= 9
       (193,500 cells; 5,544 top gaps = 3,528 T2 + 1,008 T5 + 1,008 T5R, none outside the three
       cases, z_max - 2 attained in each); word level: every content with b >= 2 and
       a+b+c <= 15 (60,192 cells; 2,992 gaps = 2,002 + 495 + 495).
 T2/T3 profile level 2 <= a,c <= 7, 2 <= b <= 10 (3,969 points (p,q), equality-profile sets
       included); word level every content with a+b+c <= 15 (2,002 points).
 T4    profile level 1 <= b <= 40; word level 1 <= b <= 10 by WE and 2 <= b <= 11 by WDP.
 T5/T5R profile level 2 <= a,c <= 7, 3 <= b <= 10, 2 <= r < b (2,592 points); word level every
       content with a+b+c <= 15 (990 points).
 Rev   per word for a+b+c <= 12 (772,626 words); rho(t) = rho(image of t) for a+b+c <= 15.
Mutation tests (notes/article2-scripts/top_gap/mutation_tests.py) confirm that each check fails
when its claim or method is altered.

Phase 1a finaliser additions (20-21 October 2026)
-------------------------------------------------
The claims below are re-typed from notes/proof-top-gap-rigidity.md; nothing is imported from
notes/. Rules (E), (N), (Ch), (Gamma) with gamma(m,n) = {0..mn} if min(m,n) <= 1, else
{0, 1, mn-1, mn}; exceptional families T2, T5, T5R (b >= 2; a, c >= 2 for T5, T5R).
 [2]  (extended) the WDP now runs to a+b+c <= 12 [22] and tests Theorem 1 in full on every cell
      (see [7]) and [Y26a] Thm 6, eq. (5.1), on every cell of its first exterior layer: the
      multiplicities p_a(j)p_c(i) + 1 + [j=2] + [i=2] at lambda and 1 at lambda + 1, and the
      word (5.2).
 [7]  Theorem 1 in full on every cell of every content, on the WE tables (a+b+c <= 9 [12]) and
      the profile bitsets (1 <= a,c <= 5, 1 <= b <= 6 [7, 9]): the rigid values (0 under (N),
      lambda under (Ch), 0/ay/cx under (E), A.C for the unique profiles under (Gamma)); Theorem
      A(i) (|Z| = 1 iff rigid); max Z = Theorem B(i); min Z >= max(0, lambda); Lemma 8.1; b = 1
      cells are (Gamma); Remark 8.2 (Theorem C as written = the families on cells with
      |Z| >= 2); Remark 8.4 (first-layer cells are in case 3 with Z = {lambda, lambda+1});
      Corollary 8.3 per content.
 [8]  Lemma 4.1 and Proposition 5.1 (arithmetic): every move whose tabled conditions hold gives
      admissible profiles with dot product z_max - 1; the case tree never gets stuck and every
      terminal is consistent with its rule, family or move; 1 <= a,c <= 6, 1 <= b <= 8 [10, 12].
 [9]  T2/T3 internals: Lemmas 6.1, 6.2, (6.1), delta never 1 and the delta = 2 set, on generic
      integer vectors (entries in [-3,3], b <= 8 [12]); exterior factor, interior weights 6/4/1
      and the Remark 8.5 witnesses at profile level.
 [10] T5 internals (Lemma 7.1, (7.2), second layer, weights, T5R witnesses by reversal); T4
      internals; Lemma R1 (a)-(c), the Theorem B(i) inequalities and the reversal action on every
      profile pair; Lemma R3 by Gaussian binomial counting (a,b <= 20 [30]).
 [11] DS06 bound coverage, the figures quoted in the note's section 11.
 [12] The worked examples and quoted source tables, by literal word enumeration: the note's
      five fibres; [Y26a] Table 1 with its word lists; MSY04 section 8 (pp. 19-20, 17 printed
      words); TR536 section 4 (the 6 x 6 table, with its one misprint); the HCH example words;
      TR536 section 7, Theorem 8 for 2 <= i <= 5 [7]: the printed words, the missing values
      0 < z < i, the i = 4 list {0,4,6,8,9,10,12}, and the T2 gap at (i^2 - i, i).
 [13] The range statistics quoted in the note's sections 8 and 12 (cells, layer cells, T2 and
      T5 points and profile pairs, word totals, Corollary 8.3 totals, and the branch table of
      the case tree over 1 <= a,c <= 12, 2 <= b <= 14).

Outcome (21 October 2026, Python 3.11.9): no claim failed. Default: 1,420,207 checks, 0
failures, about 11 s. --full: 34,524,509 checks, 0 failures, about 135 s and about 1 GB of
memory (the word DP to a+b+c <= 22). Logs: notes/article2-scripts/proof-topgap/
check-top-gap-default-2026-10-21.log and check-top-gap-full-2026-10-21.log. Mutation tests of
sections [2] and [7]-[13]: notes/article2-scripts/proof-topgap/check_top_gap_mutations.py
(17 of 17 mutants caught; log check-top-gap-mutations-2026-10-21.log).
"""

from __future__ import annotations

import sys
import time
from collections import Counter
from functools import lru_cache
from itertools import combinations, combinations_with_replacement
from math import comb
from operator import mul
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from parikh import occ  # noqa: E402  (word-level subword counts only)

FULL = "--full" in sys.argv[1:]

if FULL:
    NWE, NDP, NPE = 12, 22, 13
    PBS_AC, PBS_B = 7, 9
    PEZ_AC, PEZ_B = 6, 7
    T3_AC, T3_B = 7, 10
    T4_PB, T4_WB = 40, 10
    T5_AC, T5_B = 7, 10
    TH1_AC, TH1_B = 7, 9          # [7] profile bitsets, b >= 1
    CERT_AC, CERT_B = 10, 12      # [8] moves and case tree
    GEN_K, GEN_B = 3, 12          # [9] generic vectors
    T2I_AC, T2I_B = 7, 12         # [9] second-layer weights
    T5G_B, T5P_X = 14, 20         # [10] Lemma 7.1
    T5I_AC, T5I_B = 7, 11         # [10] T5 second layer
    R1_AC, R1_B = 5, 6            # [10] Lemma R1, B(i), reversal on all pairs
    R3_N = 30                     # [10] Lemma R3 by counting
    TR8_I = 7                     # [12] TR536 Theorem 8, content (i,i,i), 2 <= i <= TR8_I
else:
    NWE, NDP, NPE = 9, 12, 12
    PBS_AC, PBS_B = 5, 6
    PEZ_AC, PEZ_B = 5, 6
    T3_AC, T3_B = 6, 8
    T4_PB, T4_WB = 24, 7
    T5_AC, T5_B = 6, 8
    TH1_AC, TH1_B = 5, 6
    CERT_AC, CERT_B = 6, 8
    GEN_K, GEN_B = 3, 8
    T2I_AC, T2I_B = 6, 10
    T5G_B, T5P_X = 10, 14
    T5I_AC, T5I_B = 5, 8
    R1_AC, R1_B = 4, 5
    R3_N = 20
    TR8_I = 5

FAIL: list[str] = []
NCHECK = [0]


def check(cond: bool, msg: str) -> None:
    NCHECK[0] += 1
    if not cond:
        FAIL.append(msg)
        if len(FAIL) <= 40:
            print("FAIL:", msg, flush=True)


# ------------------------------------------------------------------ the claims, re-typed
def eta(n: int) -> int:
    """eta_2 = 6, eta_n = 2 floor(n/2) + 2 for n >= 3."""
    return 6 if n == 2 else 2 * (n // 2) + 2


def L(m: int, b: int) -> tuple[int, ...]:
    """L_m = ((-1)^m, 0^(b-2m), 1^m)."""
    return (-1,) * m + (0,) * (b - 2 * m) + (1,) * m


def predicted_cases(a: int, b: int, c: int, x: int, y: int) -> tuple[bool, bool, bool]:
    """(T2, T5, T5R) of Theorem C."""
    qx, r = divmod(x, b)
    qy, s = divmod(y, b)
    t2 = r == 0 and s == 0 and 1 <= qx <= a - 1 and 1 <= qy <= c - 1
    t5 = 2 <= x <= b - 1 and y == b * c - x
    t5r = 2 <= y <= b - 1 and x == a * b - y
    return t2, t5, t5r


def t3_formula(a: int, b: int, c: int, p: int, q: int) -> int:
    return eta(b) * comb(p + c - q - 2, p - 1) * comb(a - p + q - 2, a - p - 1)


def t2_family(b: int, p: int, q: int) -> set:
    fam = set()
    L1 = L(1, b)
    for m in range(1, b // 2 + 1):
        Lm = L(m, b)
        fam.add((tuple(p + u for u in Lm), tuple(q - v for v in L1)))
        fam.add((tuple(p + u for u in L1), tuple(q - v for v in Lm)))
    return fam


def t5_formula(a: int, c: int, r: int) -> int:
    return eta(r) * comb(a + c - 4, a - 2)


def t4_rho(b: int, r: int) -> int:
    h = b // 2
    if r == 0:
        return 2 * h + 4
    return 2 * (h - r) + 4 + (2 if (b % 2 == 0 and r == h) else 0)


def t4_total(b: int) -> int:
    h = b // 2
    return (h + 2) * (h + 3) if b % 2 == 0 else (h + 1) * (h + 4)


def reversal_image(a: int, b: int, c: int, t: tuple[int, int, int]) -> tuple[int, int, int]:
    x, y, z = t
    return (a * b - x, b * c - y, a * b * c - a * y - c * x + z)


# ------------------------------------------------------------------ words
def words(a: int, b: int, c: int):
    """Every word of content (a,b,c) over 1 < 2 < 3."""
    n = a + b + c
    for P1 in combinations(range(n), a):
        s1 = set(P1)
        rest = [i for i in range(n) if i not in s1]
        for P2 in combinations(rest, b):
            w = [3] * n
            for i in P1:
                w[i] = 1
            for i in P2:
                w[i] = 2
            yield tuple(w)


def xyz(w: tuple[int, ...]) -> tuple[int, int, int]:
    return occ(w, (1, 2)), occ(w, (2, 3)), occ(w, (1, 2, 3))


def word_profiles(w: tuple[int, ...]) -> tuple[tuple[int, ...], tuple[int, ...]]:
    """(A, C): A_t = 1's before the t-th 2, C_t = 3's after the t-th 2."""
    A = []
    ones = 0
    for ch in w:
        if ch == 1:
            ones += 1
        elif ch == 2:
            A.append(ones)
    C = []
    threes = 0
    for ch in reversed(w):
        if ch == 3:
            threes += 1
        elif ch == 2:
            C.append(threes)
    return tuple(A), tuple(reversed(C))


def contents(total_max: int, b_min: int = 1):
    for n in range(3, total_max + 1):
        for a in range(1, n - 1):
            for b in range(1, n - a):
                c = n - a - b
                if b >= b_min:
                    yield a, b, c


# ------------------------------------------------------------------ profiles
def inc_profiles(a: int, b: int) -> list[tuple[int, ...]]:
    """Every weakly increasing length-b tuple with entries in [0, a]."""
    return list(combinations_with_replacement(range(a + 1), b))


def dec_profiles(c: int, b: int) -> list[tuple[int, ...]]:
    """Every weakly decreasing length-b tuple with entries in [0, c]."""
    return [t[::-1] for t in combinations_with_replacement(range(c + 1), b)]


def by_sum(profiles):
    d: dict[int, list] = {}
    for P in profiles:
        d.setdefault(sum(P), []).append(P)
    return d


def gaps_A(a: int, A: tuple[int, ...]) -> tuple[int, ...]:
    return (A[0],) + tuple(A[i + 1] - A[i] for i in range(len(A) - 1)) + (a - A[-1],)


def gaps_C(c: int, C: tuple[int, ...]) -> tuple[int, ...]:
    return (c - C[0],) + tuple(C[i] - C[i + 1] for i in range(len(C) - 1)) + (C[-1],)


def weight(a: int, c: int, A: tuple[int, ...], C: tuple[int, ...]) -> int:
    w = 1
    for u, v in zip(gaps_A(a, A), gaps_C(c, C)):
        w *= comb(u + v, u)
    return w


def pe_distribution(a: int, b: int, c: int) -> Counter:
    """W-weighted distribution of (sum A, sum C, A.C) over all monotone profile pairs."""
    As = [(A, sum(A), gaps_A(a, A)) for A in inc_profiles(a, b)]
    Cs = [(C, sum(C), gaps_C(c, C)) for C in dec_profiles(c, b)]
    dist: Counter = Counter()
    for A, sa, ga in As:
        for C, sc, gc in Cs:
            w = 1
            for u, v in zip(ga, gc):
                w *= comb(u + v, u)
            dist[sa, sc, sum(map(mul, A, C))] += w
    return dist


def pe_sets(a: int, b: int, c: int) -> dict:
    """Z(x,y) as bitmasks over z, from all monotone profile pairs."""
    As = inc_profiles(a, b)
    Cs = dec_profiles(c, b)
    Csum = [(C, sum(C)) for C in Cs]
    Z: dict = {}
    for A in As:
        sa = sum(A)
        for C, sc in Csum:
            key = (sa, sc)
            Z[key] = Z.get(key, 0) | (1 << sum(map(mul, A, C)))
    return Z


def pbs_sets(a: int, b: int, c: int) -> dict:
    """Z(x,y) as bitmasks over z, by a transfer over positions with big-int bitsets.

    Bit index of (sx, sy, z) is sx*WY + sy*WZ + z with WZ > abc (a multiple of 8, so that every
    z-field is byte aligned) and WY = (bc+1)*WZ. A position with values (al, ga) shifts by
    al*WY + ga*WZ + al*ga; the states are (A_t, C_t), and the transfer to (al', ga') ORs all
    states with al <= al', ga >= ga' (a 2D prefix OR)."""
    WZ = ((a * b * c + 1 + 7) // 8) * 8
    WY = (b * c + 1) * WZ

    def sh(al: int, ga: int) -> int:
        return al * WY + ga * WZ + al * ga

    F = [[1 << sh(al, ga) for ga in range(c + 1)] for al in range(a + 1)]
    for _ in range(1, b):
        G = [[0] * (c + 1) for _ in range(a + 1)]
        for al in range(a + 1):
            for ga in range(c, -1, -1):
                v = F[al][ga]
                if al:
                    v |= G[al - 1][ga]
                if ga < c:
                    v |= G[al][ga + 1]
                G[al][ga] = v
        F = [[G[al][ga] << sh(al, ga) for ga in range(c + 1)] for al in range(a + 1)]
    total = 0
    for row in F:
        for v in row:
            total |= v
    nbytes = (a * b + 1) * WY // 8
    buf = total.to_bytes(nbytes, "little")
    Z: dict = {}
    zb = WZ // 8
    for x in range(a * b + 1):
        for y in range(b * c + 1):
            off = (x * WY + y * WZ) // 8
            m = int.from_bytes(buf[off:off + zb], "little")
            if m:
                Z[x, y] = m
    return Z


# ------------------------------------------------------------------ Theorem C on a table of sets
def theorem_C(a: int, b: int, c: int, Z: dict, stats: Counter, level: str) -> None:
    for (x, y), m in Z.items():
        if m & (m - 1) == 0:
            continue                      # |Z(x,y)| <= 1: outside the hypothesis
        stats["cells"] += 1
        zmax = m.bit_length() - 1
        missing1 = not (m >> (zmax - 1)) & 1
        t2, t5, t5r = predicted_cases(a, b, c, x, y)
        pred = t2 or t5 or t5r
        check(missing1 == pred,
              f"[C {level}] content {(a, b, c)} (x,y)={(x, y)}: z_max={zmax}, "
              f"z_max-1 missing={missing1}, predicted (T2,T5,T5R)={(t2, t5, t5r)}")
        if missing1:
            stats["gap"] += 1
            stats["T2" if t2 else "T5" if t5 else "T5R" if t5r else "unpredicted"] += 1
        if pred:
            check(zmax >= 2 and (m >> (zmax - 2)) & 1 == 1,
                  f"[C {level}] content {(a, b, c)} (x,y)={(x, y)}: z_max-2 not attained")


def masks_from_dist(dist: Counter) -> dict:
    Z: dict = {}
    for (x, y, z), n in dist.items():
        if n:
            Z[x, y] = Z.get((x, y), 0) | (1 << z)
    return Z


# ------------------------------------------------------------------ section 1: WE
def section1() -> dict:
    t0 = time.time()
    we: dict = {}
    nwords = 0
    npairs = 0
    for a, b, c in contents(NWE):
        cnt: Counter = Counter()
        prof: Counter = Counter()
        lemma_ok = True
        rev_ok = True
        for w in words(a, b, c):
            nwords += 1
            t = xyz(w)
            cnt[t] += 1
            A, C = word_profiles(w)
            prof[A, C] += 1
            if not (sum(A) == t[0] and sum(C) == t[1] and sum(map(mul, A, C)) == t[2]):
                lemma_ok = False
            if xyz(w[::-1]) != reversal_image(a, b, c, t):
                rev_ok = False
        check(lemma_ok, f"[1] Lemma 1.1(a): x = sum A, y = sum C, z = A.C for every word of {(a, b, c)}")
        check(rev_ok, f"[1] reversal formula for every word of {(a, b, c)}")
        # every monotone pair is realised by exactly W(A,C) words, and nothing else occurs
        want = {}
        for A in inc_profiles(a, b):
            for C in dec_profiles(c, b):
                want[A, C] = weight(a, c, A, C)
        npairs += len(want)
        check(all(n >= 1 for n in want.values()), f"[1] W(A,C) >= 1 for {(a, b, c)}")
        check(dict(prof) == want, f"[1] words per profile pair = W(A,C) for {(a, b, c)}")
        for t, n in cnt.items():
            img = reversal_image(a, b, c, t)
            check(reversal_image(a, b, c, img) == t and cnt.get(img, 0) == n,
                  f"[1] (Rev) fibre bijection {(a, b, c)} {t} -> {img}")
        we[a, b, c] = cnt
    print(f"[1] WE: {len(we)} contents with a+b+c <= {NWE}, {nwords} words, {npairs} profile pairs "
          f"(W validated per pair; Lemma 1.1(a) and the reversal formula per word) "
          f"({time.time() - t0:.1f} s)", flush=True)
    return we


# ------------------------------------------------------------------ section 2: WDP
def wdp_levels(N: int):
    """Yield ((n1,n2,n3), Counter of (x,y,z)) level by level, keeping only two levels."""
    prev = {(0, 0, 0): Counter({(0, 0, 0): 1})}
    for n in range(1, N + 1):
        cur = {}
        for n1 in range(n + 1):
            for n2 in range(n - n1 + 1):
                n3 = n - n1 - n2
                acc: Counter = Counter()
                if n1:
                    for t, m in prev[n1 - 1, n2, n3].items():
                        acc[t] += m
                if n2:
                    for (x, y, z), m in prev[n1, n2 - 1, n3].items():
                        acc[x + n1, y, z] += m
                if n3:
                    for (x, y, z), m in prev[n1, n2, n3 - 1].items():
                        acc[x, y + n2, z + x] += m
                cur[n1, n2, n3] = acc
        for key, acc in cur.items():
            yield key, acc
        prev = cur


def section2(we: dict) -> dict:
    t0 = time.time()
    stats: Counter = Counter()
    stats1: Counter = Counter()           # Theorem 1 in full at word level (finaliser addition)
    word_masks: dict = {}
    n_we = n_pe = n_rev = 0
    n_t3 = n_t5 = n_t4 = 0
    for (a, b, c), dist in wdp_levels(NDP):
        if min(a, b, c) < 1:
            continue
        if a + b + c <= NWE:
            check(dict(dist) == dict(we[a, b, c]), f"[2] WDP = WE for {(a, b, c)}")
            n_we += 1
        if a + b + c <= NPE:
            check(dict(dist) == dict(pe_distribution(a, b, c)), f"[2] WDP = weighted PE for {(a, b, c)}")
            n_pe += 1
        ok = all(dist.get(reversal_image(a, b, c, t), 0) == m for t, m in dist.items())
        check(ok, f"[2] (Rev) rho(t) = rho(image) for {(a, b, c)}")
        n_rev += 1
        Z = masks_from_dist(dist)
        if a <= PBS_AC and c <= PBS_AC and b <= PBS_B:
            word_masks[a, b, c] = Z
        theorem_1(a, b, c, Z, stats1, "2 WDP")
        y26a_theorem6(a, b, c, dist, stats1)
        if b < 2:
            continue
        theorem_C(a, b, c, Z, stats, "word")
        # T2/T3 at word level
        for p in range(1, a):
            for q in range(1, c):
                x, y, top = b * p, b * q, b * p * q
                m = Z[x, y]
                check(m.bit_length() - 1 == top and not (m >> (top - 1)) & 1
                      and dist.get((x, y, top - 2), 0) == t3_formula(a, b, c, p, q),
                      f"[2] T2/T3 word level {(a, b, c)} p={p} q={q}")
                n_t3 += 1
        # T5 and T5R at word level
        if a >= 2 and c >= 2:
            for r in range(2, b):
                for x, y, zt in ((r, b * c - r, (c - 1) * r), (a * b - r, r, (a - 1) * r)):
                    m = Z[x, y]
                    check(m.bit_length() - 1 == zt and not (m >> (zt - 1)) & 1
                          and dist.get((x, y, zt - 2), 0) == t5_formula(a, c, r),
                          f"[2] T5/T5R word level {(a, b, c)} (x,y)={(x, y)}")
                    n_t5 += 1
        # T4 at word level
        if a == 2 and c == 2:
            h = b // 2
            got = {z: dist[b, b, z] for z in range(b * 4 + 1) if dist.get((b, b, z), 0)}
            want = {b - 2 * r: t4_rho(b, r) for r in range(h + 1)}
            check(got == want and sum(got.values()) == t4_total(b), f"[2] T4 word level b={b}")
            n_t4 += 1
    print(f"[2] WDP, a+b+c <= {NDP}: = WE on {n_we} contents, = weighted PE on {n_pe} contents "
          f"(a+b+c <= {NPE}), (Rev) on {n_rev}; (C) word level on {stats['cells']} cells with "
          f"|Z| >= 2: {stats['gap']} top gaps (T2 {stats['T2']}, T5 {stats['T5']}, "
          f"T5R {stats['T5R']}, unpredicted {stats['unpredicted']}); T2/T3 at {n_t3} points, "
          f"T5/T5R at {n_t5}, T4 for {n_t4} b ({time.time() - t0:.1f} s)", flush=True)
    print(f"    Theorem 1 in full at word level (all contents with a+b+c <= {NDP}, b >= 1): "
          f"{describe(stats1)}", flush=True)
    print(f"    [Y26a] Thm 6 multiplicities (eq. (5.1)) and the word (5.2) on {stats1['y26a cells']} "
          f"first-layer cells", flush=True)
    return word_masks


# ------------------------------------------------------------------ section 3: (C) at profile level
def section3(word_masks: dict) -> None:
    t0 = time.time()
    stats: Counter = Counter()
    n_pe = n_w = n = 0
    for b in range(2, PBS_B + 1):
        for a in range(1, PBS_AC + 1):
            for c in range(1, PBS_AC + 1):
                Z = pbs_sets(a, b, c)
                n += 1
                if a <= PEZ_AC and c <= PEZ_AC and b <= PEZ_B:
                    check(Z == pe_sets(a, b, c), f"[3] PBS = PE sets for {(a, b, c)}")
                    n_pe += 1
                if (a, b, c) in word_masks:
                    check(Z == word_masks[a, b, c], f"[3] PBS = WDP sets for {(a, b, c)}")
                    n_w += 1
                check(len(Z) == (a * b + 1) * (b * c + 1), f"[3] every (x,y) in the box occurs {(a, b, c)}")
                theorem_C(a, b, c, Z, stats, "profile")
    print(f"[3] (C) profile level, 1 <= a,c <= {PBS_AC}, 2 <= b <= {PBS_B} ({n} contents): "
          f"{stats['cells']} cells with |Z| >= 2, {stats['gap']} top gaps (T2 {stats['T2']}, "
          f"T5 {stats['T5']}, T5R {stats['T5R']}, unpredicted {stats['unpredicted']}); "
          f"PBS = PE sets on {n_pe} contents (a,c <= {PEZ_AC}, b <= {PEZ_B}), "
          f"PBS = WDP sets on {n_w} ({time.time() - t0:.1f} s)", flush=True)


# ------------------------------------------------------------------ section 4: T2/T3 at profile level
def t23_content(a: int, b: int, c: int) -> list[tuple[bool, str]]:
    out = []
    As = by_sum(inc_profiles(a, b))
    Cs = by_sum(dec_profiles(c, b))
    for p in range(1, a):
        AL = As[b * p]
        for q in range(1, c):
            CL = Cs[b * q]
            top = b * p * q
            zmax = -1
            hit1 = 0
            hits2 = set()
            rho2 = 0
            for A in AL:
                dots = [sum(map(mul, A, C)) for C in CL]
                mz = max(dots)
                if mz > zmax:
                    zmax = mz
                if mz >= top - 2:
                    for C, z in zip(CL, dots):
                        if z == top - 1:
                            hit1 += 1
                        elif z == top - 2:
                            hits2.add((A, C))
                            rho2 += weight(a, c, A, C)
            tag = f"content {(a, b, c)} p={p} q={q}"
            out.append((zmax == top, f"[4] T2 max Z = bpq, {tag}: got {zmax}, want {top}"))
            out.append((hit1 == 0, f"[4] T2 bpq-1 not attained, {tag}: {hit1} pairs"))
            out.append((len(hits2) > 0, f"[4] T2 bpq-2 attained, {tag}"))
            out.append((hits2 == t2_family(b, p, q), f"[4] T2 equality profiles, {tag}: "
                        f"got {sorted(hits2)}, want {sorted(t2_family(b, p, q))}"))
            out.append((rho2 == t3_formula(a, b, c, p, q),
                        f"[4] T3 rho(bp,bq,bpq-2), {tag}: got {rho2}, want {t3_formula(a, b, c, p, q)}"))
    return out


def section4() -> None:
    t0 = time.time()
    jobs = [(a, b, c) for b in range(2, T3_B + 1) for a in range(2, T3_AC + 1) for c in range(2, T3_AC + 1)]
    npts = 0
    for job in jobs:
        for ok, msg in t23_content(*job):
            check(ok, msg)
        npts += (job[0] - 1) * (job[2] - 1)
    print(f"[4] T2/T3 profile level, 2 <= a,c <= {T3_AC}, 2 <= b <= {T3_B}: {len(jobs)} contents, "
          f"{npts} points (bp,bq) ({time.time() - t0:.1f} s)", flush=True)


# ------------------------------------------------------------------ section 5: T4
def section5() -> None:
    t0 = time.time()
    for b in range(1, T4_PB + 1):
        As = [A for A in inc_profiles(2, b) if sum(A) == b]
        Cs = [C for C in dec_profiles(2, b) if sum(C) == b]
        rho: Counter = Counter()
        for A in As:
            for C in Cs:
                rho[sum(map(mul, A, C))] += weight(2, 2, A, C)
        h = b // 2
        check(set(rho) == {b - 2 * r for r in range(h + 1)}, f"[5] T4 support, profile level b={b}: {sorted(rho)}")
        for r in range(h + 1):
            check(rho.get(b - 2 * r, 0) == t4_rho(b, r),
                  f"[5] T4 rho(b,b,b-2r), profile level b={b} r={r}: got {rho.get(b - 2 * r, 0)}, want {t4_rho(b, r)}")
        check(sum(rho.values()) == t4_total(b), f"[5] T4 pair-fibre total, profile level b={b}")
    nw = 0
    for b in range(1, T4_WB + 1):
        rho = Counter()
        for w in words(2, b, 2):
            x, y, z = xyz(w)
            if x == b and y == b:
                rho[z] += 1
            nw += 1
        h = b // 2
        check(set(rho) == {b - 2 * r for r in range(h + 1)}, f"[5] T4 support, word level b={b}")
        for r in range(h + 1):
            check(rho.get(b - 2 * r, 0) == t4_rho(b, r), f"[5] T4 rho, word level b={b} r={r}")
        check(sum(rho.values()) == t4_total(b), f"[5] T4 pair-fibre total, word level b={b}")
    print(f"[5] T4: profile level 1 <= b <= {T4_PB} (all monotone profile pairs), word level "
          f"1 <= b <= {T4_WB} ({nw} words) ({time.time() - t0:.1f} s)", flush=True)


# ------------------------------------------------------------------ section 6: T5, T5R
def section6() -> None:
    t0 = time.time()
    npts = 0
    for b in range(3, T5_B + 1):
        for a in range(2, T5_AC + 1):
            for c in range(2, T5_AC + 1):
                As = by_sum(inc_profiles(a, b))
                Cs = by_sum(dec_profiles(c, b))
                for r in range(2, b):
                    for kind, x, y, zt in (("T5", r, b * c - r, (c - 1) * r),
                                           ("T5R", a * b - r, r, (a - 1) * r)):
                        zmax = -1
                        n1 = 0
                        rho2 = 0
                        for A in As[x]:
                            for C in Cs[y]:
                                z = sum(map(mul, A, C))
                                if z > zmax:
                                    zmax = z
                                if z == zt - 1:
                                    n1 += 1
                                elif z == zt - 2:
                                    rho2 += weight(a, c, A, C)
                        tag = f"{kind} content {(a, b, c)} r={r} (x,y)={(x, y)}"
                        check(zmax == zt, f"[6] {tag}: max Z = {zmax}, want {zt}")
                        check(n1 == 0, f"[6] {tag}: z_max-1 attained by {n1} pairs")
                        check(rho2 == t5_formula(a, c, r), f"[6] {tag}: rho(z_max-2) = {rho2}, "
                              f"want {t5_formula(a, c, r)}")
                        npts += 1
    print(f"[6] T5 and T5R profile level, 2 <= a,c <= {T5_AC}, 3 <= b <= {T5_B}, 2 <= r < b: "
          f"{npts} points ({time.time() - t0:.1f} s)", flush=True)


# ================================================================== finaliser additions
# Claims of notes/proof-top-gap-rigidity.md (finaliser version, 20 Oct 2026), re-typed from the
# note; nothing is imported from notes/. Section numbers [7]-[12] are the ones the note cites.

def gamma_set(m: int, n: int) -> set:
    """gamma(m,n) = {0,...,mn} if min(m,n) <= 1, else {0, 1, mn-1, mn} (Salomaa's gamma)."""
    return set(range(m * n + 1)) if min(m, n) <= 1 else {0, 1, m * n - 1, m * n}


def rules(a: int, b: int, c: int, x: int, y: int) -> set:
    """The rigidity rules of the note, section 1: (E), (N), (Ch), (G) = (Gamma)."""
    t = set()
    if x in (0, a * b) or y in (0, b * c):
        t.add("E")
    if x + y <= b:
        t.add("N")
    if (a * b - x) + (b * c - y) <= b:
        t.add("Ch")
    if x in gamma_set(a, b) and y in gamma_set(b, c):
        t.add("G")
    return t


def exceptional(a: int, b: int, c: int, x: int, y: int):
    """The exceptional families of the note, section 1: b >= 2; T2; T5 and T5R with a, c >= 2."""
    if b < 2:
        return None
    qx, r = divmod(x, b)
    qy, s = divmod(y, b)
    if r == 0 and s == 0 and 1 <= qx <= a - 1 and 1 <= qy <= c - 1:
        return "T2"
    if a >= 2 and c >= 2 and 2 <= x <= b - 1 and y == b * c - x:
        return "T5"
    if a >= 2 and c >= 2 and 2 <= y <= b - 1 and x == a * b - y:
        return "T5R"
    return None


def zmax_formula(b: int, x: int, y: int) -> int:
    """Theorem B(i): z_max = b qx qy + qx s + qy r + max(0, r + s - b)."""
    qx, r = divmod(x, b)
    qy, s = divmod(y, b)
    return b * qx * qy + qx * s + qy * r + max(0, r + s - b)


def lam(a: int, b: int, c: int, x: int, y: int) -> int:
    return c * x + a * y - a * b * c


def dotp(A, C) -> int:
    return sum(p * q for p, q in zip(A, C))


@lru_cache(maxsize=None)
def inc_with_sum(a: int, b: int, x: int) -> tuple:
    """Every weakly increasing length-b tuple with entries in [0, a] and sum x (pruned recursion)."""
    out = []
    cur: list = []

    def rec(lo: int, rem: int, slots: int) -> None:
        if slots == 0:
            if rem == 0:
                out.append(tuple(cur))
            return
        for v in range(lo, a + 1):
            if v * slots > rem:
                break
            if rem - v > a * (slots - 1):
                continue
            cur.append(v)
            rec(v, rem - v, slots - 1)
            cur.pop()

    rec(0, x, b)
    return tuple(out)


def dec_with_sum(c: int, b: int, y: int) -> tuple:
    return tuple(t[::-1] for t in inc_with_sum(c, b, y))


def rule_values(tag: str, a: int, b: int, c: int, x: int, y: int) -> set:
    """Theorem 1, case 1: 0 under (N); lambda under (Ch); 0 / ay / cx under (E); A.C for the
    unique pair of profiles under (Gamma)."""
    if tag == "N":
        return {0}
    if tag == "Ch":
        return {lam(a, b, c, x, y)}
    if tag == "E":
        v = set()
        if x == 0 or y == 0:
            v.add(0)
        if x == a * b:
            v.add(a * y)
        if y == b * c:
            v.add(c * x)
        return v
    As, Cs = inc_with_sum(a, b, x), dec_with_sum(c, b, y)
    if len(As) != 1 or len(Cs) != 1:
        return {-1}                       # (Gamma) promises unique profiles
    return {dotp(As[0], Cs[0])}


def mask_of(vals) -> int:
    m = 0
    for v in vals:
        if v < 0:
            return -1
        m |= 1 << v
    return m


def theorem_1(a: int, b: int, c: int, Z: dict, st: Counter, level: str) -> None:
    """On a table Z[(x,y)] = bitmask of attained z for EVERY cell of the box: Theorem 1 (three
    cases, with the rigid values), Theorem A(i), Theorem B(i) (max Z), min Z >= max(0, lambda)
    (Lemma R1(c)), Lemma 8.1, b = 1 cells are (Gamma), Remark 8.2 (Theorem C as written = the
    families of section 1 on cells with |Z| >= 2), Remark 8.4 ([Y26a]'s first exterior layer is
    in case 3 with Z = {lambda, lambda+1}) and Corollary 8.3 (number of top gaps)."""
    head = f"[{level}] content {(a, b, c)}"
    check(len(Z) == (a * b + 1) * (b * c + 1), f"{head}: {len(Z)} cells, want the whole box")
    ngap = 0
    for x in range(a * b + 1):
        for y in range(b * c + 1):
            m = Z.get((x, y), 0)
            where = f"{head} (x,y)={(x, y)}"
            if not m:
                check(False, f"{where}: empty fibre")
                continue
            st["cells"] += 1
            zmax = m.bit_length() - 1
            zmin = (m & -m).bit_length() - 1
            single = m & (m - 1) == 0
            tags = rules(a, b, c, x, y)
            exc = exceptional(a, b, c, x, y)
            L = lam(a, b, c, x, y)
            check(zmax == zmax_formula(b, x, y),
                  f"{where}: max Z = {zmax}, Theorem B(i) gives {zmax_formula(b, x, y)}")
            check(zmin >= max(0, L), f"{where}: min Z = {zmin} < max(0, lambda) = {max(0, L)}")
            check(not (tags and exc), f"{where}: Lemma 8.1, family {exc} but rules {tags}")
            check(single == bool(tags), f"{where}: Theorem A(i), |Z| = 1 is {single}, rules {tags}")
            if b == 1:
                check("G" in tags, f"{where}: b = 1 but not (Gamma)")
            if tags:
                st["case 1"] += 1
                for t in sorted(tags):
                    check(m == mask_of(rule_values(t, a, b, c, x, y)),
                          f"{where}: Theorem 1 case 1, value under ({t}) is {sorted(rule_values(t, a, b, c, x, y))}, "
                          f"Z has bits {bin(m)}")
            elif exc:
                st["case 2"] += 1
                st[exc] += 1
                check(zmax >= 2 and not (m >> (zmax - 1)) & 1 and (m >> (zmax - 2)) & 1,
                      f"{where}: Theorem 1 case 2 ({exc}): z_max = {zmax}, Z = {bin(m)}")
            else:
                st["case 3"] += 1
                check(zmax >= 1 and (m >> (zmax - 1)) & 1, f"{where}: Theorem 1 case 3, z_max - 1 missing")
            if b >= 2 and not single:
                pc = predicted_cases(a, b, c, x, y)
                check(any(pc) == (exc is not None), f"{where}: Remark 8.2, Theorem C as written {pc}, family {exc}")
                if not (m >> (zmax - 1)) & 1:
                    ngap += 1
            i, j = b * c - y, a * b - x
            if a >= 2 and c >= 2 and i >= 2 and j >= 2 and i + j == b + 1:
                st["layer"] += 1
                check(not tags and exc is None and L >= 0 and m == 3 << L,
                      f"{where}: Remark 8.4 / [Y26a] Thm 6, Z = {bin(m)}, lambda = {L}")
    if b >= 2:
        want = (a - 1) * (c - 1) + 2 * max(0, b - 2) if a >= 2 and c >= 2 else 0
        check(ngap == want, f"{head}: Corollary 8.3, {ngap} top gaps, want {want}")
        st["top gaps"] += ngap


def describe(st: Counter) -> str:
    return (f"{st['cells']} cells: case 1 (rigid) {st['case 1']}, case 2 {st['case 2']} (T2 {st['T2']}, "
            f"T5 {st['T5']}, T5R {st['T5R']}), case 3 {st['case 3']}; {st['top gaps']} top gaps; "
            f"{st['layer']} cells on [Y26a]'s first exterior layer")


@lru_cache(maxsize=None)
def part_at_most(n: int, k: int) -> int:
    """p_k(n) of [Y26a] (section 2): partitions of n into at most k parts, p_k(0) = 1."""
    if n == 0:
        return 1
    if k == 0:
        return 0
    return part_at_most(n, k - 1) + (part_at_most(n - k, k) if n >= k else 0)


def y26a_theorem6(a: int, b: int, c: int, dist: Counter, st: Counter) -> None:
    """[Y26a] Thm 6, eq. (5.1) (PDF p. 11), as quoted in section 11 of the note, on the exact word
    counts of a content: for a, c >= 2, i, j >= 2, b = i + j - 1, x = ab - j, y = bc - i and
    z0 = abc - cj - ai (= lambda), rho(x,y,z0) = p_a(j) p_c(i) + 1 + [j = 2] + [i = 2],
    rho(x,y,z0+1) = 1 and rho(x,y,z) = 0 otherwise; the word at z0 + 1 is
    1^(a-1) 2^(j-1) 3 2 1 2^(i-1) 3^(c-1), eq. (5.2)."""
    if a < 2 or c < 2 or b < 3:
        return
    got: dict = {}
    for (x, y, z), n in dist.items():
        i, j = b * c - y, a * b - x
        if i >= 2 and j >= 2 and i + j == b + 1 and n:
            got.setdefault((i, j), {})[z] = n
    for i in range(2, b):
        j = b + 1 - i
        z0 = a * b * c - c * j - a * i
        want = {z0: part_at_most(j, a) * part_at_most(i, c) + 1 + (j == 2) + (i == 2), z0 + 1: 1}
        w52 = (1,) * (a - 1) + (2,) * (j - 1) + (3, 2, 1) + (2,) * (i - 1) + (3,) * (c - 1)
        check(got.get((i, j)) == want and xyz(w52) == (a * b - j, b * c - i, z0 + 1)
              and (w52.count(1), w52.count(2), w52.count(3)) == (a, b, c),
              f"[2] [Y26a] Thm 6 for {(a, b, c)} (i,j)={(i, j)}: rho = {got.get((i, j))}, want {want}")
        st["y26a cells"] += 1


# ------------------------------------------------------------------ section 7: Theorem 1 in full
def section7(we: dict) -> None:
    """Theorem 1 / A(i) / B(i) / Lemma 8.1 / Remarks 8.2, 8.4 / Corollary 8.3 on (a) the literal
    word enumeration of section 1 and (b) the profile bitsets PBS (b >= 1)."""
    t0 = time.time()
    st_we: Counter = Counter()
    for (a, b, c), cnt in we.items():
        theorem_1(a, b, c, masks_from_dist(cnt), st_we, "7 WE")
    st_pb: Counter = Counter()
    npe = 0
    for b in range(1, TH1_B + 1):
        for a in range(1, TH1_AC + 1):
            for c in range(1, TH1_AC + 1):
                Z = pbs_sets(a, b, c)
                if b == 1 and a <= PEZ_AC and c <= PEZ_AC:
                    check(Z == pe_sets(a, b, c), f"[7] PBS = PE sets for {(a, b, c)}")
                    npe += 1
                theorem_1(a, b, c, Z, st_pb, "7 PBS")
    print(f"[7] Theorem 1 in full (rigid values, Thm A(i), B(i), Lemma 8.1, Remarks 8.2/8.4, Cor 8.3): "
          f"word enumeration a+b+c <= {NWE}: {describe(st_we)}; profile bitsets 1 <= a,c <= {TH1_AC}, "
          f"1 <= b <= {TH1_B}: {describe(st_pb)} (b = 1 PBS = PE on {npe} contents) "
          f"({time.time() - t0:.1f} s)", flush=True)


# ------------------------------------------------------------------ section 8: moves and case tree
def bal_pair(b: int, x: int, y: int) -> tuple[list, list]:
    """A^bal = (qx^(b-r), (qx+1)^r), C^bal = ((qy+1)^s, qy^(b-s))."""
    qx, r = divmod(x, b)
    qy, s = divmod(y, b)
    return [qx] * (b - r) + [qx + 1] * r, [qy + 1] * s + [qy] * (b - s)


def move_conditions(a: int, b: int, c: int, x: int, y: int) -> dict:
    """The table of section 4 of the note, literally."""
    qx, r = divmod(x, b)
    qy, s = divmod(y, b)
    Ab = qx + (1 if r >= 1 else 0)
    C1 = qy + (1 if s >= 1 else 0)
    return {
        "M1": s >= 1 and qx >= 1 and Ab <= a - 1,
        "M2": r >= 1 and qy >= 1 and C1 <= c - 1,
        "M3": r + s < b and s >= 1 and 1 <= qx <= a - 1,
        "M3'": r + s > b and qx + 2 <= a,
        "M4": r + s > b and qy + 2 <= c,
        "M5": r + s < b and r >= 1 and 1 <= qy <= c - 1,
    }


def apply_move(name: str, b: int, x: int, y: int) -> tuple[list, list]:
    """The changes of the table, with the note's 1-based positions shifted to 0-based."""
    A, C = bal_pair(b, x, y)
    r, s = x % b, y % b
    if name == "M1":                      # A - e_1 + e_b
        A[0] -= 1
        A[b - 1] += 1
    elif name == "M2":                    # C + e_1 - e_b
        C[0] += 1
        C[b - 1] -= 1
    elif name == "M3":                    # A - e_1 + e_(b-r)
        A[0] -= 1
        A[b - r - 1] += 1
    elif name == "M3'":                   # A - e_(b-r+1) + e_b
        A[b - r] -= 1
        A[b - 1] += 1
    elif name == "M4":                    # C + e_1 - e_s
        C[0] += 1
        C[s - 1] -= 1
    elif name == "M5":                    # C + e_(s+1) - e_b
        C[s] += 1
        C[b - 1] -= 1
    return A, C


def case_tree(a: int, b: int, c: int, x: int, y: int) -> tuple[str, str]:
    """Proposition 5.1 of the note, literally (b >= 2). Returns (terminal, branch)."""
    if x in (0, a * b) or y in (0, b * c):
        return "E", "E"
    qx, r = divmod(x, b)
    qy, s = divmod(y, b)
    cond = move_conditions(a, b, c, x, y)

    def mv(name: str, br: str) -> tuple[str, str]:
        return (name, br) if cond[name] else ("STUCK", br)

    if r == 0 and s == 0:
        return "T2", "1"
    if r >= 1 and s == 0:
        return mv("M2", "2")
    if r == 0 and s >= 1:
        return mv("M1", "3")
    if 1 <= qx <= a - 2:
        return mv("M1", "4")
    if 1 <= qy <= c - 2:
        return mv("M2", "5")
    if not (qx in (0, a - 1) and qy in (0, c - 1)):
        return "STUCK", "6"
    if r + s < b:
        if qx >= 1:
            return mv("M3", "6a")
        if qy >= 1:
            return mv("M5", "6a")
        return "N", "6a"
    if r + s > b:
        if qx + 2 <= a:
            return mv("M3'", "6b")
        if qy + 2 <= c:
            return mv("M4", "6b")
        return "Ch", "6b"
    if qx == a - 1 and qy == c - 1:
        return "Ch", "6c"
    if qx == 0 and qy == 0:
        return "N", "6c"
    if qx == 0 and qy == c - 1:
        return ("T5", "6c") if r >= 2 else ("G", "6c")
    if qx == a - 1 and qy == 0:
        return ("T5R", "6c") if s >= 2 else ("G", "6c")
    return "STUCK", "6c"


def admissible(A, C, a: int, c: int, b: int, x: int, y: int) -> bool:
    return (len(A) == b and len(C) == b and sum(A) == x and sum(C) == y
            and all(0 <= v <= a for v in A) and all(0 <= v <= c for v in C)
            and all(A[i] <= A[i + 1] for i in range(b - 1)) and all(C[i] >= C[i + 1] for i in range(b - 1)))


def section8() -> None:
    """Arithmetic certificate for Lemma 4.1 and Proposition 5.1 (no enumeration): every cell of
    every content with 1 <= a,c <= CERT_AC, 1 <= b <= CERT_B."""
    t0 = time.time()
    st: Counter = Counter()
    for a in range(1, CERT_AC + 1):
        for c in range(1, CERT_AC + 1):
            for b in range(1, CERT_B + 1):
                nexc = 0
                for x in range(a * b + 1):
                    for y in range(b * c + 1):
                        st["cells"] += 1
                        where = f"[8] {(a, b, c)} (x,y)={(x, y)}"
                        A0, C0 = bal_pair(b, x, y)
                        zb = dotp(A0, C0)
                        check(admissible(A0, C0, a, c, b, x, y), f"{where}: balanced profiles not admissible")
                        check(zb == zmax_formula(b, x, y), f"{where}: A^bal.C^bal = {zb} != Theorem B(i)")
                        tags = rules(a, b, c, x, y)
                        if b == 1:
                            check("G" in tags, f"{where}: b = 1 but not (Gamma)")
                            continue
                        exc = exceptional(a, b, c, x, y)
                        cond = move_conditions(a, b, c, x, y)
                        for name, ok in cond.items():
                            if ok:
                                A1, C1 = apply_move(name, b, x, y)
                                check(admissible(A1, C1, a, c, b, x, y) and dotp(A1, C1) == zb - 1,
                                      f"{where}: Lemma 4.1 move {name} gives {A1}, {C1}")
                                st["move " + name] += 1
                        if exc:
                            nexc += 1
                            check(not tags, f"{where}: Lemma 8.1, {exc} is rigid {tags}")
                        if not tags:
                            check(any(predicted_cases(a, b, c, x, y)) == (exc is not None), f"{where}: Remark 8.2")
                        lab, br = case_tree(a, b, c, x, y)
                        st[f"{br} -> {lab}"] += 1
                        check(lab != "STUCK", f"{where}: case tree stuck in branch {br}")
                        if lab == "E":
                            check("E" in tags, f"{where}: terminal E without (E)")
                        elif lab in ("N", "Ch", "G"):
                            check(lab in tags, f"{where}: terminal {lab} without the rule")
                        elif lab in ("T2", "T5", "T5R"):
                            check(exc == lab, f"{where}: terminal {lab}, family {exc}")
                        elif lab != "STUCK":
                            check(cond[lab], f"{where}: terminal {lab} without its conditions")
                        if "E" not in tags and exc is None:
                            check(lab in ("M1", "M2", "M3", "M3'", "M4", "M5", "N", "Ch", "G"),
                                  f"{where}: Proposition 5.1 conclusion fails ({lab})")
                        if not tags and exc is None:
                            check(lab.startswith("M"), f"{where}: case 3 cell without a move ({lab})")
                        i, j = b * c - y, a * b - x
                        if a >= 2 and c >= 2 and i >= 2 and j >= 2 and i + j == b + 1:
                            st["layer"] += 1
                            check(not tags and exc is None and lab.startswith("M")
                                  and zb - lam(a, b, c, x, y) == 1, f"{where}: Remark 8.4")
                if b >= 2:
                    want = (a - 1) * (c - 1) + 2 * max(0, b - 2) if a >= 2 and c >= 2 else 0
                    check(nexc == want, f"[8] {(a, b, c)}: Corollary 8.3, {nexc} exceptional cells, want {want}")
    moves = ", ".join(f"{k[5:]} {v}" for k, v in sorted(st.items()) if k.startswith("move "))
    tree = ", ".join(f"{k}: {v}" for k, v in sorted(st.items()) if " -> " in k)
    print(f"[8] moves and case tree (arithmetic), 1 <= a,c <= {CERT_AC}, 1 <= b <= {CERT_B}: {st['cells']} cells; "
          f"moves whose conditions hold, each verified: {moves}; {st['layer']} layer cells "
          f"({time.time() - t0:.1f} s)\n    branch -> terminal: {tree}", flush=True)


# ------------------------------------------------------------------ section 9: T2/T3 internals
def section9() -> None:
    """(i) Generic integer vectors: Lemma 6.1 for every nonzero weakly increasing U with sum 0,
    Lemma 6.2 and (6.1) for every pair (U, V), delta = -U.V never 1, and delta = 2 exactly on
    {(L_k, -L_1)} u {(L_1, -L_m)}; entries in [-GEN_K, GEN_K], 2 <= b <= GEN_B. (ii) Profile level:
    the exterior factor and the interior weights 6/4/1 of every second-layer pair, and the
    Remark 8.5 witnesses (A^bal, C^bal) -> buv and (u + L_1, v - L_1) -> buv - 2."""
    t0 = time.time()
    npairs = 0
    for b in range(2, GEN_B + 1):
        Us = [U for U in combinations_with_replacement(range(-GEN_K, GEN_K + 1), b) if sum(U) == 0]
        Vs = [U[::-1] for U in Us]
        fam = set()
        for m in range(1, b // 2 + 1):
            fam.add((L(m, b), tuple(-t for t in L(1, b))))
            fam.add((L(1, b), tuple(-t for t in L(m, b))))
        got2 = set()
        for U in Us:
            S = [0] * (b + 1)
            for i in range(1, b + 1):
                S[i] = S[i - 1] + U[i - 1]
            nzU = any(U)
            if nzU:
                check(U[0] <= -1 and U[-1] >= 1 and all(S[i] <= -1 for i in range(1, b)),
                      f"[9] Lemma 6.1 fails for U = {U}")
            for V in Vs:
                npairs += 1
                delta = -dotp(U, V)
                sbp = sum(-S[i] * (V[i - 1] - V[i]) for i in range(1, b))
                check(delta == sbp, f"[9] Lemma 6.2 fails for {U}, {V}")
                if nzU and any(V):
                    check(delta >= V[0] - V[-1] >= 2, f"[9] (6.1) fails for {U}, {V}")
                check(delta != 1, f"[9] delta = 1 for {U}, {V}")
                if delta == 2:
                    got2.add((U, V))
        check(got2 == fam and len(fam) == 2 * (b // 2) - 1,
              f"[9] b={b}: delta = 2 set {sorted(got2)} != family {sorted(fam)}")
    npts = 0
    for b in range(2, T2I_B + 1):
        for a in range(2, T2I_AC + 1):
            for c in range(2, T2I_AC + 1):
                for u in range(1, a):
                    for v in range(1, c):
                        npts += 1
                        tag = f"[9] {(a, b, c)} u={u} v={v}"
                        ext = comb(u + c - v - 2, u - 1) * comb(a - u + v - 2, a - u - 1)
                        tot = 0
                        for A, C in t2_family(b, u, v):
                            ga, gc = gaps_A(a, A), gaps_C(c, C)
                            e = comb(ga[0] + gc[0], ga[0]) * comb(ga[-1] + gc[-1], ga[-1])
                            inner = 1
                            for g in range(1, b):
                                inner *= comb(ga[g] + gc[g], ga[g])
                            single = A.count(u - 1) == 1 and C.count(v + 1) == 1
                            want = (6 if b == 2 else 4) if single else 1
                            check(e == ext and inner == want and weight(a, c, A, C) == e * inner,
                                  f"{tag}: pair {A}, {C}: exterior {e} (want {ext}), interior {inner} (want {want})")
                            tot += weight(a, c, A, C)
                        check(tot == t3_formula(a, b, c, u, v), f"{tag}: sum of weights {tot} != T3")
                        A0, C0 = bal_pair(b, b * u, b * v)
                        A1 = tuple(u + t for t in L(1, b))
                        C1 = tuple(v - t for t in L(1, b))
                        check(dotp(A0, C0) == b * u * v and admissible(A1, C1, a, c, b, b * u, b * v)
                              and dotp(A1, C1) == b * u * v - 2, f"{tag}: Remark 8.5 witnesses")
    print(f"[9] T2/T3 internals: generic vectors with entries in [-{GEN_K},{GEN_K}], 2 <= b <= {GEN_B}: "
          f"{npairs} pairs (U,V); second-layer weights and witnesses at {npts} points (bu,bv), "
          f"2 <= a,c <= {T2I_AC}, 2 <= b <= {T2I_B} ({time.time() - t0:.1f} s)", flush=True)


# ------------------------------------------------------------------ section 10: T5, T4, R1, R3, reversal
def P_vec(m: int, x: int, b: int) -> tuple:
    """P_m = (0^(b-x+m), 1^(x-2m), 2^m)."""
    return (0,) * (b - x + m) + (1,) * (x - 2 * m) + (2,) * m


def lemma_7_1(A: tuple, B: tuple, x: int, where: str) -> None:
    b = len(A)
    sA = [i for i in range(b) if A[i] > 0]
    sB = [i for i in range(b) if B[i] > 0]
    final = (not sA or sA == list(range(sA[0], b))) and (not sB or sB == list(range(sB[0], b)))
    check(A[0] == 0 and B[0] == 0 and final and (set(sA) <= set(sB) or set(sB) <= set(sA)),
          f"{where}: Lemma 7.1(a) for {A}, {B}")
    E = dotp(A, B) - x
    binA, binB = max(A) <= 1, max(B) <= 1
    check(E >= 0 and (E == 0) == (binA or binB), f"{where}: Lemma 7.1(b) for {A}, {B}")
    if not (binA or binB):
        two = max(A) == 2 and max(B) == 2 and min(A.count(2), B.count(2)) == 1
        check(E >= 2 and (E == 2) == two, f"{where}: Lemma 7.1(c) for {A}, {B}")


def section10() -> None:
    t0 = time.time()
    # (i) Lemma 7.1 and (7.2) on all pairs, 3 <= b <= T5G_B, 0 <= x <= b-1
    n71 = 0
    for b in range(3, T5G_B + 1):
        for x in range(0, b):
            vecs = inc_with_sum(x, b, x)
            for A in vecs:
                for B in vecs:
                    lemma_7_1(A, B, x, f"[10] b={b} x={x}")
                    n71 += 1
            for m in range(x // 2 + 1):
                for n in range(x // 2 + 1):
                    check(sum(P_vec(m, x, b)) == x and dotp(P_vec(m, x, b), P_vec(n, x, b)) == x + 2 * min(m, n),
                          f"[10] (7.2) b={b} x={x} m={m} n={n}")
    # (i') the same on all pairs of partitions of x <= T5P_X, at the shortest length b = x + 1
    # (longer b only prepends zeros, which changes none of the quantities in Lemma 7.1)
    n71p = 0
    for x in range(2, T5P_X + 1):
        vecs = inc_with_sum(x, x + 1, x)
        for A in vecs:
            for B in vecs:
                lemma_7_1(A, B, x, f"[10] partitions x={x}")
                n71p += 1
    # (ii) T5 at profile level: second-layer pairs, weights, witnesses; T5R witnesses by reversal
    npts = 0
    for b in range(3, T5I_B + 1):
        for a in range(2, T5I_AC + 1):
            for c in range(2, T5I_AC + 1):
                for x in range(2, b):
                    npts += 1
                    y = b * c - x
                    where = f"[10] T5 {(a, b, c)} x={x}"
                    top = (c - 1) * x
                    layer2 = set()
                    for A in inc_with_sum(a, b, x):
                        for C in dec_with_sum(c, b, y):
                            if dotp(A, C) == top - 2:
                                layer2.add((A, C))
                    h = x // 2
                    fam = {(P_vec(m, x, b), tuple(c - t for t in P_vec(n, x, b)))
                           for m in range(1, h + 1) for n in range(1, h + 1) if min(m, n) == 1}
                    check(layer2 == fam and len(fam) == 2 * h - 1, f"{where}: second layer {sorted(layer2)}")
                    tot = 0
                    for A, C in fam:
                        ga, gc = gaps_A(a, A), gaps_C(c, C)
                        e = comb(ga[0] + gc[0], ga[0]) * comb(ga[-1] + gc[-1], ga[-1])
                        inner = 1
                        for g in range(1, b):
                            inner *= comb(ga[g] + gc[g], ga[g])
                        single = A.count(2) == 1 and C.count(c - 2) == 1
                        want = (6 if x == 2 else 4) if single else 1
                        check(e == comb(a + c - 4, a - 2) and inner == want,
                              f"{where}: pair {A}, {C}: exterior {e}, interior {inner} (want {want})")
                        tot += weight(a, c, A, C)
                    check(tot == t5_formula(a, c, x), f"{where}: count {tot} != eta_x C(a+c-4, a-2)")
                    W0 = (P_vec(0, x, b), tuple(c - t for t in P_vec(0, x, b)))
                    W1 = (P_vec(1, x, b), tuple(c - t for t in P_vec(1, x, b)))
                    check(dotp(*W0) == top and dotp(*W1) == top - 2, f"{where}: Remark 8.5 witnesses")
                    for (A, C), val in ((W0, (a - 1) * x), (W1, (a - 1) * x - 2)):
                        RA = tuple(a - t for t in reversed(A))
                        RC = tuple(c - t for t in reversed(C))
                        check(admissible(RA, RC, a, c, b, a * b - x, x) and dotp(RA, RC) == val,
                              f"{where}: T5R witness by reversal {RA}, {RC}")
    # (iii) T4 internals: A = 1 + L_m, C = 1 - L_n, z = b - 2 min(m,n), class weights
    for b in range(1, T4_PB + 1):
        h = b // 2
        As, Cs = inc_with_sum(2, b, b), dec_with_sum(2, b, b)
        idxA = {tuple(1 + t for t in L(m, b)): m for m in range(h + 1)}
        idxC = {tuple(1 - t for t in L(n, b)): n for n in range(h + 1)}
        check(set(As) == set(idxA) and set(Cs) == set(idxC), f"[10] T4 b={b}: profiles are not 1 +- L_m")
        for A in As:
            for C in Cs:
                m, n = idxA.get(A, -1), idxC.get(C, -1)
                if m == 0 and n == 0:
                    want = 4
                elif m == 0 or n == 0 or m != n:
                    want = 1
                else:
                    want = 6 if b == 2 * m else 4
                check(dotp(A, C) == b - 2 * min(m, n) and weight(2, 2, A, C) == want,
                      f"[10] T4 b={b} m={m} n={n}: z = {dotp(A, C)}, W = {weight(2, 2, A, C)}, want {want}")
    # (iv) Lemma R1(a)-(c), Theorem B(i) inequalities and the reversal action, on every pair
    nr1 = 0
    for b in range(1, R1_B + 1):
        for a in range(1, R1_AC + 1):
            for c in range(1, R1_AC + 1):
                for x in range(a * b + 1):
                    As = inc_with_sum(a, b, x)
                    Ab, _ = bal_pair(b, x, 0)
                    sig_bal = [sum(Ab[:k]) for k in range(b + 1)]
                    for A in As:
                        check(all(sum(A[:k]) <= sig_bal[k] for k in range(b + 1)),
                              f"[10] B(i): sigma_k(A) > sigma_k(A^bal) for {A}")
                    for y in range(b * c + 1):
                        Cs = dec_with_sum(c, b, y)
                        L0 = lam(a, b, c, x, y)
                        _, Cb = bal_pair(b, 0, y)
                        RAs = inc_with_sum(a, b, a * b - x)
                        RCs = dec_with_sum(c, b, b * c - y)
                        img = set()
                        ok = True
                        for A in As:
                            RA = tuple(a - t for t in reversed(A))
                            for C in Cs:
                                nr1 += 1
                                z = dotp(A, C)
                                Abar = [a - t for t in A]
                                Cbar = [c - t for t in C]
                                if any(A[l] >= 1 and C[l] >= 1 for l in range(b)) and x + y < b + 1:
                                    ok = False
                                if any(Abar[l] >= 1 and Cbar[l] >= 1 for l in range(b)) and \
                                        (a * b - x) + (b * c - y) < b + 1:
                                    ok = False
                                if z - L0 != dotp(Abar, Cbar) or z > dotp(Ab, C) or z > dotp(A, Cb):
                                    ok = False
                                RC = tuple(c - t for t in reversed(C))
                                if dotp(RA, RC) != z - L0 or weight(a, c, RA, RC) != weight(a, c, A, C):
                                    ok = False
                                img.add((RA, RC))
                        check(ok and img == {(A, C) for A in RAs for C in RCs},
                              f"[10] Lemma R1 / B(i) / reversal on the pairs of {(a, b, c)} (x,y)={(x, y)}")
    # (v) Lemma R3 by counting: |A(x)| is the coefficient of q^x in the Gaussian binomial
    # [a+b choose b]_q (partitions of x in a b x a box); the coefficients come from the recursion
    # [n,k] = [n-1,k-1] + q^k [n-1,k], cross-checked against direct enumeration for a,b <= 7.
    G: dict = {}
    for n in range(0, 2 * R3_N + 1):
        for k in range(0, n + 1):
            if k == 0 or k == n:
                G[n, k] = [1]
                continue
            out = [0] * (k * (n - k) + 1)
            for i, v in enumerate(G[n - 1, k - 1]):
                out[i] += v
            for i, v in enumerate(G[n - 1, k]):
                out[i + k] += v
            G[n, k] = out
    nr3 = 0
    for a in range(1, R3_N + 1):
        for b in range(1, R3_N + 1):
            coef = G[a + b, b]
            g = gamma_set(a, b)
            nr3 += 1
            check(len(coef) == a * b + 1 and sum(coef) == comb(a + b, a)
                  and all((coef[x] == 1) == (x in g) for x in range(a * b + 1)),
                  f"[10] Lemma R3 by counting, (a,b) = {(a, b)}")
            if a <= 7 and b <= 7:
                check(all(coef[x] == len(inc_with_sum(a, b, x)) for x in range(a * b + 1)),
                      f"[10] Gaussian binomial = |A(x)| for (a,b) = {(a, b)}")
    print(f"[10] T5 internals: Lemma 7.1 and (7.2) on {n71} pairs (3 <= b <= {T5G_B}) and on {n71p} "
          f"partition pairs (x <= {T5P_X}); T5 second layer, weights, witnesses and T5R witnesses at "
          f"{npts} points (2 <= a,c <= {T5I_AC}, 3 <= b <= {T5I_B}); T4 internals 1 <= b <= {T4_PB}; "
          f"Lemma R1, B(i) inequalities and reversal on {nr1} pairs (a,c <= {R1_AC}, b <= {R1_B}); "
          f"Lemma R3 by counting, 1 <= a,b <= {R3_N} ({time.time() - t0:.1f} s)", flush=True)


# ------------------------------------------------------------------ section 11: DS06 bound coverage
def section11() -> None:
    """The figures quoted in the note's section 11: on 1 <= a,c <= 5, 1 <= b <= 6 the integer
    bounds max(0, lambda) <= z <= floor(xy/b) (DS06 Lemma 3 = MSY04 Thm 4 and Lemma 2) force z on
    7,641 of the 8,295 rigid cells; on all 6,300 (E) cells; on 448 of the 640 cells where (N) is
    the only rule, 448 of the 640 where (Ch) is the only rule, and 0 of the 260 where (Gamma) is
    the only rule. Rigid = |Z| = 1 by the profile bitsets. Also: forced => rigid (soundness)."""
    t0 = time.time()
    st: Counter = Counter()
    for a in range(1, 6):
        for c in range(1, 6):
            for b in range(1, 7):
                Z = pbs_sets(a, b, c)
                for (x, y), m in Z.items():
                    st["cells"] += 1
                    forced = max(0, lam(a, b, c, x, y)) == (x * y) // b
                    rigid = m & (m - 1) == 0
                    check(rigid or not forced, f"[11] bounds force z at a non-rigid cell {(a, b, c, x, y)}")
                    if not rigid:
                        continue
                    tags = rules(a, b, c, x, y)
                    st["rigid"] += 1
                    st["rigid forced"] += forced
                    if "E" in tags:
                        st["E"] += 1
                        st["E forced"] += forced
                    for t in ("N", "Ch", "G"):
                        if tags == {t}:
                            st["only " + t] += 1
                            st["only " + t + " forced"] += forced
    want = {"cells": 23775, "rigid": 8295, "rigid forced": 7641, "E": 6300, "E forced": 6300,
            "only N": 640, "only N forced": 448, "only Ch": 640, "only Ch forced": 448,
            "only G": 260, "only G forced": 0}
    for k, v in want.items():
        check(st[k] == v, f"[11] {k}: {st[k]}, the note says {v}")
    print(f"[11] DS06 bound coverage (1 <= a,c <= 5, 1 <= b <= 6): {st['cells']} cells, {st['rigid']} rigid, "
          f"{st['rigid forced']} forced by the integer bounds; (E) {st['E forced']}/{st['E']}, only (N) "
          f"{st['only N forced']}/{st['only N']}, only (Ch) {st['only Ch forced']}/{st['only Ch']}, only (Gamma) "
          f"{st['only G forced']}/{st['only G']} ({time.time() - t0:.1f} s)", flush=True)


# ------------------------------------------------------------------ section 12: examples and source tables
def word_of(s: str, alphabet: str = "abc") -> tuple:
    return tuple(alphabet.index(ch) + 1 for ch in s)


def fibre(a: int, b: int, c: int, x: int, y: int) -> dict:
    """z -> sorted list of the words (as strings over 1,2,3) of content (a,b,c) in the cell (x,y)."""
    out: dict = {}
    for w in words(a, b, c):
        if occ(w, (1, 2)) == x and occ(w, (2, 3)) == y:
            out.setdefault(occ(w, (1, 2, 3)), []).append("".join(map(str, w)))
    return {z: sorted(v) for z, v in sorted(out.items())}


def section12() -> None:
    """Every worked example and quoted source table of the note, by literal word enumeration."""
    t0 = time.time()

    def counts(f: dict) -> dict:
        return {z: len(v) for z, v in f.items()}

    # the note's own examples
    f = fibre(2, 3, 2, 2, 1)
    check(counts(f) == {0: 3} and "N" in rules(2, 3, 2, 2, 1) and 2 not in gamma_set(2, 3)
          and gamma_set(2, 3) == {0, 1, 5, 6}, f"[12] (2,3,2) at (2,1): {counts(f)}")
    f = fibre(2, 6, 2, 6, 6)
    check(counts(f) == {0: 6, 2: 6, 4: 8, 6: 10} and sum(counts(f).values()) == 30, f"[12] (2,6,2) at (6,6): {counts(f)}")
    f = fibre(2, 2, 2, 2, 2)
    check(counts(f) == {0: 6, 2: 6} and xyz(word_of("123321", "123")) == (2, 2, 2)
          and xyz(word_of("213312", "123")) == (2, 2, 0), f"[12] (2,2,2) at (2,2): {counts(f)}")
    f = fibre(2, 4, 3, 3, 9)
    check(counts(f) == {3: 4, 4: 4, 6: 10} and exceptional(2, 4, 3, 3, 9) == "T5", f"[12] (2,4,3) at (3,9): {counts(f)}")
    # [Y26a] Table 1, p. 12: content (2,3,2), (x,y) = (ab - j, bc - i)
    table1 = {(1, 1): {8: ["1212323"]},
              (1, 2): {6: ["1212332", "1213223", "1231223"]},
              (2, 2): {4: ["1221332", "1223132", "1223312", "2112332", "2113223", "2131223", "2311223"],
                       5: ["1232123"]}}
    for (j, i), want in table1.items():
        x, y = 6 - j, 6 - i
        f = fibre(2, 3, 2, x, y)
        check(f == {z: sorted(v) for z, v in want.items()}, f"[12] [Y26a] Table 1 row (j,i)={(j, i)}: {f}")
    check(rules(2, 3, 2, 5, 5) >= {"Ch"} and rules(2, 3, 2, 5, 4) >= {"Ch"} and not rules(2, 3, 2, 4, 4)
          and exceptional(2, 3, 2, 4, 4) is None and zmax_formula(3, 4, 4) == lam(2, 3, 2, 4, 4) + 1 == 5,
          "[12] [Y26a] Table 1: the cases of its three cells")
    # MSY04 section 8, p. 20: content (3,5,3), |w|ab = 7, |w|bc = 6 (A_x) and 7 (A'_x)
    first = ("bbcccabaabb bcbcabcaabb cbbabccaabb babcccbabab cbbcabaabcb "
             "cbabcbabcab cbabcabbcba cbacbabbbac acbcbbabbac").split()
    second = ("bbccabcaabb bcbabccaabb bcabbccabab cbbaabcbcab cbbabcaabcb "
              "cbbcaabbabc cbabcabbbca cabbcbabbac").split()
    for listing, yy, values in ((first, 6, list(range(9))), (second, 7, [1, 2, 4, 5, 6, 7, 8, 9])):
        got = []
        for s in listing:
            w = word_of(s)
            check((w.count(1), w.count(2), w.count(3)) == (3, 5, 3) and xyz(w)[:2] == (7, yy),
                  f"[12] MSY04 p. 20 word {s}: content or pair counts")
            got.append(xyz(w)[2])
        f = fibre(3, 5, 3, 7, yy)
        check(sorted(got) == values and sorted(f) == values, f"[12] MSY04 p. 20, y = {yy}: printed {got}, fibre {sorted(f)}")
    check(not rules(3, 5, 3, 7, 7) and exceptional(3, 5, 3, 7, 7) is None and zmax_formula(5, 7, 7) == 9,
          "[12] MSY04 p. 20: (3,5,3) at (7,7) is a case-3 cell with z_max = 9")
    # TR536 section 4, printed pp. 6-7: the 6 x 6 table of |w|abc over (u_i, v_j), "i - j : value"
    us = "bababbba abbbabba abbbbaab babbabab bbaabbab bbabaabb".split()
    vs = "cbbcbbbc cbbbcbcb bccbbbbc bcbcbbcb bcbbccbb bbccbcbb".split()
    tab = [[8, 8, 7, 6, 6, 5], [9, 8, 9, 8, 7, 7], [9, 7, 9, 7, 7, 7],
           [9, 6, 7, 5, 4, 4], [7, 6, 7, 4, 4, 2], [7, 5, 7, 4, 2, 1]]     # tab[i][j] = printed value of (u_(i+1), v_(j+1))
    slips = {(3, 0): 8}   # printed "4 - 1 : 9"; the only word with projections u4, v1 is cbabcbababc, |w|abc = 8
    Aset = {word_profiles(word_of(s))[0] for s in us}
    Cset = {word_profiles(word_of(s))[1] for s in vs}
    check(Aset == set(inc_with_sum(3, 5, 7)) and Cset == set(dec_with_sum(3, 5, 7)) and len(Aset) == len(Cset) == 6,
          "[12] TR536: the u_i and v_j are exactly the profiles A(7) and C(7) of content (3,5,3)")
    for i, su in enumerate(us):
        for j, sv in enumerate(vs):
            A = word_profiles(word_of(su))[0]
            C = word_profiles(word_of(sv))[1]
            want = slips.get((i, j), tab[i][j])
            check(dotp(A, C) == want, f"[12] TR536 table (u{i + 1}, v{j + 1}): A.C = {dotp(A, C)}, printed {tab[i][j]}")
    f = fibre(3, 5, 3, 7, 7)
    comb41 = [w for z, ws in f.items() for w in ws
              if "".join(ch for ch in w if ch in "12") == us[3].replace("a", "1").replace("b", "2")
              and "".join(ch for ch in w if ch in "23") == vs[0].replace("b", "2").replace("c", "3")]
    check(comb41 == ["32123212123"] and xyz(word_of("cbabcbababc"))[2] == 8,
          f"[12] TR536 slip: the words combining u4 and v1 are {comb41}")
    check(xyz(word_of("bbccabcaabb")) == xyz(word_of("bbaccbaacbb")) == (7, 7, 1),
          "[12] TR536: the two printed combinations of (u6, v6) have z = 1")
    check({v for row in tab for v in row} == set(f) and min(len(v) for v in f.values()) >= 2,
          "[12] TR536: the table's values are the fibre's, and no value is unambiguous")
    # TR536 section 7, Theorem 8 (printed pp. 11-12; finaliser continuation, 21 Oct 2026). M(i, x)
    # has second diagonal (i, i, i) and third diagonal (i^2 - i, i): content (i,i,i) at
    # (x,y) = (i^2 - i, i), which is the T2 cell with b = i, u = a - 1, v = 1 and z_max = i^2 - i.
    # Printed: x = 0, i, i^2 - i occur, by the words b c^i a^i b^(i-1), c b c^(i-2) a^i b c b^(i-2)
    # and c^(i-1) b a^i b^(i-1) c; no x with 0 < x < i occurs; for i = 4 the values 0, 4, 6, 8,
    # 9, 10, 12 "exhaust all the possibilities" (p. 12). The note reads off two T2 gaps: the whole
    # theorem at i = 2, and the i = 4 list (11 missing, 10 present).
    n8 = 0
    for i in range(2, TR8_I + 1):
        x8, y8, top = i * i - i, i, i * i - i
        printed = (("b" + "c" * i + "a" * i + "b" * (i - 1), 0),
                   ("cb" + "c" * (i - 2) + "a" * i + "bc" + "b" * (i - 2), i),
                   ("c" * (i - 1) + "b" + "a" * i + "b" * (i - 1) + "c", top))
        for s, zz in printed:
            w = word_of(s)
            check((w.count(1), w.count(2), w.count(3)) == (i, i, i) and xyz(w) == (x8, y8, zz),
                  f"[12] TR536 Thm 8, i = {i}: printed word {s} has (x,y,z) = {xyz(w)}, want {(x8, y8, zz)}")
        m = pbs_sets(i, i, i)[x8, y8]
        if i <= 4:
            check(m == mask_of(fibre(i, i, i, x8, y8)), f"[12] TR536 Thm 8, i = {i}: profile bitsets = words")
        vals = [z for z in range(m.bit_length()) if (m >> z) & 1]
        check(exceptional(i, i, i, x8, y8) == "T2" and vals[-1] == top and top - 1 not in vals
              and top - 2 in vals and {0, i, top} <= set(vals) and not any(0 < z < i for z in vals),
              f"[12] TR536 Thm 8 and T2, i = {i}: values {vals}")
        if i == 4:
            check(vals == [0, 4, 6, 8, 9, 10, 12], f"[12] TR536 p. 12, i = 4: values {vals}")
        n8 += 1
    print(f"[12] examples: the note's five fibres, [Y26a] Table 1 (word lists), MSY04 p. 20 (17 printed words, two "
          f"fibres), TR536 pp. 6-7 (36 table entries), the HCH example words, TR536 Thm 8 for 2 <= i <= {TR8_I} "
          f"({n8} contents (i,i,i); words for i <= 4) ({time.time() - t0:.1f} s)", flush=True)


# ------------------------------------------------------------------ section 13: quoted statistics
# The branch table of section 12 of the note (case tree of Proposition 5.1 over 1 <= a,c <= 12,
# 2 <= b <= 14, as printed by verify_topgap_proof.py --full), re-typed from the note.
NOTE_BRANCHES = {"E -> E": 389376, "1 -> T2": 56628, "2 -> M2": 468468, "3 -> M1": 468468,
                 "4 -> M1": 3513510, "5 -> M2": 1036035, "6a -> M3": 92092, "6a -> M5": 48048,
                 "6a -> N": 52416, "6b -> M3'": 92092, "6b -> M4": 48048, "6b -> Ch": 52416,
                 "6c -> Ch": 13104, "6c -> N": 13013, "6c -> G": 3146, "6c -> T5": 9438,
                 "6c -> T5R": 9438}


def gaussian_rows(nmax: int) -> dict:
    """G[n, k] = coefficients of the Gaussian binomial [n choose k]_q, from
    [n,k] = [n-1,k-1] + q^k [n-1,k]. The coefficient of q^x in [a+b choose b]_q is the number of
    weakly increasing length-b vectors with entries in [0, a] and sum x."""
    G: dict = {}
    for n in range(nmax + 1):
        for k in range(n + 1):
            if k == 0 or k == n:
                G[n, k] = [1]
                continue
            out = [0] * (k * (n - k) + 1)
            for i, v in enumerate(G[n - 1, k - 1]):
                out[i] += v
            for i, v in enumerate(G[n - 1, k]):
                out[i + k] += v
            G[n, k] = out
    return G


def section13() -> None:
    """Every range statistic quoted in sections 8 and 12 of the note, recomputed here:
    (i) cells and [Y26a] first-layer cells of the four ranges of verify_topgap_proof.py [A], [B]
    (direct count of (x,y) pairs, and of the layer by its definition); (ii) T2 and T5 points and
    the numbers of profile pairs examined in [C] and [D], by Gaussian binomials, cross-checked
    against direct enumeration on the default ranges; (iii) the word totals of [G] (and of
    section [1] here) by multinomials; (iv) Corollary 8.3's consistency totals 3,528 and 1,008;
    (v) the branch table, by the literal case tree of [8] (Proposition 5.1), b >= 2 cells of
    1 <= a,c <= 12, 2 <= b <= 14."""
    t0 = time.time()
    G = gaussian_rows(40)

    def n_vec(m: int, b: int, s: int) -> int:
        co = G[m + b, b]
        return co[s] if 0 <= s < len(co) else 0

    # (i) cells and layer cells
    def cells(A: int, B: int) -> tuple[int, int]:
        n = lay = 0
        for a in range(1, A + 1):
            for c in range(1, A + 1):
                for b in range(1, B + 1):
                    for x in range(a * b + 1):
                        for y in range(b * c + 1):
                            n += 1
                            i, j = b * c - y, a * b - x
                            lay += a >= 2 and c >= 2 and i >= 2 and j >= 2 and i + j == b + 1
        return n, lay

    quoted_cells = {(8, 10): (531280, 1764), (5, 6): (23775, 160), (6, 7): (69048, 375)}
    if FULL:
        quoted_cells[12, 14] = (6373836, 9438)
    for (A, B), want in quoted_cells.items():
        check(cells(A, B) == want, f"[13] cells of 1 <= a,c <= {A}, 1 <= b <= {B}: {cells(A, B)}, note {want}")
    check(sum((a * b + 1) * (b * c + 1) for a in range(1, 13) for c in range(1, 13) for b in range(1, 15)) == 6373836
          and 121 * sum(b - 2 for b in range(3, 15)) == 9438, "[13] cells of 1 <= a,c <= 12, 1 <= b <= 14 (closed form)")

    # (ii) T2 and T5 points and profile pairs
    def t2_pts(A: int, B: int, direct: bool) -> tuple[int, int]:
        pts = pairs = 0
        for b in range(2, B + 1):
            for a in range(2, A + 1):
                for c in range(2, A + 1):
                    for u in range(1, a):
                        for v in range(1, c):
                            pts += 1
                            if direct:
                                pairs += len(inc_with_sum(a, b, b * u)) * len(dec_with_sum(c, b, b * v))
                            else:
                                pairs += n_vec(a, b, b * u) * n_vec(c, b, b * v)
        return pts, pairs

    def t5_pts(A: int, B: int, direct: bool) -> tuple[int, int]:
        pts = pairs = 0
        for b in range(3, B + 1):
            for a in range(2, A + 1):
                for c in range(2, A + 1):
                    for x in range(2, b):
                        pts += 1
                        if direct:
                            pairs += len(inc_with_sum(a, b, x)) * len(inc_with_sum(c, b, x))
                        else:
                            pairs += n_vec(a, b, x) * n_vec(c, b, x)
        return pts, pairs

    check(t2_pts(6, 8, False) == t2_pts(6, 8, True) == (1575, 708685), f"[13] T2 range 6/8: {t2_pts(6, 8, False)}")
    check(t2_pts(7, 10, False) == (3969, 18256863), f"[13] T2 range 7/10: {t2_pts(7, 10, False)}")
    check(t5_pts(6, 9, False) == t5_pts(6, 9, True) == (700, 22099), f"[13] T5 range 6/9: {t5_pts(6, 9, False)}")
    check(t5_pts(7, 11, False) == (1620, 116648), f"[13] T5 range 7/11: {t5_pts(7, 11, False)}")
    if FULL:
        check(t2_pts(7, 10, True) == (3969, 18256863) and t5_pts(7, 11, True) == (1620, 116648),
              "[13] T2/T5 full ranges by direct enumeration")

    # (iii) word totals
    def words_up_to(N: int) -> int:
        return sum(comb(n, a) * comb(n - a, b) for n in range(3, N + 1) for a in range(1, n - 1)
                   for b in range(1, n - a))

    check((words_up_to(9), words_up_to(11), words_up_to(12)) == (26484, 253470, 772626),
          f"[13] word totals {(words_up_to(9), words_up_to(11), words_up_to(12))}")

    # (iv) Corollary 8.3 consistency totals (section 8 of the note)
    t2c = sum((a - 1) * (c - 1) for a in range(1, 8) for c in range(1, 8) for b in range(2, 10))
    t5c = sum(max(0, b - 2) for a in range(2, 8) for c in range(2, 8) for b in range(2, 10))
    check((t2c, t5c) == (3528, 1008), f"[13] Corollary 8.3 totals for 1 <= a,c <= 7, 2 <= b <= 9: {(t2c, t5c)}")

    # (v) the branch table
    st: Counter = Counter()
    for a in range(1, 13):
        for c in range(1, 13):
            for b in range(2, 15):
                for x in range(a * b + 1):
                    for y in range(b * c + 1):
                        lab, br = case_tree(a, b, c, x, y)
                        st[f"{br} -> {lab}"] += 1
    check(dict(st) == NOTE_BRANCHES, f"[13] branch table {dict(st)}")
    print(f"[13] quoted statistics: cells and layer cells of {len(quoted_cells) + 1} ranges, T2/T5 points and "
          f"profile pairs of 4 ranges, word totals, Corollary 8.3 totals, branch table over "
          f"{sum(st.values())} cells (1 <= a,c <= 12, 2 <= b <= 14) ({time.time() - t0:.1f} s)", flush=True)


def main() -> int:
    t0 = time.time()
    print("== check_top_gap: Theorem 1 (A(i), C) and T2-T5 (top of a ternary fibre)" + ("  [--full]" if FULL else ""),
          flush=True)
    we = section1()
    word_masks = section2(we)
    section3(word_masks)
    section4()
    section5()
    section6()
    section7(we)
    section8()
    section9()
    section10()
    section11()
    section12()
    section13()
    print(f"check_top_gap: {NCHECK[0]} checks, {len(FAIL)} failures, {time.time() - t0:.1f} s")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
