"""R7 mechanism: checks for notes/explore-r7-mechanism.md.

Python standard library only; deterministic; accepts and ignores unknown arguments.

Content (a,b,c) over 1 < 2 < 3; x = |w|_12, y = |w|_23, z = |w|_123 (scattered).
F(x, y) = number of words with these pair counts (the psi_2-fibre).  Four independent
evaluations are used: word enumeration (brute force), the level product
[u^a v^c] prod_{h=0}^b 1/(1 - u s^h - v t^h) (Kronecker-packed), a prefix dynamic
programme over words, and the trace-class (profile) sum.  The fast methods are compared
with brute force at small sizes before they are used.

What is checked (bounds are this file's own; larger runs are recorded in the note):
  1. Infrastructure.  Level product = prefix DP = brute force for all contents with
     total <= 9; class sum = brute force at every point, total <= 8; the full (x,y,z) level
     DP = brute force, total <= 8; the weighted-sequence form
     G(x,y') = (1/(a!c!)) sum_{u in [0,b]^a, v in [0,b]^c} prod_h m_h(u,v)!, total <= 7.
  2. The recorded conjecture holds for b even, total <= 19: unique maximiser at the centre
     (ab/2, bc/2) whenever (a,c) != (1,1) (brute force for total <= 10).
  3. COUNTEREXAMPLE.  At total 20 the conjecture fails exactly for (7,6,7) and (5,10,5);
     F(centre) < F(centre + (-1,1)) = F(centre + (1,-1)), confirmed by the prefix DP and
     the class sum; for (7,6,7) the maximisers are exactly (20,22), (22,20).
  4. Parity map, b even, total <= 22: failures of the unique centre occur only when
     ab/2 and bc/2 are both odd, and then the maximisers are exactly
     (ab/2 - 1, bc/2 + 1), (ab/2 + 1, bc/2 - 1).  The q = -1 evaluation behind the parity
     heuristic: [a+b choose a]_{-1} = binom(floor((a+b)/2), floor(a/2)) > 0 for b even
     (a, b <= 20).  Island endpoints for (a,6,a): (23,6,23) still fails, (25,6,25) does not.
  5. Cauchy-Schwarz for content (a,b,a): F(x,y)^2 < F(x,ab-x) F(ab-y,y) whenever
     x + y != ab (total <= 16); hence every maximiser lies on x + y = ab (brute force,
     total <= 9).
  6. Content (2,b,2), 1 <= b <= 14: maximisers {(b,b)} for b even, {(b-1,b+1),(b+1,b-1)}
     for b odd >= 3, {(0,2),(2,0)} for b = 1 (brute force for b <= 4).  The gap-block
     permutations used in the proof sketch exist for every x, and permuting gap blocks
     is a bijection on words preserving trace-class sizes (brute force, b <= 4).
  7. Failures of candidate mechanisms, each at its smallest witness, by brute force:
     row/column unimodality and log-concavity, monotonicity toward the centre, strict
     local maxima away from the centre, the three decompositions D1-D3, trace-class
     dominance.
  8. Projections: the x - y projection is binom(a+c,a)[a+b+c choose b]_q (total <= 10);
     the (1,2) projection is not unimodal at (1,1,2).
  9. b odd: stated maximiser sets for (1,3,2), (2,3,2), (3,3,4), (4,3,4); reversal
     invariance and (a = c) antidiagonal location for all b odd, total <= 16.  Section 9's
     categories at this bound (b odd >= 3, (a,c) != (1,1)): V 49, C 9, N 139; in N the
     largest L-infinity distance of a maximiser from the centre is 7/2, at (2,3,11) and
     (11,3,2) only, and 14 N contents have four maximisers (the note's total <= 26 figures
     come from notes/r7-scripts/mechanism/exp9_bodd.py).
 10. Parikh classes: on the four box edges z is forced (brute force, total <= 8);
     boundary/interior classification counts for total <= 12 (level DP, brute force <= 8).
 11. Grand-canonical central maximum (b = 2, 4; u = v = 1/4): exact truncated sums with
     a rigorous tail bound, offsets |p|,|q| <= 2.
"""

from __future__ import annotations

import sys
import time
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
from math import comb, factorial, prod

from parikh import Checker

START = time.perf_counter()


# ---------------------------------------------------------------- brute force

def words(a, b, c):
    def rec(ra, rb, rc, pre):
        if ra == rb == rc == 0:
            yield tuple(pre)
            return
        if ra:
            pre.append(1); yield from rec(ra - 1, rb, rc, pre); pre.pop()
        if rb:
            pre.append(2); yield from rec(ra, rb - 1, rc, pre); pre.pop()
        if rc:
            pre.append(3); yield from rec(ra, rb, rc - 1, pre); pre.pop()
    yield from rec(a, b, c, [])


def stats(w):
    n1 = n12 = n2 = x = y = z = 0
    for ch in w:
        if ch == 1:
            n1 += 1
        elif ch == 2:
            x += n1
            n12 += n1
            n2 += 1
        else:
            y += n2
            z += n12
    return x, y, z


BRUTE = {}


def F_brute(a, b, c):
    key = (a, b, c)
    if key not in BRUTE:
        F = [[0] * (b * c + 1) for _ in range(a * b + 1)]
        for w in words(a, b, c):
            x, y, _ = stats(w)
            F[x][y] += 1
        BRUTE[key] = F
    return BRUTE[key]


# ---------------------------------------------------------------- level product

LEVEL = {}


def F_level(a, b, c):
    key = (a, b, c)
    if key in LEVEL:
        return LEVEL[key]
    W = b * c + 1
    K = (factorial(a + b + c) // (factorial(a) * factorial(b) * factorial(c))).bit_length() + 1
    P = [[0] * (c + 1) for _ in range(a + 1)]
    P[0][0] = 1
    for h in range(b + 1):
        sx, sy = K * h * W, K * h
        for i in range(a + 1):
            row = P[i]
            prev = P[i - 1] if i else None
            for j in range(c + 1):
                v = row[j]
                if i:
                    v += prev[j] << sx
                if j:
                    v += row[j - 1] << sy
                row[j] = v
    g = P[a][c]
    mask = (1 << K) - 1
    F = [[0] * W for _ in range(a * b + 1)]
    for x in range(a * b + 1):
        for yp in range(W):
            F[x][b * c - yp] = (g >> (K * (x * W + yp))) & mask
    LEVEL[key] = F
    return F


def F_level_points(a, b, c, points):
    """Values F(x,y) at the given points only (level product; no full unpacking)."""
    W = b * c + 1
    K = (factorial(a + b + c) // (factorial(a) * factorial(b) * factorial(c))).bit_length() + 1
    P = [[0] * (c + 1) for _ in range(a + 1)]
    P[0][0] = 1
    for h in range(b + 1):
        sx, sy = K * h * W, K * h
        for i in range(a + 1):
            row = P[i]
            prev = P[i - 1] if i else None
            for j in range(c + 1):
                v = row[j]
                if i:
                    v += prev[j] << sx
                if j:
                    v += row[j - 1] << sy
                row[j] = v
    g = P[a][c]
    mask = (1 << K) - 1
    return {(x, y): (g >> (K * (x * W + b * c - y))) & mask for (x, y) in points}


def F_prefix(a, b, c, X=None, Y=None):
    """Prefix DP over words; returns dict (x,y) -> count, pruned to x <= X, y <= Y."""
    X = a * b if X is None else X
    Y = b * c if Y is None else Y
    layer = {(0, 0, 0, 0, 0): 1}
    for _ in range(a + b + c):
        new = defaultdict(int)
        for (i1, i2, i3, x, y), m in layer.items():
            if i1 < a:
                new[(i1 + 1, i2, i3, x, y)] += m
            if i2 < b and x + i1 <= X:
                new[(i1, i2 + 1, i3, x + i1, y)] += m
            if i3 < c and y + i2 <= Y:
                new[(i1, i2, i3 + 1, x, y + i2)] += m
        layer = new
    return {(x, y): m for (i1, i2, i3, x, y), m in layer.items()}


def compositions(n, k):
    if k == 1:
        yield (n,)
        return
    for f in range(n + 1):
        for r in compositions(n - f, k - 1):
            yield (f,) + r


def slices(a, b):
    d = defaultdict(list)
    for al in compositions(a, b + 1):
        d[sum(h * v for h, v in enumerate(al))].append(al)
    return d


def Kc(al, ga):
    return prod(comb(i + j, i) for i, j in zip(al, ga))


def class_sum(a, b, c, x, y):
    """Sum of trace-class sizes over profile pairs (level coordinates, y' = bc - y)."""
    SA, SC = slices(a, b), slices(c, b)
    return sum(Kc(al, ga) for al in SA.get(x, []) for ga in SC.get(b * c - y, []))


def M_level(a, b, c):
    states = {(0, 0, 0, 0, 0): 1}
    for h in range(b, -1, -1):
        new = defaultdict(int)
        for (i, j, x, yp, z), m in states.items():
            for di in range(a - i + 1):
                for dj in range(c - j + 1):
                    new[(i + di, j + dj, x + di * h, yp + dj * h, z + dj * (x - i * h))] += m * comb(di + dj, di)
        states = new
    out = {}
    for (i, j, x, yp, z), m in states.items():
        if i == a and j == c:
            out[(x, b * c - yp, z)] = out.get((x, b * c - yp, z), 0) + m
    return out


def contents(tmax, bf=lambda b: True, tmin=3):
    for T in range(tmin, tmax + 1):
        for b in range(1, T - 1):
            if not bf(b):
                continue
            for a in range(1, T - b):
                c = T - a - b
                if c >= 1:
                    yield a, b, c


def argmax(F):
    M = max(max(r) for r in F)
    return M, sorted((x, y) for x, r in enumerate(F) for y, v in enumerate(r) if v == M)


def unimodal(seq):
    s = list(seq)
    while s and s[0] == 0:
        s.pop(0)
    while s and s[-1] == 0:
        s.pop()
    if any(v == 0 for v in s):
        return False
    i, n = 0, len(s)
    while i + 1 < n and s[i + 1] >= s[i]:
        i += 1
    while i + 1 < n and s[i + 1] <= s[i]:
        i += 1
    return i >= n - 1


def logconcave(seq):
    return all(seq[i] ** 2 >= seq[i - 1] * seq[i + 1] for i in range(1, len(seq) - 1))


# ---------------------------------------------------------------- checks

def check_infrastructure(chk):
    n = 0
    ok_lp = ok_cs = ok_m = ok_seq = True
    for a, b, c in contents(9):
        Fb = F_brute(a, b, c)
        if F_level(a, b, c) != Fb:
            ok_lp = False
        P = F_prefix(a, b, c)
        if any(P.get((x, y), 0) != Fb[x][y] for x in range(a * b + 1) for y in range(b * c + 1)):
            ok_lp = False
        if a + b + c <= 8:
            if any(class_sum(a, b, c, x, y) != Fb[x][y] for x in range(a * b + 1) for y in range(b * c + 1)):
                ok_cs = False
            Mb = Counter(stats(w) for w in words(a, b, c))
            if M_level(a, b, c) != dict(Mb):
                ok_m = False
        if a + b + c <= 7:
            G = defaultdict(int)
            for u in product(range(b + 1), repeat=a):
                for v in product(range(b + 1), repeat=c):
                    G[(sum(u), sum(v))] += prod(factorial(k) for k in Counter(u + v).values())
            if any(G[(x, yp)] != factorial(a) * factorial(c) * Fb[x][b * c - yp]
                   for x in range(a * b + 1) for yp in range(b * c + 1)):
                ok_seq = False
        n += 1
    chk.ok("level product and prefix DP equal brute force (total <= 9)", ok_lp)
    chk.ok("trace-class sum equals brute force (total <= 8)", ok_cs)
    chk.ok("full (x,y,z) level DP equals brute force (total <= 8)", ok_m)
    chk.ok("weighted-sequence form of G (total <= 7)", ok_seq)
    chk.note(f"1. infrastructure on {n} contents")


def check_conjecture_small(chk):
    fails = []
    n = 0
    for a, b, c in contents(19, lambda b: b % 2 == 0):
        if (a, c) == (1, 1):
            continue
        n += 1
        F = F_brute(a, b, c) if a + b + c <= 10 else F_level(a, b, c)
        if argmax(F)[1] != [(a * b // 2, b * c // 2)]:
            fails.append((a, b, c))
    chk.check("b even, total <= 19: unique central maximiser (brute force <= 10)", fails, [])
    chk.note(f"2. {n} contents with b even, total <= 19")


def check_counterexample(chk):
    fails20 = []
    for a, b, c in contents(20, lambda b: b % 2 == 0, tmin=20):
        if (a, c) == (1, 1):
            continue
        if argmax(F_level(a, b, c))[1] != [(a * b // 2, b * c // 2)]:
            fails20.append((a, b, c))
    chk.check("total 20, b even: failures of the unique centre", sorted(fails20), [(5, 10, 5), (7, 6, 7)])
    want = {(7, 6, 7): (484020, 484422), (5, 10, 5): (111322, 111460)}
    for (a, b, c), (vc, vn) in want.items():
        cx, cy = a * b // 2, b * c // 2
        P = F_prefix(a, b, c, cx + 1, cy + 1)
        got = (P.get((cx, cy), 0), P.get((cx - 1, cy + 1), 0), P.get((cx + 1, cy - 1), 0))
        chk.check(f"{(a,b,c)} prefix DP: F(centre), F(centre+(-1,1)), F(centre+(1,-1))", got, (vc, vn, vn))
        got2 = (class_sum(a, b, c, cx, cy), class_sum(a, b, c, cx - 1, cy + 1))
        chk.check(f"{(a,b,c)} class sum: F(centre), F(centre+(-1,1))", got2, (vc, vn))
        chk.ok(f"{(a,b,c)}: neighbour fibre strictly larger than the central fibre", vn > vc)
    M, arg = argmax(F_level(7, 6, 7))
    chk.check("(7,6,7) global maximisers (level product)", (M, arg), (484422, [(20, 22), (22, 20)]))
    chk.note("3. counterexamples (7,6,7), (5,10,5) confirmed by three methods")


def check_parity(chk, T=22):
    bad = []
    nf = 0
    for a, b, c in contents(T, lambda b: b % 2 == 0):
        if (a, c) == (1, 1):
            continue
        cx, cy = a * b // 2, b * c // 2
        arg = argmax(F_level(a, b, c))[1]
        if arg != [(cx, cy)]:
            nf += 1
            if not (cx % 2 == 1 and cy % 2 == 1 and arg == [(cx - 1, cy + 1), (cx + 1, cy - 1)]):
                bad.append((a, b, c, arg))
    chk.check(f"parity map, b even, total <= {T}: every failure is odd-odd with the (-1,1),(1,-1) pair", bad, [])
    chk.check(f"number of failures, total <= {T}", nf, 6)
    # parity heuristic: for b even the q = -1 value of [a+b choose a]_q is
    # binom(floor((a+b)/2), floor(a/2)) > 0, so even x (and even y) carry excess mass;
    # the centre coordinate ab/2 is odd iff a odd and b = 2 mod 4.
    okq = True
    for a in range(1, 21):
        for b in range(2, 21, 2):
            g = gauss(a + b, a)
            sgn = sum(v * (-1) ** i for i, v in enumerate(g))
            if sgn != comb((a + b) // 2, a // 2) or sgn <= 0:
                okq = False
            if ((a * b // 2) % 2 == 1) != (a % 2 == 1 and b % 4 == 2):
                okq = False
    chk.ok("q=-1: [a+b choose a]_{-1} = binom(floor((a+b)/2), floor(a/2)) > 0 for b even (a,b <= 20)", okq)
    # the island for (a,6,a), a odd: (23,6,23) still fails, (25,6,25) has the centre back
    for a, sign in ((23, -1), (25, 1)):
        cx = 3 * a
        v = F_level_points(a, 6, a, [(cx, cx), (cx - 1, cx + 1)])
        d = v[(cx, cx)] - v[(cx - 1, cx + 1)]
        chk.ok(f"({a},6,{a}): sign of F(centre) - F(centre+(-1,1)) is {sign}", d * sign > 0, f"diff {d}")
    chk.note(f"4. parity map to total {T}: {nf} failures")


def check_cs_aca(chk):
    bad = 0
    n = 0
    for a in range(1, 9):
        for b in range(1, 15):
            if 2 * a + b > 16:
                continue
            n += 1
            F = F_level(a, b, a)
            X = a * b
            for x in range(X + 1):
                for y in range(X + 1):
                    if x + y != X and not (F[x][y] ** 2 < F[x][X - x] * F[X - y][y]):
                        bad += 1
            if 2 * a + b <= 9:
                Fb = F_brute(a, b, a)
                if any(x + y != X for x, y in argmax(Fb)[1]):
                    bad += 1
    chk.check("(a,b,a): strict Cauchy-Schwarz off x+y=ab (total <= 16); maximisers on x+y=ab (brute <= 9)", bad, 0)
    chk.note(f"5. {n} contents (a,b,a)")


def block_perm_ok(b, x, t):
    """Proof-sketch permutation for (2,b,2): a level permutation pi with pi(i)+pi(x-i) = t
    for every pair {i, x-i} of levels in [0,b].  Returns True iff the greedy construction
    (squares to squares, other pairs to other pairs) succeeds and maps A_2(x) into A_2(t)."""
    pairs_x = [(i, x - i) for i in range(x // 2 + 1) if x - i <= b]
    target_pairs = [(j, t - j) for j in range(t // 2 + 1) if t - j <= b]
    sq_x = [p for p in pairs_x if p[0] == p[1]]
    sq_t = [p for p in target_pairs if p[0] == p[1]]
    ns_x = [p for p in pairs_x if p[0] != p[1]]
    ns_t = [p for p in target_pairs if p[0] != p[1]]
    if len(sq_x) > len(sq_t) or len(ns_x) > len(ns_t):
        return False
    pi = {}
    for (i, j), (k, l) in zip(sq_x, sq_t):
        pi[i] = k
    for (i, j), (k, l) in zip(ns_x, ns_t):
        pi[i], pi[j] = k, l
    used = set(pi.values())
    free = [h for h in range(b + 1) if h not in used]
    for h in range(b + 1):
        if h not in pi:
            pi[h] = free.pop(0)
    if sorted(pi.values()) != list(range(b + 1)):
        return False
    S = slices(2, b)
    return all(sum(pi[h] * al[h] for h in range(b + 1)) == t for al in S[x])


def permute_gap_blocks(w, pi_levels, b):
    """Cut w at its 2s into b+1 gap blocks (gap g has level b-g) and move the block of level
    h to level pi[h]."""
    blocks = [[]]
    for ch in w:
        if ch == 2:
            blocks.append([])
        else:
            blocks[-1].append(ch)
    new = [None] * (b + 1)
    for g, blk in enumerate(blocks):
        h = b - g
        new[b - pi_levels[h]] = blk
    out = []
    for g, blk in enumerate(new):
        if g:
            out.append(2)
        out.extend(blk)
    return tuple(out)


def check_2b2(chk):
    for b in range(1, 15):
        F = F_brute(2, b, 2) if b <= 4 else F_level(2, b, 2)
        arg = argmax(F)[1]
        if b == 1:
            want = [(0, 2), (2, 0)]
        elif b % 2 == 0:
            want = [(b, b)]
        else:
            want = [(b - 1, b + 1), (b + 1, b - 1)]
        chk.check(f"(2,{b},2) maximisers", arg, want)
        # permutations used in the proof sketch (x below the centre; x above by reversal)
        if b % 2 == 0:
            okp = all(block_perm_ok(b, x, b) for x in range(b))
        else:
            okp = all(block_perm_ok(b, x, b) for x in range(1, b - 1, 2)) and \
                  all(block_perm_ok(b, x, b + 1) for x in range(0, b, 2))
            # x = b is not reachable by a permutation (b odd): compared by closed forms
            okp = okp and not block_perm_ok(b, b, b + 1)
        chk.ok(f"(2,{b},2) gap-block permutations of the proof sketch exist", okp)
        D = [F[x][2 * b - x] for x in range(2 * b + 1)]
        h = b // 2
        if b % 2 == 0:
            chk.check(f"(2,{b},2) D(b) = (h+2)(h+3)", D[b], (h + 2) * (h + 3))
        else:
            m = (b + 1) // 2
            chk.check(f"(2,{b},2) D(b) = (h+1)(h+4), D(b+1) = (m+1)(m+2)", (D[b], D[b + 1]),
                      ((h + 1) * (h + 4), (m + 1) * (m + 2)))
    # gap-block permutation is a bijection on words preserving class sizes
    from itertools import permutations
    allok = True
    for b in range(1, 5):
        for a, c in ((2, 2), (1, 2), (2, 3)):
            ws = list(words(a, b, c))
            # trace class of w = pair of binary projections
            cls = Counter((tuple(ch for ch in w if ch != 3), tuple(ch for ch in w if ch != 1)) for w in ws)
            for pi in permutations(range(b + 1)):
                img = [permute_gap_blocks(w, pi, b) for w in ws]
                if len(set(img)) != len(ws):
                    allok = False
                for w, v in zip(ws, img):
                    kw = cls[(tuple(ch for ch in w if ch != 3), tuple(ch for ch in w if ch != 1))]
                    kv = cls[(tuple(ch for ch in v if ch != 3), tuple(ch for ch in v if ch != 1))]
                    if kw != kv:
                        allok = False
    chk.ok("permuting gap blocks: bijection on words preserving trace-class sizes (b <= 4)", allok)
    chk.note("6. (2,b,2), b <= 14")


def check_candidate_failures(chk):
    F = F_brute(2, 2, 1)
    chk.check("row y=0 of (2,2,1) (not unimodal)", [F[x][0] for x in range(5)], [1, 1, 3, 2, 3])
    chk.ok("row y=0 of (2,2,1) is not unimodal", not unimodal([F[x][0] for x in range(5)]))
    F = F_brute(1, 2, 2)
    col = [F[0][y] for y in range(5)]
    chk.check("column x=0 of (1,2,2)", col, [1, 1, 3, 2, 3])
    chk.ok("column x=0 of (1,2,2) not unimodal, row prefix not log-concave", not unimodal(col) and not logconcave(col[:3]))
    chk.ok("(1,2,2): F(0,4)=3 > F(1,4)... orthant monotonicity fails (x-step toward centre)",
           F[0][4] == 3 and F[1][4] == 1)
    F = F_brute(2, 2, 2)
    king = [F[x][y] for x in (0, 1) for y in (3, 4) if (x, y) != (0, 4)]
    chk.ok("(2,2,2): (0,4) is a strict local maximum, value 6, centre 12",
           F[0][4] == 6 and all(v < 6 for v in king) and F[2][2] == 12)
    chk.check("(2,2,2) antidiagonal through the centre (ridge direction)", [F[x][4 - x] for x in range(5)], [6, 4, 12, 4, 6])
    F = F_brute(2, 4, 2)
    nb = [F[2 + dx][6 + dy] for dx in (-1, 0, 1) for dy in (-1, 0, 1) if (dx, dy) != (0, 0)]
    chk.ok("(2,4,2): ridge vertex (2,6) is a strict local maximum (12), centre 20",
           F[2][6] == 12 and all(v < 12 for v in nb) and F[4][4] == 20)
    # D1: comb pieces by outer 2-runs, (1,2,2), m = 1 (exactly one inner 2)
    piece = Counter()
    for w in words(1, 2, 2):
        lead = next(i for i, ch in enumerate(w) if ch != 2)
        trail = next(i for i, ch in enumerate(reversed(w)) if ch != 2)
        if 2 - lead - trail == 1:
            piece[stats(w)[:2]] += 1
    chk.ok("D1 (1,2,2): piece m=1 vanishes at the centre (1,2) but has value 2 elsewhere",
           piece[(1, 2)] == 0 and max(piece.values()) == 2)
    # D2: path pair v = 13333 and its reverse, (1,2,4)
    pair = Counter()
    for w in words(1, 2, 4):
        v = tuple(ch for ch in w if ch != 2)
        if v in ((1, 3, 3, 3, 3), (3, 3, 3, 3, 1)):
            pair[stats(w)[:2]] += 1
    chk.ok("D2 (1,2,4): pair (13333, 33331) has centre value 2 < max 3",
           pair[(1, 4)] == 2 and max(pair.values()) == 3)
    # D3: (1,2,2), words with an empty middle gap (the two 2s adjacent)
    k = Counter(stats(w)[:2] for w in words(1, 2, 2) if any(w[i] == 2 and w[i + 1] == 2 for i in range(len(w) - 1)))
    chk.ok("D3 (1,2,2): empty-middle-gap piece vanishes at centre (1,2), max 3",
           k[(1, 2)] == 0 and max(k.values()) == 3)
    # trace-class dominance, (2,2,3): fibre (2,2) [level point (2,4)] vs centre (2,3)
    def classes_at(a, b, c, pt):
        cl = Counter()
        for w in words(a, b, c):
            if stats(w)[:2] == pt:
                cl[(tuple(ch for ch in w if ch != 3), tuple(ch for ch in w if ch != 1))] += 1
        return sorted(cl.values(), reverse=True)
    chk.check("(2,2,3) class sizes at (2,2)", classes_at(2, 2, 3, (2, 2)), [6, 6, 2, 1])
    chk.check("(2,2,3) class sizes at centre (2,3)", classes_at(2, 2, 3, (2, 3)), [10, 4, 3, 1])
    chk.note("7. candidate-mechanism failures at their smallest witnesses")


def gauss(n, k):
    P = [1]
    for i in range(k):
        num = [0] * (len(P) + n - i)
        for j, v in enumerate(P):
            num[j] += v
            num[j + n - i] -= v
        out = [0] * (len(num) - (i + 1))
        for j in range(len(out)):
            out[j] = num[j] + (out[j - i - 1] if j >= i + 1 else 0)
        P = out
    return P


def check_projections(chk):
    ok = True
    for a, b, c in contents(10):
        F = F_brute(a, b, c)
        d = Counter()
        for x, r in enumerate(F):
            for y, v in enumerate(r):
                d[x - y + b * c] += v
        g = gauss(a + b + c, b)
        if [d[i] for i in range(len(g))] != [comb(a + c, a) * v for v in g]:
            ok = False
    chk.ok("x - y projection = binom(a+c,a) [a+b+c choose b]_q (brute, total <= 10)", ok)
    ok = True
    for a, b, c in contents(10):
        F = F_brute(a, b, c)
        mx = [sum(F[x]) for x in range(a * b + 1)]
        my = [sum(F[x][y] for x in range(a * b + 1)) for y in range(b * c + 1)]
        if mx != [comb(a + b + c, c) * v for v in gauss(a + b, a)] or \
           my != [comb(a + b + c, a) * v for v in gauss(b + c, b)]:
            ok = False
    chk.ok("marginals: x ~ binom(a+b+c,c)[a+b choose a]_q, y ~ binom(a+b+c,a)[b+c choose b]_q (brute, total <= 10)", ok)
    F = F_brute(1, 1, 2)
    d = Counter()
    for x, r in enumerate(F):
        for y, v in enumerate(r):
            d[x + 2 * y] += v
    seq = [d[i] for i in range(min(d), max(d) + 1)]
    chk.check("(1,1,2): distribution of x + 2y", seq, [1, 3, 2, 2, 3, 1])
    chk.ok("(1,1,2): x + 2y not unimodal", not unimodal(seq))
    chk.note("8. projections")


def check_bodd(chk):
    want = {(1, 3, 2): [(1, 4), (2, 2)], (2, 3, 2): [(2, 4), (4, 2)],
            (3, 3, 4): [(4, 6), (5, 6)], (4, 3, 4): [(6, 6)]}
    for abc, arg in want.items():
        F = F_brute(*abc) if sum(abc) <= 10 else F_level(*abc)
        chk.check(f"b odd maximisers {abc}", argmax(F)[1], arg)
    P = F_prefix(4, 3, 4)
    vals = sorted(P.values())
    chk.ok("(4,3,4): centre (6,6) is the unique maximum (prefix DP)",
           P[(6, 6)] == vals[-1] and vals[-2] < vals[-1])
    ok = True
    for a, b, c in contents(16, lambda b: b % 2 == 1 and b >= 3):
        arg = argmax(F_level(a, b, c))[1]
        if sorted((a * b - x, b * c - y) for x, y in arg) != arg:
            ok = False
        if a == c and any(x + y != a * b for x, y in arg):
            ok = False
    chk.ok("b odd, total <= 16: maximiser sets reversal-invariant; a=c on x+y=ab", ok)
    # Section 9 categories and the corrected distance statement, at this file's bound.
    cat = Counter()
    dist = Counter()
    far = []
    four = 0
    for a, b, c in contents(16, lambda b: b % 2 == 1 and b >= 3):
        if (a, c) == (1, 1):
            continue
        arg = argmax(F_level(a, b, c))[1]
        h1, h2 = (b - 1) // 2, (b + 1) // 2
        V = sorted([(a * h1, c * (b - h1)), (a * h2, c * (b - h2))])
        cx, cy = Fraction(a * b, 2), Fraction(b * c, 2)
        if arg == V:
            cat['V'] += 1
        elif arg == [(cx, cy)]:
            cat['C'] += 1
        else:
            cat['N'] += 1
            d = max(max(abs(x - cx), abs(y - cy)) for x, y in arg)
            dist[d] += 1
            far.append((d, (a, b, c)))
            four += len(arg) == 4
            if len(arg) not in (2, 4):
                four = -10 ** 6
    chk.check("b odd, total <= 16: categories V / C / N", dict(cat), {'V': 49, 'C': 9, 'N': 139})
    dmax = max(dist)
    chk.check("b odd, total <= 16: largest L-inf distance of an N maximiser set", dmax,
              Fraction(7, 2))
    chk.check("b odd, total <= 16: contents attaining it",
              sorted(abc for d, abc in far if d == dmax), [(2, 3, 11), (11, 3, 2)])
    chk.check("b odd, total <= 16: N contents with distance > 3",
              sum(v for d, v in dist.items() if d > 3), 2)
    chk.check("b odd, total <= 16: N contents with four maximisers (others have two)", four, 14)
    chk.note("9. b odd")


def check_mclass(chk):
    ok = True
    for a, b, c in contents(8):
        for w in words(a, b, c):
            x, y, z = stats(w)
            if x == 0 and z != 0 or y == 0 and z != 0 or x == a * b and z != a * y or y == b * c and z != c * x:
                ok = False
    chk.ok("z forced on the box edges (brute, total <= 8)", ok)
    cnt = Counter()
    for a, b, c in contents(12):
        if b == 1 or (a, c) == (1, 1):
            continue
        D = M_level(a, b, c)
        onb = lambda k: k[0] in (0, a * b) or k[1] in (0, b * c)
        Mb = max(v for k, v in D.items() if onb(k))
        Mi = max((v for k, v in D.items() if not onb(k)), default=0)
        cnt['boundary' if Mb > Mi else ('tie' if Mb == Mi else 'interior')] += 1
    chk.check("largest Parikh class, total <= 12: boundary / tie / interior", dict(cnt),
              {'boundary': 92, 'tie': 27, 'interior': 37})
    chk.note("10. Parikh classes")


def check_grand_canonical(chk):
    u = v = Fraction(1, 4)
    N = 22
    for b in (2, 4):
        # rigorous tail: sum_{n > N} (u+v)^n binom(n+b, b) bounds the omitted terms
        tail = sum((u + v) ** n * comb(n + b, b) for n in range(N + 1, N + 400))
        tail += Fraction(1, 2 ** (N + 300))  # crude bound for n >= N + 400
        S = defaultdict(Fraction)
        for a in range(0, N + 1):
            for c in range(0, N + 1 - a):
                if a == 0 and c == 0:
                    S[(0, 0)] += 1
                    continue
                F = F_level(a, b, c) if a and c else None
                if F is None:
                    # binary contents: one letter type absent
                    if a == 0:
                        g = gauss(b + c, b)
                        for y, m in enumerate(g):
                            p, q = 0, y - b * c // 2
                            if abs(q) <= 2:
                                S[(p, q)] += u ** a * v ** c * m
                    else:
                        g = gauss(a + b, a)
                        for x, m in enumerate(g):
                            p, q = x - a * b // 2, 0
                            if abs(p) <= 2:
                                S[(p, q)] += u ** a * v ** c * m
                    continue
                cx, cy = a * b // 2, b * c // 2
                for p in range(-2, 3):
                    for q in range(-2, 3):
                        x, y = cx + p, cy - q
                        if 0 <= x <= a * b and 0 <= y <= b * c:
                            S[(p, q)] += u ** a * v ** c * F[x][y]
        worst = min(S[(0, 0)] - S[(p, q)] for p in range(-2, 3) for q in range(-2, 3) if (p, q) != (0, 0))
        chk.ok(f"grand-canonical central maximum, b={b}: min gap exceeds 2*tail", worst > 2 * tail,
               f"gap {float(worst)}, tail {float(tail)}")
    chk.note("11. grand-canonical sums (u = v = 1/4, truncation a + c <= 22)")


def main() -> int:
    chk = Checker("R7 mechanism: ternary psi_2 maxima (notes/explore-r7-mechanism.md)")
    check_infrastructure(chk)
    check_conjecture_small(chk)
    check_counterexample(chk)
    check_parity(chk)
    check_cs_aca(chk)
    check_2b2(chk)
    check_candidate_failures(chk)
    check_projections(chk)
    check_bodd(chk)
    check_mclass(chk)
    check_grand_canonical(chk)
    chk.note(f"time {time.perf_counter() - START:.1f} s")
    return chk.finish()


if __name__ == "__main__":
    sys.exit(main())
