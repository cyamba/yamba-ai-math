"""Independent checks for the ternary defect theorem package.

The proofs and priority cautions are in notes/ternary-defect-theorems.md.
All arithmetic is exact; this file uses the Python standard library only.
"""

from collections import Counter
from itertools import combinations_with_replacement, product
from math import comb
import sys

from parikh import Checker, occ


def kernel(b, i, j):
    return min(i, j) * (b - max(i, j))


def profile_weight(a, c, A, C):
    ag = (A[0],) + tuple(v-u for u, v in zip(A, A[1:])) + (a-A[-1],)
    cg = (c-C[0],) + tuple(u-v for u, v in zip(C, C[1:])) + (C[-1],)
    weight = 1
    for u, v in zip(ag, cg):
        weight *= comb(u+v, u)
    return weight


def parameter_fibres(a, b, c):
    """Use differences, congruences and the defect kernel, not profile sums."""
    result = Counter()
    for d in product(range(a+1), repeat=b-1):
        if sum(d) > a:
            continue
        U = sum((b-i)*d[i-1] for i in range(1, b))
        for e in product(range(c+1), repeat=b-1):
            if sum(e) > c:
                continue
            V = sum(i*e[i-1] for i in range(1, b))
            defect = sum(kernel(b, i, j)*d[i-1]*e[j-1]
                         for i in range(1, b) for j in range(1, b))
            for x in range(U, a*b-sum(i*d[i-1] for i in range(1, b))+1, b):
                u = (x-U)//b
                for y in range(V, b*c-sum((b-i)*e[i-1] for i in range(1, b))+1, b):
                    v = (y-V)//b
                    assert (x*y-defect) % b == 0
                    z = (x*y-defect)//b
                    ag = (u,) + d + (a-u-sum(d),)
                    cg = (c-v-sum(e),) + e + (v,)
                    weight = 1
                    for ai, ci in zip(ag, cg):
                        weight *= comb(ai+ci, ai)
                    result[x, y, z] += weight
    return result


def words(content):
    remaining = list(content)
    prefix = []

    def visit():
        if not any(remaining):
            yield tuple(prefix)
            return
        for i, count in enumerate(remaining):
            if count:
                remaining[i] -= 1
                prefix.append(i+1)
                yield from visit()
                prefix.pop()
                remaining[i] += 1
    yield from visit()


def L(b, m):
    return (-1,)*m + (0,)*(b-2*m) + (1,)*m


def second_top_formula(a, b, c, p, q):
    factor = comb(p+c-q-2, p-1) * comb(a-p+q-2, a-p-1)
    return (6 if b == 2 else 2*(b//2)+2) * factor


def central_formula(b):
    h = b//2
    result = {b: 2*h+4}
    for m in range(1, h+1):
        result[b-2*m] = 2*(h-m)+4+2*int(b % 2 == 0 and m == h)
    return result


def main():
    check = Checker("ternary defect, isolated upper endpoint, and closed fibres")
    pair_count = 0
    for a, b, c in product(range(1, 4), range(1, 6), range(1, 4)):
        for A in combinations_with_replacement(range(a+1), b):
            d = tuple(v-u for u, v in zip(A, A[1:]))
            for reverse_C in combinations_with_replacement(range(c+1), b):
                C = reverse_C[::-1]
                e = tuple(u-v for u, v in zip(C, C[1:]))
                x, y = sum(A), sum(C)
                z = sum(u*v for u, v in zip(A, C))
                defect = sum(kernel(b, i, j)*d[i-1]*e[j-1]
                             for i in range(1, b) for j in range(1, b))
                check.check("defect identity", x*y-b*z, defect)
                if b > 1:
                    check.check("defect equality characterization", defect == 0,
                                A[0] == A[-1] or C[0] == C[-1])
                pair_count += 1
    check.note(f"all bounded profiles: 1<=a,c<=3, 1<=b<=5; {pair_count} pairs")

    for b in range(2, 20):
        for i, j in product(range(1, b), repeat=2):
            entry = 2*kernel(b, i, j)
            if j > 1:
                entry -= kernel(b, i, j-1)
            if j < b-1:
                entry -= kernel(b, i, j+1)
            check.check("kernel times type-A Cartan matrix", entry, b*int(i == j))

    word_count = 0
    for a, b, c in product(range(1, 4), range(1, 5), range(1, 4)):
        if a+b+c > 9:
            continue
        actual = Counter()
        for w in words((a, b, c)):
            actual[occ(w, (1,2)), occ(w, (2,3)), occ(w, (1,2,3))] += 1
            word_count += 1
        check.check(f"full arithmetic fibre formula {(a,b,c)}", parameter_fibres(a,b,c), actual)
    check.note(f"independent full-word enumeration: a,c<=3, b<=4, total<=9; {word_count} words")

    centered_pairs = 0
    for a, b, c in product(range(2, 5), range(2, 7), range(2, 5)):
        left = [(A, sum(A)//b) for A in combinations_with_replacement(range(a+1), b)
                if sum(A) % b == 0 and 0 < sum(A)//b < a]
        right = [(R[::-1], sum(R)//b) for R in combinations_with_replacement(range(c+1), b)
                 if sum(R) % b == 0 and 0 < sum(R)//b < c]
        second = Counter()
        for A, p in left:
            U = tuple(t-p for t in A)
            for C, q in right:
                V = tuple(t-q for t in C)
                gap = -sum(u*v for u, v in zip(U,V))
                check.ok("isolated upper endpoint", gap == 0 or gap >= 2)
                equality = any((U == L(b,m) and V == tuple(-v for v in L(b,1))) or
                               (U == L(b,1) and V == tuple(-v for v in L(b,m)))
                               for m in range(1,b//2+1))
                check.check("second-top equality profiles", gap == 2, equality)
                if gap == 2:
                    second[p,q] += profile_weight(a,c,A,C)
                centered_pairs += 1
        for p, q in product(range(1,a), range(1,c)):
            check.check("second-top binomial formula", second[p,q],
                        second_top_formula(a,b,c,p,q))
    check.note(f"integer-mean gap and second-top classification: a,c<=4, 2<=b<=6; {centered_pairs} pairs")

    for b in range(1, 25):
        actual = Counter()
        h = b//2
        for m, n in product(range(h+1), repeat=2):
            A = tuple(1+u for u in L(b,m))
            C = tuple(1-v for v in L(b,n))
            z = sum(u*v for u,v in zip(A,C))
            actual[z] += profile_weight(2,2,A,C)
        check.check(f"central (2,{b},2) complete distribution", actual, Counter(central_formula(b)))
        total = (h+2)*(h+3) if b % 2 == 0 else (h+1)*(h+4)
        check.check("central total pair fibre", sum(actual.values()), total)
        if b <= 6:
            independent = Counter()
            for w in words((2,b,2)):
                if occ(w,(1,2)) == b and occ(w,(2,3)) == b:
                    independent[occ(w,(1,2,3))] += 1
            check.check("central distribution against full words", independent, actual)
    check.note("central closed distributions: 1<=b<=24; full-word comparison for b<=6")

    corner_pairs = 0
    for a, b, c in product(range(2,5), range(3,8), range(2,5)):
        for r in range(2,b):
            left = [A for A in combinations_with_replacement(range(a+1),b) if sum(A) == r]
            right = [B for B in combinations_with_replacement(range(c+1),b) if sum(B) == r]
            second = 0
            for A in left:
                for B in right:
                    excess = sum(u*v for u,v in zip(A,B))-r
                    check.ok("corner isolated endpoint", excess == 0 or excess >= 2)
                    check.check("corner top equality", excess == 0, A[-1] <= 1 or B[-1] <= 1)
                    equality = A[-1] == B[-1] == 2 and min(A.count(2),B.count(2)) == 1
                    check.check("corner second-top equality", excess == 2, equality)
                    if excess == 2:
                        C = tuple(c-v for v in B)
                        second += profile_weight(a,c,A,C)
                    corner_pairs += 1
            H = 6 if r == 2 else 2*(r//2)+2
            check.check("corner second-top binomial formula", second,
                        H*comb(a+c-4,a-2))
    check.note(f"corner gap and second-top formula: a,c<=4, 3<=b<=7, 2<=r<b; {corner_pairs} pairs")
    return check.finish()


if __name__ == "__main__":
    sys.exit(main())
