"""R2: exact conditional extrema of the ternary triple count |w|_123.

Evidence for notes/proof-r2-extrema.md (the detailed record) and the Proposition in
notes/partition-route-audit.md section 4. Every computational claim of the note is recomputed
here: by brute force over words at small sizes, without the profile model, and by exact
profile-level methods where there are too many words. A pass is evidence, not a proof.

    python3 checks/check_r2_extrema.py          # default sizes, about 20 s
    python3 checks/check_r2_extrema.py --full   # adds the [full] ranges of the note's Section 7

Any other argument (run_all.py passes --max-n N) is ignored. Standard library only, and
deterministic: there is no randomness. The exit status is non-zero on any failure.

Notation, as in the note: words of content (a,b,c) over 1 < 2 < 3; x = |w|_12, y = |w|_23,
z = |w|_123 (scattered subwords). For the l-th 2 of w, A_l is the number of 1's before it and
C_l the number of 3's after it. x = bq+r and y = bt+s with 0 <= r,s < b; x = aQ+R and
y = cT+S with 0 <= R < a and 0 <= S < c; L = cx+ay-abc is Ding-Salomaa 2006, Lemma 3's lower
bound.
"""

from __future__ import annotations

import sys
import time
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations, combinations_with_replacement
from math import comb
from operator import mul

FULL = "--full" in sys.argv[1:]


# ---------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------


class Checker:
    def __init__(self, title: str) -> None:
        self.title = title
        self.passed = 0
        self.failures: list[str] = []
        print(f"== {title}" + ("  [--full]" if FULL else ""))

    def check(self, label: str, got, want) -> bool:
        if got == want:
            self.passed += 1
            return True
        self.failures.append(f"{label}\n      expected: {want!r}\n      got:      {got!r}")
        return False

    def ok(self, label: str, condition: bool) -> bool:
        if condition:
            self.passed += 1
            return True
        self.failures.append(label)
        return False

    def note(self, text: str) -> None:
        print(f"   {text}", flush=True)

    def finish(self) -> int:
        if self.failures:
            print(f"FAIL {self.title}: {len(self.failures)} failure(s), {self.passed} passed")
            for f in self.failures[:25]:
                print(f"   - {f}")
            if len(self.failures) > 25:
                print(f"   ... and {len(self.failures) - 25} more")
            return 1
        print(f"OK   {self.title}: {self.passed} checks passed")
        return 0


# ---------------------------------------------------------------------------
# Words (no profile model)
# ---------------------------------------------------------------------------


def word_cells(a: int, b: int, c: int) -> dict:
    """All words of content (a,b,c): {(x, y): Counter{z: number of words}}.

    Depth first over prefixes. Reading a 2 adds the number of 1's read so far to x; reading
    a 3 adds the number of 2's read so far to y and the number of 12's read so far to z."""
    cells: dict = defaultdict(Counter)

    def rec(r1, r2, r3, n1, n2, n12, x, y, z):
        if r1:
            rec(r1 - 1, r2, r3, n1 + 1, n2, n12, x, y, z)
        if r2:
            rec(r1, r2 - 1, r3, n1, n2 + 1, n12 + n1, x + n1, y, z)
        if r3:
            rec(r1, r2, r3 - 1, n1, n2, n12, x, y + n2, z + n12)
        if not (r1 or r2 or r3):
            cells[x, y][z] += 1

    rec(a, b, c, 0, 0, 0, 0, 0, 0)
    return cells


def words(a: int, b: int, c: int):
    """Yield every word of content (a,b,c) as a tuple."""
    n = a + b + c
    for pos2 in combinations(range(n), b):
        rest = [p for p in range(n) if p not in set(pos2)]
        for pos1 in combinations(rest, a):
            w = [3] * n
            for p in pos2:
                w[p] = 2
            for p in pos1:
                w[p] = 1
            yield tuple(w)


def counts_incremental(w) -> tuple:
    """(|w|_1, |w|_2, |w|_3, |w|_12, |w|_23, |w|_123), one left-to-right pass."""
    n1 = n2 = n3 = n12 = n23 = n123 = 0
    for ch in w:
        if ch == 1:
            n1 += 1
        elif ch == 2:
            n2 += 1
            n12 += n1
        else:
            n3 += 1
            n23 += n2
            n123 += n12
    return n1, n2, n3, n12, n23, n123


def counts_naive(w) -> tuple:
    """(x, y, z) by listing position pairs and triples."""
    n = len(w)
    x = sum(1 for i, j in combinations(range(n), 2) if (w[i], w[j]) == (1, 2))
    y = sum(1 for i, j in combinations(range(n), 2) if (w[i], w[j]) == (2, 3))
    z = sum(1 for i, j, k in combinations(range(n), 3) if (w[i], w[j], w[k]) == (1, 2, 3))
    return x, y, z


def profile_pair(w) -> tuple:
    """(A(w), C(w)) by scanning: ones before, and threes after, each 2."""
    total3 = w.count(3)
    A, C = [], []
    n1 = n3 = 0
    for ch in w:
        if ch == 1:
            n1 += 1
        elif ch == 3:
            n3 += 1
        else:
            A.append(n1)
            C.append(total3 - n3)
    return tuple(A), tuple(C)


def word_from_pair(A, C, a: int, c: int) -> tuple:
    """The gap construction: gap g gets a_g 1's then c_g 3's (one of the W(A,C) words)."""
    b = len(A)
    ag = [A[0]] + [A[g] - A[g - 1] for g in range(1, b)] + [a - A[-1]]
    cg = [c - C[0]] + [C[g - 1] - C[g] for g in range(1, b)] + [C[-1]]
    w: list = []
    for g in range(b + 1):
        w += [1] * ag[g] + [3] * cg[g]
        if g < b:
            w.append(2)
    return tuple(w)


# ---------------------------------------------------------------------------
# Profiles and the note's formulas
# ---------------------------------------------------------------------------


def incr_profiles(top: int, b: int) -> list:
    """All weakly increasing integer vectors of length b with entries in [0, top]."""
    return list(combinations_with_replacement(range(top + 1), b))


def decr_profiles(top: int, b: int) -> list:
    return [p[::-1] for p in incr_profiles(top, b)]


def dot(A, C) -> int:
    return sum(map(mul, A, C))


def phi(P) -> int:
    return sum(v * v for v in P)


def is_incr(P, top: int) -> bool:
    return all(0 <= u <= v <= top for u, v in zip(P, P[1:])) and 0 <= P[0] and P[-1] <= top


def is_decr(P, top: int) -> bool:
    return is_incr(P[::-1], top)


def z_max_formula(a, b, c, x, y) -> int:
    q, r = divmod(x, b)
    t, s = divmod(y, b)
    return b * q * t + q * s + t * r + max(0, r + s - b)


def z_min_formula(a, b, c, x, y) -> int:
    Q, R = divmod(x, a)
    T, S = divmod(y, c)
    if Q + T >= b:
        return a * c * (Q + T - b) + a * S + c * R
    if Q + T == b - 1:
        return R * S
    return 0


def z_min_one_expression(a, b, c, x, y) -> int:
    """Section 3.4: ac*max(0,Q+T-b) + (aS+cR)[Q+T>=b] + RS[Q+T=b-1]."""
    Q, R = divmod(x, a)
    T, S = divmod(y, c)
    return (a * c * max(0, Q + T - b) + (a * S + c * R) * (Q + T >= b)
            + R * S * (Q + T == b - 1))


def lower_bound_L(a, b, c, x, y) -> int:
    return c * x + a * y - a * b * c


# The four extremal profiles in three independent forms (Section 1.3 of the note).

def a_bal_block(a, b, x):
    q, r = divmod(x, b)
    return tuple([q] * (b - r) + [q + 1] * r)


def c_bal_block(c, b, y):
    t, s = divmod(y, b)
    return tuple([t + 1] * s + [t] * (b - s))


def a_con_block(a, b, x):
    Q, R = divmod(x, a)
    return tuple([a] * b) if Q == b else tuple([0] * (b - Q - 1) + [R] + [a] * Q)


def c_con_block(c, b, y):
    T, S = divmod(y, c)
    return tuple([c] * b) if T == b else tuple([c] * T + [S] + [0] * (b - T - 1))


def a_bal_bracket(a, b, x):
    q, r = divmod(x, b)
    return tuple(q + (l >= b - r + 1) for l in range(1, b + 1))


def c_bal_bracket(c, b, y):
    t, s = divmod(y, b)
    return tuple(t + (l <= s) for l in range(1, b + 1))


def a_con_bracket(a, b, x):
    Q, R = divmod(x, a)
    return tuple(a * (l >= b - Q + 1) + R * (l == b - Q) for l in range(1, b + 1))


def c_con_bracket(c, b, y):
    T, S = divmod(y, c)
    return tuple(c * (l <= T) + S * (l == T + 1) for l in range(1, b + 1))


def a_bal_closed(a, b, x):
    return tuple((x + l - 1) // b for l in range(1, b + 1))


def c_bal_closed(c, b, y):
    return tuple((y + b - l) // b for l in range(1, b + 1))


def a_con_closed(a, b, x):
    return tuple(min(a, max(0, x - a * (b - l))) for l in range(1, b + 1))


def c_con_closed(c, b, y):
    return tuple(min(c, max(0, y - c * (l - 1))) for l in range(1, b + 1))


def gap_weight(A, C, a: int, c: int) -> int:
    """W(A,C) = prod_g binom(a_g + c_g, a_g) (Lemma 1.1(b))."""
    b = len(A)
    ag = [A[0]] + [A[g] - A[g - 1] for g in range(1, b)] + [a - A[-1]]
    cg = [c - C[0]] + [C[g - 1] - C[g] for g in range(1, b)] + [C[-1]]
    w = 1
    for u, v in zip(ag, cg):
        w *= comb(u + v, u)
    return w


# ---------------------------------------------------------------------------
# 1. The subword counter itself
# ---------------------------------------------------------------------------


def check_counters(chk: Checker) -> None:
    """The incremental counter and the scan for (A, C) against naive position counting."""
    n_words = 0
    for a in range(1, 4):
        for b in range(1, 4):
            for c in range(1, 4):
                agg = Counter()
                for w in words(a, b, c):
                    n_words += 1
                    inc = counts_incremental(w)
                    x, y, z = counts_naive(w)
                    if not chk.ok(f"counter {w}", inc == (a, b, c, x, y, z)):
                        return
                    A, C = profile_pair(w)
                    chk.ok(f"profile sums {w}", (sum(A), sum(C), dot(A, C)) == (x, y, z))
                    agg[x, y, z] += 1
                dfs = Counter()
                for (x, y), zs in word_cells(a, b, c).items():
                    for z, k in zs.items():
                        dfs[x, y, z] += k
                chk.check(f"DFS cells = explicit words {(a, b, c)}", dfs, agg)
    chk.check("words with 1<=a,b,c<=3", n_words, 5052)
    chk.note(f"counters: incremental and DFS counts = naive counts on all {n_words} words, "
             "1<=a,b,c<=3")


# ---------------------------------------------------------------------------
# 2. Word level: the Proposition, Corollary 5.1, Remark 5.3, holes (no profile model)
# ---------------------------------------------------------------------------


def check_word_cells(chk: Checker, contents, label: str) -> Counter:
    tally = Counter()
    for a, b, c in contents:
        cells = word_cells(a, b, c)
        tally["contents"] += 1
        chk.check(f"{label}: every (x,y) of the box occurs {(a, b, c)}", set(cells),
                  {(x, y) for x in range(a * b + 1) for y in range(b * c + 1)})
        for (x, y), zs in cells.items():
            tally["words"] += sum(zs.values())
            tally["cells"] += 1
            lo, hi = min(zs), max(zs)
            key = (a, b, c, x, y)
            # The Proposition.
            chk.check(f"{label}: (z_min, z_max) {key}", (lo, hi),
                      (z_min_formula(a, b, c, x, y), z_max_formula(a, b, c, x, y)))
            # Corollary 5.1.
            Q, R = divmod(x, a)
            T, S = divmod(y, c)
            L = lower_bound_L(a, b, c, x, y)
            chk.ok(f"{label}: DS06 bound z_min >= L {key}", lo >= L)
            chk.check(f"{label}: z_min = L iff Q+T >= b {key}", lo == L, Q + T >= b)
            chk.check(f"{label}: a word with z = L exists iff Q+T >= b {key}", L in zs,
                      Q + T >= b)
            if Q + T == b - 1:
                chk.check(f"{label}: gap (a-R)(c-S) {key}", lo - L, (a - R) * (c - S))
            if Q + T <= b - 2:
                chk.ok(f"{label}: L <= -(a+c) {key}", L <= -(a + c) and lo == 0)
            chk.check(f"{label}: z_min = max(0,L) + [Q+T=b-1]min(RS,(a-R)(c-S)) {key}", lo,
                      max(0, L) + (Q + T == b - 1) * min(R * S, (a - R) * (c - S)))
            chk.check(f"{label}: max(0,L) attained iff Q+T != b-1 or RS = 0 {key}",
                      max(0, L) in zs, Q + T != b - 1 or R * S == 0)
            # Remark 5.3.
            q, r = divmod(x, b)
            t, s = divmod(y, b)
            d = min(r * s, (b - r) * (b - s))
            chk.check(f"{label}: xy - b z_max = min(rs,(b-r)(b-s)) {key}", x * y - b * hi, d)
            chk.check(f"{label}: xy/b attained iff b|x or b|y {key}",
                      any(b * z == x * y for z in zs), r == 0 or s == 0)
            chk.ok(f"{label}: floor(xy/b) - z_max = floor(d/b) <= floor(b/4) {key}",
                   x * y // b - hi == d // b <= b // 4)
            # Tallies quoted in the note.
            tally["z_min = L"] += lo == L
            tally["z_min > L"] += lo > L
            tally["z_min > max(0,L)"] += lo > max(0, L)
            tally["Q+T=b-1 and R,S>=1"] += Q + T == b - 1 and R >= 1 and S >= 1
            tally["Q+T=b-1 and L>0"] += Q + T == b - 1 and L > 0
            tally["Q+T>=b"] += Q + T >= b
            tally["cells with holes"] += len(zs) != hi - lo + 1
    return tally


def check_words(chk: Checker) -> None:
    upto4 = [(a, b, c) for a in range(1, 5) for b in range(1, 5) for c in range(1, 5)]
    t = check_word_cells(chk, upto4, "words a,b,c<=4")
    want = {"contents": 64, "words": 109512, "cells": 3864, "z_min = L": 1864,
            "z_min > L": 2000, "z_min > max(0,L)": 360, "Q+T=b-1 and R,S>=1": 360,
            "Q+T=b-1 and L>0": 140, "Q+T>=b": 1864, "cells with holes": 546}
    for k, v in want.items():
        chk.check(f"note tally, 1<=a,b,c<=4: {k}", t[k], v)
    chk.note(f"words, 1<=a,b,c<=4: {t['words']} words, {t['cells']} cells; z_min=L on "
             f"{t['z_min = L']} (= the Q+T>=b cells), z_min>L on {t['z_min > L']}, "
             f"z_min>max(0,L) on {t['z_min > max(0,L)']}, Q+T=b-1 with L>0 on "
             f"{t['Q+T=b-1 and L>0']}, holes in {t['cells with holes']} cells")

    five = [(a, b, c) for a in range(1, 6) for b in range(1, 6) for c in range(1, 6)
            if max(a, b, c) == 5]
    t5 = check_word_cells(chk, five, "words max(a,b,c)=5")
    chk.check("words with max(a,b,c)=5", t5["words"], 2432448 - 109512)
    chk.note(f"words, max(a,b,c)=5: {t5['words']} words, {t5['cells']} cells, all formulas hold")

    long_b = [(a, b, c) for a in (1, 2) for c in (1, 2) for b in range(6, 12)]
    long_b += [(a, b, c) for a in (1, 2, 3) for c in (1, 2, 3) for b in (6, 7) if 3 in (a, c)]
    wide = [(a, b, c) for a in range(6, 9) for c in range(1, 9) for b in (1, 2)]
    wide += [(a, b, c) for a in range(1, 6) for c in range(6, 9) for b in (1, 2)]
    t6 = check_word_cells(chk, long_b + wide, "words long b / wide a,c")
    chk.note(f"words, b up to 11 with a,c<=2 (and b<=7 with a,c<=3), and b<=2 with a,c up "
             f"to 8: {t6['words']} words, {t6['cells']} cells, all formulas hold")

    if FULL:
        six = [(a, b, c) for a in range(1, 7) for b in range(1, 7) for c in range(1, 7)
               if max(a, b, c) == 6]
        start = time.perf_counter()
        t7 = check_word_cells(chk, six, "words max(a,b,c)=6")
        chk.note(f"[full] words, max(a,b,c)=6: {t7['words']} words, {t7['cells']} cells "
                 f"({time.perf_counter() - start:.0f} s)")


# ---------------------------------------------------------------------------
# 3. Lemma 1.1: the profile model, at word level
# ---------------------------------------------------------------------------


def check_profile_model(chk: Checker) -> None:
    n_words = n_pairs = 0
    for a in range(1, 5):
        for b in range(1, 5):
            for c in range(1, 5):
                seen = Counter()
                zsets = defaultdict(set)
                for w in words(a, b, c):
                    n_words += 1
                    _, _, _, x, y, z = counts_incremental(w)
                    A, C = profile_pair(w)
                    if not chk.ok(f"Lemma 1.1(a) {w}", is_incr(A, a) and is_decr(C, c)
                                  and (sum(A), sum(C), dot(A, C)) == (x, y, z)):
                        return
                    seen[A, C] += 1
                    zsets[x, y].add(z)
                As, Cs = incr_profiles(a, b), decr_profiles(c, b)
                want = {(A, C): gap_weight(A, C, a, c) for A in As for C in Cs}
                n_pairs += len(want)
                chk.check(f"Lemma 1.1(b): each pair (A,C) has W(A,C) words {(a, b, c)}",
                          dict(seen), want)
                prof = defaultdict(set)
                for A in As:
                    for C in Cs:
                        prof[sum(A), sum(C)].add(dot(A, C))
                chk.check(f"Z(x,y) = {{A.C}} {(a, b, c)}", dict(zsets), dict(prof))
    chk.note(f"Lemma 1.1: {n_words} words, 1<=a,b,c<=4; all {n_pairs} profile pairs occur, "
             "each exactly W(A,C) times, and z = A.C")


# ---------------------------------------------------------------------------
# 4. Profile level: extremal pairs, one-sided corollaries, the defect identity
# ---------------------------------------------------------------------------


def check_profile_extrema(chk: Checker, amax: int, bmax: int, cmax: int, label: str):
    cells = pairs = 0
    for b in range(1, bmax + 1):
        A_by_a = {a: defaultdict(list) for a in range(1, amax + 1)}
        for a in range(1, amax + 1):
            for A in incr_profiles(a, b):
                A_by_a[a][sum(A)].append(A)
        C_by_c = {c: defaultdict(list) for c in range(1, cmax + 1)}
        for c in range(1, cmax + 1):
            for C in decr_profiles(c, b):
                C_by_c[c][sum(C)].append(C)
        for a in range(1, amax + 1):
            for c in range(1, cmax + 1):
                for x, As in A_by_a[a].items():
                    Abal, Acon = a_bal_block(a, b, x), a_con_block(a, b, x)
                    for y, Cs in C_by_c[c].items():
                        lo = hi = None
                        for A in As:
                            zs = [sum(map(mul, A, C)) for C in Cs]
                            mn, mx = min(zs), max(zs)
                            lo = mn if lo is None or mn < lo else lo
                            hi = mx if hi is None or mx > hi else hi
                        pairs += len(As) * len(Cs)
                        cells += 1
                        key = (a, b, c, x, y)
                        Cbal, Ccon = c_bal_block(c, b, y), c_con_block(c, b, y)
                        chk.check(f"{label}: (min, max) of A.C {key}", (lo, hi),
                                  (z_min_formula(a, b, c, x, y), z_max_formula(a, b, c, x, y)))
                        chk.check(f"{label}: extremal pairs {key}", (dot(Acon, Ccon),
                                  dot(Abal, Cbal)), (lo, hi))
    return cells, pairs


def check_profiles(chk: Checker) -> None:
    start = time.perf_counter()
    cells, pairs = check_profile_extrema(chk, 5, 6, 5, "profiles a,c<=5, b<=6")
    chk.check("cells a,c<=5, b<=6", cells, 23775)
    chk.check("profile pairs a,c<=5, b<=6", pairs, 920253)
    chk.note(f"profiles, 1<=a,c<=5, 1<=b<=6: {cells} cells, {pairs} pairs; brute-force min and "
             f"max of A.C = the Proposition = the extremal pairs ({time.perf_counter() - start:.1f} s)")
    if FULL:
        start = time.perf_counter()
        cells, pairs = check_profile_extrema(chk, 6, 8, 6, "profiles a,c<=6, b<=8")
        chk.check("cells a,c<=6, b<=8", cells, 99324)
        chk.check("profile pairs a,c<=6, b<=8", pairs, 38108994)
        chk.note(f"[full] profiles, 1<=a,c<=6, 1<=b<=8: {cells} cells, {pairs} pairs "
                 f"({time.perf_counter() - start:.0f} s)")

    # Corollaries 2.3, 2.6, 3.3, 3.6 against every opposite profile, and the elementary identity
    # xy - b A.C = sum_{l<l'} (A_l' - A_l)(C_l - C_l') (the note's Section 7, item 8).
    n = 0
    amax, bmax = (5, 7) if FULL else (4, 6)
    for b in range(1, bmax + 1):
        for a in range(1, amax + 1):
            As = incr_profiles(a, b)
            for c in range(1, amax + 1):
                Cs = decr_profiles(c, b)
                for A in As:
                    x = sum(A)
                    Abal, Acon = a_bal_block(a, b, x), a_con_block(a, b, x)
                    for C in Cs:
                        y = sum(C)
                        z = dot(A, C)
                        n += 1
                        ok = (dot(Acon, C) <= z <= dot(Abal, C)
                              and dot(A, c_con_block(c, b, y)) <= z
                              <= dot(A, c_bal_block(c, b, y)))
                        cov = sum((A[m] - A[l]) * (C[l] - C[m])
                                  for l in range(b) for m in range(l + 1, b))
                        if not chk.ok(f"one-sided corollaries / defect identity {(a, b, c, A, C)}",
                                      ok and x * y - b * z == cov
                                      and cov >= (A[-1] - A[0]) * (C[0] - C[-1]) >= 0):
                            return
    chk.note(f"Corollaries 2.3, 2.6, 3.3, 3.6 and the defect identity: {n} pairs "
             f"(A,C), 1<=a,c<={amax}, 1<=b<={bmax}")


# ---------------------------------------------------------------------------
# 5. The transfer lemmas 2.1, 2.4, 3.1, 3.4 and the uniqueness lemmas, step by step
# ---------------------------------------------------------------------------


def unit(b: int, i: int) -> tuple:
    return tuple(1 if l == i else 0 for l in range(b))


def vec_sub(P, Q) -> tuple:
    return tuple(u - v for u, v in zip(P, Q))


def step_balance_A(A, a):
    """Lemma 2.1 (0-based): i = last of the minimum block, j = first of the maximum block."""
    m, M = A[0], A[-1]
    if M - m < 2:
        return None
    i = max(l for l in range(len(A)) if A[l] == m)
    j = min(l for l in range(len(A)) if A[l] == M)
    B = list(A)
    B[i] += 1
    B[j] -= 1
    return i, j, tuple(B)


def step_balance_C(C, c):
    """Lemma 2.4: i = last of the maximum block, j = first of the minimum block."""
    M, m = C[0], C[-1]
    if M - m < 2:
        return None
    i = max(l for l in range(len(C)) if C[l] == M)
    j = min(l for l in range(len(C)) if C[l] == m)
    D = list(C)
    D[i] -= 1
    D[j] += 1
    return i, j, tuple(D)


def step_concentrate_A(A, a):
    """Lemma 3.1: I = {l : 0 < A_l < a}, i = min I, j = max I, A' = A - e_i + e_j."""
    I = [l for l in range(len(A)) if 0 < A[l] < a]
    if len(I) < 2:
        return None
    i, j = I[0], I[-1]
    B = list(A)
    B[i] -= 1
    B[j] += 1
    return i, j, tuple(B)


def step_concentrate_C(C, c):
    """Lemma 3.4: J = {l : 0 < C_l < c}, i = min J, j = max J, C' = C + e_i - e_j."""
    J = [l for l in range(len(C)) if 0 < C[l] < c]
    if len(J) < 2:
        return None
    i, j = J[0], J[-1]
    D = list(C)
    D[i] += 1
    D[j] -= 1
    return i, j, tuple(D)


def check_transfers(chk: Checker) -> None:
    steps = Counter()
    dot_checks = 0
    amax, bmax = 6, 7
    dmax_a, dmax_b = (6, 7) if FULL else (4, 6)
    for a in range(1, amax + 1):
        for b in range(1, bmax + 1):
            family = dmax_a >= a and dmax_b >= b
            incr_family = incr_profiles(a, b) if family else []   # c = a, as in the note
            decr_family = decr_profiles(a, b) if family else []
            # real-valued opposite vectors, including negative entries
            decr_family_r = [tuple(v / 2 for v in p[::-1])
                             for p in combinations_with_replacement(range(-2, 4), b)] if family else []
            incr_family_r = [p[::-1] for p in decr_family_r]
            for P in incr_profiles(a, b):
                x = sum(P)
                # Lemma 2.1: balancing A.
                A, n = P, 0
                while True:
                    st = step_balance_A(A, a)
                    if st is None:
                        break
                    i, j, B = st
                    m, M = A[0], A[-1]
                    good = (i < j and all(A[l] == m for l in range(i + 1))
                            and all(A[l] == M for l in range(j, b))
                            and all(m + 1 <= A[l] <= M - 1 for l in range(i + 1, j))
                            and is_incr(B, a) and sum(B) == x
                            and vec_sub(B, A) == vec_sub(unit(b, i), unit(b, j))
                            and phi(B) == phi(A) - 2 * (M - m - 1) <= phi(A) - 2)
                    for C in decr_family + decr_family_r:
                        dot_checks += 1
                        good = good and dot(B, C) - dot(A, C) == C[i] - C[j] >= 0
                    if not chk.ok(f"Lemma 2.1 step {(a, b, A)}", good):
                        return
                    A, n = B, n + 1
                steps["2.1"] += n
                chk.ok(f"Corollary 2.3 chain {(a, b, P)}", A == a_bal_block(a, b, x)
                       and n <= (phi(P) - phi(A)) // 2)
                # Lemma 3.1: concentrating A.
                A, n = P, 0
                while True:
                    st = step_concentrate_A(A, a)
                    if st is None:
                        break
                    i, j, B = st
                    I = [l for l in range(b) if 0 < A[l] < a]
                    good = (i < j and I == list(range(i, j + 1))
                            and all(A[l] == 0 for l in range(i))
                            and all(A[l] == a for l in range(j + 1, b))
                            and 1 <= A[i] <= A[j] <= a - 1
                            and is_incr(B, a) and sum(B) == x
                            and vec_sub(B, A) == vec_sub(unit(b, j), unit(b, i))
                            and phi(B) == phi(A) + 2 * (A[j] - A[i] + 1) >= phi(A) + 2
                            and phi(B) <= b * a * a)
                    for C in decr_family + decr_family_r:
                        dot_checks += 1
                        good = good and dot(B, C) - dot(A, C) == C[j] - C[i] <= 0
                    if not chk.ok(f"Lemma 3.1 step {(a, b, A)}", good):
                        return
                    A, n = B, n + 1
                steps["3.1"] += n
                chk.ok(f"Corollary 3.3 chain {(a, b, P)}", A == a_con_block(a, b, x)
                       and n <= (phi(A) - phi(P)) // 2)
            for P in decr_profiles(a, b):           # C-profiles with c = a
                c, y = a, sum(P)
                # Lemma 2.4: balancing C.
                C, n = P, 0
                while True:
                    st = step_balance_C(C, c)
                    if st is None:
                        break
                    i, j, D = st
                    M, m = C[0], C[-1]
                    good = (i < j and all(C[l] == M for l in range(i + 1))
                            and all(C[l] == m for l in range(j, b))
                            and all(m + 1 <= C[l] <= M - 1 for l in range(i + 1, j))
                            and is_decr(D, c) and sum(D) == y
                            and vec_sub(D, C) == vec_sub(unit(b, j), unit(b, i))
                            and phi(D) == phi(C) - 2 * (M - m - 1) <= phi(C) - 2)
                    for A in incr_family + incr_family_r:
                        dot_checks += 1
                        good = good and dot(A, D) - dot(A, C) == A[j] - A[i] >= 0
                    if not chk.ok(f"Lemma 2.4 step {(c, b, C)}", good):
                        return
                    C, n = D, n + 1
                steps["2.4"] += n
                chk.ok(f"Corollary 2.6 chain {(c, b, P)}", C == c_bal_block(c, b, y)
                       and n <= (phi(P) - phi(C)) // 2)
                # Lemma 3.4: concentrating C.
                C, n = P, 0
                while True:
                    st = step_concentrate_C(C, c)
                    if st is None:
                        break
                    i, j, D = st
                    J = [l for l in range(b) if 0 < C[l] < c]
                    good = (i < j and J == list(range(i, j + 1))
                            and all(C[l] == c for l in range(i))
                            and all(C[l] == 0 for l in range(j + 1, b))
                            and 1 <= C[j] <= C[i] <= c - 1
                            and is_decr(D, c) and sum(D) == y
                            and vec_sub(D, C) == vec_sub(unit(b, i), unit(b, j))
                            and phi(D) == phi(C) + 2 * (C[i] - C[j] + 1) >= phi(C) + 2
                            and phi(D) <= b * c * c)
                    for A in incr_family + incr_family_r:
                        dot_checks += 1
                        good = good and dot(A, D) - dot(A, C) == A[i] - A[j] <= 0
                    if not chk.ok(f"Lemma 3.4 step {(c, b, C)}", good):
                        return
                    C, n = D, n + 1
                steps["3.4"] += n
                chk.ok(f"Corollary 3.6 chain {(c, b, P)}", C == c_con_block(c, b, y)
                       and n <= (phi(C) - phi(P)) // 2)
    for lemma in ("2.1", "2.4", "3.1", "3.4"):
        chk.check(f"transfer steps of Lemma {lemma}, a<=6, b<=7, c=a", steps[lemma], 19287)
    chk.note(f"transfer Lemmas 2.1, 2.4, 3.1, 3.4: {sum(steps.values())} steps from every "
             f"profile with 1<=a<=6, 1<=b<=7 (c=a), all per-step facts hold; dot-product change "
             f"checked against opposite vectors for a<={dmax_a}, b<={dmax_b} "
             f"({dot_checks} comparisons)")

    # Lemmas 2.2, 2.5, 3.2, 3.5: the terminal profiles are unique.
    n = 0
    for a in range(1, 7):
        for b in range(1, 8):
            for A in incr_profiles(a, b):
                x, n = sum(A), n + 1
                chk.check(f"Lemma 2.2 {(a, A)}", A[-1] - A[0] <= 1, A == a_bal_block(a, b, x))
                chk.check(f"Lemma 3.2 {(a, A)}", sum(0 < v < a for v in A) <= 1,
                          A == a_con_block(a, b, x))
            for C in decr_profiles(a, b):
                y = sum(C)
                chk.check(f"Lemma 2.5 {(a, C)}", C[0] - C[-1] <= 1, C == c_bal_block(a, b, y))
                chk.check(f"Lemma 3.5 {(a, C)}", sum(0 < v < a for v in C) <= 1,
                          C == c_con_block(a, b, y))
    chk.note(f"uniqueness Lemmas 2.2, 2.5, 3.2, 3.5: all {n} profiles of each kind, "
             "1<=a<=6, 1<=b<=7")


# ---------------------------------------------------------------------------
# 6. Remark 3.7: summation by parts and the prefix-sum bounds
# ---------------------------------------------------------------------------


def prefix_sums(P) -> list:
    """[S_0, S_1, ..., S_b] with S_k = P_1 + ... + P_k."""
    out = [0]
    for v in P:
        out.append(out[-1] + v)
    return out


def check_summation_by_parts(chk: Checker) -> None:
    amax, bmax = (7, 8) if FULL else (6, 7)
    n_prof = 0
    for top in range(1, amax + 1):
        for b in range(1, bmax + 1):
            for A in incr_profiles(top, b):
                n_prof += 1
                x = sum(A)
                q, r = divmod(x, b)
                S = prefix_sums(A)
                Sbal = prefix_sums(a_bal_block(top, b, x))
                Scon = prefix_sums(a_con_block(top, b, x))
                # S_k(A^con) = max(0, x - a(b-k)) <= S_k(A) <= kq + max(0, k-(b-r)) = S_k(A^bal)
                if not chk.ok(f"Remark 3.7 prefix-sum bounds {(top, b, A)}",
                              all(Scon[k] == max(0, x - top * (b - k)) <= S[k]
                                  <= k * q + max(0, k - (b - r)) == Sbal[k]
                                  for k in range(b + 1))):
                    return
                # The C side by reversal: here A is read as a reversed C-profile with c = top.
                # The reverses of C^bal(y) and C^con(y) are the A-side extremal vectors for (c, y).
                C = A[::-1]
                chk.ok(f"Remark 3.7 reversal {(top, b, C)}",
                       c_bal_block(top, b, x)[::-1] == a_bal_block(top, b, x)
                       and c_con_block(top, b, x)[::-1] == a_con_block(top, b, x)
                       and is_decr(C, top) and sum(C) == x)
    # The identity A.C = x C_b + sum_{k=1}^{b-1} (C_k - C_{k+1}) S_k(A), for every decreasing C,
    # here integer profiles and a family of real vectors (multiples of 1/2, negatives included).
    n_id = 0
    for b in range(1, 7):
        Cs = [C for c in range(1, 5) for C in decr_profiles(c, b)]
        Cs += [tuple(v / 2 for v in p[::-1]) for p in combinations_with_replacement(range(-3, 5), b)]
        for a in range(1, 5):
            for A in incr_profiles(a, b):
                x, S = sum(A), prefix_sums(A)
                for C in Cs:
                    n_id += 1
                    if not chk.ok(f"Remark 3.7 summation by parts {(A, C)}",
                                  dot(A, C) == x * C[-1] + sum((C[k - 1] - C[k]) * S[k]
                                                               for k in range(1, b))):
                        return
    chk.note(f"Remark 3.7: prefix-sum bounds and their attainment for all {n_prof} increasing "
             f"profiles with entries <= {amax}, length <= {bmax} (and the reversal for C); "
             f"summation by parts on {n_id} pairs, a<=4, b<=6")


# ---------------------------------------------------------------------------
# 7. Arithmetic: closed forms, Corollary 5.1 algebra, Remark 5.3
# ---------------------------------------------------------------------------


def check_arithmetic(chk: Checker) -> None:
    N = 13 if FULL else 8
    cells = 0
    for b in range(1, N + 1):
        A_forms = {}
        for a in range(1, N + 1):
            for x in range(a * b + 1):
                blk = (a_bal_block(a, b, x), a_con_block(a, b, x))
                chk.ok(f"A-profiles: block = bracket = closed, membership {(a, b, x)}",
                       blk == (a_bal_bracket(a, b, x), a_con_bracket(a, b, x))
                       == (a_bal_closed(a, b, x), a_con_closed(a, b, x))
                       and all(is_incr(P, a) and sum(P) == x for P in blk))
                A_forms[a, x] = blk
        C_forms = {}
        for c in range(1, N + 1):
            for y in range(b * c + 1):
                blk = (c_bal_block(c, b, y), c_con_block(c, b, y))
                chk.ok(f"C-profiles: block = bracket = closed, membership {(c, b, y)}",
                       blk == (c_bal_bracket(c, b, y), c_con_bracket(c, b, y))
                       == (c_bal_closed(c, b, y), c_con_closed(c, b, y))
                       and all(is_decr(P, c) and sum(P) == y for P in blk))
                C_forms[c, y] = blk
        for a in range(1, N + 1):
            for c in range(1, N + 1):
                for x in range(a * b + 1):
                    Abal, Acon = A_forms[a, x]
                    Q, R = divmod(x, a)
                    q, r = divmod(x, b)
                    for y in range(b * c + 1):
                        Cbal, Ccon = C_forms[c, y]
                        T, S = divmod(y, c)
                        t, s = divmod(y, b)
                        cells += 1
                        zmax = z_max_formula(a, b, c, x, y)
                        zmin = z_min_formula(a, b, c, x, y)
                        L = c * x + a * y - a * b * c
                        d = min(r * s, (b - r) * (b - s))
                        good = (dot(Abal, Cbal) == zmax and dot(Acon, Ccon) == zmin
                                == z_min_one_expression(a, b, c, x, y)
                                and L == a * c * (Q + T - b) + a * S + c * R
                                and zmin >= L and (zmin == L) == (Q + T >= b)
                                and zmin == max(0, L) + (Q + T == b - 1)
                                * min(R * S, (a - R) * (c - S))
                                and x * y - b * zmax == d and (d == 0) == (r * s == 0)
                                and x * y // b - zmax == d // b <= b // 4
                                and zmin <= zmax)
                        if Q + T == b - 1:
                            good = good and zmin - L == (a - R) * (c - S) >= 1
                        if Q + T <= b - 2:
                            good = good and L <= -(a + c) and zmin == 0
                        if x == a * b:
                            good = good and zmin == zmax == a * y
                        if y == b * c:
                            good = good and zmin == zmax == c * x
                        if b == 1:
                            good = good and zmin == zmax == x * y
                        if not chk.ok(f"arithmetic {(a, b, c, x, y)}", good):
                            return
    chk.note(f"closed forms, dot products, Corollary 5.1 and Remark 5.3 identities: {cells} "
             f"cells, 1<=a,b,c<={N}")

    # Remark 5.3: the defect depends on (b, r, s) only.
    B = 400 if FULL else 100
    for b in range(1, B + 1):
        best = 0
        for r in range(b):
            for s in range(b):
                d = r * s - b * max(0, r + s - b)
                if not chk.ok(f"Remark 5.3 defect {(b, r, s)}",
                              d == min(r * s, (b - r) * (b - s)) and 4 * d <= b * b
                              and d // b <= b // 4):
                    return
                best = max(best, d // b)
        chk.check(f"Remark 5.3: max floor(d/b) = floor(b/4), b={b}", best, b // 4)
        if b >= 2:
            x, y = b // 2, (b + 1) // 2
            chk.check(f"Remark 5.3 witness b={b}", (z_max_formula(1, b, 1, x, y), x * y // b),
                      (0, b // 4))
    P = 200000
    chk.ok("floor(floor(b^2/4)/b) = floor(b/4)",
           all((b * b // 4) // b == b // 4 for b in range(1, P + 1)))
    # The parity computation written out in the note.
    chk.ok("parity computation, even and odd b",
           all((k * k) // (2 * k) == k // 2 == (2 * k) // 4 for k in range(1, P))
           and all((k * (k + 1)) // (2 * k + 1) == k // 2 == (2 * k + 1) // 4
                   and 4 * k < 2 * (2 * k + 1) for k in range(0, P)))
    chk.note(f"Remark 5.3: defect identity and floor bound for every b<={B} and all r,s<b; "
             f"floor(b/4) reached at x=floor(b/2), y=ceil(b/2); parity identity for b<={P}")


# ---------------------------------------------------------------------------
# 8. The examples: Section 4, Example 5.2, Remark 5.3, Example 5.4 (DS06's table)
# ---------------------------------------------------------------------------

# Ding-Salomaa 2006, author PDF p. 12, typed in: w, |w|_a = |w|_c, |w|_b, |w|_ab = |w|_bc,
# |w|_abc, and "the bounds for |w|_abc, resulting by Lemma 3".
DS06_TABLE = {
    1: (3, 2, 5, 12, (12, 12)),
    2: (7, 3, 17, 92, (91, 96)),
    3: (15, 4, 49, 576, (570, 600)),
    4: (31, 5, 129, 3216, (3193, 3328)),
    5: (63, 6, 321, 16704, (16632, 17173)),
}


def alpha_word(i: int) -> tuple:
    """DS06 author PDF p. 11: alpha_i = prod_{j=0}^{i} a^(2^(i-j)) b c^(2^j), with a,b,c = 1,2,3."""
    w: list = []
    for j in range(i + 1):
        w += [1] * 2 ** (i - j) + [2] + [3] * 2 ** j
    return tuple(w)


def incr_with_sum(top: int, b: int, total: int, lo: int = 0):
    """Weakly increasing vectors of length b, entries in [lo, top], with the given sum."""
    if b == 0:
        if total == 0:
            yield ()
        return
    for v in range(lo, top + 1):
        if v * b > total:
            break
        if total - v > (b - 1) * top:
            continue
        for tail in incr_with_sum(top, b - 1, total - v, v):
            yield (v,) + tail


def spread_at_most(top: int, b: int, total: int, D: int) -> list:
    """The vectors of incr_with_sum(top, b, total) with max - min <= D."""
    out = []
    for m in range(top + 1):
        if m * b > total:
            break
        for p in incr_with_sum(min(top, m + D), b, total, m):
            if p[0] == m:
                out.append(p)
    return out


def check_examples(chk: Checker) -> None:
    # Section 4: (a,b,c) = (2,2,2), x = y = 2.
    chk.check("Section 4: Z(2,2) for (2,2,2)", set(word_cells(2, 2, 2)[2, 2]), {0, 2})
    # Remark 5.3 / old note: b = 4, x = y = 2 gives z_max = 0 < floor(xy/b) = 1.
    for a, c in ((1, 1), (2, 2)):
        chk.check(f"Remark 5.3: b=4, x=y=2, content {(a, 4, c)}", max(word_cells(a, 4, c)[2, 2]), 0)

    # Example 5.2: (a,b,c,x,y) = (3,2,3,5,2).
    a, b, c, x, y = 3, 2, 3, 5, 2
    ws = list(words(a, b, c))
    cell = [w for w in ws if counts_incremental(w)[3:5] == (x, y)]
    zdist = Counter(counts_incremental(w)[5] for w in cell)
    pairs = Counter(profile_pair(w) for w in cell)
    chk.check("Example 5.2: number of words", len(ws), 560)
    chk.check("Example 5.2: words with (x,y) = (5,2)", len(cell), 15)
    chk.check("Example 5.2: z distribution", dict(zdist), {4: 9, 5: 6})
    chk.check("Example 5.2: profile pairs and W", dict(pairs),
              {((2, 3), (2, 0)): 9, ((2, 3), (1, 1)): 6})
    chk.check("Example 5.2: A(5), C(2)", ([A for A in incr_profiles(a, b) if sum(A) == x],
              sorted(C for C in decr_profiles(c, b) if sum(C) == y)), ([(2, 3)], [(1, 1), (2, 0)]))
    chk.check("Example 5.2: W values", (gap_weight((2, 3), (2, 0), a, c),
              gap_weight((2, 3), (1, 1), a, c)), (9, 6))
    chk.check("Example 5.2: Q,R,T,S, L, z_min = RS = L+(a-R)(c-S), z_max = xy/b",
              (divmod(x, a), divmod(y, c), lower_bound_L(a, b, c, x, y), min(zdist), max(zdist)),
              ((1, 2), (0, 2), 3, 4, 5))

    # Example 5.4: DS06's table.
    for i, (na, nb, nab, nabc, bounds) in DS06_TABLE.items():
        w = alpha_word(i)
        a, b, c, x, y, z = counts_incremental(w)
        chk.check(f"alpha_{i}: counted from the word = DS06 table row", (a, b, c, x, y, z),
                  (na, nb, na, nab, nab, nabc))
        L = lower_bound_L(a, b, c, x, y)
        chk.check(f"alpha_{i}: printed bounds = (L, floor(xy/b))", (L, x * y // b), bounds)
        # The xy/b column of the note's table: 12.5, 96.33..., 600.25, 3328.2, 17173.5.
        chk.check(f"alpha_{i}: xy/b", Fraction(x * y, b),
                  {1: Fraction(25, 2), 2: Fraction(289, 3), 3: Fraction(2401, 4),
                   4: Fraction(16641, 5), 5: Fraction(103041, 6)}[i])
        Q, T = x // a, y // c
        chk.ok(f"alpha_{i}: Q+T >= b, and b divides neither x nor y",
               Q + T >= b and x % b and y % b)
        zmin, zmax = z_min_formula(a, b, c, x, y), z_max_formula(a, b, c, x, y)
        chk.check(f"alpha_{i}: Proposition values", (zmin, zmax),
                  {1: (12, 12), 2: (91, 96), 3: (570, 600), 4: (3193, 3328),
                   5: (16632, 17172)}[i])
        # Witness words for both extremes, counted letter by letter.
        for name, A, C, want in (("z_min", a_con_block(a, b, x), c_con_block(c, b, y), zmin),
                                 ("z_max", a_bal_block(a, b, x), c_bal_block(c, b, y), zmax)):
            chk.check(f"alpha_{i}: witness word for {name}",
                      counts_incremental(word_from_pair(A, C, a, c)), (a, b, c, x, y, want))
        if i <= 2:
            # Word level: all words of the content (2,333,760 words for alpha_2).
            Z = set(word_cells(a, b, c)[x, y])
            chk.check(f"alpha_{i}: Z(x,y) by words", Z,
                      {1: {12}, 2: {91, 92, 93, 95, 96}}[i])
        if i <= 4:
            # Exhaustive over all profile pairs.
            As = list(incr_with_sum(a, b, x))
            Cs = [p[::-1] for p in incr_with_sum(c, b, y)]
            Z = {dot(A, C) for A in As for C in Cs}
            chk.check(f"alpha_{i}: min and max over all {len(As)}x{len(Cs)} profile pairs",
                      (min(Z), max(Z)), (zmin, zmax))
            if i == 2:
                chk.check("alpha_2: the hole", sorted(set(range(zmin, zmax + 1)) - Z), [94])
    chk.note("Example 5.4: DS06 rows alpha_1..alpha_5 recounted from the words; printed bounds "
             "= (L, floor(xy/b)); witness words for z_min and z_max; Z(17,17) for alpha_2 = "
             "{91,92,93,95,96} by all 2,333,760 words")

    # alpha_5: exact maximum by the search pruned with the defect identity, and every value
    # in between.
    a, b, c, x, y, _ = counts_incremental(alpha_word(5))
    L = lower_bound_L(a, b, c, x, y)
    d_bal = x * y - b * dot(a_bal_block(a, b, x), c_bal_block(c, b, y))
    As_s = spread_at_most(a, b, x, d_bal)
    Cs_s = [p[::-1] for p in spread_at_most(c, b, y, d_bal)]
    # Any pair outside this family has max-min > d_bal in A or in C. Both are nonconstant
    # (b divides neither x nor y), so its defect xy - b A.C >= (A_b-A_1)(C_1-C_b) > d_bal.
    defects = []
    for A in As_s:
        for C in Cs_s:
            dfc = x * y - b * dot(A, C)
            cov = sum((A[m] - A[l]) * (C[l] - C[m]) for l in range(b) for m in range(l + 1, b))
            if not chk.ok(f"alpha_5 defect identity {(A, C)}", dfc == cov):
                return
            defects.append(dfc)
    chk.check("alpha_5: balanced defect, pruned family sizes, minimum defect",
              (d_bal, len(As_s), len(Cs_s), min(defects)), (9, 335, 335, 9))
    chk.check("alpha_5: exact maximum (xy - 9)/b; 17173 is not attained",
              ((x * y - min(defects)) // b, (x * y - min(defects)) % b), (17172, 0))
    As = list(incr_with_sum(a, b, x))
    Cs = [p[::-1] for p in incr_with_sum(c, b, y)]
    chk.check("alpha_5: |A(321)| = |C(321)|", (len(As), len(Cs)), (15944, 15944))
    witness = {}
    for A in As_s:
        for C in Cs_s:
            witness.setdefault(dot(A, C), (A, C))
    in_range = True
    for C in Cs[::997]:
        for A in As:
            z = dot(A, C)
            in_range = in_range and L <= z <= 17172
            witness.setdefault(z, (A, C))
    chk.ok("alpha_5: every value examined lies in [L, 17172]", in_range)
    chk.check("alpha_5: a witness pair for every value in [16632, 17172]",
              sorted(set(range(L, 17173)) - set(witness)), [])
    bad = [z for z, (A, C) in witness.items()
           if counts_incremental(word_from_pair(A, C, a, c)) != (a, b, c, x, y, z)]
    chk.check("alpha_5: each witness word, counted letter by letter", bad, [])
    chk.note(f"alpha_5: pruned search over {len(As_s)}x{len(Cs_s)} pairs gives minimum defect 9, "
             f"so z_max = 17172 < 17173; witness words for all {17172 - L + 1} values "
             f"{L}..17172")


# ---------------------------------------------------------------------------


def main() -> int:
    chk = Checker("R2: exact extrema of |w|_123 given content and both pair counts")
    total = time.perf_counter()
    for part in (check_counters, check_words, check_profile_model, check_profiles,
                 check_transfers, check_summation_by_parts, check_arithmetic, check_examples):
        start = time.perf_counter()
        part(chk)
        chk.note(f"({part.__name__}: {time.perf_counter() - start:.1f} s)")
    chk.note(f"total {time.perf_counter() - total:.1f} s")
    return chk.finish()


if __name__ == "__main__":
    sys.exit(main())
