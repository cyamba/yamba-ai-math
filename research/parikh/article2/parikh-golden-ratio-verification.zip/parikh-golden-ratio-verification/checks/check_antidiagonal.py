"""check_antidiagonal: Theorem D (largest psi_2-fibres) and Proposition D'.

Claims of notes/proof-antidiagonal.md (finalised 20 October 2026), re-typed here; nothing is
imported from notes/ or from the prover's scripts.

Python standard library only; deterministic; exact integer and rational arithmetic (no floats).
Unknown command-line arguments are ignored (run_all.py passes e.g. --max-n); --full selects the
slow ranges shown in brackets below. Exit status is non-zero on any failure. The last line is
"check_antidiagonal: N checks, F failures, T s". A passing run is evidence on the stated finite
ranges (VERIFIED). The theorems themselves are proved in the note; no step of those proofs rests
on this file, except Proposition D', which is a finite computation and is VERIFIED here in full.

Setting
-------
Content (a,b,c), a,b,c >= 1, letters 1 < 2 < 3; x = |w|_12, y = |w|_23, y' = bc - y = |w|_32
(scattered subwords); P(x,y) = #{w : (|w|_12, |w|_23) = (x,y)}; N = (a+b+c)!/(a!b!c!).
Level of a 1 or a 3 = number of 2s to its right; alpha_h, gamma_h = numbers of 1s, 3s of level h.
A_n(v) = level vectors with |alpha| = n and sum h alpha_h = v; f^(n)_v = sum multinom(n;alpha) S^alpha.

Claims tested (note section in brackets)
---------------------------------------
 L1.1  [s1] w -> (alpha,gamma) is onto, x = sum h alpha_h, y' = sum h gamma_h, and the fibre over
       (alpha,gamma) has K = prod_h C(alpha_h+gamma_h, alpha_h) words; hence (1.1).
 Sym   complement P_abc(x,y) = P_cba(bc-y, ab-x); reversal P(x,y) = P(ab-x, bc-y); sum = N;
       P > 0 on the whole box [s2 Remark 3]; the witness of A_n(v) != {} for 0 <= v <= nb.
 L2.2  [s2] E[S^m] = b! prod m_h! / (|m|+b)! for S uniform on the simplex Delta_b.
 L2.3  [s2] K(alpha,gamma) = N multinom(a;alpha) multinom(c;gamma) E[S^(alpha+gamma)].
 D(i)  [s2] P(x,y) = N E[f^(a)_x f^(c)_(bc-y)], evaluated exactly; integral values; sum N.
 D(ii) [s3] a = c: G(u,v) = P(u, ab-v) symmetric and positive definite (exact LDL^T pivots and
       exact leading principal minors); P(x,y)^2 < P(x,ab-x) P(ab-y,y) off x+y = ab, equality on
       it; every maximiser on x+y = ab; max P = max D.
 R3    [s3 Remark 3] (a,1,a): D(x) = C(2x,x) C(2a-2x,a-x), the ratio D(x+1)/D(x), maximisers
       exactly (0,a),(a,0); (1,b,1): D = 2, all b+1 antidiagonal points maximise.
 R4    [s3 Remark 4] a != c: P_abc(x,y)^2 < kappa P_aba(x,ab-x) P_cbc(bc-y,y),
       kappa = N_abc^2/(N_aba N_cbc), strictly, in every cell.
 D(iii)[s4] (2,b,2), l = floor(b/2): closed formula in every cell; n(v) = |A_2(v)|; the
       weight analysis 1/2/3/4/6 term by term; maximum (l+2)(l+3), maximisers exactly (b,b)
       (b even) or (b-1,b+1),(b+1,b-1) (b odd); P(b,b) = (l+1)(l+4) for b odd; the profiles
       D(x) quoted for b = 6, 7; D(2k) - D(2k+1) = 2 for 2k+1 < b.
 Y26a  [s4.4] [Y26a] Thm 2 (3.1)-(3.2) and Thm 6 (5.1), re-typed: fibre totals
       p_a(j)p_c(i) + eps_b(i,j) on i+j <= b, and p_a(j)p_c(i) + 2 + [j=2] + [i=2] on
       i+j = b+1 (a,c,i,j >= 2), with j = ab-x, i = bc-y; checked against the DP for general
       contents, and at a = c = 2 (with reversal images) against the D(iii) formula; the
       overlap has (b+1)(b+2) + 2max(0,b-2) cells, and the rest is the band b+2 <= x+y <= 3b-2
       plus 8 edge cells (3 for b = 1); [Y26a] Table 1 (p. 12) word lists of (2,3,2).
 T4    [s4] the totals of T4 equal P(b,b); T4's z-distribution at (b,b) (own note
       notes/ternary-defect-theorems.md s4) against an (x,y,z) prefix DP and word enumeration.
 D'    [s5] (7,6,7): 484,422 exactly at (20,22),(22,20), centre 484,020; (5,10,5): 111,460
       exactly at (24,26),(26,24), centre 111,322; the centre value is the second-largest value;
       scan: every content with b even, (a,c) != (1,1), total <= 19 (436 contents, 232 with
       a <= c) has the centre as unique maximiser; at total 20 (516 contents in all) exactly
       (7,6,7) and (5,10,5) fail; (1,b,1), b even: b+1 tied maximisers (why (1,1) is excluded).

Methods (independent implementations)
-------------------------------------
 WE   word enumeration; |w|_12, |w|_23 and |w|_123 counted literally from the definition.
 LDP  last-letter (prefix) DP over (#1,#2,#3), bivariate polynomials in (x,y) packed into one
      integer; appending 2 adds #1 to x, appending 3 adds #2 to y. It does not use levels.
 GAP  the gap model (1.1): product over levels h = 0..b, packed integers.
 SYM  symbolic iterated integration of polynomials over the simplex (no Beta function).
 DIR  exact evaluation of N E[f_x f_y'] with the polynomials f obtained by expanding
      (S_0 + ... + S_b)^n and grouping by level sum.
 LDL  exact LDL^T in Fractions; BAR fraction-free (Bareiss) leading principal minors.
 ZDP  prefix DP over (#1,#2,#3) keyed by (x,y), with z = |w|_123 packed (appending 3 adds x).

Sections and ranges, default [--full]
-------------------------------------
 [1] WE = LDP = GAP: total <= 10 [11]; LDP = GAP: total <= 18 [18]; L1.1 per word: total <= 9
     [10]; Sym and positivity: total <= 18 [18].
 [2] L2.2 by SYM: 1 <= b <= 4, |m| <= 6 [b <= 5, |m| <= 7].
 [3] L2.3 pair by pair: a,c <= 3, b <= 4 [a,c <= 4, b <= 5]. D(i) by DIR: = WE for total <= 9
     [10], = LDP for total <= 12 [14].
 [4] D(ii): 2a+b <= 30 [30] (LDP; LDP = GAP for 2a+b <= 20 [30]); LDL for 2a+b <= 14 [20];
     BAR for 2a+b <= 20 [30]; LDL pivots = ratios of BAR minors where both run.
 [5] R3: 1 <= a <= 14, 1 <= b <= 28 (41 distinct contents), both modes.
 [6] R4: every content with a != c and total <= 14 [16].
 [7] D(iii): LDP for 1 <= b <= 60 [120], every cell; term-by-term weights b <= 12 [30];
     WE for b <= 6 [7]; n(v) = |A_2(v)| for b <= 40.
 [8] Y26a: general contents a,c <= 4, b <= 6 [a,c <= 5, b <= 8] (LDP); a = c = 2 for
     b <= 60 [120]; Table 1 by WE.
 [9] T4: ZDP for 1 <= b <= 24 [40]; WE for b <= 6 [8].
 [10] D': both contents by GAP and LDP (all cells); scan by GAP for total <= 20, and also by LDP
     in --full; (1,b,1) for even b <= 28.

Outcome (20 October 2026, Python 3.11.9)
----------------------------------------
No claim failed; no statement was corrected by this check. Default: 109,938 checks, about 6 s.
--full: 767,015 checks, about 64 s. Logs: notes/article2-scripts/proof-antidiagonal/
check_default.log and check_full.log; notes/proof-antidiagonal.md s7 tabulates them.
VERIFIED on these exact ranges (--full):
 [1] LDP = GAP on the 816 contents with total <= 18 (also complement, reversal, sum N, P > 0);
     WE on the 165 contents with total <= 11; Lemma 1.1 on 82,464 words (total <= 10).
 [2] 2,994 moments (b <= 5, |m| <= 7).  [3] 65,419 pairs; D(i) on 364 contents (60,372 fibres).
 [4] 210 contents (a,b,a), 2a+b <= 30: 567,224 strict inequalities, 9,170 equalities, all
     maximisers on x+y = ab, all 9,170 leading minors > 0; LDL^T pivots > 0 for 2a+b <= 20.
 [5] 41 contents.  [6] 130,092 cells of 504 contents, all strict.
 [7] 2,362,040 cells (b <= 120); weights term by term on 1,674,991 pairs (b <= 30).
 [8] [Y26a] Thm 2 on 4,100 and Thm 6 on 336 cells (general contents); 619,282 overlap cells at
     a = c = 2 (b <= 120); Table 1 word for word.  [9] T4 by ZDP (b <= 40) and WE (b <= 8).
 [10] Prop D' exactly as stated; scan 436 / 232 / 516 by GAP and LDP.
Mutation tests (notes/article2-scripts/proof-antidiagonal/mutation_tests.py) confirm that each
section fails when its claim or its method is altered (15 mutations, all caught).
"""

from __future__ import annotations

import sys
import time
from collections import defaultdict
from fractions import Fraction
from itertools import combinations
from math import comb, factorial

FULL = "--full" in sys.argv[1:]
T0 = time.perf_counter()

if FULL:
    WE_T, LG_T, L11_T, SYM_T = 11, 18, 10, 18
    MOM_B, MOM_M = 5, 7
    L23_AC, L23_B, DIR_WE_T, DIR_T = 4, 5, 10, 14
    DII_T, DII_LDP_T, LDL_T, BAR_T = 30, 30, 20, 30
    R4_T = 16
    DIII_B, TERM_B, DIII_WE_B = 120, 30, 7
    Y_AC, Y_B, Y22_B = 5, 8, 120
    T4_B, T4_WE_B = 40, 8
else:
    WE_T, LG_T, L11_T, SYM_T = 10, 18, 9, 18
    MOM_B, MOM_M = 4, 6
    L23_AC, L23_B, DIR_WE_T, DIR_T = 3, 4, 9, 12
    DII_T, DII_LDP_T, LDL_T, BAR_T = 30, 20, 14, 20
    R4_T = 14
    DIII_B, TERM_B, DIII_WE_B = 60, 12, 6
    Y_AC, Y_B, Y22_B = 4, 6, 60
    T4_B, T4_WE_B = 24, 6
R3_A, R3_B = 14, 28
DP_T = 20

FAIL: list[str] = []
NCHECK = [0]


def check(cond: bool, msg: str) -> bool:
    NCHECK[0] += 1
    if not cond:
        FAIL.append(msg)
        if len(FAIL) <= 40:
            print("FAIL:", msg, flush=True)
    return cond


def section(title: str) -> None:
    print(f"[{time.perf_counter() - T0:7.1f} s] {title}", flush=True)


def say(text: str) -> None:
    print("           " + text, flush=True)


# ------------------------------------------------------------------ basics
FACT = [factorial(n) for n in range(200)]


def nwords(a: int, b: int, c: int) -> int:
    return FACT[a + b + c] // (FACT[a] * FACT[b] * FACT[c])


def multinom(n: int, parts) -> int:
    r = FACT[n]
    for k in parts:
        r //= FACT[k]
    return r


def compositions(n: int, k: int):
    """Weak compositions of n into k parts, as tuples."""
    if k == 1:
        yield (n,)
        return
    for first in range(n, -1, -1):
        for rest in compositions(n - first, k - 1):
            yield (first,) + rest


def contents(tmax: int, tmin: int = 3):
    for t in range(tmin, tmax + 1):
        for b in range(1, t - 1):
            for a in range(1, t - b):
                c = t - a - b
                if c >= 1:
                    yield a, b, c


def slot_bits(N: int) -> int:
    return 8 * ((N.bit_length() + 1 + 7) // 8)


def unpack(v: int, B: int, X: int, Y: int):
    """Packed polynomial (index x + X*y, B bits per slot) -> list of lists M[x][y]."""
    nb = B // 8
    raw = v.to_bytes(nb * X * Y, "little")
    M = [[0] * Y for _ in range(X)]
    fb = int.from_bytes
    for y in range(Y):
        base = X * y
        for x in range(X):
            k = (base + x) * nb
            M[x][y] = fb(raw[k:k + nb], "little")
    return M


# ------------------------------------------------------------------ WE: words, by definition
def words(a: int, b: int, c: int):
    n = a + b + c
    idx = range(n)
    for P1 in combinations(idx, a):
        s1 = set(P1)
        rem = [i for i in idx if i not in s1]
        for P2 in combinations(rem, b):
            w = [3] * n
            for i in P1:
                w[i] = 1
            for i in P2:
                w[i] = 2
            yield tuple(w)


def occ2(w, s: int, t: int) -> int:
    """|w|_{st}: pairs i < j with w_i = s and w_j = t (the definition)."""
    n = len(w)
    cnt = 0
    for i in range(n):
        if w[i] == s:
            for j in range(i + 1, n):
                if w[j] == t:
                    cnt += 1
    return cnt


def occ123(w) -> int:
    """|w|_123: triples i < j < k with letters 1, 2, 3 (the definition)."""
    n = len(w)
    cnt = 0
    for i in range(n):
        if w[i] == 1:
            for j in range(i + 1, n):
                if w[j] == 2:
                    for k in range(j + 1, n):
                        if w[k] == 3:
                            cnt += 1
    return cnt


def psi2_we(a: int, b: int, c: int) -> dict:
    d = defaultdict(int)
    for w in words(a, b, c):
        d[(occ2(w, 1, 2), occ2(w, 2, 3))] += 1
    return dict(d)


def as_dict(M) -> dict:
    return {(x, y): v for x, row in enumerate(M) for y, v in enumerate(row) if v}


# ------------------------------------------------------------------ LDP: prefix DP (no levels)
def psi2_ldp(a: int, b: int, c: int):
    N = nwords(a, b, c)
    B = slot_bits(N)
    X, Y = a * b + 1, b * c + 1
    sy = B * X
    cur = [[[0] * (c + 1) for _ in range(b + 1)] for _ in range(a + 1)]
    cur[0][0][0] = 1
    for n1 in range(a + 1):
        for n2 in range(b + 1):
            row = cur[n1][n2]
            for n3 in range(c + 1):
                v = row[n3]
                if not v:
                    continue
                if n1 < a:
                    cur[n1 + 1][n2][n3] += v
                if n2 < b:
                    cur[n1][n2 + 1][n3] += v << (B * n1)
                if n3 < c:
                    row[n3 + 1] += v << (sy * n2)
    return unpack(cur[a][b][c], B, X, Y)


# ------------------------------------------------------------------ GAP: the gap model (1.1)
def psi2_gap(a: int, b: int, c: int):
    N = nwords(a, b, c)
    B = slot_bits(N)
    X, Yp = a * b + 1, b * c + 1
    poly = [[0] * (c + 1) for _ in range(a + 1)]
    poly[0][0] = 1
    for h in range(b + 1):
        new = [[0] * (c + 1) for _ in range(a + 1)]
        for i in range(a + 1):
            for j in range(c + 1):
                v = poly[i][j]
                if not v:
                    continue
                for p in range(a - i + 1):
                    nr = new[i + p]
                    for q in range(c - j + 1):
                        nr[j + q] += comb(p + q, p) * (v << (B * h * (p + X * q)))
        poly = new
    G = unpack(poly[a][c], B, X, Yp)  # G[x][y']
    bc = b * c
    return [[G[x][bc - y] for y in range(bc + 1)] for x in range(X)]


_GAP: dict = {}
_LDP: dict = {}


def gap_cached(a: int, b: int, c: int):
    k = (a, b, c)
    if k not in _GAP:
        _GAP[k] = psi2_gap(a, b, c)
    return _GAP[k]


def ldp_cached(a: int, b: int, c: int):
    k = (a, b, c)
    if k not in _LDP:
        _LDP[k] = psi2_ldp(a, b, c)
    return _LDP[k]


# ------------------------------------------------------------------ levels of a word
def levels(w, b: int):
    """(alpha, gamma): numbers of 1s and 3s with h 2s to their right, h = 0..b."""
    al = [0] * (b + 1)
    ga = [0] * (b + 1)
    twos = 0
    for letter in reversed(w):
        if letter == 2:
            twos += 1
        elif letter == 1:
            al[twos] += 1
        else:
            ga[twos] += 1
    return tuple(al), tuple(ga)


def K_weight(al, ga) -> int:
    r = 1
    for p, q in zip(al, ga):
        r *= comb(p + q, p)
    return r


# ------------------------------------------------------------------ section [1]
def sec1() -> dict:
    section("[1] implementations, Lemma 1.1, symmetries, positivity")
    ldp = {}
    nwe = nwd = 0
    for a, b, c in contents(LG_T):
        L = psi2_ldp(a, b, c)
        Gp = psi2_gap(a, b, c)
        ldp[(a, b, c)] = L
        check(L == Gp, f"[1] LDP != GAP at {(a, b, c)}")
        if a + b + c <= WE_T:
            nwe += 1
            we = psi2_we(a, b, c)
            nwd += len(we)
            check(we == as_dict(L), f"[1] WE != LDP at {(a, b, c)}")
    nlg = len(ldp)
    say(f"LDP = GAP on all {nlg} contents with total <= {LG_T}; "
        f"WE = LDP on all {nwe} contents with total <= {WE_T} ({nwd} nonempty fibres)")

    # Lemma 1.1 per word
    nw = ncont = npairs = 0
    for a, b, c in contents(L11_T):
        ncont += 1
        fib = defaultdict(int)
        for w in words(a, b, c):
            nw += 1
            al, ga = levels(w, b)
            x, y = occ2(w, 1, 2), occ2(w, 2, 3)
            if not (sum(h * k for h, k in enumerate(al)) == x
                    and sum(h * k for h, k in enumerate(ga)) == b * c - y):
                check(False, f"[1] level sums wrong for {w}")
            fib[(al, ga)] += 1
        for al in compositions(a, b + 1):
            for ga in compositions(c, b + 1):
                npairs += 1
                check(fib.get((al, ga), 0) == K_weight(al, ga),
                      f"[1] fibre over {(al, ga)} has {fib.get((al, ga), 0)} words, K = {K_weight(al, ga)}")
        check(len(fib) == comb(a + b, b) * comb(c + b, b), f"[1] w -> (alpha,gamma) not onto at {(a, b, c)}")
    say(f"Lemma 1.1: {nw} words of the {ncont} contents with total <= {L11_T}: x = sum h alpha_h, "
        f"y' = sum h gamma_h per word; all {npairs} pairs (alpha,gamma) occur, each with exactly K words")

    # symmetries, sums, positivity
    ns = 0
    for (a, b, c), P in ldp.items():
        if a + b + c > SYM_T:
            continue
        ns += 1
        ab, bc = a * b, b * c
        Q = ldp[(c, b, a)]
        tot = 0
        ok_c = ok_r = ok_p = True
        for x in range(ab + 1):
            for y in range(bc + 1):
                v = P[x][y]
                tot += v
                if v != Q[bc - y][ab - x]:
                    ok_c = False
                if v != P[ab - x][bc - y]:
                    ok_r = False
                if v <= 0:
                    ok_p = False
        check(ok_c, f"[1] complement symmetry fails at {(a, b, c)}")
        check(ok_r, f"[1] reversal symmetry fails at {(a, b, c)}")
        check(ok_p, f"[1] some fibre is empty at {(a, b, c)}")
        check(tot == nwords(a, b, c), f"[1] sum != N at {(a, b, c)}")
    # the explicit witness of A_n(v) != {} (s2 Remark 3)
    nwit = 0
    for n in range(1, 9):
        for b in range(1, 9):
            for v in range(n * b + 1):
                q, r = divmod(v, b)
                al = [0] * (b + 1)
                al[b] += q
                al[r] += 1 if r else 0
                al[0] += n - sum(al)
                nwit += 1
                check(al[0] >= 0 and sum(al) == n and sum(h * k for h, k in enumerate(al)) == v,
                      f"[1] witness of A_{n}({v}) fails for b = {b}")
    say(f"complement and reversal symmetry, sum = N, P > 0 on the whole box: all {ns} contents with "
        f"total <= {SYM_T}; witness of A_n(v) != {{}} for n, b <= 8, all 0 <= v <= nb ({nwit} cases)")
    return ldp


# ------------------------------------------------------------------ section [2]: Lemma 2.2
_POW: dict = {}


def one_minus_sum_power(n: int, nv: int) -> dict:
    """(1 - s_0 - ... - s_{nv-1})^n as {exponent tuple: integer coefficient}, by repeated product."""
    key = (n, nv)
    if key in _POW:
        return _POW[key]
    poly = {(0,) * nv: 1}
    for _ in range(n):
        new = defaultdict(int)
        for e, cf in poly.items():
            new[e] += cf
            for t in range(nv):
                e2 = list(e)
                e2[t] += 1
                new[tuple(e2)] -= cf
        poly = {e: cf for e, cf in new.items() if cf}
    _POW[key] = poly
    return poly


def moment_symbolic(m) -> Fraction:
    """E[S^m] = b! * integral over T_b, integrating s_0, s_1, ... in turn as polynomials."""
    b = len(m) - 1
    poly = {}
    for e, cf in one_minus_sum_power(m[b], b).items():
        e2 = tuple(e[h] + m[h] for h in range(b))
        poly[e2] = poly.get(e2, 0) + Fraction(cf)
    for v in range(b):
        nrest = b - v - 1
        new: dict = {}
        for e, cf in poly.items():
            k, rest = e[0], e[1:]
            for e3, cf3 in one_minus_sum_power(k + 1, nrest).items():
                key = tuple(rest[t] + e3[t] for t in range(nrest))
                new[key] = new.get(key, 0) + cf * cf3 / (k + 1)
        poly = new
    return FACT[b] * poly.get((), Fraction(0))


def moment_closed(m) -> Fraction:
    b = len(m) - 1
    num = FACT[b]
    for k in m:
        num *= FACT[k]
    return Fraction(num, FACT[sum(m) + b])


def sec2() -> None:
    section("[2] Lemma 2.2 (Dirichlet moments) by symbolic iterated integration")
    n = 0
    for b in range(1, MOM_B + 1):
        for tot in range(MOM_M + 1):
            for m in compositions(tot, b + 1):
                n += 1
                check(moment_symbolic(m) == moment_closed(m), f"[2] moment mismatch at m = {m}")
    say(f"E[S^m] = b! prod m_h!/(|m|+b)! for all {n} moments with 1 <= b <= {MOM_B}, |m| <= {MOM_M} "
        f"(m = 0 gives vol T_b = 1/b!)")


# ------------------------------------------------------------------ section [3]: L2.3 and D(i)
_FPOL: dict = {}


def level_polys(n: int, b: int) -> dict:
    """{v: {alpha: coeff}}: f^(n)_v, from the expansion of (S_0 + ... + S_b)^n grouped by level sum."""
    key = (n, b)
    if key in _FPOL:
        return _FPOL[key]
    poly = {(0,) * (b + 1): 1}
    for _ in range(n):
        new = defaultdict(int)
        for al, cf in poly.items():
            for h in range(b + 1):
                al2 = list(al)
                al2[h] += 1
                new[tuple(al2)] += cf
        poly = new
    f: dict = defaultdict(dict)
    for al, cf in poly.items():
        f[sum(h * k for h, k in enumerate(al))][al] = cf
    _FPOL[key] = dict(f)
    return _FPOL[key]


def psi2_dirichlet(a: int, b: int, c: int) -> dict:
    """D(i): N E[f^(a)_x f^(c)_(bc-y)] exactly. Every moment has |m| = a + c, so
    E[S^m] = b! prod m_h!/(a+b+c)! and N E[...] = (N b!/(a+b+c)!) * sum cf cf prod (alpha_h+gamma_h)!."""
    N = nwords(a, b, c)
    scale = Fraction(N * FACT[b], FACT[a + b + c])
    fa, fc = level_polys(a, b), level_polys(c, b)
    out = {}
    for x, fx in fa.items():
        for yp, fy in fc.items():
            s = 0
            for al, ca in fx.items():
                for ga, cg in fy.items():
                    pr = ca * cg
                    for p, q in zip(al, ga):
                        pr *= FACT[p + q]
                    s += pr
            out[(x, b * c - yp)] = scale * s
    return out


def sec3(ldp: dict) -> None:
    section("[3] Lemma 2.3 pair by pair; Theorem D(i) evaluated exactly")
    npair = 0
    for b in range(1, L23_B + 1):
        for a in range(1, L23_AC + 1):
            for c in range(1, L23_AC + 1):
                N = nwords(a, b, c)
                for al in compositions(a, b + 1):
                    for ga in compositions(c, b + 1):
                        npair += 1
                        m = tuple(p + q for p, q in zip(al, ga))
                        rhs = N * multinom(a, al) * multinom(c, ga) * moment_closed(m)
                        check(rhs == K_weight(al, ga), f"[3] Lemma 2.3 fails at {(al, ga)}")
    say(f"Lemma 2.3: {npair} pairs (a,c <= {L23_AC}, b <= {L23_B}) satisfy K = N multinom multinom E[S^(alpha+gamma)]")
    ncont = nfib = nwe = 0
    for a, b, c in contents(DIR_T):
        D = psi2_dirichlet(a, b, c)
        ncont += 1
        P = ldp[(a, b, c)] if (a, b, c) in ldp else psi2_ldp(a, b, c)
        ok = all(v.denominator == 1 for v in D.values()) and sum(D.values()) == nwords(a, b, c)
        check(ok, f"[3] D(i) values not integral or sum != N at {(a, b, c)}")
        Dint = {k: int(v) for k, v in D.items() if v}
        nfib += len(Dint)
        check(Dint == as_dict(P), f"[3] D(i) != LDP at {(a, b, c)}")
        check(len(D) == (a * b + 1) * (b * c + 1), f"[3] D(i) does not cover the box at {(a, b, c)}")
        if a + b + c <= DIR_WE_T:
            nwe += 1
            check(Dint == psi2_we(a, b, c), f"[3] D(i) != WE at {(a, b, c)}")
    say(f"D(i): exact value = LDP on all {ncont} contents with total <= {DIR_T} ({nfib} nonempty fibres, "
        f"all integral, sum N); = WE on all {nwe} contents with total <= {DIR_WE_T}")


# ------------------------------------------------------------------ section [4]: D(ii)
def ldl_pivots(M) -> list:
    """Exact LDL^T (Gaussian elimination without pivoting) in Fractions; returns the pivots d_k,
    stopping at the first pivot <= 0."""
    n = len(M)
    A = [[Fraction(v) for v in row] for row in M]
    piv = []
    for k in range(n):
        d = A[k][k]
        piv.append(d)
        if d <= 0:
            break
        Ak = A[k]
        for i in range(k + 1, n):
            Ai = A[i]
            l = Ai[k] / d
            if l:
                for j in range(k + 1, n):
                    Ai[j] -= l * Ak[j]
    return piv


def bareiss_minors(M) -> list:
    """Leading principal minors by fraction-free elimination (stops at the first zero)."""
    A = [list(r) for r in M]
    n = len(A)
    prev = 1
    out = []
    for k in range(n):
        piv = A[k][k]
        out.append(piv)
        if piv == 0:
            break
        Ak = A[k]
        for i in range(k + 1, n):
            Ai = A[i]
            aik = Ai[k]
            for j in range(k + 1, n):
                Ai[j] = (Ai[j] * piv - aik * Ak[j]) // prev
        prev = piv
    return out


def sec4() -> None:
    section("[4] Theorem D(ii): contents (a,b,a)")
    ncont = ncmp = neq = nldl = nbar = nmin = nlp = 0
    for a in range(1, DII_T // 2 + 1):
        for b in range(1, DII_T - 2 * a + 1):
            P = ldp_cached(a, b, a)
            ab = a * b
            ncont += 1
            if 2 * a + b <= DII_LDP_T:
                nlp += 1
                check(P == gap_cached(a, b, a), f"[4] LDP != GAP at {(a, b, a)}")
            G = [[P[u][ab - v] for v in range(ab + 1)] for u in range(ab + 1)]
            check(all(G[u][v] == G[v][u] for u in range(ab + 1) for v in range(u)),
                  f"[4] G not symmetric at {(a, b, a)}")
            D = [P[x][ab - x] for x in range(ab + 1)]
            ok = True
            for x in range(ab + 1):
                Px, dx = P[x], D[x]
                for y in range(ab + 1):
                    lhs = Px[y] * Px[y]
                    rhs = dx * P[ab - y][y]
                    if x + y == ab:
                        neq += 1
                        ok &= lhs == rhs
                    else:
                        ncmp += 1
                        ok &= lhs < rhs
            check(ok, f"[4] inequality (b) fails at {(a, b, a)}")
            M = max(max(r) for r in P)
            arg = [(x, y) for x in range(ab + 1) for y in range(ab + 1) if P[x][y] == M]
            check(all(x + y == ab for x, y in arg) and M == max(D), f"[4] maximiser off x+y = ab at {(a, b, a)}")
            if 2 * a + b <= BAR_T:
                mins = bareiss_minors(G)
                nbar += 1
                nmin += len(mins)
                check(len(mins) == ab + 1 and all(d > 0 for d in mins), f"[4] G not positive definite at {(a, b, a)}")
                if 2 * a + b <= LDL_T:
                    piv = ldl_pivots(G)
                    nldl += 1
                    check(len(piv) == ab + 1 and all(d > 0 for d in piv), f"[4] LDL^T pivot <= 0 at {(a, b, a)}")
                    ratios = [Fraction(mins[0])] + [Fraction(mins[k], mins[k - 1]) for k in range(1, len(mins))]
                    check(piv == ratios, f"[4] LDL^T pivots != ratios of leading minors at {(a, b, a)}")
    say(f"{ncont} contents (a,b,a) with 2a+b <= {DII_T}: G symmetric; {ncmp} strict inequalities "
        f"P(x,y)^2 < P(x,ab-x)P(ab-y,y) off x+y = ab and {neq} equalities on it; every maximiser on x+y = ab")
    say(f"positive definite: exact LDL^T pivots > 0 on {nldl} contents (2a+b <= {LDL_T}); all {nmin} "
        f"leading principal minors > 0 on {nbar} contents (2a+b <= {BAR_T}); GAP = LDP on {nlp} contents")


# ------------------------------------------------------------------ section [5]: s3 Remark 3
def sec5() -> None:
    section("[5] s3 Remark 3: (a,1,a) and (1,b,1)")
    seen = set()
    for a in range(1, R3_A + 1):
        seen.add((a, 1, a))
        P = gap_cached(a, 1, a)
        D = [P[x][a - x] for x in range(a + 1)]
        check(D == [comb(2 * x, x) * comb(2 * (a - x), a - x) for x in range(a + 1)], f"[5] D formula fails, a = {a}")
        for x in range(a):
            check(Fraction(D[x + 1], D[x]) == Fraction((2 * x + 1) * (a - x), (x + 1) * (2 * a - 2 * x - 1)),
                  f"[5] ratio formula fails, a = {a}, x = {x}")
        M = max(max(r) for r in P)
        arg = sorted((x, y) for x in range(a + 1) for y in range(a + 1) if P[x][y] == M)
        check(arg == sorted({(0, a), (a, 0)}) and M == comb(2 * a, a), f"[5] (a,1,a) maximisers wrong, a = {a}")
    for b in range(1, R3_B + 1):
        seen.add((1, b, 1))
        P = gap_cached(1, b, 1)
        check([P[x][b - x] for x in range(b + 1)] == [2] * (b + 1), f"[5] (1,b,1): D != 2, b = {b}")
        M = max(max(r) for r in P)
        arg = sorted((x, y) for x in range(b + 1) for y in range(b + 1) if P[x][y] == M)
        check(arg == [(x, b - x) for x in range(b + 1)], f"[5] (1,b,1) maximiser set wrong, b = {b}")
    check(len(seen) == R3_A + R3_B - 1, "[5] count of distinct contents")
    say(f"(a,1,a), 1 <= a <= {R3_A}: D(x) = C(2x,x)C(2a-2x,a-x), ratio (2x+1)(a-x)/((x+1)(2a-2x-1)), "
        f"maximisers exactly (0,a),(a,0) with value C(2a,a); (1,b,1), 1 <= b <= {R3_B}: D = 2 and all b+1 "
        f"antidiagonal points maximise; {len(seen)} distinct contents")


# ------------------------------------------------------------------ section [6]: s3 Remark 4
def sec6() -> None:
    section("[6] s3 Remark 4: the cross-content bound, strict")
    nc = ncell = 0
    for a, b, c in contents(R4_T):
        if a == c:
            continue
        nc += 1
        P, Pa, Pc = gap_cached(a, b, c), gap_cached(a, b, a), gap_cached(c, b, c)
        Nabc, Naba, Ncbc = nwords(a, b, c), nwords(a, b, a), nwords(c, b, c)
        ab, bc = a * b, b * c
        ok = True
        for x in range(ab + 1):
            dx = Pa[x][ab - x]
            for y in range(bc + 1):
                ncell += 1
                ok &= P[x][y] ** 2 * Naba * Ncbc < Nabc ** 2 * dx * Pc[bc - y][y]
        check(ok, f"[6] cross-content bound not strict at {(a, b, c)}")
    say(f"strict in all {ncell} cells of the {nc} contents with a != c and total <= {R4_T}")


# ------------------------------------------------------------------ section [7]: D(iii)
def n2(v: int, b: int) -> int:
    return v // 2 - max(0, v - b) + 1


def closed_2b2(b: int, x: int, y: int) -> int:
    """Theorem D(iii), re-typed: y' = 2b - y, H = [max(0,x-b,y'-b), min(b,x,y')]."""
    yp = 2 * b - y
    if x == yp:
        n = n2(x, b)
        return n * n + 3 * n + (2 if x % 2 == 0 else 0)
    lo, hi = max(0, x - b, yp - b), min(b, x, yp)
    H = max(0, hi - lo + 1)
    ex = 1 if (x % 2 == 0 and lo <= x // 2 <= hi) else 0
    ey = 1 if (yp % 2 == 0 and lo <= yp // 2 <= hi) else 0
    return n2(x, b) * n2(yp, b) + H + ex + ey


def A2(v: int, b: int) -> list:
    """A_2(v) as level vectors, by enumeration of all pairs of levels."""
    out = set()
    for i in range(b + 1):
        for j in range(i, b + 1):
            if i + j == v:
                al = [0] * (b + 1)
                al[i] += 1
                al[j] += 1
                out.add(tuple(al))
    return sorted(out)


def sec7() -> dict:
    section("[7] Theorem D(iii): content (2,b,2)")
    arrays = {}
    ncell = 0
    for b in range(1, DIII_B + 1):
        P = psi2_ldp(2, b, 2)
        arrays[b] = P
        ok = True
        tot = 0
        for x in range(2 * b + 1):
            for y in range(2 * b + 1):
                ncell += 1
                v = closed_2b2(b, x, y)
                tot += v
                ok &= v == P[x][y]
        check(ok, f"[7] closed formula != LDP for b = {b}")
        check(tot == nwords(2, b, 2), f"[7] closed values do not sum to N, b = {b}")
        l = b // 2
        M = max(max(r) for r in P)
        arg = sorted((x, y) for x in range(2 * b + 1) for y in range(2 * b + 1) if P[x][y] == M)
        want = [(b, b)] if b % 2 == 0 else [(b - 1, b + 1), (b + 1, b - 1)]
        check(M == (l + 2) * (l + 3) and arg == want, f"[7] maximum or maximisers wrong, b = {b}")
        if b % 2:
            check(P[b][b] == (l + 1) * (l + 4), f"[7] P(b,b) != (l+1)(l+4), b = {b}")
        D = [P[x][2 * b - x] for x in range(2 * b + 1)]
        check(all(D[2 * k] - D[2 * k + 1] == 2 for k in range(b) if 2 * k + 1 < b),
              f"[7] D(2k) - D(2k+1) != 2 below b, b = {b}")
        if b <= 40:
            check(all(len(A2(v, b)) == n2(v, b) and ((v % 2 == 0) == any(max(al) == 2 for al in A2(v, b)))
                      for v in range(2 * b + 1)), f"[7] n(v) != |A_2(v)| or square rule, b = {b}")
        if b <= DIII_WE_B:
            check(as_dict(P) == psi2_we(2, b, 2), f"[7] LDP != WE for b = {b}")
    say(f"closed formula = LDP in all {ncell} cells, 1 <= b <= {DIII_B} (values sum to N); LDP = WE for b <= {DIII_WE_B}")
    say(f"maximum (l+2)(l+3), maximisers exactly (b,b) [b even] / (b-1,b+1),(b+1,b-1) [b odd], "
        f"P(b,b) = (l+1)(l+4) [b odd], D(2k) - D(2k+1) = 2 for 2k+1 < b: all b <= {DIII_B}; "
        f"n(v) = |A_2(v)| and the square rule for b <= {min(DIII_B, 40)}")
    want6 = [6, 4, 12, 10, 20, 18, 30, 18, 20, 10, 12, 4, 6]
    want7 = [6, 4, 12, 10, 20, 18, 30, 28, 30, 18, 20, 10, 12, 4, 6]
    check([arrays[6][x][12 - x] for x in range(13)] == want6, "[7] (2,6,2) profile")
    check([arrays[7][x][14 - x] for x in range(15)] == want7, "[7] (2,7,2) profile")
    say("the quoted profiles D(x) of (2,6,2) and (2,7,2) agree")
    # term by term: the weight analysis of the proof
    npair = 0
    for b in range(1, TERM_B + 1):
        AA = {v: A2(v, b) for v in range(2 * b + 1)}
        for x in range(2 * b + 1):
            for yp in range(2 * b + 1):
                Ks = defaultdict(int)
                for al in AA[x]:
                    for ga in AA[yp]:
                        npair += 1
                        Ks[K_weight(al, ga)] += 1
                n = n2(x, b)
                if x == yp:
                    ev = 1 if x % 2 == 0 else 0
                    want = {1: n * n - n, 4: n - ev, 6: ev}
                else:
                    lo, hi = max(0, x - b, yp - b), min(b, x, yp)
                    H = max(0, hi - lo + 1)
                    e3 = (1 if (x % 2 == 0 and lo <= x // 2 <= hi) else 0) + \
                         (1 if (yp % 2 == 0 and lo <= yp // 2 <= hi) else 0)
                    want = {1: n * n2(yp, b) - H, 2: H - e3, 3: e3}
                check({k: v for k, v in Ks.items() if v} == {k: v for k, v in want.items() if v},
                      f"[7] weight analysis fails at b = {b}, (x,y') = {(x, yp)}: {dict(Ks)}")
    say(f"weight analysis (K = 1/2/3/4/6 counts as in the proof) term by term: {npair} pairs, b <= {TERM_B}")
    return arrays


# ------------------------------------------------------------------ section [8]: [Y26a] overlap
def partitions_at_most(r: int, nmax: int) -> list:
    """p_r(n) for n = 0..nmax: partitions of n into at most r parts (= parts of size <= r)."""
    p = [1] + [0] * nmax
    for part in range(1, r + 1):
        for k in range(part, nmax + 1):
            p[k] += p[k - part]
    return p


def y26a_thm2(a: int, b: int, c: int, i: int, j: int, pa, pc) -> int:
    if i + j < b:
        eps = 0
    elif i > 0 and j > 0:
        eps = 1
    elif j == 0:
        eps = a
    else:
        eps = c
    return pa[j] * pc[i] + eps


def y26a_thm6(i: int, j: int, pa, pc) -> int:
    return pa[j] * pc[i] + 2 + (1 if j == 2 else 0) + (1 if i == 2 else 0)


def sec8(arrays: dict) -> None:
    section("[8] overlap with [Y26a] Thms 2 and 6, Table 1")
    n2c = n6c = ncont = 0
    for a in range(1, Y_AC + 1):
        for c in range(1, Y_AC + 1):
            for b in range(1, Y_B + 1):
                ncont += 1
                P = psi2_ldp(a, b, c)
                pa, pc = partitions_at_most(a, b + 2), partitions_at_most(c, b + 2)
                ab, bc = a * b, b * c
                for i in range(b + 1):
                    for j in range(b + 1 - i):
                        n2c += 1
                        check(P[ab - j][bc - i] == y26a_thm2(a, b, c, i, j, pa, pc),
                              f"[8] [Y26a] Thm 2 total != DP at {(a, b, c)}, (i,j) = {(i, j)}")
                if a >= 2 and c >= 2:
                    for i in range(2, b):
                        j = b + 1 - i
                        if j >= 2:
                            n6c += 1
                            check(P[ab - j][bc - i] == y26a_thm6(i, j, pa, pc),
                                  f"[8] [Y26a] Thm 6 total != DP at {(a, b, c)}, (i,j) = {(i, j)}")
    say(f"re-typed [Y26a] totals = DP: Thm 2 on {n2c} chamber cells, Thm 6 on {n6c} layer cells "
        f"({ncont} contents, a,c <= {Y_AC}, b <= {Y_B})")
    ncell = 0
    for b in range(1, Y22_B + 1):
        p2 = partitions_at_most(2, b + 2)
        check(all(p2[n] == n // 2 + 1 for n in range(b + 3)), "[8] p_2(n) != floor(n/2) + 1")
        cells = set()
        for i in range(b + 1):
            for j in range(b + 1 - i):
                x, y = 2 * b - j, 2 * b - i
                val = y26a_thm2(2, b, 2, i, j, p2, p2)
                for (u, v) in ((x, y), (2 * b - x, 2 * b - y)):
                    cells.add((u, v))
                    check(closed_2b2(b, u, v) == val, f"[8] D(iii) != [Y26a] Thm 2 at b = {b}, {(u, v)}")
        for i in range(2, b):
            j = b + 1 - i
            if j >= 2:
                x, y = 2 * b - j, 2 * b - i
                val = y26a_thm6(i, j, p2, p2)
                for (u, v) in ((x, y), (2 * b - x, 2 * b - y)):
                    cells.add((u, v))
                    check(closed_2b2(b, u, v) == val, f"[8] D(iii) != [Y26a] Thm 6 at b = {b}, {(u, v)}")
        if b in arrays:
            P = arrays[b]
            check(all(P[u][v] == closed_2b2(b, u, v) for (u, v) in cells), f"[8] overlap cells vs LDP, b = {b}")
        check(len(cells) == (b + 1) * (b + 2) + 2 * max(0, b - 2), f"[8] overlap cell count wrong, b = {b}")
        if b == 6:
            check(len(cells) == 64, "[8] 64 overlap cells at b = 6")
        ncell += len(cells)
        # the cells NOT covered (note s4.4): the band b+2 <= x+y <= 3b-2, plus, for b >= 2, the
        # 4 cells of x+y = 3b-1 with x or y >= 2b-1 and their 4 reversal images; for b = 1, x+y = 2
        box = {(x, y) for x in range(2 * b + 1) for y in range(2 * b + 1)}
        unc = box - cells
        band = {(x, y) for (x, y) in unc if b + 2 <= x + y <= 3 * b - 2}
        if b >= 2:
            edge = {(x, y) for (x, y) in box if x + y == 3 * b - 1 and (x >= 2 * b - 1 or y >= 2 * b - 1)}
            edge |= {(2 * b - x, 2 * b - y) for (x, y) in edge}
            ok = len(edge) == 8 and unc - band == edge
        else:
            ok = unc - band == {(0, 2), (1, 1), (2, 0)}
        check(ok and all(b + 2 <= x + y <= 3 * b - 2 for (x, y) in band)
              and band == {(x, y) for (x, y) in box if b + 2 <= x + y <= 3 * b - 2},
              f"[8] description of the uncovered cells fails, b = {b}")
    say(f"at a = c = 2: D(iii) = [Y26a] Thm 2 on x+y >= 3b, Thm 6 on x+y = 3b-1 (x,y <= 2b-2), and on the "
        f"reversal images; {ncell} cells for 1 <= b <= {Y22_B}; (b+1)(b+2) + 2max(0,b-2) cells per b "
        f"(64 of 169 at b = 6); the uncovered cells are exactly the band b+2 <= x+y <= 3b-2 and 8 edge "
        f"cells (3 for b = 1)")
    # Table 1 of [Y26a] (p. 12): complete fibres of (2,3,2)
    table1 = {
        (5, 5): {8: {"1212323"}},
        (5, 4): {6: {"1212332", "1213223", "1231223"}},
        (4, 4): {4: {"1221332", "1223132", "1223312", "2112332", "2113223", "2131223", "2311223"},
                 5: {"1232123"}},
    }
    got: dict = {k: defaultdict(set) for k in table1}
    for w in words(2, 3, 2):
        key = (occ2(w, 1, 2), occ2(w, 2, 3))
        if key in got:
            got[key][occ123(w)].add("".join(map(str, w)))
    for key, want in table1.items():
        check(dict(got[key]) == want, f"[8] [Y26a] Table 1 fibre at (x,y) = {key}: {dict(got[key])}")
        check(sum(len(s) for s in want.values()) == closed_2b2(3, *key), f"[8] Table 1 total vs D(iii) at {key}")
    say("[Y26a] Table 1 (p. 12): the complete (2,3,2) fibres at (x,y) = (5,5), (5,4), (4,4) agree word for word "
        "with WE, with totals 1, 3, 8 = D(iii); the three words of Fig. 1 (p. 4) are the (5,4) fibre")


# ------------------------------------------------------------------ section [9]: T4
def fibre_z(a: int, b: int, c: int, x0: int, y0: int) -> dict:
    """{z: count} on the psi_2-fibre (x0,y0): prefix DP keyed by (x,y) (pruned at x0, y0), with the
    z-polynomial packed; appending 1 changes nothing, 2 adds #1 to x, 3 adds #2 to y and x to z."""
    N = nwords(a, b, c)
    B = slot_bits(N)
    zmax = x0 * c
    cur = [[[None] * (c + 1) for _ in range(b + 1)] for _ in range(a + 1)]
    cur[0][0][0] = {(0, 0): 1}

    def add(d, key, v):
        d[key] = d.get(key, 0) + v

    for n1 in range(a + 1):
        for n2 in range(b + 1):
            for n3 in range(c + 1):
                d = cur[n1][n2][n3]
                if not d:
                    continue
                if n1 < a:
                    t = cur[n1 + 1][n2][n3]
                    if t is None:
                        t = cur[n1 + 1][n2][n3] = {}
                    for key, v in d.items():
                        add(t, key, v)
                if n2 < b:
                    t = cur[n1][n2 + 1][n3]
                    if t is None:
                        t = cur[n1][n2 + 1][n3] = {}
                    for (x, y), v in d.items():
                        if x + n1 <= x0:
                            add(t, (x + n1, y), v)
                if n3 < c:
                    t = cur[n1][n2][n3 + 1]
                    if t is None:
                        t = cur[n1][n2][n3 + 1] = {}
                    for (x, y), v in d.items():
                        if y + n2 <= y0:
                            add(t, (x, y + n2), v << (B * x))
    v = (cur[a][b][c] or {}).get((x0, y0), 0)
    row = unpack(v, B, zmax + 1, 1)
    return {z: row[z][0] for z in range(zmax + 1) if row[z][0]}


def t4_distribution(b: int) -> dict:
    l = b // 2
    d = {b: 2 * l + 4}
    for r in range(1, l + 1):
        d[b - 2 * r] = 2 * (l - r) + 4 + (2 if (b % 2 == 0 and r == l) else 0)
    return d


def sec9(arrays: dict) -> None:
    section("[9] T4 (own note): totals and z-distribution at (b,b) for (2,b,2)")
    for b in range(1, DIII_B + 1):
        l = b // 2
        total = (l + 2) * (l + 3) if b % 2 == 0 else (l + 1) * (l + 4)
        check(arrays[b][b][b] == total == sum(t4_distribution(b).values()), f"[9] T4 total, b = {b}")
    for b in range(1, T4_B + 1):
        check(fibre_z(2, b, 2, b, b) == t4_distribution(b), f"[9] T4 z-distribution != ZDP, b = {b}")
    for b in range(1, T4_WE_B + 1):
        d = defaultdict(int)
        for w in words(2, b, 2):
            if occ2(w, 1, 2) == b and occ2(w, 2, 3) == b:
                d[occ123(w)] += 1
        check(dict(d) == t4_distribution(b), f"[9] T4 z-distribution != WE, b = {b}")
    say(f"P(b,b) = T4's totals for b <= {DIII_B}; T4's z-distribution = ZDP for b <= {T4_B} and = WE for "
        f"b <= {T4_WE_B} (b = 6: z = 6,4,2,0 with 10,8,6,6; b = 7: z = 7,5,3,1 with 10,8,6,4)")
    check(t4_distribution(6) == {6: 10, 4: 8, 2: 6, 0: 6} and t4_distribution(7) == {7: 10, 5: 8, 3: 6, 1: 4},
          "[9] the quoted T4 examples")


# ------------------------------------------------------------------ section [10]: Prop D'
def sec10() -> None:
    section("[10] Proposition D'")
    quoted = {
        (7, 6, 7): (133024320, 484422, [(20, 22), (22, 20)], (21, 21), 484020),
        (5, 10, 5): (46558512, 111460, [(24, 26), (26, 24)], (25, 25), 111322),
    }
    for abc, (N, M, arg, cen, cval) in quoted.items():
        G = psi2_gap(*abc)
        L = psi2_ldp(*abc)
        check(G == L, f"[10] GAP != LDP at {abc}")
        mx = max(max(r) for r in G)
        am = sorted((x, y) for x, r in enumerate(G) for y, v in enumerate(r) if v == mx)
        vals = sorted({v for r in G for v in r}, reverse=True)
        check(nwords(*abc) == N and mx == M and am == arg and G[cen[0]][cen[1]] == cval,
              f"[10] values at {abc}: max {mx} at {am}, centre {G[cen[0]][cen[1]]}")
        check(vals[1] == cval, f"[10] centre value is not the second-largest value at {abc}")
        check(all(x + y == abc[0] * abc[1] for x, y in am), f"[10] counterexample off the antidiagonal at {abc}")
        say(f"{abc}: N = {N}; GAP = LDP on all cells; max {mx} exactly at {am}; centre {cen} = {cval}, "
            f"the second-largest value")
    n19 = n19le = n20 = 0
    bad = []
    nldp = 0
    for t in range(4, DP_T + 1):
        for b in range(2, t - 1, 2):
            for a in range(1, t - b):
                c = t - a - b
                if c < 1 or (a, c) == (1, 1):
                    continue
                P = gap_cached(a, b, c)
                if FULL:
                    nldp += 1
                    check(P == psi2_ldp(a, b, c), f"[10] scan: GAP != LDP at {(a, b, c)}")
                n20 += 1
                if t <= 19:
                    n19 += 1
                    if a <= c:
                        n19le += 1
                mx = max(max(r) for r in P)
                am = [(x, y) for x, r in enumerate(P) for y, v in enumerate(r) if v == mx]
                if am != [(a * b // 2, b * c // 2)]:
                    bad.append((a, b, c))
    check((n19, n19le, n20) == (436, 232, 516), f"[10] scan counts {(n19, n19le, n20)}")
    check(sorted(bad) == [(5, 10, 5), (7, 6, 7)], f"[10] scan failures {bad}")
    say(f"scan, b even, (a,c) != (1,1): {n19} contents with total <= 19 ({n19le} with a <= c), centre the unique "
        f"maximiser in each; {n20} with total <= 20; failures exactly {sorted(bad)}"
        + (f"; GAP = LDP on all {nldp}" if FULL else ""))
    nt = 0
    for b in range(2, R3_B + 1, 2):
        P = gap_cached(1, b, 1)
        mx = max(max(r) for r in P)
        nt += 1
        check(sum(1 for r in P for v in r if v == mx) == b + 1 and P[b // 2][b // 2] == mx,
              f"[10] (1,b,1) ties, b = {b}")
    say(f"(1,b,1), b even <= {R3_B}: the centre ties with all b+1 antidiagonal points ({nt} contents), "
        f"so the exclusion (a,c) != (1,1) is needed")


def main() -> int:
    print("== check_antidiagonal: Theorem D and Proposition D' (notes/proof-antidiagonal.md)"
          + ("  [--full]" if FULL else ""), flush=True)
    ldp = sec1()
    sec2()
    sec3(ldp)
    sec4()
    sec5()
    sec6()
    arrays = sec7()
    sec8(arrays)
    sec9(arrays)
    sec10()
    dt = time.perf_counter() - T0
    status = "PASS" if not FAIL else "FAIL"
    print(f"check_antidiagonal: {NCHECK[0]} checks, {len(FAIL)} failures, {dt:.1f} s  [{status}]", flush=True)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
