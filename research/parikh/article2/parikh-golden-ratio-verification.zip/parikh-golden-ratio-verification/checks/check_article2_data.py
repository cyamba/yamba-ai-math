"""check_article2_data: the data ports of Article 2 (design Phase 2d).

notes/article2-numbers.md lists every number that Article 2 (notes/article2-design.md) will
quote, where it appears in the plan, its label, and the check that recomputes it.  Most numbers
are recomputed by the theorem checks (check_rigidity, check_top_gap, check_antidiagonal,
check_lr_sandwich, check_r2_extrema, check_r7_golden, check_r7_switch, check_h1_centre,
check_2b2, ...).  This file recomputes the rest: the exploration and certification numbers that
were so far only in notes/r7-scripts/ logs or in no check at all, the scoreboard and P8
sequences as literal values, and the data behind the planned figures; and, as a second method,
the headline numbers of the Phase 2 notes proof-h1-centre.md and proof-2b2.md.  Nothing is
imported from notes/ and no file is read.  Revised by the finaliser after the review of
21 Oct 2026 (sections [PM] and [CF], the multi-class counts of [C1], the growth tables to k = 26,
and the Phase 2 numbers in [E] and [B]).

    python3 checks/check_article2_data.py               # default, under a minute
    python3 checks/check_article2_data.py --full        # every section at full range
    python3 checks/check_article2_data.py --full --only=C1,C4   # selected sections only

Unknown arguments are ignored (run_all.py passes --max-n).  Python 3.11, standard library only,
deterministic, exact integer and Fraction arithmetic in every assertion, at most two worker
processes.  The exit status is non-zero on any failure, and the last line reads
"check_article2_data: N checks, F failures, T s".  A pass is evidence on the stated finite
ranges (VERIFIED), not a proof; where a number is a consequence of a PROVED statement the
recomputation is a consistency check.

Conventions (thesis): letters 1 < 2 < ... < k; scattered subwords; |w|_{j..l} counts
j(j+1)...l; psi_2(w) = (x_1, ..., x_{k-1}), x_i = |w|_{i(i+1)}; a Parikh class is a set of words
of one content with equal |w|_{j..l} for all j < l.  Z (or Z_k) is the alternating class with
edge 1 full (all 1's before all 2's), e(Z) its size; the other alternating class has the same
size (reversal).  For (n^k), D_k(S_A) is the psi_2 fibre (A, 0, n^2, 0, ...) (one Parikh class,
cut lemma) and r_k(S_A) = |D_k(S_A)| / e(Z_k); n^2 - A is the edge-1 deficit.

Sections (default range; [--full range]).  Methods are named after the list.
  [U]  Uniform contents by the chain-insertion recursion INS (own code), cross-checked by the
       downset DP DOWN: e(Z(2^k)) for every k <= 26, e(Z(3^k)) for k <= 15 (literal values of
       explore-r7-general Tables 1-3 and of its logs growth_2k.txt, growth_3k.txt, relax_3k.txt),
       and the step of e(Z)/W to 6 decimals for every k in those ranges;
       every one-end class D_k(S_A); the (2^k) end-relaxed sizes R_k and their 6-decimal ratios
       for every 3 <= k <= 26;
       the (3^k) deficit-3 sizes and ratios (k <= 15); Theorem F(iv)'s exact values (50/53,
       798/662, 55020/57400, 1962796290/1942824800, r_3(n)); the strict parity order of the
       computed r_k (consistency with Theorem F(iii)); the brackets of Cor 5.7 of
       proof-lr-sandwich.md (n = 2: (r_59, r_60); n = 3: (r_15, r_14) and (r_29, r_30)) with
       their directed decimals; the Fig 8 data (n = 2, 3, 4).
  [P]  Literal enumeration LIT (own code) of every Parikh class of (2^k), k <= 5, (3^3) and
       (3^4): class counts 5, 30, 173, 993; Prop F' for k = 3, 4, 5 (6, 56 > 53, 844 > 840);
       (3^3): 20 = e(Z) attained by 6 classes; (3^4): 798 at four vectors; the explore-r7-general
       counterexample (1,4,4,1).
  [C1] C1 for (2^k) by MITM + SPLIT (ported from notes/r7-scripts/proof-switch/c1_certify.py and
       common.py, standard library and deterministic; validated here against LIT): for
       3 <= k <= 9 [12]: e(Z), R_k, the largest psi_2 fibre (unique, central), the fibres of size
       >= R_k, how many of them contain an entry 2 (these go to SPLIT: "split" in
       proof-r7-switch.md section 6) and how many have more than one Parikh class (5, 5, 21, 35,
       53, 99, 175 for k = 3..9 [317, 639, 1273 for k = 10..12]), every class >= R_k, the
       largest classes (S6 for k <= 5; for k >= 6 exactly the alternating pair), the
       second-largest (exactly the four end-relaxed classes), the best class of the central
       fibre and its F_k classes.
  [C4] C4 for every {1,2}-content with 4 <= k <= 8 [11] letters, one per reversal pair (port of
       c4_scan.py): the kind of every content against the rule, the counts per k (2,130 contents
       and 491 not alternating for k <= 11), no tie.
  [T3] (3^k): best one-end and two-end relaxations for k <= 10 (explore-r7-general Table 2,
       relax_3k.txt), by the alphabet transfer TR and INS; the largest psi_2 fibres for
       k = 3..6 (MITM); the largest Parikh classes and their maximisers for k = 4, 5 [and 6, with
       the order at the top: 8568624, 8205714, 8063656].
  [R]  Theorem A(iv): the rigid counts of (2^k), 20, 86, 364, 1548, 6576, 27944 (own transfer
       matrix and brute force over vectors).
  [E]  Theorem E data, by the gap model GAP for (a,2,c) (own code) and LIT: the ties
       (F_nF_{n+1}, F_nF_{n+2}), n odd (a <= 10^5), and five maximisers at the first two; the
       threshold sequence (largest c with B = tau), a <= 19 by the criterion and a <= 10 [19] by
       direct class counts; (3,2,7): B = 140 > tau = 120 at (0,12,0), (6,2,6) and the Fig 1
       heat map; (6,2,10): five maximisers of size 8008; (2,2,2): four of size 6; Target 5:
       D(x) for (4,2,4); H1 (the centre is the unique largest psi_2 fibre of (a,2,c),
       (a,c) != (1,1)) by PSI for a + c <= 30 [a <= c with a + c <= 50, a > c with
       a + c <= 30, and (40,2,65), (65,2,40)].  Phase 2a (proof-h1-centre.md), a second method
       beside check_h1_centre: on the same contents the centre value P(a,c) by PSI equals
       (M+1) C(M, floor(a/2)) C(n-M, ceil(a/2)) and the double sum of Theorem 1(ii); the
       sequences P(a,a) (1, 2, 12, 36, 180, 600, 2800; odd a 2, 36, 600, 9800, 158760; even a
       1, 12, 180, 2800, 44100, 698544); Corollary 2's value for a <= 60; (1,2,1); a = 6:
       D(4), D(5), D(6) = 1620, 1608, 2800; a = 60: D(59)/D(60) = 0.8722; Andrews-Paule (1.1)
       for N <= 30 [59].
  [B]  (2,b,2): the largest Parikh class for b <= 20 [40] by profile enumeration PROF (own
       code; LIT for b <= 7), with the z = 0 / reversal-image location (b != 4); the z = 0 closed
       sum CS against PROF (b <= 14 [30]); M0(b) for b <= 160 (both modes), the formula
       floor((b^2+9b+36)/14) (fails exactly at b in {1..9, 11, 12, 14, 15}), its period-7
       quasi-polynomial for 20 <= b and the maximisers; M0 = largest class for 5 <= b <= 20 [40];
       the Fig 5 data D(x) = P(x, 2b-x) for b = 8, 9 (closed formula of Thm D(iii) and PROF).
       Phase 2b (proof-2b2.md), a second method beside check_2b2, by PROF for b <= 20 [40]:
       Theorem 1(i) (thin classes <= b + 4; the largest thin class b + 4 at (b,b,b) for b even,
       b + 3 at three cells for b odd >= 3); (ii) as stated, on every cell for b <= 14 [30];
       (iii) for b >= 20 (M(b) = M*(b) and the maximiser set); (v) (the failure set of
       M(b) = M*(b), the thin classes among the largest, the z = 0 maximisers for
       16 <= b <= 20); and, by arithmetic for b <= 400, Lemma 3.4, Table 3.4, the 2/4/6
       count of largest classes (6 iff b mod 14 in {0, 5, 7, 12}) and the kappa identity.
  [CF] explore-r7-general Table 3 and its growth logs: the central psi_2 fibre C of (2^k) by TR
       for k <= 20 [26], with C/e(Z) and the step of C/W to 6 decimals; B/e(Z) for k = 4..12;
       for (3^k) the fibre v_k = (3,6,3,...) for k <= 10 [15]; its classes and the best class
       by SPLIT for k = 4..6 [7].
  [PM] Every Parikh class by the merged prefix-matrix DP PM (own code, a second method
       independent of MITM, SPLIT and TR; validated against LIT on ten contents): for (2^k),
       k <= 7 [9], the class counts (5, 30, 173, 993, 5702, 32745 [188045, 1079886]), the
       single-class fibres (= the rigid counts of [R]) and all the C1 data of [C1]; for (3^k),
       k = 3..5 [6], the psi_2 maxima, the largest classes and the fibre v_k [and the order at
       the top of (3^6)]; C4 for 4 <= k <= 6 [8] from every class of every content.
  [D]  Fig 5 data near the centre: (7,6,7) and (5,10,5) on the antidiagonal (packed prefix DP).
  [G]  Fig 2: the rigid cells of (4,5,4) by rule against profile-level value sets; Fig 4: the
       top-gap cells of (5,6,5) (z_max - 1 missing) against T2, T5, T5^R, and their number 24.
  [QE] Question E (b even) by the packed prefix DP PSI: every content with a <= c,
       (a,c) != (1,1), b even and total <= 24 [45]: E0 (total <= 19), E1, E2, E3, the list of
       failures (30 to total 45), the margins quoted in explore-r7-ternary.md section 2.1;
       [the complete odd-odd scans of its section 2.1: b = 6 to total 66 (239 contents, 30
       failures), b = 10, 14, 18 to total 60 (168, 143, 120 contents; 6, 1, 0 failures)].

Methods.
  INS   e(Z) and one-end classes by inserting one letter chain at a time, keeping only the
        position of the copy of the last letter that the next chain meets (first copy of a peak,
        last copy of a valley).  Written for this file.
  DOWN  Linear extensions of a trace class by a DP over the downsets (numbers of copies of each
        letter placed).  Written for this file.
  LIT   Every word of the content by depth-first search, all |w|_{j..l} updated letter by letter.
  MITM  Every psi_2 fibre by meet in the middle at the middle letter (alphabet transfer of gap
        profiles); the fibre sizes are asserted to sum to the multinomial.  Ported.
  SPLIT The Parikh classes inside one psi_2 fibre by an F-vector DP.  Ported.
  TR    The size of one psi_2 fibre by the alphabet transfer restricted to its areas.  Ported.
  GAP   (a,2,c): words u0 2 u1 2 u2; weight prod C(a_g + c_g, a_g), x = 2a0 + a1,
        y = c1 + 2c2, z = a0 c1 + x c2.
  PROF  (2,b,2): profile pairs given by the gaps of the two 1's and the two 3's.
  PSI   P(x,y) for a ternary content by a word-prefix DP with the bivariate polynomial packed
        in one integer.
  PM    Every Parikh class of a content by a word-prefix DP whose state is the partial Parikh
        matrix (all |w|_{j..l}, j <= l) packed in one integer; equal states are merged.
        Written for this file in the review of 21 Oct 2026.  (2^9): 1,079,886 classes, about
        50 s and 2 GB; (3^6): 1,336,350 classes, about 20 s.
"""

from __future__ import annotations

import sys
import time
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from functools import lru_cache
from itertools import combinations_with_replacement, product
from math import comb, factorial, isqrt, prod
from operator import mul

ARGV = sys.argv[1:]
FULL = "--full" in ARGV
ONLY: set[str] = set()
for _arg in ARGV:
    if _arg.startswith("--only="):
        ONLY.update(s.strip() for s in _arg.split("=", 1)[1].split(",") if s.strip())
WORKERS = 2
START = time.perf_counter()


# ---------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------


class Checker:
    def __init__(self) -> None:
        self.count = 0
        self.failures: list[str] = []

    def ok(self, cond, label: str) -> bool:
        self.count += 1
        if not cond:
            self.failures.append(label)
            print(f"   FAIL: {label}", flush=True)
        return bool(cond)

    def eq(self, got, want, label: str) -> bool:
        good = got == want
        return self.ok(good, label if good else f"{label}: got {got!r}, expected {want!r}")


CHK = Checker()


def note(msg: str) -> None:
    print(f"   {msg}", flush=True)


def head(msg: str) -> None:
    print(f"[{msg}]", flush=True)


def dec(fr: Fraction, digits: int = 6) -> str:
    """fr rounded half up to `digits` decimals, as a string (exact)."""
    q = (fr * 10 ** digits + Fraction(1, 2)).__floor__()
    s = str(q).rjust(digits + 1, "0")
    return f"{s[:-digits]}.{s[-digits:]}"


def dec_floor(fr: Fraction, digits: int) -> Fraction:
    return Fraction((fr * 10 ** digits).__floor__(), 10 ** digits)


def dec_ceil(fr: Fraction, digits: int) -> Fraction:
    return Fraction(-((-fr * 10 ** digits).__floor__()), 10 ** digits)


def multinomial(n) -> int:
    out = factorial(sum(n))
    for a in n:
        out //= factorial(a)
    return out


def fib(k: int) -> int:
    """F_1 = F_2 = 1."""
    a, b = 0, 1
    for _ in range(k):
        a, b = b, a + b
    return a


# ---------------------------------------------------------------------------
# The quoted values (re-typed from the notes named in each comment)
# ---------------------------------------------------------------------------

# explore-r7-general.md Tables 1 and 3 and its log notes/r7-scripts/general/out/growth_2k.txt
# (growth.py 2 26 12), every k <= 26; re-typed mechanically by
# notes/article2-scripts/data-ports/retype_growth.py (its output: retype_growth.log).
# e(Z(2^k)):
EZ2 = {1: 1, 2: 1, 3: 6, 4: 53, 5: 840, 6: 18717, 7: 585984, 8: 24004425, 9: 1258008192,
       10: 81754904025, 11: 6463563321600, 12: 610397072367165, 13: 67885424299929600,
       14: 8780676002797088565, 15: 1307030997005163601920, 16: 221836171387458769366545,
       17: 42585493443915644233482240, 18: 9180534813278280771840636465,
       19: 2208459101228628145294364835840, 20: 589453956022638711219214544605125,
       21: 173667685917471861206777650147491840, 22: 56218092928014857467524984310114046925,
       23: 19910511829872088485182459262175857868800,
       24: 7685240895728633605550126782830706102721625,
       25: 3221510393241524253017031866438609931337728000,
       26: 1461736269421611199247687452311372709520954255625}
# end-relaxed class R_k (edge-1 deficit 2; proof-r7-switch.md section 6) and R_k/e(Z):
R2 = {3: 4, 4: 50, 5: 680, 6: 16098, 7: 490728, 8: 20326650, 9: 1060140888, 10: 69036903930,
      11: 5453267773800, 12: 515181809220930, 13: 57286786646208600, 14: 7410301676025884370,
      15: 1103013805411205147880, 16: 187211678038570351960650, 17: 35938495693788513052063320,
      18: 7747600265538513347162693610, 19: 1863752119348468678967912498280,
      20: 497449343650341783459141045637650, 21: 146560829102806521147303172134812760,
      22: 47443316324553055489889841037971604290, 23: 16802787677051372415799343449114869748200,
      24: 6485693285398437683118742939573954557073050,
      25: 2718682274294714272596129166729790785553127000,
      26: 1233581770915197336011973415013790073770938348250}
R2_RATIO = {3: '0.666667', 4: '0.943396', 5: '0.809524', 6: '0.860074', 7: '0.837443',
            8: '0.846788', 9: '0.842714', 10: '0.844437', 11: '0.843694', 12: '0.844011',
            13: '0.843875', 14: '0.843933', 15: '0.843908', 16: '0.843919', 17: '0.843914',
            18: '0.843916', 19: '0.843915', 20: '0.843916', 21: '0.843915', 22: '0.843915',
            23: '0.843915', 24: '0.843915', 25: '0.843915', 26: '0.843915'}
# step of e(Z)/W, W = (2k)!/2^k (Table 3, column 3):
EZ2_STEP = {4: '0.315476', 5: '0.352201', 6: '0.337608', 7: '0.344039', 8: '0.341369',
            9: '0.342532', 10: '0.342040', 11: '0.342252', 12: '0.342162', 13: '0.342201',
            14: '0.342184', 15: '0.342191', 16: '0.342188', 17: '0.342189', 18: '0.342189',
            19: '0.342189', 20: '0.342189', 21: '0.342189', 22: '0.342189', 23: '0.342189',
            24: '0.342189', 25: '0.342189', 26: '0.342189'}
# the central psi_2 fibre C = |(2,...,2)| of (2^k), C/e(Z), and the step of C/W (Table 3):
C2 = {2: 2, 3: 12, 4: 132, 5: 2372, 6: 62304, 7: 2261668, 8: 108184432, 9: 6600715188,
      10: 500046044352, 11: 46059875586796, 12: 5068945239589696, 13: 656892001498969252,
      14: 99009203492091313952, 15: 17173393918707980647932, 16: 3396475065491885353441536,
      17: 759770160669043937854620212, 18: 190859410467833019920981703456,
      19: 53500737146181968368810113206956, 20: 16639688831651994011083683252920320,
      21: 5712670802891605941062444186330733252, 22: 2154870492891101317340698305213442046240,
      23: 889308343281089612052098037203526584040028,
      24: 399992923211232063641708425264957712112055552,
      25: 195379610003355663936883543740382107303018896468,
      26: 103303159401185665859313922591656411468518907135776}
C2_RATIO = {2: '2.000000', 3: '2.000000', 4: '2.490566', 5: '2.823810', 6: '3.328739',
            7: '3.859607', 8: '4.506854', 9: '5.246957', 10: '6.116404', 11: '7.126081',
            12: '8.304341', 13: '9.676481', 14: '11.275806', 15: '13.139240', 16: '15.310736',
            17: '17.841056', 18: '20.789574', 19: '24.225369', 20: '28.228988', 21: '32.894265',
            22: '38.330551', 23: '44.665268', 24: '52.046895', 25: '60.648449', 26: '70.671544'}
C2_STEP = {4: '0.392857', 5: '0.399327', 6: '0.397976', 7: '0.398907', 8: '0.398616',
           9: '0.398781', 10: '0.398718', 11: '0.398750', 12: '0.398736', 13: '0.398743',
           14: '0.398740', 15: '0.398741', 16: '0.398741', 17: '0.398741', 18: '0.398741',
           19: '0.398741', 20: '0.398741', 21: '0.398741', 22: '0.398741', 23: '0.398741',
           24: '0.398741', 25: '0.398741', 26: '0.398741'}
# (3^k), growth_3k.txt (growth.py 3 16 7, rows k <= 15): the step of e(Z)/W, W = (3k)!/6^k;
# the fibre v_k = (3,6,3,6,...), its ratio to e(Z) and the step of C/W.
EZ3_STEP = {4: '0.150455', 5: '0.190565', 6: '0.172159', 7: '0.181155', 8: '0.176930',
            9: '0.178998', 10: '0.178013', 11: '0.178492', 12: '0.178262', 13: '0.178374',
            14: '0.178320', 15: '0.178346'}
C3 = {2: 3, 3: 56, 4: 2560, 5: 254140, 6: 44512068, 7: 12844528058, 8: 5614889182369,
      9: 3556864968145454, 10: 3123444924611725448, 11: 3688654784051763746172,
      12: 5698572194409087565213589, 13: 11270769030825775738677805208,
      14: 27998704675991571541940728025721, 15: 85978209013776400394392233901011596}
C3_RATIO = {2: '3.000000', 3: '2.800000', 4: '3.867069', 5: '4.427526', 6: '5.520085',
            7: '6.611264', 8: '8.070387', 9: '9.764433', 10: '11.864148', 11: '14.387234',
            12: '17.462986', 13: '21.187361', 14: '25.711052', 15: '31.197876'}
C3_STEP = {4: '0.207792', 5: '0.218183', 6: '0.214642', 7: '0.216965', 8: '0.215979',
           9: '0.216571', 10: '0.216292', 11: '0.216451', 12: '0.216371', 13: '0.216416',
           14: '0.216393', 15: '0.216405'}
# (3^k), explore-r7-general Table 3 (k = 4..7): classes in the fibre v_k and the best of them.
V3_CLASSES = {4: (11, 767), 5: (30, 62352), 6: (81, 6701251), 7: (217, 1606540296)}
# largest psi_2 fibre (the centre), best central class, fibres >= R (split): proof-r7-switch
# section 6 and explore-r7-general Table 1.
PSI2MAX2 = {3: 12, 4: 132, 5: 2372, 6: 62304, 7: 2261668, 8: 108184432, 9: 6600715188,
            10: 500046044352, 11: 46059875586796, 12: 5068945239589696}
BESTCENTRAL2 = {3: 6, 4: 56, 5: 844, 6: 15450, 7: 471674, 8: 15892120, 9: 815999564,
                10: 43566347530, 11: 3377505503988, 12: 261964704830830}
# fibres of size >= R_k: (number, number with an entry 2).  proof-r7-switch.md section 6 calls
# the second number "split": these fibres were passed to SPLIT.  It is NOT the number of fibres
# with more than one Parikh class, which is MULTI2 (review of 21 Oct 2026: the skeptic's own
# class DP gave 5, 5, 21, 35, 53, 99, 175 for k = 3..9; k = 10..12 are from the first --full
# run of this file, 21 Oct 2026, single method).
FIBRES_GE_R = {3: (13, 9), 4: (11, 9), 5: (29, 27), 6: (41, 39), 7: (59, 57), 8: (105, 103),
               9: (181, 179), 10: (323, 321), 11: (645, 643), 12: (1279, 1277)}
MULTI2 = {3: 5, 4: 5, 5: 21, 6: 35, 7: 53, 8: 99, 9: 175, 10: 317, 11: 639, 12: 1273}
# number of Parikh classes of (2^k), k = 2..9 (explore-r7-general section 3: 5, 30, 173, 993
# by brute force; 5702, 32745, 188045 and 1079886 from the 19 Oct audit, script not saved).
CLASSES2 = {2: 5, 3: 30, 4: 173, 5: 993, 6: 5702, 7: 32745, 8: 188045, 9: 1079886}
# rigid psi_2 vectors of (2^k) = single-class fibres (Theorem A(ii), (iv)), k = 3..9
RIGID2 = {3: 20, 4: 86, 5: 364, 6: 1548, 7: 6576, 8: 27944, 9: 118736}
# (3^k): explore-r7-general Table 2, relax_3k.txt, growth_3k.txt.
EZ3 = {1: 1, 2: 1, 3: 20, 4: 662, 5: 57400, 6: 8063656, 7: 1942824800, 8: 695739771944,
       9: 364267448771200, 10: 263267521334257720, 11: 256383869987002419200,
       12: 326322903987041883199040, 13: 531957180342202859849113600,
       14: 1088975468745552873519870209920, 15: 2755899468004456652155311609344000}
ONE3 = {3: 15, 4: 798, 5: 55020, 6: 8568624, 7: 1962796290, 8: 719817916776,
        9: 372526066515720, 10: 270734649065627880, 11: 262946429767038605280,
        12: 335109677045133706820160, 13: 545938334858816426127619200,
        14: 1117934634675070109043183535680, 15: 2828773333836216951363481154067600}
ONE3_RATIO = {3: "0.750000", 4: "1.205438", 5: "0.958537", 6: "1.062623", 7: "1.010280",
              8: "1.034608", 9: "1.022672", 10: "1.028363", 11: "1.025597", 12: "1.026927",
              13: "1.026282", 14: "1.026593", 15: "1.026443"}
TWO3 = {4: 798, 5: 66024, 6: 8568624, 7: 2085268500, 8: 727111615104, 9: 385420914646560,
        10: 276865601488972020}
TWO3_RATIO = {4: "1.205438", 5: "1.150244", 6: "1.062623", 7: "1.073318", 8: "1.045091",
              9: "1.058071", 10: "1.051651"}
PSI2MAX3 = {3: (56, {(3, 6), (6, 3)}), 4: (2560, {(3, 6, 3), (6, 3, 6)}),
            5: (254140, {(3, 6, 3, 6), (6, 3, 6, 3)}),
            6: (44512068, {(3, 6, 3, 6, 3), (6, 3, 6, 3, 6)})}
LARGEST3 = {4: (798, {(0, 9, 3), (3, 9, 0), (6, 0, 9), (9, 0, 6)}),
            5: (66024, {(3, 9, 0, 6), (6, 0, 9, 3)}),
            6: (8568624, {(0, 9, 0, 9, 3), (3, 9, 0, 9, 0), (6, 0, 9, 0, 9), (9, 0, 9, 0, 6)})}
# proof-lr-sandwich.md Prop 5.2 and check_lr_sandwich (3): r_3(n), n = 1..8.
R3N = {1: Fraction(1, 2), 2: Fraction(2, 3), 3: Fraction(3, 4), 4: Fraction(71, 70),
       5: Fraction(41, 36), 6: Fraction(32, 21), 7: Fraction(1951, 1144),
       8: Fraction(13976, 6435)}
# (2,b,2), b = 1..40: explore-r7-ternary.md section 4.4 and family_2b2_40.log.
LARGEST_2B2 = [6, 6, 7, 8, 8, 11, 11, 13, 16, 16, 19, 22, 23, 26, 29, 31, 34, 37, 40, 44, 47, 51,
               55, 59, 63, 67, 72, 76, 81, 86, 91, 96, 101, 107, 112, 118, 124, 130, 136, 142]
NMAX_2B2 = [2, 4, 2, 1, 7, 2, 4, 4, 2, 10, 4, 2, 6, 4, 2, 6, 6, 6, 10, 2, 6, 4, 2, 2, 4, 6, 2, 6,
            4, 2, 2, 4, 6, 2, 6, 4, 2, 2, 4, 6]
M0_SAMPLES = {60: (298, [(34, 36), (36, 34)]), 80: (511, [(46, 46)]), 100: (781, [(58, 58)]),
              120: (1108, [(68, 70), (70, 68)]), 140: (1492, [(80, 80), (80, 82), (82, 80)]),
              160: (1934, [(92, 92)])}
# Question E failures with a <= c, total <= 45 (explore-r7-ternary.md section 2.1).
QE_FAILS_45 = [(5, 10, 5), (7, 6, 7), (5, 10, 7), (7, 6, 9), (5, 14, 5), (7, 6, 11), (7, 10, 7),
               (9, 6, 9), (7, 10, 9), (9, 6, 11), (7, 10, 11), (9, 6, 13), (11, 6, 11),
               (7, 10, 13), (11, 6, 13), (11, 6, 15), (13, 6, 13), (11, 6, 17), (13, 6, 15),
               (11, 6, 19), (13, 6, 17), (15, 6, 15), (13, 6, 19), (15, 6, 17), (13, 6, 21),
               (15, 6, 19), (17, 6, 17), (17, 6, 19), (17, 6, 21), (19, 6, 19)]
# the complete odd-odd scans of explore-r7-ternary.md section 2.1 ((a, c), a <= c both odd)
ISLAND6 = [(7, 7), (7, 9), (7, 11), (9, 9), (9, 11), (9, 13), (11, 11), (11, 13), (11, 15),
           (11, 17), (11, 19), (13, 13), (13, 15), (13, 17), (13, 19), (13, 21), (15, 15),
           (15, 17), (15, 19), (17, 17), (17, 19), (17, 21), (17, 23), (19, 19), (19, 21),
           (19, 23), (21, 21), (21, 23), (23, 23), (23, 25)]
ISLAND10 = [(5, 5), (5, 7), (7, 7), (7, 9), (7, 11), (7, 13)]
ISLAND14 = [(5, 5)]
ISLAND18: list = []


# ---------------------------------------------------------------------------
# INS: the chain-insertion recursion (own code)
# ---------------------------------------------------------------------------


def insert_chain(F, m, peak, c):
    """One letter chain of c copies.  F[p] = number of words of the current prefix class whose
    relevant copy of the last letter is at position p (1-based) in a word of length m; the
    relevant copy is the first one if the last letter is a peak, the last one if a valley.
    After a peak the new letter is a valley (all its copies precede the first copy of the
    peak); after a valley it is a peak (all its copies follow the last copy of the valley)."""
    new = [0] * (m + c + 1)
    if peak:
        suf = 0
        for g in range(m - 1, -1, -1):          # last new copy in gap g <= p - 1
            suf += F[g + 1]
            if suf:
                new[g + c] += suf * comb(g + c - 1, c - 1)
    else:
        pre = 0
        for g in range(m + 1):                  # first new copy in gap g >= p
            pre += F[g]
            if pre:
                new[g + 1] += pre * comb(m - g + c - 1, c - 1)
    return new, m + c, not peak


def ez_ins(n) -> int:
    """e(Z(n)) for any positive content (letter 1 a valley: edge 1 full)."""
    F = [0] * (n[0] + 1)
    F[n[0]] = 1
    m, peak = n[0], False
    for c in n[1:]:
        F, m, peak = insert_chain(F, m, peak, c)
    return sum(F)


def one_end_table(n: int, kmax: int):
    """For (n^k), 2 <= k <= kmax: T[k][p] = |D_k({lam})| for any lam with lam_1 = p
    (p = 0..n; p = n is the full projection, so T[k][n] = e(Z_k)).  The {1,2}-word with
    projection lam is unique and its first 2 is at position p + 1; letter 2 is a peak."""
    T = {k: [0] * (n + 1) for k in range(2, kmax + 1)}
    for p in range(n + 1):
        F = [0] * (2 * n + 1)
        F[p + 1] = 1
        m, peak = 2 * n, True
        T[2][p] = 1
        for k in range(3, kmax + 1):
            F, m, peak = insert_chain(F, m, peak, n)
            T[k][p] = sum(F)
    return T


@lru_cache(maxsize=None)
def area_counts(n: int):
    """N[A][p] = number of weakly increasing lam in [0,n]^n with area A and lam_1 = p."""
    N = [[0] * (n + 1) for _ in range(n * n + 1)]
    for lam in combinations_with_replacement(range(n + 1), n):
        N[sum(lam)][lam[0]] += 1
    return N


def d_area(T, n, k, A) -> int:
    N = area_counts(n)
    return sum(N[A][p] * T[k][p] for p in range(n + 1))


# ---------------------------------------------------------------------------
# DOWN: linear extensions of a trace class (own code)
# ---------------------------------------------------------------------------


def trace_down(n, lams) -> int:
    """Words of content n with the edge projections lams: with 0-based letters, lams[i][t] is
    the number of copies of letter i before the (t+1)-th copy of letter i+1.  The (r+1)-th copy
    of letter a may be placed iff exactly lams[a-1][r] copies of a-1 and exactly
    #{s : lams[a][s] <= r} copies of a+1 are already placed."""
    k = len(n)

    @lru_cache(maxsize=None)
    def count(state):
        if all(state[a] == n[a] for a in range(k)):
            return 1
        tot = 0
        for a in range(k):
            r = state[a]                    # placing copy number r + 1 of letter a
            if r == n[a]:
                continue
            if a > 0 and state[a - 1] != lams[a - 1][r]:
                continue
            if a < k - 1 and state[a + 1] != sum(1 for s in lams[a] if s <= r):
                continue
            s2 = list(state)
            s2[a] += 1
            tot += count(tuple(s2))
        return tot

    return count((0,) * k)


def alt_lams(n, first_full=True):
    out, full = [], first_full
    for i in range(len(n) - 1):
        out.append((n[i],) * n[i + 1] if full else (0,) * n[i + 1])
        full = not full
    return out


def alt_psi2(n, first_full=True):
    out, full = [], first_full
    for i in range(len(n) - 1):
        out.append(n[i] * n[i + 1] if full else 0)
        full = not full
    return tuple(out)


# ---------------------------------------------------------------------------
# LIT: all Parikh classes by enumeration (own code)
# ---------------------------------------------------------------------------


def lit_classes(n) -> Counter:
    """Counter: full key (|w|_{j..l} for j < l, ordered by j then l) -> class size."""
    k = len(n)
    total = sum(n)
    rem = list(n)
    c = [[0] * (k + 2) for _ in range(k + 2)]
    pairs = [(j, l) for j in range(1, k) for l in range(j + 1, k + 1)]
    out: Counter = Counter()

    def rec(depth):
        if depth == total:
            out[tuple(c[j][l] for j, l in pairs)] += 1
            return
        for a in range(1, k + 1):
            if rem[a - 1]:
                rem[a - 1] -= 1
                for j in range(1, a):
                    c[j][a] += c[j][a - 1]
                c[a][a] += 1
                rec(depth + 1)
                c[a][a] -= 1
                for j in range(1, a):
                    c[j][a] -= c[j][a - 1]
                rem[a - 1] += 1

    rec(0)
    return out


def key_psi2(key, k):
    pairs = [(j, l) for j in range(1, k) for l in range(j + 1, k + 1)]
    return tuple(v for (j, l), v in zip(pairs, key) if l == j + 1)


# ---------------------------------------------------------------------------
# MITM, SPLIT, TR: ported from notes/r7-scripts/proof-switch/common.py and c1_certify.py
# (standard library, deterministic; validated against LIT in section [C1])
# ---------------------------------------------------------------------------


@lru_cache(maxsize=None)
def lambdas(ni, nj):
    return tuple(combinations_with_replacement(range(ni + 1), nj))


@lru_cache(maxsize=None)
def lambdas_by_area(ni, nj):
    out: dict = {}
    for lam in lambdas(ni, nj):
        out.setdefault(sum(lam), []).append(lam)
    return {a: tuple(v) for a, v in out.items()}


@lru_cache(maxsize=None)
def _weak_compositions(total, parts):
    if parts == 1:
        return ((total,),)
    out = []
    for first in range(total + 1):
        for rest in _weak_compositions(total - first, parts - 1):
            out.append((first,) + rest)
    return tuple(out)


@lru_cache(maxsize=None)
def step(L, lam):
    """Insert the (i+1)-chain with projection lam into gap profile L of the i-chain."""
    ni = len(L) - 1
    a = [0] * (ni + 1)
    for t in lam:
        a[t] += 1
    partial = {((), 0): 1}
    for g in range(ni + 1):
        new: dict = {}
        for (closed, acc), mult in partial.items():
            for compo in _weak_compositions(L[g], a[g] + 1):
                cl = closed
                cur = acc + compo[0]
                for r in range(1, a[g] + 1):
                    cl = cl + (cur,)
                    cur = compo[r]
                if g < ni:
                    cur += 1
                key = (cl, cur)
                new[key] = new.get(key, 0) + mult
        partial = new
    out: dict = {}
    for (closed, acc), mult in partial.items():
        Lp = closed + (acc,)
        out[Lp] = out.get(Lp, 0) + mult
    return tuple(out.items())


@lru_cache(maxsize=None)
def last_weight(L, lam):
    a = [0] * len(L)
    for t in lam:
        a[t] += 1
    w = 1
    for g in range(len(L)):
        w *= comb(L[g] + a[g], a[g])
    return w


def forward_table(n, upto):
    D = {((), (0,) * (n[0] + 1)): 1}
    for i in range(upto - 1):
        new: dict = {}
        for (xs, L), m in D.items():
            for lam in lambdas(n[i], n[i + 1]):
                xs2 = xs + (sum(lam),)
                for Lp, mult in step(L, lam):
                    key = (xs2, Lp)
                    new[key] = new.get(key, 0) + m * mult
        D = new
    return D


def fibre_size_tr(n, x) -> int:
    """TR: size of the psi_2 fibre x of content n."""
    k = len(n)
    D = {(0,) * (n[0] + 1): 1}
    for i in range(k - 1):
        lams = lambdas_by_area(n[i], n[i + 1]).get(x[i], ())
        if i == k - 2:
            return sum(m * last_weight(L, lam) for L, m in D.items() for lam in lams)
        new: dict = {}
        for L, m in D.items():
            for lam in lams:
                for Lp, mult in step(L, lam):
                    new[Lp] = new.get(Lp, 0) + m * mult
        D = new
    raise AssertionError


def end_relax_table(n, first_full) -> dict:
    """TR for all fibres that agree with an alternating vector except on the two end edges:
    (A, B) -> size of the fibre (A, pattern..., B) (k >= 3; one transfer per A)."""
    k = len(n)
    base = alt_psi2(n, first_full)
    out = {}
    for A in range(n[0] * n[1] + 1):
        x = (A,) + base[1:]
        D = {(0,) * (n[0] + 1): 1}
        for i in range(k - 2):
            new: dict = {}
            for L, m in D.items():
                for lam in lambdas_by_area(n[i], n[i + 1]).get(x[i], ()):
                    for Lp, mult in step(L, lam):
                        new[Lp] = new.get(Lp, 0) + m * mult
            D = new
        for B in range(n[-2] * n[-1] + 1):
            lams = lambdas_by_area(n[-2], n[-1]).get(B, ())
            out[(A, B)] = sum(m * last_weight(L, lam) for L, m in D.items() for lam in lams)
    return out


def classes_in_fibre(n, x) -> dict:
    """SPLIT: dict higher-entry key -> Parikh class size, inside the psi_2 fibre x."""
    k = len(n)
    D = {((0,) * (n[0] + 1), (), ()): 1}
    for i in range(k - 1):
        last = i == k - 2
        new: dict = {}
        for (L, F, key), m in D.items():
            prefix = []
            for f in F:
                ps = [0]
                for v in f:
                    ps.append(ps[-1] + v)
                prefix.append(ps)
            for lam in lambdas_by_area(n[i], n[i + 1]).get(x[i], ()):
                Fp = tuple(tuple(ps[t] for t in lam) for ps in prefix)
                key2 = key + tuple(sum(f) for f in Fp)
                if last:
                    new[key2] = new.get(key2, 0) + m * last_weight(L, lam)
                else:
                    st_F = Fp + (lam,)
                    for Lp, mult in step(L, lam):
                        st = (Lp, st_F, key2)
                        new[st] = new.get(st, 0) + m * mult
        D = new
    return D


def mitm_prepare(n):
    """Left and right half tables of MITM, in the form the scan needs."""
    k = len(n)
    m = max(2, min(k - 1, (k + 1) // 2))
    left = forward_table(n, m)
    rn = tuple(reversed(n[m - 1:]))
    right_raw = forward_table(rn, len(rn))
    right: dict = {}
    for (ys, R), c in right_raw.items():
        xr = []
        for j in range(len(ys)):
            hi = k - j
            lo = hi - 1
            xr.append(n[lo - 1] * n[hi - 1] - ys[j])
        key = (tuple(reversed(xr)), R)
        right[key] = right.get(key, 0) + c
    Rs = sorted({R for (_, R) in right})
    Ls = sorted({L for (_, L) in left})
    Ridx = {R: r for r, R in enumerate(Rs)}
    K = {L: [prod(comb(L[g] + R[g], L[g]) for g in range(len(L))) for R in Rs] for L in Ls}
    lg: dict = {}
    for (xl, L), c in left.items():
        lg.setdefault(xl, []).append((L, c))
    rg: dict = {}
    for (xr, R), c in right.items():
        v = rg.get(xr)
        if v is None:
            v = rg[xr] = [0] * len(Rs)
        v[Ridx[R]] += c
    rkeys = sorted(rg)
    rvecs = [rg[x] for x in rkeys]
    litems = [(xl, lg[xl]) for xl in sorted(lg)]
    return litems, rkeys, rvecs, K, len(Rs)


def mitm_scan(args):
    """Scan part `part` of `nparts` of the left keys.  Returns (fibres >= floor, sum of all
    fibre sizes, number of fibres, maximum, maximisers)."""
    n, floor, part, nparts = args
    litems, rkeys, rvecs, K, nR = mitm_prepare(n)
    big = []
    total = 0
    nfib = 0
    best, best_x = -1, []
    for idx, (xl, items) in enumerate(litems):
        if idx % nparts != part:
            continue
        u = [0] * nR
        for L, c in items:
            row = K[L]
            for r in range(nR):
                u[r] += c * row[r]
        for xr, v in zip(rkeys, rvecs):
            s = sum(map(mul, u, v))
            total += s
            nfib += 1
            if s >= floor:
                big.append((s, xl + xr))
            if s > best:
                best, best_x = s, [xl + xr]
            elif s == best:
                best_x.append(xl + xr)
    return big, total, nfib, best, best_x


def mitm_all(n, floor, pool=None):
    """Every psi_2 fibre of n: fibres >= floor, total, count, max and maximisers."""
    parts = WORKERS if pool is not None else 1
    jobs = [(tuple(n), floor, p, parts) for p in range(parts)]
    results = list(pool.map(mitm_scan, jobs)) if pool is not None else [mitm_scan(jobs[0])]
    big, total, nfib, best, best_x = [], 0, 0, -1, []
    for b, t, nf, bs, bx in results:
        big += b
        total += t
        nfib += nf
        if bs > best:
            best, best_x = bs, list(bx)
        elif bs == best:
            best_x += bx
    return sorted(big, reverse=True), total, nfib, best, sorted(best_x)


def split_job(args):
    n, x = args
    return x, sorted(classes_in_fibre(n, x).values(), reverse=True)


def single_trace(n, x):
    return all(len(lambdas_by_area(n[i], n[i + 1])[x[i]]) == 1 for i in range(len(x)))


# ---------------------------------------------------------------------------
# PM: every Parikh class by a merged prefix-matrix DP (own code, written in the review of
# 21 Oct 2026; independent of MITM, SPLIT and TR: no gap profiles, no traces, no psi_2 split)
# ---------------------------------------------------------------------------


def pm_layout(n):
    """(k, W): |w|_{j..l} <= n_j n_{j+1} ... n_l < 2^W for every j <= l."""
    k = len(n)
    top = 1
    for j in range(k):
        p = 1
        for l in range(j, k):
            p *= n[l]
            top = max(top, p)
    return k, top.bit_length()


def pm_classes(n) -> dict:
    """PM: dict packed key -> Parikh class size, for content n.  The state of a prefix is its
    partial Parikh matrix (|w|_{j..l} for all j <= l) packed in one integer, field (j, l) at bit
    offset ((l-1)k + (j-1))W.  Appending letter a adds |w|_{j..a-1} to |w|_{j..a} (j < a) and 1
    to |w|_{a..a}.  Column a-1 lies kW bits below column a, so the update is
    S + ((S & mask_{a-1}) << kW) + unit_a (no field overflows, by the choice of W).  Prefixes
    with equal states are merged, one length at a time; the final states are the classes."""
    k, W = pm_layout(n)
    FM = (1 << W) - 1
    shift = k * W
    moves = []
    for a in range(1, k + 1):
        mask = 0
        for j in range(1, a):
            mask |= FM << (((a - 2) * k + (j - 1)) * W)
        oa = ((a - 1) * k + (a - 1)) * W
        moves.append((mask, 1 << oa, oa, n[a - 1]))
    layer = {0: 1}
    for _ in range(sum(n)):
        new: dict = {}
        get = new.get
        for S, c in layer.items():
            for mask, unit, oa, na in moves:
                if (S >> oa) & FM < na:
                    S2 = S + ((S & mask) << shift) + unit
                    new[S2] = get(S2, 0) + c
        layer = new
    return layer


def pm_unpack(n):
    """Functions: packed key -> psi_2 vector; packed key -> the full key of LIT (j < l)."""
    k, W = pm_layout(n)
    FM = (1 << W) - 1
    psi_off = [(i * k + (i - 1)) * W for i in range(1, k)]                 # field (i, i+1)
    full_off = [((l - 1) * k + (j - 1)) * W for j in range(1, k) for l in range(j + 1, k + 1)]

    def psi2(S):
        return tuple((S >> o) & FM for o in psi_off)

    def full(S):
        return tuple((S >> o) & FM for o in full_off)

    return psi2, full


def pm_by_fibre(n) -> dict:
    """PM grouped by psi_2: dict psi_2 vector -> list of the class sizes in that fibre."""
    psi2, _ = pm_unpack(n)
    by: dict = {}
    for S, m in pm_classes(n).items():
        by.setdefault(psi2(S), []).append(m)
    return by


def pm_c4(n):
    """C4 kind of a {1,2}-content from every one of its Parikh classes (PM)."""
    by = pm_by_fibre(n)
    e = ez_ins(n)
    alt = {alt_psi2(n, True), alt_psi2(n, False)}
    alt_ok = all(by.get(x) == [e] for x in alt)          # each alternating fibre: one class, e(Z)
    best_other = max((m for x, sizes in by.items() for m in sizes if x not in alt), default=0)
    kind = "BEATEN" if best_other > e else ("TIE" if best_other == e else "ALT")
    total_ok = sum(map(sum, by.values())) == multinomial(n)
    return n, kind, e, best_other, alt_ok and total_ok


# ---------------------------------------------------------------------------
# Ternary helpers (own code)
# ---------------------------------------------------------------------------


def ternary_words_xyz(a, b, c) -> Counter:
    """LIT for a ternary content: Counter (x, y, z) -> number of words."""
    out: Counter = Counter()

    def rec(r1, r2, r3, n1, n2, n12, x, y, z):
        if r1 == r2 == r3 == 0:
            out[(x, y, z)] += 1
            return
        if r1:
            rec(r1 - 1, r2, r3, n1 + 1, n2, n12, x, y, z)
        if r2:
            rec(r1, r2 - 1, r3, n1, n2 + 1, n12 + n1, x + n1, y, z)
        if r3:
            rec(r1, r2, r3 - 1, n1, n2, n12, x, y + n2, z + n12)

    rec(a, b, c, 0, 0, 0, 0, 0, 0)
    return out


def a2c_classes(a, c) -> Counter:
    """GAP for content (a,2,c): Counter (x,y,z) -> class size."""
    out: Counter = Counter()
    for a0 in range(a + 1):
        for a1 in range(a - a0 + 1):
            a2 = a - a0 - a1
            x = 2 * a0 + a1
            for c0 in range(c + 1):
                for c1 in range(c - c0 + 1):
                    c2 = c - c0 - c1
                    out[(x, c1 + 2 * c2, a0 * c1 + x * c2)] += (
                        comb(a0 + c0, a0) * comb(a1 + c1, a1) * comb(a2 + c2, a2))
    return out


def fibres_of(classes: Counter) -> Counter:
    P: Counter = Counter()
    for (x, y, _z), m in classes.items():
        P[(x, y)] += m
    return P


def psi2_packed(a, b, c) -> list:
    """PSI: P[x][y] for content (a,b,c) by a word-prefix DP over (#1, #2, #3) with the
    polynomial in (x, y) packed in one integer (appending a 2 adds #1 to x, a 3 adds #2 to y)."""
    X, Y = a * b, b * c
    bits = 8 * ((multinomial((a, b, c)).bit_length() + 8) // 8)
    row = (Y + 1) * bits
    prev = None
    for i in range(a + 1):
        cur = [[0] * (c + 1) for _ in range(b + 1)]
        sx = i * row
        for j in range(b + 1):
            cj = cur[j]
            cjm = cur[j - 1] if j else None
            pj = prev[j] if i else None
            sy = j * bits
            for k in range(c + 1):
                v = pj[k] if i else (1 if j == k == 0 else 0)
                if j:
                    v += cjm[k] << sx
                if k:
                    v += cj[k - 1] << sy
                cj[k] = v
        prev = cur
    poly = prev[b][c]
    w = bits // 8
    raw = poly.to_bytes((X + 1) * (Y + 1) * w, "little")
    P = []
    for x in range(X + 1):
        base = x * (Y + 1) * w
        P.append([int.from_bytes(raw[base + y * w: base + (y + 1) * w], "little")
                  for y in range(Y + 1)])
    return P


def mono_profiles(b, top, increasing):
    """All weakly increasing (decreasing) vectors of length b with entries in [0, top]."""
    out = []
    for comb_ in combinations_with_replacement(range(top + 1), b):
        out.append(comb_ if increasing else tuple(reversed(comb_)))
    return out


def profile_value_sets(a, b, c) -> dict:
    """(x, y) -> set of z, from every monotone profile pair (A, C) (MSY04 section 7)."""
    As = mono_profiles(b, a, True)
    Cs = mono_profiles(b, c, False)
    Cinfo = [(sum(C), C) for C in Cs]
    Z: dict = {}
    for A in As:
        x = sum(A)
        for y, C in Cinfo:
            z = sum(map(mul, A, C))
            s = Z.get((x, y))
            if s is None:
                Z[(x, y)] = {z}
            else:
                s.add(z)
    return Z


def gamma_set(m, n):
    return set(range(m * n + 1)) if min(m, n) <= 1 else {0, 1, m * n - 1, m * n}


def rigid_rules(a, b, c, u, v):
    """The rules (E), (N), (Ch), (Gamma) of Theorem A that hold at (u, v)."""
    rules = []
    if u in (0, a * b) or v in (0, b * c):
        rules.append("E")
    if u + v <= b:
        rules.append("N")
    if (a * b - u) + (b * c - v) <= b:
        rules.append("Ch")
    if u in gamma_set(a, b) and v in gamma_set(b, c):
        rules.append("G")
    return rules


# ---------------------------------------------------------------------------
# [U] uniform contents by INS and DOWN
# ---------------------------------------------------------------------------


def sec_U():
    head("U  uniform contents (n^k): e(Z), one-end classes, Theorem F(iv) values, brackets")
    t0 = time.perf_counter()
    # e(Z) by INS against DOWN (independent), small k
    for n, kmax in ((1, 8), (2, 8), (3, 6), (4, 4)):
        for k in range(1, kmax + 1):
            cont = (n,) * k
            CHK.eq(ez_ins(cont), trace_down(cont, alt_lams(cont)), f"INS = DOWN e(Z({n}^{k}))")
    for cont in ((2, 2, 1, 2), (1, 2, 2, 1), (2, 3, 2, 3), (3, 2, 3, 2, 3), (1, 4, 4, 1),
                 (2, 1, 3, 2, 2)):
        CHK.eq(ez_ins(cont), trace_down(cont, alt_lams(cont)), f"INS = DOWN e(Z{cont})")
    # n = 1 (classical sanity check): the Euler zigzag numbers
    CHK.eq([ez_ins((1,) * k) for k in range(2, 10)], [1, 2, 5, 16, 61, 272, 1385, 7936],
           "e(Z(1^k)) = E_k (Euler zigzag numbers), k = 2..9")
    # literal values
    T2 = one_end_table(2, 60)
    T3 = one_end_table(3, 40)
    for k, v in EZ2.items():
        CHK.eq(ez_ins((2,) * k), v, f"e(Z(2^{k}))")
        if k >= 2:
            CHK.eq(T2[k][2], v, f"one-end table start = e(Z(2^{k}))")
    for k, v in EZ3.items():
        CHK.eq(ez_ins((3,) * k), v, f"e(Z(3^{k}))")
    # one-end classes against DOWN (independent): every projection, small k
    for n, kmax in ((2, 7), (3, 5)):
        Tn = one_end_table(n, kmax)
        for k in range(2, kmax + 1):
            cont = (n,) * k
            for lam in lambdas(n, n):
                lams = [lam] + alt_lams(cont)[1:]
                CHK.eq(Tn[k][lam[0]], trace_down(cont, lams), f"INS = DOWN D_{k}({lam}), n={n}")
    # (2^k): R_k = |D_k(S_2)| and its ratio
    for k, v in R2.items():
        CHK.eq(d_area(T2, 2, k, 2), v, f"R_{k} of (2^k)")
    for k, s in R2_RATIO.items():
        CHK.eq(dec(Fraction(d_area(T2, 2, k, 2), T2[k][2])), s, f"R_{k}/e(Z) to 6 decimals")
    # the best one-end class of (2^k) is the deficit-2 class for 3 <= k <= 26
    for k in range(3, 27):
        sizes = {A: d_area(T2, 2, k, A) for A in range(4)}
        CHK.ok(max(sizes, key=sizes.get) == 2 and sorted(sizes.values())[-1] >
               sorted(sizes.values())[-2], f"(2^{k}): best one-end class is deficit 2")
    # explore-r7-general Table 3 and growth_{2,3}k.txt: per-letter step of e(Z)/W,
    # W = (nk)!/(n!)^k, 6 decimals, every k (4 <= k <= 26 for n = 2, 4 <= k <= 15 for n = 3)
    for n, Tn, want in ((2, T2, EZ2_STEP), (3, T3, EZ3_STEP)):
        for k, s in want.items():
            Wk = Fraction(factorial(n * k), factorial(n) ** k)
            Wk1 = Fraction(factorial(n * (k - 1)), factorial(n) ** (k - 1))
            step_k = (Tn[k][n] / Wk) / (Tn[k - 1][n] / Wk1)
            CHK.eq(dec(step_k), s, f"(n^k) = ({n}^{k}): step of e(Z)/W")
    # (3^k): deficit-3 class sizes and ratios; best one-end class is deficit 3 (3 <= k <= 40)
    for k, v in ONE3.items():
        CHK.eq(d_area(T3, 3, k, 6), v, f"(3^{k}) deficit-3 class")
    for k, s in ONE3_RATIO.items():
        CHK.eq(dec(Fraction(d_area(T3, 3, k, 6), T3[k][3])), s, f"(3^{k}) one-end ratio")
    for k in range(3, 41):
        sizes = {A: d_area(T3, 3, k, A) for A in range(9)}
        best = max(sizes.values())
        CHK.ok([A for A in sizes if sizes[A] == best] == [6], f"(3^{k}): best one-end = deficit 3")
    # Theorem F(iv), n = 3: r_4 = 798/662, r_5 = 55020/57400 < 1, r_7 = 1962796290/1942824800;
    # r_k(S_3) > 1 for 4 <= k <= 40 except k = 5
    r3 = {k: Fraction(d_area(T3, 3, k, 6), T3[k][3]) for k in range(2, 41)}
    CHK.eq((d_area(T3, 3, 4, 6), T3[4][3]), (798, 662), "r_4 = 798/662 (n = 3)")
    CHK.eq((d_area(T3, 3, 5, 6), T3[5][3]), (55020, 57400), "r_5 = 55020/57400 (n = 3)")
    CHK.eq((d_area(T3, 3, 7, 6), T3[7][3]), (1962796290, 1942824800), "r_7 (n = 3)")
    CHK.eq([k for k in range(4, 41) if r3[k] <= 1], [5], "n = 3: r_k > 1 for 4 <= k <= 40, k != 5")
    # every one-end relaxation of (3^5) loses: the nine |D_5(S_A)|, A = 0..8, are < 57400
    nine = [d_area(T3, 3, 5, A) for A in range(9)]
    CHK.ok(max(nine) == 55020 and all(v < 57400 for v in nine), f"(3^5) one-end values {nine}")
    # n = 2: r_k(S_A) <= 50/53 for every area A and 3 <= k <= 60, equality only at (k, A) = (4, 2)
    eq_cases = []
    for k in range(3, 61):
        for A in range(4):
            r = Fraction(d_area(T2, 2, k, A), T2[k][2])
            CHK.ok(r <= Fraction(50, 53), f"n = 2: r_{k}(S_{A}) <= 50/53")
            if r == Fraction(50, 53):
                eq_cases.append((k, A))
    CHK.eq(eq_cases, [(4, 2)], "n = 2: equality 50/53 only at k = 4, area 2")
    # n >= 4: r_k(S_n) > 1 (deficit n), 4 <= n <= 8, 3 <= k <= 15; r_3(n) by the partition formula
    for n in range(4, 9):
        Tn = one_end_table(n, 15)
        for k in range(3, 16):
            CHK.ok(d_area(Tn, n, k, n * n - n) > Tn[k][n], f"r_{k}(S_{n}) > 1 for n = {n}")
    # r_3(n) = sum_{mu |- n} C(2n - mu_1, n) / C(2n, n): partitions of n by largest part
    pmax = partitions_by_largest(50)
    for n in range(1, 51):
        r3n = Fraction(sum(pmax[n][j] * comb(2 * n - j, n) for j in range(1, n + 1)),
                       comb(2 * n, n))
        if n <= 8:
            CHK.eq(r3n, R3N[n], f"r_3({n}) by partitions")
            Tn = one_end_table(n, 3)
            CHK.eq(Fraction(d_area(Tn, n, 3, n * n - n), Tn[3][n]), R3N[n], f"r_3({n}) by INS")
        CHK.ok((r3n > 1) == (n >= 4), f"r_3({n}) > 1 iff n >= 4")
        two = Fraction(comb(2 * n - 1, n) + (n // 2) * comb(2 * n - 2, n), comb(2 * n, n))
        CHK.ok((two > 1) == (n >= 6), f"mu_1 <= 2 terms of r_3({n}) exceed 1 iff n >= 6")
    # strict parity order of the computed values (consistency with Theorem F(iii), PROVED)
    for n, Tn, kmax in ((2, T2, 60), (3, T3, 40), (4, one_end_table(4, 15), 15)):
        for A in range(n * n):
            r = [None, None] + [Fraction(d_area(Tn, n, k, A), Tn[k][n]) for k in range(2, kmax + 1)]
            odd = [r[k] for k in range(3, kmax + 1, 2)]
            even = [r[k] for k in range(2, kmax + 1, 2)]
            CHK.ok(all(u < v for u, v in zip(odd, odd[1:])) and
                   all(u > v for u, v in zip(even, even[1:])) and max(odd) < min(even),
                   f"strict sandwich n = {n}, A = {A}, k <= {kmax}")
    # brackets (proof-lr-sandwich.md Cor 5.7)
    r2 = {k: Fraction(d_area(T2, 2, k, 2), T2[k][2]) for k in range(2, 61)}
    CHK.ok(dec_floor(r2[59], 9) == Fraction("0.843915414") and
           dec_ceil(r2[60], 9) == Fraction("0.843915415"), "n = 2: (r_59, r_60) decimals")
    CHK.ok(dec_floor(r3[15], 9) == Fraction("1.026442860") and
           dec_ceil(r3[14], 9) == Fraction("1.026593038"), "n = 3: (r_15, r_14) decimals")
    CHK.ok(dec_floor(r3[29], 10) == Fraction("1.0264917187") and
           dec_ceil(r3[30], 10) == Fraction("1.0264917215"), "n = 3: (r_29, r_30) decimals")
    CHK.eq((dec(r3[15]), dec(r3[7])), ("1.026443", "1.010280"), "design: 1.026443 (k=15), 1.010280")
    CHK.ok(r2[59] < Fraction("0.8439155") and r2[60] > Fraction("0.8439145") and
           r3[29] > Fraction("1.026485") and r3[30] < Fraction("1.026495"),
           "design's c_2 ~ 0.843915 and c_3 ~ 1.02649 lie in the brackets' rounding range")
    # n = 1 (Remark 4.4 of proof-lr-sandwich.md, KNOWN: Ehrenborg 2002): the one-end ratio
    # r_k = |D_k|/E_k = (k E_{k-1} - E_k)/E_k tends to pi/2 - 1, odd k from below and even k
    # from above.  A numerical consistency check of that KNOWN limit, with exact bounds on pi.
    T1 = one_end_table(1, 61)
    CHK.ok(all(T1[k][0] == k * T1[k - 1][1] - T1[k][1] for k in range(3, 62)),
           "n = 1: |D_k| = k E_(k-1) - E_k, 3 <= k <= 61")
    plo, phi = pi_bounds()
    c1lo, c1hi = plo / 2 - 1, phi / 2 - 1
    r1 = {k: Fraction(T1[k][0], T1[k][1]) for k in range(3, 62)}
    CHK.ok(all(r1[k] < c1lo for k in range(3, 62, 2)) and all(r1[k] > c1hi for k in range(4, 62, 2))
           and r1[60] - r1[61] < Fraction(1, 10 ** 28),
           "n = 1: odd r_k < pi/2 - 1 < even r_k for k <= 61, and r_60 - r_61 < 1e-28")
    # Fig 8 data: the best one-end ratio r_k(S_n) for n = 2, 3, 4 and 2 <= k <= 15
    T4 = one_end_table(4, 15)
    for n, Tn in ((2, T2), (3, T3), (4, T4)):
        row = [dec(Fraction(d_area(Tn, n, k, n * n - n), Tn[k][n]), 4) for k in range(2, 16)]
        note(f"Fig 8 data, n = {n}, k = 2..15: {' '.join(row)}")
    note(f"c_2 in (r_59, r_60) = ({float(r2[59]):.10f}, {float(r2[60]):.10f}); "
         f"c_3 in (r_29, r_30) = ({float(r3[29]):.11f}, {float(r3[30]):.11f})")
    note(f"{time.perf_counter() - t0:.1f} s")


def pi_bounds(terms: int = 40):
    """Exact rational bounds lo < pi < hi from Machin's formula pi = 16 atan(1/5) - 4 atan(1/239),
    each arctangent between two consecutive partial sums of its alternating series."""
    def atan_bounds(x):
        s, bounds = Fraction(0), []
        for i in range(terms + 1):
            s += Fraction((-1) ** i, (2 * i + 1) * x ** (2 * i + 1))
            bounds.append(s)
        return min(bounds[-2:]), max(bounds[-2:])
    a_lo, a_hi = atan_bounds(5)
    b_lo, b_hi = atan_bounds(239)
    return 16 * a_lo - 4 * b_hi, 16 * a_hi - 4 * b_lo


def partitions_by_largest(N):
    """p[n][j] = number of partitions of n with largest part exactly j (p[0][0] = 1)."""
    # q[n][j] = partitions of n with parts <= j
    q = [[0] * (N + 1) for _ in range(N + 1)]
    for j in range(N + 1):
        q[0][j] = 1
    for n in range(1, N + 1):
        for j in range(1, N + 1):
            q[n][j] = q[n][j - 1] + (q[n - j][j] if j <= n else 0)
    p = [[0] * (N + 1) for _ in range(N + 1)]
    p[0][0] = 1
    for n in range(1, N + 1):
        for j in range(1, n + 1):
            p[n][j] = q[n][j] - q[n][j - 1]
    return p


# ---------------------------------------------------------------------------
# [P] literal enumeration
# ---------------------------------------------------------------------------


def sec_P():
    head("P  literal enumeration: (2^k) for k <= 5, (3^3), (3^4), (1,4,4,1)")
    t0 = time.perf_counter()
    counts = {}
    for k in range(2, 6):
        cl = lit_classes((2,) * k)
        counts[k] = len(cl)
        sizes = sorted(cl.values(), reverse=True)
        top = sizes[0]
        at = sorted(key_psi2(key, k) for key, v in cl.items() if v == top)
        ezv = EZ2[k]
        if k == 3:
            CHK.ok(top == 6 and at == [(0, 4), (2, 2), (2, 2), (4, 0)], f"(2^3) four-way tie {at}")
        elif k == 4:
            CHK.ok(top == 56 and at == [(2, 2, 2), (2, 2, 2)] and sizes[2] == ezv == 53,
                   f"(2^4): 56 > 53 at two central classes {at}")
        elif k == 5:
            CHK.ok(top == 844 and at == [(2, 2, 2, 2)] and sizes[1] == 840 == ezv and
                   sizes[3] == 698, "(2^5): 844 > 840 at one central class; next central 698")
        else:
            CHK.eq(top, 2, "(2^2) largest class")
    CHK.eq([counts[k] for k in range(2, 6)], [5, 30, 173, 993], "number of Parikh classes of (2^k)")
    cl = lit_classes((3, 3, 3))
    top = max(cl.values())
    CHK.ok(top == 20 == EZ3[3] and sum(1 for v in cl.values() if v == 20) == 6,
           "(3^3): largest class 20 = e(Z), attained by 6 classes")
    cl = lit_classes((3, 3, 3, 3))
    top = max(cl.values())
    at = sorted(key_psi2(key, 4) for key, v in cl.items() if v == top)
    CHK.ok(top == 798 and set(at) == LARGEST3[4][1] and len(at) == 4,
           f"(3^4): largest class 798 at {at}")
    P = Counter()
    for key, v in cl.items():
        P[key_psi2(key, 4)] += v
    pm = max(P.values())
    CHK.ok(pm == 2560 and {x for x, v in P.items() if v == pm} == PSI2MAX3[4][1],
           "(3^4): largest psi_2 fibre 2560 at (3,6,3), (6,3,6)")
    cl = lit_classes((1, 4, 4, 1))
    big = sorted({key_psi2(key, 4) for key, v in cl.items() if v == 29})
    CHK.ok(ez_ins((1, 4, 4, 1)) == 26 and (0, 12, 0) in big and (4, 4, 4) in big,
           f"(1,4,4,1): classes of 29 at {big} against e(Z) = 26")
    note(f"(1,4,4,1): largest class {max(cl.values())}; classes of 29 at {big}")
    note(f"{time.perf_counter() - t0:.1f} s")


# ---------------------------------------------------------------------------
# [C1] C1 for (2^k)
# ---------------------------------------------------------------------------


def certify_2k(k, pool):
    """MITM + SPLIT certification for (2^k): the data of proof-r7-switch.md section 6."""
    n = (2,) * k
    e = ez_ins(n)
    T2 = one_end_table(2, k)
    R = d_area(T2, 2, k, 2)
    t0 = time.perf_counter()
    big, total, nfib, best, best_x = mitm_all(n, R, pool)
    t1 = time.perf_counter()
    CHK.eq(total, factorial(2 * k) // 2 ** k, f"(2^{k}) fibre sum = (2k)!/2^k")
    CHK.eq(nfib, 5 ** (k - 1), f"(2^{k}) number of fibres")
    CHK.ok(best == PSI2MAX2[k] and best_x == [(2,) * (k - 1)],
           f"(2^{k}) largest psi_2 fibre {best} at {best_x[:3]}")
    # a fibre with no entry 2 is one Parikh class (gamma(2,2) = {0,1,3,4}); the others go to
    # SPLIT ("split" in proof-r7-switch.md section 6), and some of those are one class too
    tosplit = [x for s, x in big if 2 in x]
    CHK.eq((len(big), len(tosplit)), FIBRES_GE_R[k], f"(2^{k}) fibres >= R (with an entry 2)")
    classes = [(s, x) for s, x in big if 2 not in x]
    central = None
    jobs = [(n, x) for x in tosplit]
    results = pool.map(split_job, jobs, chunksize=4) if pool is not None else map(split_job, jobs)
    fibre_of = {xx: s for s, xx in big}
    multi = 0
    for x, sizes in results:
        CHK.eq(sum(sizes), fibre_of[x], f"(2^{k}) split sums to fibre {x}")
        multi += len(sizes) > 1
        if x == (2,) * (k - 1):
            central = sizes
        classes += [(s, x) for s in sizes if s >= R]
    if k in MULTI2:
        CHK.eq(multi, MULTI2[k], f"(2^{k}) fibres >= R with more than one Parikh class")
    classes.sort(reverse=True)
    t2 = time.perf_counter()
    alt = {alt_psi2(n, True), alt_psi2(n, False)}
    top = [c for c in classes if c[0] >= e]
    CHK.ok(central is not None and len(central) == fib(k) and central[0] == BESTCENTRAL2[k],
           f"(2^{k}) central fibre: {len(central or [])} classes (F_k = {fib(k)}), best "
           f"{(central or [0])[0]}")
    if k == 3:
        CHK.ok(sorted(x for s, x in top) == [(0, 4), (2, 2), (2, 2), (4, 0)] and
               all(s == 6 for s, x in top), "(2^3) four-way tie at 6")
    elif k == 4:
        CHK.ok([c for c in top if c[0] > e] == [(56, (2, 2, 2)), (56, (2, 2, 2))],
               "(2^4) 56 > 53")
    elif k == 5:
        CHK.ok([c for c in top if c[0] > e] == [(844, (2, 2, 2, 2))], "(2^5) 844 > 840")
    else:
        CHK.ok({x for s, x in top} == alt and len(top) == 2 and all(s == e for s, x in top),
               f"(2^{k}) C1-fin: only the alternating pair has size >= e(Z)")
        rest = [c for c in classes if c[0] < e]
        second = [x for s, x in rest if s == rest[0][0]]
        endrel = {(2,) + alt_psi2(n, True)[1:], alt_psi2(n, True)[:-1] + (2,),
                  (2,) + alt_psi2(n, False)[1:], alt_psi2(n, False)[:-1] + (2,)}
        CHK.ok(rest[0][0] == R and set(second) == endrel and len(second) == 4,
               f"(2^{k}) second largest = the four end-relaxed classes ({rest[0][0]})")
    note(f"(2^{k}): e(Z) = {e}, R = {R} ({dec(Fraction(R, e))}), psi_2 max {best}, fibres >= R: "
         f"{len(big)} ({len(tosplit)} with an entry 2, {multi} with more than one class), "
         f"central: {len(central or [])} classes, best {(central or [0])[0]}; "
         f"stream {t1 - t0:.1f} s, split {t2 - t1:.1f} s")


def sec_C1(pool):
    head("C1 (2^k): largest and second-largest Parikh classes (port of c1_certify.py)")
    t0 = time.perf_counter()
    # validation of the ported MITM + SPLIT against LIT on small contents
    for cont in ((2, 2, 2), (2, 2, 2, 2), (2, 2, 2, 2, 2), (3, 3, 3), (2, 2, 1, 2), (1, 2, 2, 1, 2),
                 (2, 3, 2, 3), (2, 1, 2, 2, 1)):
        k = len(cont)
        lit = Counter()
        for key, v in lit_classes(cont).items():
            lit[(key_psi2(key, k), v)] += 1
        big, total, nfib, best, bx = mitm_all(cont, 0, None)
        port = Counter()
        for s, x in big:
            for size in sorted(classes_in_fibre(cont, x).values()):
                port[(x, size)] += 1
        CHK.eq(port, lit, f"MITM + SPLIT = LIT on every class of {cont}")
        CHK.eq(total, multinomial(cont), f"fibre sum of {cont}")
    kmax = 12 if FULL else 9
    for k in range(3, kmax + 1):
        certify_2k(k, pool)
    note(f"{time.perf_counter() - t0:.1f} s")


# ---------------------------------------------------------------------------
# [C4] the {1,2} end-block rule
# ---------------------------------------------------------------------------


def c4_classify(n):
    e = ez_ins(n)
    alt = {alt_psi2(n, True), alt_psi2(n, False)}
    big, total, nfib, best, bx = mitm_all(n, e, None)
    assert total == multinomial(n), n
    best_other, arg = 0, []
    for s, x in big:
        sizes = [s] if single_trace(n, x) else list(classes_in_fibre(n, x).values())
        for size in sizes:
            if x in alt and size == e:
                continue
            if size > best_other:
                best_other, arg = size, [x]
            elif size == best_other:
                arg.append(x)
    kind = "BEATEN" if best_other > e else ("TIE" if best_other == e else "ALT")
    return n, kind, e, best_other


def c4_rule(n):
    if n in ((2, 2, 2, 2), (2, 2, 2, 2, 2)):
        return "BEATEN"
    if n[:3] == (2, 2, 1) or n[-3:] == (1, 2, 2):
        return "BEATEN"
    return "ALT"


C4_TABLE = {4: (10, 7, 3), 5: (20, 15, 5), 6: (36, 28, 8), 7: (72, 56, 16), 8: (136, 105, 31),
            9: (272, 210, 62), 10: (528, 406, 122), 11: (1056, 812, 244)}


def sec_C4(pool):
    head("C4 the {1,2} end-block rule (port of c4_scan.py)")
    t0 = time.perf_counter()
    kmax = 11 if FULL else 8
    tot_c = tot_not = 0
    for k in range(4, kmax + 1):
        t1 = time.perf_counter()
        reps, seen = [], set()
        for n in product((1, 2), repeat=k):
            if tuple(reversed(n)) in seen:
                continue
            seen.add(n)
            reps.append(n)
        res = list(pool.map(c4_classify, reps, chunksize=2)) if pool is not None else \
            [c4_classify(n) for n in reps]
        kinds = Counter(kind for _, kind, _, _ in res)
        bad = [(n, kind) for n, kind, _, _ in res if kind != c4_rule(n)]
        CHK.eq(bad, [], f"C4 rule, k = {k}")
        CHK.eq((len(reps), kinds["ALT"], kinds["BEATEN"], kinds["TIE"]), C4_TABLE[k] + (0,),
               f"C4 counts, k = {k}")
        tot_c += len(reps)
        tot_not += kinds["BEATEN"]
        note(f"k = {k}: {len(reps)} contents up to reversal, ALT {kinds['ALT']}, not ALT "
             f"{kinds['BEATEN']}, TIE {kinds['TIE']}; {time.perf_counter() - t1:.1f} s")
    if kmax == 11:
        CHK.eq((tot_c, tot_not), (2130, 491), "C4: 2,130 contents, 491 not alternating")
    note(f"{time.perf_counter() - t0:.1f} s")


# ---------------------------------------------------------------------------
# [PM] every Parikh class by PM: a second, independent method for [C1], [C4], [T3] and [R]
# ---------------------------------------------------------------------------


def pm_2k(k):
    """The C1 data of (2^k) recomputed from every Parikh class (PM)."""
    n = (2,) * k
    t0 = time.perf_counter()
    by = pm_by_fibre(n)
    nclass = sum(len(v) for v in by.values())
    fs = {x: sum(v) for x, v in by.items()}
    CHK.eq(nclass, CLASSES2[k], f"PM: number of Parikh classes of (2^{k})")
    CHK.eq(sum(fs.values()), factorial(2 * k) // 2 ** k, f"PM: (2^{k}) total (2k)!/2^k")
    CHK.eq(len(fs), 5 ** (k - 1), f"PM: (2^{k}) every psi_2 vector of the box occurs")
    if k < 3:
        return
    CHK.eq(sum(1 for v in by.values() if len(v) == 1), RIGID2[k],
           f"PM: (2^{k}) single-class fibres = rigid vectors (Theorem A(ii), (iv))")
    e = EZ2[k]
    alt = {alt_psi2(n, True), alt_psi2(n, False)}
    CHK.ok(all(by[x] == [e] for x in alt), f"PM: (2^{k}) each alternating fibre is one class "
                                            f"of e(Z) = {e}")
    pmax = max(fs.values())
    CHK.ok(pmax == PSI2MAX2[k] and [x for x, v in fs.items() if v == pmax] == [(2,) * (k - 1)],
           f"PM: (2^{k}) largest psi_2 fibre {pmax}, unique at the centre")
    cen = sorted(by[(2,) * (k - 1)], reverse=True)
    CHK.ok(len(cen) == fib(k) and cen[0] == BESTCENTRAL2[k],
           f"PM: (2^{k}) central fibre: {len(cen)} classes (F_k), best {cen[0]}")
    R = R2[k]
    ge = [x for x, v in fs.items() if v >= R]
    with2 = [x for x in ge if 2 in x]
    multi = [x for x in ge if len(by[x]) > 1]
    CHK.ok(all(len(by[x]) == 1 for x in ge if 2 not in x),
           f"PM: (2^{k}) fibres >= R without an entry 2 are single classes")
    CHK.eq((len(ge), len(with2), len(multi)), FIBRES_GE_R[k] + (MULTI2[k],),
           f"PM: (2^{k}) fibres >= R: number, with an entry 2, with more than one class")
    top = sorted(((m, x) for x, v in by.items() for m in v if m >= e), reverse=True)
    if k == 3:
        CHK.ok(sorted(x for m, x in top) == [(0, 4), (2, 2), (2, 2), (4, 0)] and
               all(m == 6 for m, x in top), "PM: (2^3) four-way tie at 6")
    elif k == 4:
        CHK.ok([c for c in top if c[0] > e] == [(56, (2, 2, 2)), (56, (2, 2, 2))],
               "PM: (2^4) 56 > 53 at the two central classes")
    elif k == 5:
        CHK.ok([c for c in top if c[0] > e] == [(844, (2, 2, 2, 2))] and cen[1] == 698,
               "PM: (2^5) 844 > 840 at one central class; next central 698")
    else:
        CHK.ok({x for m, x in top} == alt and len(top) == 2 and all(m == e for m, x in top),
               f"PM: (2^{k}) C1-fin: only the alternating pair has size >= e(Z)")
        second = max(m for v in by.values() for m in v if m < e)
        at2 = sorted(x for x, v in by.items() for m in v if m == second)
        endrel = sorted({(2,) + alt_psi2(n, True)[1:], alt_psi2(n, True)[:-1] + (2,),
                         (2,) + alt_psi2(n, False)[1:], alt_psi2(n, False)[:-1] + (2,)})
        CHK.ok(second == R and at2 == endrel,
               f"PM: (2^{k}) second largest = the four end-relaxed classes ({second})")
    note(f"PM (2^{k}): {nclass} classes, {len(fs)} fibres, {len(multi)} of the {len(ge)} fibres "
         f">= R have more than one class; {time.perf_counter() - t0:.1f} s")


def pm_3k(k):
    """(3^k) from every Parikh class (PM): psi_2 maximum, largest classes, the fibre v_k."""
    n = (3,) * k
    t0 = time.perf_counter()
    by = pm_by_fibre(n)
    fs = {x: sum(v) for x, v in by.items()}
    nclass = sum(len(v) for v in by.values())
    CHK.eq(sum(fs.values()), multinomial(n), f"PM: (3^{k}) total")
    pmax = max(fs.values())
    CHK.ok(pmax == PSI2MAX3[k][0] and {x for x, v in fs.items() if v == pmax} == PSI2MAX3[k][1],
           f"PM: (3^{k}) largest psi_2 fibre {pmax}")
    CHK.ok(all(by[x] == [EZ3[k]] for x in (alt_psi2(n, True), alt_psi2(n, False))),
           f"PM: (3^{k}) each alternating fibre is one class of e(Z) = {EZ3[k]}")
    sizes = sorted({m for v in by.values() for m in v}, reverse=True)
    at = [sorted(x for x, v in by.items() for m in v if m == s) for s in sizes[:3]]
    if k == 3:
        CHK.ok(sizes[0] == 20 == EZ3[3] and len(at[0]) == 6,
               f"PM: (3^3) largest class 20 = e(Z), attained by 6 classes")
    else:
        CHK.ok(sizes[0] == LARGEST3[k][0] and set(at[0]) == LARGEST3[k][1] and
               len(at[0]) == len(LARGEST3[k][1]),
               f"PM: (3^{k}) largest class {sizes[0]} at {at[0]}")
    if k == 6:
        CHK.ok(sizes[:3] == [8568624, 8205714, 8063656] and
               at[1] == [(3, 9, 0, 9, 3), (6, 0, 9, 0, 6)] and
               at[2] == sorted({alt_psi2(n, True), alt_psi2(n, False)}),
               f"PM: (3^6) order at the top {sizes[:3]}")
    if k in V3_CLASSES:
        v = tuple(3 if i % 2 == 0 else 6 for i in range(k - 1))
        CHK.eq((len(by[v]), max(by[v])), V3_CLASSES[k], f"PM: (3^{k}) classes in v_k and the best")
    note(f"PM (3^{k}): {nclass} classes, {len(fs)} fibres, largest {sizes[0]} at {at[0]}; "
         f"{time.perf_counter() - t0:.1f} s")


def sec_PM(pool):
    head("PM every Parikh class by the merged prefix-matrix DP (independent of MITM/SPLIT/TR)")
    t0 = time.perf_counter()
    # validation: PM = LIT on every class of these contents (full keys, not only psi_2)
    for cont in ((2, 2, 2), (2, 2, 2, 2), (3, 3, 3), (2, 2, 1, 2), (1, 2, 2, 1, 2), (2, 3, 2, 3),
                 (2, 1, 2, 2, 1), (1, 1, 1, 1, 1, 1), (1, 4, 4, 1), (4, 1, 3, 2)):
        _, full = pm_unpack(cont)
        pmc = Counter()
        for S, m in pm_classes(cont).items():
            pmc[full(S)] += m
        CHK.eq(pmc, lit_classes(cont), f"PM = LIT on every class of {cont}")
    kmax2 = 9 if FULL else 7
    for k in range(2, kmax2 + 1):
        pm_2k(k)
    kmax3 = 6 if FULL else 5
    for k in range(3, kmax3 + 1):
        pm_3k(k)
    # C4 for every {1,2}-content with 4 <= k <= 6 [8] letters, one per reversal pair
    kmax4 = 8 if FULL else 6
    for k in range(4, kmax4 + 1):
        t1 = time.perf_counter()
        reps, seen = [], set()
        for n in product((1, 2), repeat=k):
            if tuple(reversed(n)) in seen:
                continue
            seen.add(n)
            reps.append(n)
        res = list(pool.map(pm_c4, reps, chunksize=1)) if pool is not None else \
            [pm_c4(n) for n in reps]
        kinds = Counter(kind for _, kind, _, _, _ in res)
        CHK.ok(all(ok for *_, ok in res), f"PM C4, k = {k}: totals and alternating fibres")
        CHK.eq([(n, kind) for n, kind, _, _, _ in res if kind != c4_rule(n)], [],
               f"PM C4 rule, k = {k}")
        CHK.eq((len(reps), kinds["ALT"], kinds["BEATEN"], kinds["TIE"]), C4_TABLE[k] + (0,),
               f"PM C4 counts, k = {k}")
        note(f"PM C4 k = {k}: {len(reps)} contents, ALT {kinds['ALT']}, not ALT "
             f"{kinds['BEATEN']}, TIE {kinds['TIE']}; {time.perf_counter() - t1:.1f} s")
    note(f"{time.perf_counter() - t0:.1f} s")


# ---------------------------------------------------------------------------
# [CF] central psi_2 fibres by TR (explore-r7-general Table 3 and its growth logs)
# ---------------------------------------------------------------------------


def sec_CF():
    head("CF central psi_2 fibres of (2^k) and the fibre v_k of (3^k) by TR (Table 3)")
    t0 = time.perf_counter()
    k2 = 26 if FULL else 20
    prev = None
    for k in range(2, k2 + 1):
        n = (2,) * k
        C = fibre_size_tr(n, (2,) * (k - 1))
        Wk = Fraction(factorial(2 * k), 2 ** k)
        CHK.eq(C, C2[k], f"TR: central fibre of (2^{k})")
        CHK.eq(dec(Fraction(C, EZ2[k])), C2_RATIO[k], f"(2^{k}): C/e(Z) to 6 decimals")
        if k >= 4:
            CHK.eq(dec((C / Wk) / prev), C2_STEP[k], f"(2^{k}): step of C/W to 6 decimals")
        prev = C / Wk
    # cross-check with [C1] (MITM, k <= 12) and [PM] (k <= 9), which assert PSI2MAX2 as the
    # largest psi_2 fibre of (2^k), and with [T3] / [PM] for (3^k): the tables agree
    CHK.ok(all(C2[k] == PSI2MAX2[k] for k in range(3, 13)) and
           all(C3[k] == PSI2MAX3[k][0] for k in range(3, 7)),
           "TR central fibres = the psi_2 maxima of [C1], [PM], [T3] ((2^k) k <= 12, (3^k) k <= 6)")
    # B/e(Z) of Table 3 for (2^k), k = 4..12 (B = the best central class, asserted in [C1])
    b2 = {4: "1.056604", 5: "1.004762", 6: "0.825453", 7: "0.804926", 8: "0.662050",
          9: "0.648644", 10: "0.532890", 11: "0.522545", 12: "0.429171"}
    CHK.eq({k: dec(Fraction(BESTCENTRAL2[k], EZ2[k])) for k in b2}, b2, "(2^k): B/e(Z), k = 4..12")
    k3 = 15 if FULL else 10
    prev = None
    for k in range(2, k3 + 1):
        n = (3,) * k
        v = tuple(3 if i % 2 == 0 else 6 for i in range(k - 1))
        C = fibre_size_tr(n, v)
        Wk = Fraction(factorial(3 * k), 6 ** k)
        CHK.eq(C, C3[k], f"TR: fibre v_k of (3^{k})")
        CHK.eq(dec(Fraction(C, EZ3[k])), C3_RATIO[k], f"(3^{k}): C/e(Z) to 6 decimals")
        if k >= 4:
            CHK.eq(dec((C / Wk) / prev), C3_STEP[k], f"(3^{k}): step of C/W to 6 decimals")
        prev = C / Wk
    # the classes in v_k (SPLIT), k = 4..6 [7], and B/e(Z)
    b3 = {4: "1.158610", 5: "1.086272", 6: "0.831044", 7: "0.826910"}
    for k in range(4, 8 if FULL else 7):
        n = (3,) * k
        v = tuple(3 if i % 2 == 0 else 6 for i in range(k - 1))
        sizes = list(classes_in_fibre(n, v).values())
        CHK.eq((len(sizes), max(sizes), sum(sizes)), V3_CLASSES[k] + (C3[k],),
               f"SPLIT: (3^{k}) classes in v_k, the best, the total")
        CHK.eq(dec(Fraction(max(sizes), EZ3[k])), b3[k], f"(3^{k}): B/e(Z)")
    note(f"(2^k): C, C/e(Z) and the C/W step for k <= {k2}; (3^k): for k <= {k3}; "
         f"{time.perf_counter() - t0:.1f} s")
    # the transfer caches grow large for (3^k), k >= 12; free them for the later sections
    for cached in (step, last_weight, lambdas_by_area, lambdas, _weak_compositions):
        cached.cache_clear()


# ---------------------------------------------------------------------------
# [T3] (3^k)
# ---------------------------------------------------------------------------


def sec_T3(pool):
    head("T3 (3^k): end relaxations, largest psi_2 fibres and largest classes")
    t0 = time.perf_counter()
    T3 = one_end_table(3, 10)
    for k in range(3, 11):
        n = (3,) * k
        CHK.eq(fibre_size_tr(n, alt_psi2(n)), EZ3[k], f"TR e(Z(3^{k}))")
        # one-end: TR against INS for every area at the left end
        for A in range(9):
            x = (A,) + alt_psi2(n)[1:]
            CHK.eq(fibre_size_tr(n, x), d_area(T3, 3, k, A), f"TR = INS D_{k}(S_{A})")
        if k < 4:
            continue
        # best over relaxations of the two end edges (both patterns, any areas, not alternating)
        best, arg = 0, []
        for first_full in (True, False):
            base = alt_psi2(n, first_full)
            table = end_relax_table(n, first_full)
            if first_full and k <= 6:
                for (A, B) in ((0, 0), (6, 3), (3, 6), (9, 9)):
                    x = (A,) + base[1:-1] + (B,)
                    CHK.eq(table[(A, B)], fibre_size_tr(n, x), f"end table = TR at {x}")
            for (A, B), s in table.items():
                x = (A,) + base[1:-1] + (B,)
                if x == base:
                    continue
                if s > best:
                    best, arg = s, [x]
                elif s == best:
                    arg.append(x)
        CHK.eq(best, TWO3[k], f"(3^{k}) best relaxation of the end edges")
        CHK.eq(dec(Fraction(best, EZ3[k])), TWO3_RATIO[k], f"(3^{k}) two-end ratio")
    # (3^5): the two-end class (6,0,9,3) has 66024 words
    CHK.eq(fibre_size_tr((3,) * 5, (6, 0, 9, 3)), 66024, "(3^5) class (6,0,9,3)")
    # largest psi_2 fibres and largest classes
    kmax = 6 if FULL else 5
    for k in range(3, kmax + 1):
        n = (3,) * k
        floor = EZ3[k] if k >= 4 else 0
        big, total, nfib, best, best_x = mitm_all(n, floor, pool if k >= 6 else None)
        CHK.eq(total, multinomial(n), f"(3^{k}) fibre sum")
        CHK.ok(best == PSI2MAX3[k][0] and set(best_x) == PSI2MAX3[k][1],
               f"(3^{k}) largest psi_2 fibre {best} at {best_x}")
        if k < 4:
            continue
        jobs = [(n, x) for s, x in big]
        results = pool.map(split_job, jobs, chunksize=8) if (pool is not None and k >= 6) \
            else map(split_job, jobs)
        classes = []
        for x, sizes in results:
            classes += [(s, x) for s in sizes]
        classes.sort(reverse=True)
        top = classes[0][0]
        at = {x for s, x in classes if s == top}
        CHK.ok(top == LARGEST3[k][0] and at == LARGEST3[k][1] and
               sum(1 for s, x in classes if s == top) == len(LARGEST3[k][1]),
               f"(3^{k}) largest class {top} at {sorted(at)}")
        if k == 6:
            sizes = sorted({s for s, x in classes}, reverse=True)
            second = sorted(x for s, x in classes if s == sizes[1])
            third = sorted(x for s, x in classes if s == sizes[2])
            CHK.ok(sizes[:3] == [8568624, 8205714, 8063656] and
                   second == [(3, 9, 0, 9, 3), (6, 0, 9, 0, 6)] and
                   third == sorted({alt_psi2(n, True), alt_psi2(n, False)}),
                   f"(3^6) order at the top {sizes[:3]}, second {second}, third {third}")
        note(f"(3^{k}): {len(big)} fibres >= e(Z) split; largest class {top} at {sorted(at)}")
    note(f"{time.perf_counter() - t0:.1f} s")


# ---------------------------------------------------------------------------
# [R] Theorem A(iv): rigid counts
# ---------------------------------------------------------------------------


def sec_R():
    head("R  Theorem A(iv): rigid psi_2 vectors of (2^k)")
    T = [[1 if rigid_rules(2, 2, 2, u, v) else 0 for v in range(5)] for u in range(5)]
    vec = [1] * 5
    counts = {2: 5}
    for k in range(3, 13):
        vec = [sum(T[u][v] * vec[v] for v in range(5)) for u in range(5)]
        counts[k] = sum(vec)
    CHK.eq([counts[k] for k in range(3, 9)], [20, 86, 364, 1548, 6576, 27944],
           "rigid counts of (2^k), k = 3..8")
    for k in range(3, 8):
        brute = sum(1 for x in product(range(5), repeat=k - 1)
                    if all(rigid_rules(2, 2, 2, x[i], x[i + 1]) for i in range(k - 2)))
        CHK.eq(brute, counts[k], f"rigid count of (2^{k}) by brute force over vectors")
    CHK.eq(sorted((u, v) for u in range(5) for v in range(5) if not T[u][v]),
           [(1, 2), (2, 1), (2, 2), (2, 3), (3, 2)], "the five non-rigid pairs of (2,2,2)")
    # the generating function t(1-t)(1+2t)/(1-4t-2t^2+4t^3): a_k = 4a_{k-1}+2a_{k-2}-4a_{k-3}
    a = {1: 1, 2: 5}
    a.update(counts)
    CHK.ok(all(a[k] == 4 * a[k - 1] + 2 * a[k - 2] - 4 * a[k - 3] for k in range(4, 13)),
           "recurrence of the rigid counts")
    note(f"counts k = 3..12: {[counts[k] for k in range(3, 13)]}")


# ---------------------------------------------------------------------------
# [E] Theorem E data
# ---------------------------------------------------------------------------


def largest_classes(classes: Counter):
    top = max(classes.values())
    return top, sorted(k for k, v in classes.items() if v == top)


def binom0(N, k):
    return comb(N, k) if 0 <= k <= N else 0


def h1_centre(a, c):
    """proof-h1-centre.md Theorem 1(ii), closed form: (M+1) C(M, floor(a/2)) C(n-M, ceil(a/2))."""
    n = a + c
    M = n // 2
    return (M + 1) * binom0(M, a // 2) * binom0(n - M, (a + 1) // 2)


def h1_double_sum(a, c):
    """proof-h1-centre.md Theorem 1(ii), double sum: sum C(p+q,p)^2 C(n-2p-2q, a-2p)."""
    n = a + c
    return sum(binom0(p + q, p) ** 2 * binom0(n - 2 * p - 2 * q, a - 2 * p)
               for p in range(a // 2 + 1) for q in range(c // 2 + 1))


def p_a2c(a, c, x, y) -> int:
    """GAP summed over z: P(x, y) for content (a,2,c), with x = 2a0 + a1 and y = c1 + 2c2."""
    tot = 0
    for a0 in range(x // 2 + 1):
        a1 = x - 2 * a0
        a2 = a - a0 - a1
        if a2 < 0:
            continue
        for c2 in range(y // 2 + 1):
            c1 = y - 2 * c2
            c0 = c - c1 - c2
            if c0 < 0:
                continue
            tot += comb(a0 + c0, a0) * comb(a1 + c1, a1) * comb(a2 + c2, a2)
    return tot


def sec_E():
    head("E  Theorem E: ties, threshold sequence, (3,2,7), (6,2,10), (2,2,2), Target 5")
    t0 = time.perf_counter()
    # ties c(c-1) = a(a+c-1), 1 <= a <= c
    ties = []
    for a in range(1, 100001):
        D = 5 * a * a - 2 * a + 1
        s = isqrt(D)
        if s * s == D and (a + 1 + s) % 2 == 0:
            c = (a + 1 + s) // 2
            if c >= a and c * (c - 1) == a * (a + c - 1):
                ties.append((a, c))
    fibties = [(fib(n) * fib(n + 1), fib(n) * fib(n + 2)) for n in range(1, 30, 2)]
    CHK.eq(ties, [t for t in fibties if t[0] <= 100000], "ties = (F_nF_{n+1}, F_nF_{n+2}), n odd")
    CHK.eq(ties[:5], [(1, 2), (6, 10), (40, 65), (273, 442), (1870, 3026)], "P8 tie sequences")
    for a, c in ties[:2]:
        cl = a2c_classes(a, c)
        top, at = largest_classes(cl)
        CHK.ok(top == comb(a + c, a) and len(at) == 5, f"tie ({a},2,{c}): five maximisers {at}")
    # threshold: largest c with B = tau
    thr = []
    for a in range(1, 20):
        c = a
        while (c + 1) * c <= a * (a + c):    # criterion at c + 1: (c+1)c <= a(a+c)
            c += 1
        thr.append(c)
    CHK.eq(thr, [2, 3, 5, 6, 8, 10, 11, 13, 14, 16, 18, 19, 21, 22, 24, 26, 27, 29, 31],
           "threshold sequence by the criterion, a = 1..19")
    amax = 19 if FULL else 10
    for a in range(1, amax + 1):
        good = True
        for c in range(a, thr[a - 1] + 2):
            top = max(a2c_classes(a, c).values())
            good &= (top == comb(a + c, a)) == (c <= thr[a - 1])
        CHK.ok(good, f"threshold for a = {a} by direct class counts (GAP)")
    # (3,2,7): Fig 1
    cl = a2c_classes(3, 7)
    CHK.eq(cl, Counter(ternary_words_xyz(3, 2, 7)), "GAP = LIT on (3,2,7)")
    top, at = largest_classes(cl)
    CHK.ok(top == 140 and comb(10, 3) == 120 and at == [(0, 12, 0), (6, 2, 6)],
           f"(3,2,7): B = 140 > tau = 120 at {at}")
    P = fibres_of(cl)
    pm = max(P.values())
    pat = sorted(x for x, v in P.items() if v == pm)
    zs: dict = {}
    for (x, y, z), m in cl.items():
        zs.setdefault((x, y), {})[z] = m
    single = all(len(zs[(x, y)]) == 1 for (x, y) in zs if x in (0, 6) or y in (0, 14))
    CHK.ok(pat == [(3, 7)] and single, f"(3,2,7): psi_2 maximum {pm} at {pat}; boundary single")
    note(f"Fig 1 (3,2,7): psi_2 max {pm} at the centre (3,7); central fibre by z: "
         f"{sorted(zs[(3, 7)].items())}")
    for x in range(7):
        note(f"Fig 1 row x = {x}: {[P[(x, y)] for y in range(15)]}")
    # (6,2,10): five maximisers of size 8008; (2,2,2): four of size 6
    top, at = largest_classes(a2c_classes(6, 10))
    CHK.ok(top == 8008 == comb(16, 6) and at == [(0, 18, 0), (0, 20, 0), (6, 10, 0), (12, 0, 0),
                                                  (12, 2, 12)], f"(6,2,10): {top} at {at}")
    top, at = largest_classes(a2c_classes(2, 2))
    CHK.ok(top == 6 and at == [(0, 4, 0), (2, 2, 0), (2, 2, 2), (4, 0, 0)], f"(2,2,2): {at}")
    # Target 5: D(x) = P(x, 2a - x) for (4,2,4)
    P = fibres_of(a2c_classes(4, 4))
    D = [P[(x, 8 - x)] for x in range(9)]
    PL = fibres_of(Counter(ternary_words_xyz(4, 2, 4)))
    CHK.eq(D, [PL[(x, 8 - x)] for x in range(9)], "Target 5: GAP = LIT on (4,2,4)")
    CHK.eq(D[:5], [70, 40, 96, 88, 180], "Target 5: D(x) for (4,2,4) begins 70, 40, 96, 88, 180")
    CHK.ok(D == D[::-1] and max(D) == D[4] and D.count(D[4]) == 1,
           "(4,2,4): D symmetric, unique maximum at the centre")
    note(f"Target 5, (4,2,4): D(0..8) = {D}")
    # H1 (CONJECTURE in the design; PROVED in proof-h1-centre.md, Phase 2a): for (a,2,c),
    # (a,c) != (1,1), the centre (a, c) is the unique largest psi_2 fibre.  Range of design
    # section 5: a <= c with a + c <= 50 and a > c with a + c <= 30 [default: a + c <= 30 both
    # ways], plus (40,2,65), (65,2,40) [full].
    smax = 50 if FULL else 30
    bad, nh = [], 0
    conts = [(a, s - a) for s in range(3, smax + 1) for a in range(1, s)
             if (a, s - a) != (1, 1) and (a <= s - a or s <= 30)]
    if FULL:
        conts += [(40, 65), (65, 40)]
    badv = []
    for a, c in conts:
        P = psi2_packed(a, 2, c)
        mx = max(max(row) for row in P)
        at = [(x, y) for x in range(2 * a + 1) for y in range(2 * c + 1) if P[x][y] == mx]
        nh += 1
        if at != [(a, c)]:
            bad.append((a, c, at))
        if not P[a][c] == h1_centre(a, c) == h1_double_sum(a, c):
            badv.append((a, c))
    CHK.eq(bad, [], f"H1: the centre is the unique largest psi_2 fibre on {nh} contents (PSI)")
    # proof-h1-centre.md Theorem 1(ii) (Phase 2a): the centre value, both forms, on the same range
    CHK.eq(badv, [], f"H1 centre value: P(a,c) = (M+1)C(M,[a/2])C(n-M,[(a+1)/2]) = double sum, "
                     f"{nh} contents")
    note(f"H1 and its centre value on {nh} contents (a <= c: a + c <= {smax}; a > c: a + c <= 30"
         f"{'; and (40,2,65), (65,2,40)' if FULL else ''})")
    # proof-h1-centre.md: the quoted numbers.  (1,2,1) ties; the a = c sequences (OEIS queries);
    # Corollary 2's value; D(4..6) at a = 6; D(59)/D(60) at a = 60; Andrews-Paule (1.1).
    P = psi2_packed(1, 2, 1)
    CHK.eq(sorted((x, y) for x in range(3) for y in range(3) if P[x][y] == 2),
           [(0, 2), (1, 1), (2, 0)],
           "(1,2,1): the three antidiagonal points tie at 2 (and nothing else reaches 2)")
    seq = [h1_centre(a, a) for a in range(11)]
    CHK.eq(seq[:7], [1, 2, 12, 36, 180, 600, 2800],
           "P(a,a), a = 0..6: 1, 2, 12, 36, 180, 600, 2800")
    CHK.eq(seq[1::2], [2, 36, 600, 9800, 158760], "P(a,a), a odd: 2, 36, 600, 9800, 158760")
    CHK.eq(seq[0::2], [1, 12, 180, 2800, 44100, 698544], "P(a,a), a even: 1, 12, ..., 698544")
    CHK.eq([psi2_packed(a, 2, a)[a][a] for a in range(1, 11)], seq[1:], "P(a,a) by PSI, a <= 10")
    amax_cor = 60
    CHK.ok(all(h1_centre(a, a) == (a + 1) * comb(a, a // 2) ** 2 == h1_double_sum(a, a)
               for a in range(1, amax_cor + 1)),
           f"Corollary 2: P(a,a) = (a+1)C(a,[a/2])^2 = double sum, a <= {amax_cor}")
    D6 = [p_a2c(6, 6, x, 12 - x) for x in range(13)]
    CHK.eq(D6, [psi2_packed(6, 2, 6)[x][12 - x] for x in range(13)], "GAP = PSI on (6,2,6)")
    CHK.ok(D6[4:7] == [1620, 1608, 2800] and 2800 == 7 * 20 ** 2,
           "a = 6: D(4) = 1620 > D(5) = 1608 < D(6) = 2800 = 7*20^2")
    d59, d60 = p_a2c(60, 60, 59, 61), p_a2c(60, 60, 60, 60)
    CHK.ok(d60 == 61 * comb(60, 30) ** 2 == h1_centre(60, 60) and
           dec(Fraction(d59, d60), 4) == "0.8722",
           f"a = 60: D(60) = 61 C(60,30)^2 and D(59)/D(60) = {dec(Fraction(d59, d60), 4)}")
    Nmax = 59 if FULL else 30
    CHK.ok(all(h1_double_sum(2 * N, 2 * N) == (2 * N + 1) * comb(2 * N, N) ** 2
               for N in range(Nmax + 1)),
           f"Andrews-Paule (1.1): double sum at a = c = 2N is (2N+1)C(2N,N)^2, N <= {Nmax}")
    note(f"a = 6: D = {D6}; a = 60: D(59)/D(60) = {float(Fraction(d59, d60)):.6f}")
    note(f"{time.perf_counter() - t0:.1f} s")


# ---------------------------------------------------------------------------
# [B] (2,b,2)
# ---------------------------------------------------------------------------


def dist2b2(b) -> Counter:
    """PROF: Counter (x,y,z) -> class size for content (2,b,2).  The two 1's lie in the gaps
    p <= p+q of the 2-chain, the two 3's in the gaps r' <= r'+q'; A_l = #1-gaps < l,
    C_l = #3-gaps >= l, so z = sum over (1-gap s, 3-gap t) of max(0, t - s)."""
    out: Counter = Counter()
    Cs = []
    for rp in range(b + 1):
        for qp in range(b - rp + 1):
            Cs.append((qp + 2 * rp, rp, rp + qp))
    for p in range(b + 1):
        for q in range(b - p + 1):
            x = 2 * b - 2 * p - q
            s1, s2 = p, p + q
            for y, t1, t2 in Cs:
                z = (max(0, t1 - s1) + max(0, t2 - s1) + max(0, t1 - s2) + max(0, t2 - s2))
                # gap weight: product over gaps of C(#1 + #3, #1)
                w = 1
                if s1 == s2:
                    if t1 == t2:
                        if t1 == s1:
                            w = 6
                    elif t1 == s1 or t2 == s1:
                        w = 3
                else:
                    if t1 == t2:
                        if t1 == s1 or t1 == s2:
                            w = 3
                    else:
                        w = (2 if t1 in (s1, s2) else 1) * (2 if t2 in (s1, s2) else 1)
                out[(x, y, z)] += w
    return out


def rho0(b, x, y) -> int:
    """CS: the z = 0 closed sum for (2,b,2), x, y >= 1 (explore-r7-ternary.md section 4.4),
    with the inner sum over r' in closed form."""
    tot = 0
    for L in range(max(b - x, 1), (2 * b - x) // 2 + 1):
        q = 2 * (b - L) - x
        r = x - (b - L)
        if q < 0 or r < 0 or L > b - 1:
            continue
        aL = 1 if q >= 1 else 2
        lo = max(0, y - L)
        hi = y // 2
        if lo > hi:
            continue
        tot += hi - lo + 1
        if y - L >= 0:                       # r' = y - L is in range: C_L = 1 or 2
            CL = 2 if y == 2 * L else 1
            tot += comb(aL + CL, aL) - 1
    return tot


def rho0_fast(b, x, y) -> int:
    """CS with the sum over L in closed form as well (validated against rho0 and PROF)."""
    Lmin = max(b - x, 1, (y + 1) // 2)
    Lmax = min((2 * b - x) // 2, b - 1)
    if Lmin > Lmax:
        return 0
    tot = (Lmax - Lmin + 1) * (y // 2 + 1)
    u = min(Lmax, y - 1)                      # subtract sum_{L = Lmin..u} (y - L)
    if u >= Lmin:
        m = u - Lmin + 1
        tot -= m * y - (Lmin + u) * m // 2
    v = min(Lmax, y)                          # the terms r' = y - L, L = Lmin..v
    if v >= Lmin:
        tot += v - Lmin + 1                   # C(1+1, 1) - 1 = 1 when a_L = C_L = 1
        special = set()
        if y % 2 == 0:
            special.add(y // 2)
        if x % 2 == 0:
            special.add(b - x // 2)
        for L in special:
            if Lmin <= L <= v:
                aL = 2 if 2 * (b - L) == x else 1
                CL = 2 if 2 * L == y else 1
                tot += comb(aL + CL, aL) - 2
    return tot


def mstar(b):
    """proof-2b2.md: M*(b) = floor((b^2+9b+36)/14)."""
    return (b * b + 9 * b + 36) // 14


def f2b2(d):
    """proof-2b2.md: f(d) = (d-2)(d+1)/2 (an integer)."""
    return (d - 2) * (d + 1) // 2


def v2b2(b, S):
    """proof-2b2.md: V(S) = floor((S+2)^2/4) - f(2S-b)."""
    return (S + 2) ** 2 // 4 - f2b2(2 * S - b)


# proof-2b2.md Table 3.4: b = 14q + r; the S with V(S) = M*(b) are 8q + s, s in TABLE34[r]
TABLE34 = {0: (0, 1), 1: (1,), 2: (2,), 3: (2,), 4: (3,), 5: (3, 4), 6: (4,), 7: (4, 5), 8: (5,),
           9: (6,), 10: (6,), 11: (7,), 12: (7, 8), 13: (8,)}
# proof-2b2.md section 4: the z = 0 maximisers (x, y) for 16 <= b <= 20
Z0MAX_2B2 = {16: [(8, 12), (10, 10), (12, 8)], 17: [(10, 10), (10, 12), (12, 10)],
             18: [(10, 12), (12, 10), (12, 12)],
             19: [(10, 12), (10, 14), (12, 10), (12, 12), (14, 10)], 20: [(12, 12)]}


def rho0_thm(b, x, y) -> int:
    """proof-2b2.md Theorem 1(ii) as stated: c(d) + N_d + beta (any cell of [0,2b]^2)."""
    X, Y = x // 2, y // 2
    eps, eta = x - 2 * X, y - 2 * Y
    d = x + y - b
    cd = sum(max(0, Y - max(0, d - u) + 1) for u in range(X + 1))
    Nd = sum(1 for u in range(X + 1) if 0 <= d - u <= Y)
    beta = ((eps == 0 and X <= d <= X + Y) + (eta == 0 and Y <= d <= X + Y) +
            2 * (eps == 0 and eta == 0 and d == X + Y))
    return cd + Nd + beta


def rule_2b2(b):
    """proof-2b2.md Theorem 1(iii), b >= 20: the largest classes (2X, 2Y, 0) with |X-Y| <= 1 and
    V(X+Y) = M*(b), and their reversal images (2b-2X, 2b-2Y, 4b-4X-4Y)."""
    out = set()
    for S in range(2 * b + 1):
        if v2b2(b, S) == mstar(b):
            for X in range(S + 1):
                if abs(2 * X - S) <= 1:
                    Y = S - X
                    out.add((2 * X, 2 * Y, 0))
                    out.add((2 * b - 2 * X, 2 * b - 2 * Y, 4 * b - 4 * X - 4 * Y))
    return sorted(out)


def M0(b):
    best, arg = 0, []
    for x in range(1, 2 * b + 1):
        for y in range(1, 2 * b - x + 1):    # z = 0 needs x + y <= 2b
            v = rho0_fast(b, x, y)
            if v > best:
                best, arg = v, [(x, y)]
            elif v == best:
                arg.append((x, y))
    return best, sorted(arg)


def sec_B():
    head("B  (2,b,2): largest Parikh classes, z = 0 closed sum, M0(b), Fig 5 data")
    t0 = time.perf_counter()
    for b in range(1, 8):
        CHK.eq(dist2b2(b), Counter(ternary_words_xyz(2, b, 2)), f"PROF = LIT for (2,{b},2)")
    bmax = 40 if FULL else 20
    largest = []
    for b in range(1, bmax + 1):
        rho = dist2b2(b)
        CHK.eq(sum(rho.values()), multinomial((2, b, 2)), f"(2,{b},2) total")
        top = max(rho.values())
        at = sorted(k for k, v in rho.items() if v == top)
        largest.append(top)
        CHK.eq(len(at), NMAX_2B2[b - 1], f"(2,{b},2) number of largest classes")
        lowest = [(x, y, z) for x, y, z in at if z == max(0, 2 * x + 2 * y - 4 * b)]
        if b == 4:
            CHK.eq(at, [(4, 4, 4)], "(2,4,2): single central maximiser (4,4,4)")
        else:
            CHK.ok(lowest, f"(2,{b},2): a maximiser with z = 0 or its reversal image")
            if b >= 3:
                CHK.ok(any(0 < x < 2 * b and 0 < y < 2 * b for x, y, z in lowest),
                       f"(2,{b},2): such a maximiser is interior")
        # proof-2b2.md (Phase 2b).  Theorem 1(i) and Remark 2: thin classes (z, z' >= 1, where
        # z' = |w|_321 = z - 2x - 2y + 4b) have at most b + 4 words; the largest thin class.
        thin = {key: v for key, v in rho.items()
                if key[2] >= 1 and key[2] - 2 * key[0] - 2 * key[1] + 4 * b >= 1}
        tmax = max(thin.values(), default=0)
        tat = sorted(key for key, v in thin.items() if v == tmax)
        want_t = ((b + 4, [(b, b, b)]) if b % 2 == 0 else
                  (4, [(1, 1, 1)]) if b == 1 else
                  (b + 3, [(b - 1, b + 1, b - 1), (b, b, b), (b + 1, b - 1, b - 1)]))
        CHK.ok(tmax <= b + 4 and (tmax, tat) == want_t,
               f"(2,{b},2): thin classes <= b + 4; largest thin {tmax} at {tat}")
        # Theorem 1(v-b): every largest class has z = 0 or z' = 0 iff b in {1, 3} or b >= 6
        thin_top = [key for key in at if key in thin]
        want_tt = {2: [(2, 2, 2)], 4: [(4, 4, 4)], 5: [(4, 6, 4), (5, 5, 5), (6, 4, 4)]}.get(b, [])
        CHK.eq(thin_top, want_tt, f"(2,{b},2): thin classes among the largest")
        if b >= 20:     # Theorem 1(iii): M(b) = M*(b) and the maximiser set
            CHK.ok(top == mstar(b) and at == rule_2b2(b),
                   f"(2,{b},2): largest {top} = M*(b), maximisers = Theorem 1(iii)")
        if b in Z0MAX_2B2:
            CHK.eq(sorted((x, y) for x, y, z in at if z == 0), Z0MAX_2B2[b],
                   f"(2,{b},2): the z = 0 maximisers of section 4")
            CHK.eq(at, sorted({(x, y, 0) for x, y in Z0MAX_2B2[b]} |
                              {(2 * b - x, 2 * b - y, 4 * b - 2 * x - 2 * y)
                               for x, y in Z0MAX_2B2[b]}),
                   f"(2,{b},2): the maximisers are those and their reversal images")
        if b == 21:
            CHK.ok({(28, 30, 32), (30, 28, 32), (30, 30, 36)} <= set(at),
                   "(2,21,2): (28,30,32), (30,28,32), (30,30,36) are largest classes")
        if b <= 14 or (FULL and b <= 30):
            bad = [(x, y) for x in range(1, 2 * b + 1) for y in range(1, 2 * b + 1)
                   if not rho.get((x, y, 0), 0) == rho0(b, x, y) == rho0_fast(b, x, y)]
            CHK.eq(bad, [], f"CS (loop and closed form) = PROF on every z = 0 cell of (2,{b},2)")
            # proof-2b2.md Theorem 1(ii) as stated, every cell, and its z' = 0 clause
            bad = [(x, y) for x in range(2 * b + 1) for y in range(2 * b + 1)
                   if rho.get((x, y, 0), 0) != rho0_thm(b, x, y) or
                   rho.get((x, y, 2 * x + 2 * y - 4 * b), 0) * (2 * x + 2 * y >= 4 * b) !=
                   rho0_thm(b, 2 * b - x, 2 * b - y) * (2 * x + 2 * y >= 4 * b)]
            CHK.eq(bad, [], f"(2,{b},2): Theorem 1(ii) of proof-2b2.md on every cell")
        if b >= 5:
            CHK.eq(M0(b)[0], top, f"(2,{b},2): largest class = M0(b)")
        # Fig 5 / Thm D(iii): D(x) = P(x, 2b - x) by the closed formula and by PROF
        if b in (8, 9):
            P = Counter()
            for (x, y, z), m in rho.items():
                P[(x, y)] += m

            def nv(v):
                return v // 2 - max(0, v - b) + 1

            D = [P[(x, 2 * b - x)] for x in range(2 * b + 1)]
            CHK.eq(D, [nv(x) ** 2 + 3 * nv(x) + 2 * (x % 2 == 0) for x in range(2 * b + 1)],
                   f"D(iii) antidiagonal formula, b = {b}")
            note(f"Fig 5 data, (2,{b},2): D(0..{2 * b}) = {D}")
    CHK.eq(largest, LARGEST_2B2[:bmax], f"largest class of (2,b,2), b = 1..{bmax}")
    CHK.eq(largest[:10], [6, 6, 7, 8, 8, 11, 11, 13, 16, 16], "P8: (2,b,2) largest classes")
    # proof-2b2.md Theorem 1(iii), (v-a): M(b) = M*(b) fails exactly at b in {1..9, 11, 12, 14, 15}
    CHK.eq([b for b in range(1, bmax + 1) if largest[b - 1] != mstar(b)],
           [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 14, 15],
           f"M(b) = M*(b) fails exactly at b in {{1..9, 11, 12, 14, 15}}, b <= {bmax}")
    # Lemma 3.4: g(S*) = (b^2+9b+36)/14 with S* = (4b+4)/7; V(S) <= M*(b), equality only for
    # |S - S*| < 3/4; Table 3.4 (the S with V(S) = M*(b)); 2, 4 or 6 largest classes, 6 iff
    # b mod 14 in {0, 5, 7, 12}; the kappa identity of Theorem 1(iv).  b <= 400 (pure arithmetic).
    kappa = {0: Fraction(2), 1: Fraction(16, 7), 2: Fraction(17, 7), 3: Fraction(17, 7),
             4: Fraction(16, 7), 5: Fraction(2), 6: Fraction(18, 7)}
    bad34 = []
    for b in range(1, 401):
        Ss = Fraction(4 * b + 4, 7)
        g = (Ss + 2) ** 2 / 4 - (2 * Ss - b - 2) * (2 * Ss - b + 1) / 2
        eqS = [S for S in range(2 * b + 1) if v2b2(b, S) == mstar(b)]
        ok = (g == Fraction(b * b + 9 * b + 36, 14) and
              all(v2b2(b, S) <= mstar(b) for S in range(2 * b + 1)) and
              all(abs(28 * S - 16 * b - 16) < 21 for S in eqS) and
              mstar(b) == Fraction(b * b + 9 * b, 14) + kappa[b % 7])
        if b >= 20:
            q, r = divmod(b, 14)
            nmax = 2 * sum(1 if S % 2 == 0 else 2 for S in eqS)
            ok &= (eqS == [8 * q + s for s in TABLE34[r]] and
                   nmax in (2, 4, 6) and (nmax == 6) == (r in (0, 5, 7, 12)) and
                   (b > bmax or nmax == NMAX_2B2[b - 1] == len(rule_2b2(b))))
        if not ok:
            bad34.append(b)
    CHK.eq(bad34, [], "Lemma 3.4, Table 3.4, the 2/4/6 count and kappa, b <= 400")
    bm0 = 160
    vals = {}
    for b in range(1, bm0 + 1):
        vals[b], arg = M0(b)
        if b in M0_SAMPLES:
            CHK.eq((vals[b], arg), M0_SAMPLES[b], f"M0({b}) and its maximisers")
    fails = [b for b in vals if vals[b] != (b * b + 9 * b + 36) // 14]
    CHK.eq(fails, [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 14, 15],
           f"M0(b) = floor((b^2+9b+36)/14) fails exactly at these b <= {bm0}")
    CHK.ok(all(vals[b] == Fraction(b * b + 9 * b, 14) + kappa[b % 7] for b in range(20, bm0 + 1)),
           f"M0(b) = (b^2+9b)/14 + kappa(b mod 7) for 20 <= b <= {bm0}")
    note(f"M0(b) for b = 16..{bm0} matches the formula; samples "
         f"{[(b, vals[b]) for b in sorted(vals) if b % 20 == 0]}")
    note(f"{time.perf_counter() - t0:.1f} s")


# ---------------------------------------------------------------------------
# [D] Fig 5: (7,6,7) and (5,10,5) near the centre
# ---------------------------------------------------------------------------


def sec_D():
    head("D  Fig 5 data: (7,6,7) and (5,10,5) on the antidiagonal (PSI)")
    t0 = time.perf_counter()
    for (a, b, c), want in (((7, 6, 7), (484422, 484020, (20, 22))),
                            ((5, 10, 5), (111460, 111322, (24, 26)))):
        P = psi2_packed(a, b, c)
        CHK.eq(sum(map(sum, P)), multinomial((a, b, c)), f"PSI total {(a, b, c)}")
        X = a * b
        cx = X // 2
        D = {x: P[x][X - x] for x in range(X + 1)}
        mx = max(max(row) for row in P)
        at = sorted((x, y) for x in range(X + 1) for y in range(len(P[0])) if P[x][y] == mx)
        CHK.ok(mx == want[0] and D[cx] == want[1] and at == [want[2], want[2][::-1]],
               f"{(a, b, c)}: max {mx} at {at}, centre {D[cx]}")
        note(f"Fig 5 data {(a, b, c)}: D(x) = P(x, {X} - x) for x = {cx - 4}..{cx + 4}: "
             f"{[D[x] for x in range(cx - 4, cx + 5)]}")
    note(f"{time.perf_counter() - t0:.1f} s")


# ---------------------------------------------------------------------------
# [G] Figs 2 and 4
# ---------------------------------------------------------------------------


def sec_G():
    head("G  Fig 2: rigid cells of (4,5,4); Fig 4: top-gap cells of (5,6,5)")
    t0 = time.perf_counter()
    a, b, c = 4, 5, 4
    Z = profile_value_sets(a, b, c)
    cells = [(x, y) for x in range(a * b + 1) for y in range(b * c + 1)]
    CHK.eq(sorted(Z), cells, "(4,5,4): every cell of the box is attained")
    rigid = {xy for xy in cells if rigid_rules(a, b, c, *xy)}
    forced = {xy for xy in cells if len(Z[xy]) == 1}
    CHK.eq(forced, rigid, "(4,5,4): z constant on the fibre iff rigid (Theorem A(i))")
    cor35 = {(x, y) for x, y in cells if x in (0, a * b) or y in (0, b * c) or x + y <= b or
             (a * b - x) + (b * c - y) <= b} | {(1, b * c - 1), (a * b - 1, 1)}
    CHK.eq(rigid, cor35, "(4,5,4): Corollary 3.5 description")
    by_rule = Counter()
    for xy in rigid:
        for r in rigid_rules(a, b, c, *xy):
            by_rule[r] += 1
    note(f"Fig 2 (4,5,4): {len(rigid)} rigid cells of {len(cells)}; cells satisfying each rule: "
         f"{dict(sorted(by_rule.items()))}")
    a, b, c = 5, 6, 5
    Z = profile_value_sets(a, b, c)
    gap = set()
    for (x, y), s in Z.items():
        if len(s) >= 2 and max(s) - 1 not in s:
            gap.add((x, y))
            CHK.ok(max(s) - 2 in s, f"(5,6,5) z_max - 2 present at {(x, y)}")
    rule = set()
    for x in range(a * b + 1):
        for y in range(b * c + 1):
            r, s = x % b, y % b
            qx, qy = x // b, y // b
            if (r == s == 0 and 1 <= qx <= a - 1 and 1 <= qy <= c - 1) or \
               (2 <= x <= b - 1 and y == b * c - x) or (2 <= y <= b - 1 and x == a * b - y):
                rule.add((x, y))
    CHK.eq(gap, rule, "(5,6,5): top-gap cells = T2 u T5 u T5^R (Theorem C)")
    CHK.eq(len(gap), (a - 1) * (c - 1) + 2 * max(0, b - 2), "(5,6,5): 24 top-gap cells")
    note(f"Fig 4 (5,6,5): {len(gap)} top-gap cells: {sorted(gap)}")
    note(f"{time.perf_counter() - t0:.1f} s")


# ---------------------------------------------------------------------------
# [QE] Question E
# ---------------------------------------------------------------------------


def qe_content(abc):
    a, b, c = abc
    P = psi2_packed(a, b, c)
    mx = max(max(row) for row in P)
    at = [(x, y) for x in range(len(P)) for y in range(len(P[0])) if P[x][y] == mx]
    cx, cy = a * b // 2, b * c // 2
    near = sorted({P[cx + 1][cy - 1], P[cx - 1][cy + 1]}, reverse=True)
    return abc, mx, at, P[cx][cy], near[0], sum(map(sum, P)) == multinomial(abc)


def sec_QE(pool):
    tmax = 45 if FULL else 24
    head(f"QE Question E: b even, a <= c, (a,c) != (1,1), total <= {tmax} (PSI)")
    t0 = time.perf_counter()
    conts = [(a, b, c) for tot in range(3, tmax + 1) for b in range(2, tot, 2)
             for a in range(1, tot - b) for c in [tot - a - b] if a <= c and (a, c) != (1, 1)]
    conts.sort(key=lambda t: -(t[0] + 1) * (t[1] + 1) * (t[2] + 1) * t[0] * t[2])
    res = list(pool.map(qe_content, conts, chunksize=1)) if pool is not None else \
        [qe_content(t) for t in conts]
    res.sort(key=lambda r: (sum(r[0]), r[0]))
    fails = []
    for (a, b, c), mx, at, pc, pn, total_ok in res:
        CHK.ok(total_ok, f"PSI total {(a, b, c)}")
        cx, cy = a * b // 2, b * c // 2
        allowed = {(cx, cy), (cx + 1, cy - 1), (cx - 1, cy + 1)}
        CHK.ok(set(at) <= allowed, f"E1 at {(a, b, c)}: {at}")
        unique = at == [(cx, cy)]
        if a + b + c <= 19:
            CHK.ok(unique, f"E0 at {(a, b, c)}")
        if (a * b // 2) % 2 == 0 or (b * c // 2) % 2 == 0:
            CHK.ok(unique, f"E2 at {(a, b, c)}")
        if not unique:
            fails.append((a, b, c))
            CHK.ok(a % 2 == 1 and c % 2 == 1 and b % 4 == 2 and
                   sorted(at) == [(cx - 1, cy + 1), (cx + 1, cy - 1)] and mx > pc,
                   f"E3 at {(a, b, c)}: {at}")
    want = [t for t in QE_FAILS_45 if sum(t) <= tmax]
    CHK.eq(sorted(fails, key=lambda t: (sum(t), t)), sorted(want, key=lambda t: (sum(t), t)),
           f"the failures of the unique centre, total <= {tmax}")
    CHK.eq(sum(1 for t in conts if sum(t) <= 19), 232, "232 contents with total <= 19")
    if tmax == 45:
        CHK.eq(len(conts), 3521, "3,521 contents with total <= 45")
    byc = {r[0]: r for r in res}
    for abc, (mx, pc) in (((7, 10, 7), (10689414, 10669592)),
                          ((11, 6, 11), (529108280, 528234494))):
        if abc in byc:
            CHK.eq((byc[abc][1], byc[abc][3]), (mx, pc), f"margin values at {abc}")
    if fails:
        margins = {t: Fraction(byc[t][1], byc[t][3]) - 1 for t in fails}
        lo = min(margins, key=margins.get)
        hi = max(margins, key=margins.get)
        note(f"margins max/P(centre) - 1: smallest {float(margins[lo]):.2e} at {lo}, largest "
             f"{float(margins[hi]):.2e} at {hi}")
        if tmax == 45:
            CHK.ok(lo == (11, 6, 19) and hi == (7, 10, 7) and
                   f"{float(margins[lo]):.1e}" == "5.4e-05" and
                   f"{float(margins[hi]):.1e}" == "1.9e-03", "margin range 5.4e-5 .. 1.9e-3")
    note(f"{len(conts)} contents, {len(fails)} failures; {time.perf_counter() - t0:.1f} s")
    if not FULL:
        return
    # the odd-odd islands (explore-r7-ternary.md section 2.1): b = 6 to total 66, b = 10, 14, 18
    # to total 60
    for b, tmax_b, want_n, want_fail in ((6, 66, 239, ISLAND6), (10, 60, 168, ISLAND10),
                                         (14, 60, 143, ISLAND14), (18, 60, 120, ISLAND18)):
        t1 = time.perf_counter()
        isl = [(a, b, c) for a in range(1, tmax_b, 2) for c in range(a, tmax_b, 2)
               if a + b + c <= tmax_b and (a, c) != (1, 1)]
        isl.sort(key=lambda t: -(t[0] + 1) * (t[2] + 1) * t[0] * t[2])
        res = list(pool.map(qe_content, isl, chunksize=1)) if pool is not None else \
            [qe_content(t) for t in isl]
        off = []
        for (a, bb, c), mx, at, pc, pn, total_ok in res:
            CHK.ok(total_ok, f"PSI total {(a, bb, c)}")
            cx, cy = a * bb // 2, bb * c // 2
            if at != [(cx, cy)]:
                CHK.ok(sorted(at) == [(cx - 1, cy + 1), (cx + 1, cy - 1)] and mx > pc,
                       f"island {(a, bb, c)}: maximisers {at}")
                off.append((a, c))
        CHK.eq((len(isl), sorted(off)), (want_n, want_fail),
               f"odd-odd island b = {b}, total <= {tmax_b}")
        note(f"island b = {b}, total <= {tmax_b}: {len(isl)} contents, centre not the unique "
             f"maximiser in {len(off)}, always the pair centre +- (1,-1); "
             f"{time.perf_counter() - t1:.1f} s")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

SECTIONS = ["U", "P", "R", "E", "G", "D", "B", "CF", "T3", "C1", "C4", "PM", "QE"]


def main() -> int:
    print(f"check_article2_data ({'--full' if FULL else 'default'}"
          f"{', only ' + ','.join(sorted(ONLY)) if ONLY else ''})", flush=True)
    unknown = sorted(ONLY - set(SECTIONS))
    if unknown:
        print(f"unknown section(s) {unknown}; the sections are {SECTIONS}")
        return 2
    run = [s for s in SECTIONS if not ONLY or s in ONLY]
    needs_pool = any(s in run for s in ("C1", "C4", "T3", "QE", "PM"))
    pool = ProcessPoolExecutor(max_workers=WORKERS) if needs_pool else None
    try:
        for s in run:
            t = time.perf_counter()
            if s == "U":
                sec_U()
            elif s == "P":
                sec_P()
            elif s == "R":
                sec_R()
            elif s == "E":
                sec_E()
            elif s == "G":
                sec_G()
            elif s == "D":
                sec_D()
            elif s == "B":
                sec_B()
            elif s == "CF":
                sec_CF()
            elif s == "PM":
                sec_PM(pool)
            elif s == "T3":
                sec_T3(pool)
            elif s == "C1":
                sec_C1(pool)
            elif s == "C4":
                sec_C4(pool)
            elif s == "QE":
                sec_QE(pool)
            print(f"   section {s}: {time.perf_counter() - t:.1f} s, {CHK.count} checks so far",
                  flush=True)
    finally:
        if pool is not None:
            pool.shutdown()
    secs = time.perf_counter() - START
    if CHK.failures:
        print(f"FAILURES ({len(CHK.failures)}):")
        for f in CHK.failures[:40]:
            print(f"   - {f}")
    print(f"check_article2_data: {CHK.count} checks, {len(CHK.failures)} failures, {secs:.1f} s")
    return 1 if CHK.failures else 0


if __name__ == "__main__":
    sys.exit(main())
