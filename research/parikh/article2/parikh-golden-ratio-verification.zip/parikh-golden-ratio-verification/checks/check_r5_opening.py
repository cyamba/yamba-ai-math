"""R5, the opening and its cyclic companion: every computational claim of notes/r5-opening.md.

Each claim is checked by brute force over words at small sizes (all permutations of [n], or all
words of a fixed content) and, where useful, by an independent exact method at larger sizes.
Section labels follow the note:

* Numbers. Euler numbers E_n (EC1 p. 39 and (1.55); Seidel's triangle; OEIS A000111) and
  Entringer numbers E_{n,k} (EC1 Ex. 1.141(a), (1.139); the rows printed on EC1 p. 144; OEIS
  A008281 and A008282).
* A.1-A.4, the dictionary: the Parikh matrix of a permutation; Parikh classes and beta_n(S);
  commutation classes and reduced words of Coxeter elements; alphabet graphs (fibres = acyclic
  orientations, fibre sizes = linear extensions, count = (-1)^n chi_G(-1)).
* B.1, the Euler maximum and strict monotonicity in alt(v) (EC1 Prop 1.6.4, Cor 1.6.5).
* C.1-C.4, the Entringer layer: refinement by position, the last-letter recurrence, binomial rows.
* D.1, diagonal sums = occurrences of the consecutive pattern 12...j in p^{-1}.
* E.0-E.4, the cyclic companion: sinks and through vertices, the cycle vector and its fibres,
  the even and odd maxima, Lemmas 1-4, the table of maxima, OEIS A024255 and A024283.
* G.2, commutation classes of words with repeated letters: the largest classes are the
  transitive heaps.

Conventions, as in the thesis and the note: permutations are one-line words over [n], subwords
are scattered, and in psi_2 a 0 marks a descent and a 1 an ascent (of p^{-1}). Bit masks: bit
t-1 of a psi_2 mask is psi_2(p)_t, and bit i-1 of a descent mask means i is a descent. Bit e of
a cycle vector J is J_{e+1}. Vertex v of C_n (0-based) is the letter v+1, and edge e joins the
vertices e and e+1 mod n; it points e -> e+1 iff bit e of J is set.

Bounds (the note's section F lists them against each claim): brute force over S_n for n <= 9
(E.4 odd and even maxima included); the down-set DP for the cyclic fibres for n <= 14; the sink
formula for n <= 18; D.1 (diagonal sums, run-length form, j = 1, 2, n) for n <= 7; Entringer
rows against EC1 p. 144 and OEIS A008281/A008282; G.2 for every content with 2 <= k <= 5 letters
and total <= 9 (372 contents).

Reviewed on 19 October 2026 against the final note (it was written by an interrupted
finaliser): the G.2 bound was raised to total <= 9 by default, matching the note.

Standard library only (Python 3.9 or later); deterministic (fixed random seeds); about 25 s
(load-dependent). Unknown command-line arguments (run_all.py passes --max-n) are accepted and
ignored. The environment variable R5_QUICK=1 lowers the G.2 enumeration to total <= 8.
"""

from __future__ import annotations

import os
import random
import sys
import time
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations, permutations, product
from math import comb, factorial

from parikh import Checker, beta_det, beta_pie, multiset_words, occ, parikh_matrix_product

# ------------------------------------------------------------------------------------------
# Data transcribed from the sources (OEIS entries fetched 18 October 2026; EC1 preprint of
# 15 July 2011, p. 144).
# ------------------------------------------------------------------------------------------

A000111 = [1, 1, 1, 2, 5, 16, 61, 272, 1385, 7936, 50521, 353792, 2702765, 22368256,
           199360981, 1903757312, 19391512145, 209865342976, 2404879675441, 29088885112832,
           370371188237525, 4951498053124096, 69348874393137901, 1015423886506852352,
           15514534163557086905, 246921480190207983616, 4087072509293123892361]
A024255 = [0, 1, 4, 48, 1088, 39680, 2122752, 156577792, 15230058496, 1888788086784,
           290888851128320, 54466478584365056, 12185086638082228224,
           3209979242472703787008, 983522422455215438430208, 346787762817143967622103040,
           139423404114002708738732982272, 63399930963249002708657663639552]
A024283 = [0, 1, 8, 136, 3968, 176896, 11184128, 951878656, 104932671488, 14544442556416,
           2475749026562048, 507711943253426176, 123460740095103991808,
           35125800801971979943936, 11559592093904798920736768,
           4356981378562584648085405696, 1864703851860264785548754812928]
A008281 = [1, 0, 1, 0, 1, 1, 0, 1, 2, 2, 0, 2, 4, 5, 5, 0, 5, 10, 14, 16, 16, 0, 16, 32, 46,
           56, 61, 61, 0, 61, 122, 178, 224, 256, 272, 272, 0, 272, 544, 800, 1024, 1202, 1324,
           1385, 1385, 0, 1385, 2770, 4094, 5296, 6320, 7120, 7664, 7936, 7936]
A008282 = [1, 1, 1, 1, 2, 2, 2, 4, 5, 5, 5, 10, 14, 16, 16, 16, 32, 46, 56, 61, 61, 61, 122, 178,
           224, 256, 272, 272, 272, 544, 800, 1024, 1202, 1324, 1385, 1385, 1385, 2770, 4094, 5296,
           6320, 7120, 7664, 7936, 7936, 7936, 15872, 23536, 30656, 36976, 42272, 46366, 49136,
           50521, 50521]
# EC1 p. 144, the first seven rows of (1.140), read as (E_{n,0}, ..., E_{n,n}); this is also
# the table in section C of the note.
EC1_ROWS = [[1], [0, 1], [0, 1, 1], [0, 1, 2, 2], [0, 2, 4, 5, 5], [0, 5, 10, 14, 16, 16],
            [0, 16, 32, 46, 56, 61, 61]]
# G.2 enumerates every word of every content with 2 <= k <= 5 letters and total <= 9, the 372
# contents quoted in the note (about 15 s). R5_QUICK=1 lowers this to total <= 8 (about 3 s).
G2_MAX_TOTAL = 8 if os.environ.get("R5_QUICK") else 9
# The E.4 table of the note: n -> (maximum of rho_C, number of maximising vectors J).
E4_TABLE = {3: (1, 6), 4: (4, 2), 5: (8, 10), 6: (48, 2), 7: (136, 14), 8: (1088, 2),
            9: (3968, 18), 10: (39680, 2), 11: (176896, 22), 12: (2122752, 2),
            13: (11184128, 26), 14: (156577792, 2), 15: (951878656, 30), 16: (15230058496, 2),
            17: (104932671488, 34), 18: (1888788086784, 2)}

# ------------------------------------------------------------------------------------------
# Numbers
# ------------------------------------------------------------------------------------------


def entringer_rows(m: int) -> list[list[int]]:
    """Rows (E_{n,0}, ..., E_{n,n}), 0 <= n <= m, by EC1 (1.139):
    E_{0,0} = 1, E_{n,0} = 0, E_{n+1,k+1} = E_{n+1,k} + E_{n,n-k}."""
    rows = [[1]]
    for n in range(m):
        new = [0]
        for k in range(n + 1):
            new.append(new[-1] + rows[n][n - k])
        rows.append(new)
    return rows


def euler_155(m: int) -> list[int]:
    """E_0..E_m by EC1 (1.55): 2 E_{n+1} = sum_k C(n,k) E_k E_{n-k} (n >= 1), E_0 = E_1 = 1."""
    out = [1, 1]
    for n in range(1, m):
        s = sum(comb(n, k) * out[k] * out[n - k] for k in range(n + 1))
        assert s % 2 == 0
        out.append(s // 2)
    return out[: m + 1]


# ------------------------------------------------------------------------------------------
# Permutations and descent sets
# ------------------------------------------------------------------------------------------


def is_alt(w) -> bool:
    """EC1 p. 39: w_1 > w_2 < w_3 > ..., i.e. D(w) = {1, 3, 5, ...}."""
    return all((w[i] > w[i + 1]) == (i % 2 == 0) for i in range(len(w) - 1))


def is_revalt(w) -> bool:
    """Reverse alternating: w_1 < w_2 > w_3 < ..., i.e. D(w) = {2, 4, 6, ...}."""
    return all((w[i] < w[i + 1]) == (i % 2 == 0) for i in range(len(w) - 1))


def inv(p) -> tuple[int, ...]:
    """p^{-1}: its i-th letter is the position of i in p."""
    q = [0] * len(p)
    for i, v in enumerate(p, start=1):
        q[v - 1] = i
    return tuple(q)


def dmask(w) -> int:
    """D(w) as a mask: bit i-1 set iff w_i > w_{i+1}."""
    m = 0
    for i in range(len(w) - 1):
        if w[i] > w[i + 1]:
            m |= 1 << i
    return m


def positions(p) -> list[int]:
    pos = [0] * (len(p) + 2)
    for i, v in enumerate(p):
        pos[v] = i
    return pos


def psi2(p) -> int:
    """psi_2(p) as a mask: bit t-1 set iff t precedes t+1 in p, i.e. |p|_{t(t+1)} = 1."""
    pos = positions(p)
    return sum(1 << (t - 1) for t in range(1, len(p)) if pos[t] < pos[t + 1])


def cycle_vector(p) -> int:
    """psi_C(p) as a mask: psi_2(p) in bits 0..n-2 and |p|_{n1} in bit n-1."""
    n = len(p)
    pos = positions(p)
    return psi2(p) | ((1 << (n - 1)) if pos[n] < pos[1] else 0)


def cyclic_ascent_mask(s) -> int:
    """Cyclic ascents of s (s_{n+1} := s_1) as a mask: bit i-1 set iff s_i < s_{i+1}."""
    n = len(s)
    return sum(1 << i for i in range(n) if s[i] < s[(i + 1) % n])


def sweep(n: int):
    """One pass over S_n: Counters of psi_2(p), psi_C(p) (n >= 3) and D(p), as masks."""
    r2: Counter = Counter()
    rc: Counter = Counter()
    dd: Counter = Counter()
    top = 1 << (n - 1)
    ts = range(1, n)
    for p in permutations(range(1, n + 1)):
        pos = [0] * (n + 1)
        i = 0
        for v in p:
            pos[v] = i
            i += 1
        m = 0
        for t in ts:
            if pos[t] < pos[t + 1]:
                m |= 1 << (t - 1)
        r2[m] += 1
        if n >= 3:
            rc[(m | top) if pos[n] < pos[1] else m] += 1
        d = 0
        for t in ts:
            if p[t - 1] > p[t]:
                d |= 1 << (t - 1)
        dd[d] += 1
    return r2, rc, dd


def beta_table(N: int) -> list[int]:
    """beta_N(S) for every S subset of [N-1], indexed by its mask, by a depth-first last-letter
    DP: vec[r] counts the prefixes with the given descent pattern whose last letter has
    relative rank r. Independent of any enumeration of S_N."""
    if N <= 1:
        return [1]
    out = [0] * (1 << (N - 1))

    def rec(t: int, vec: list[int], mask: int) -> None:
        if t == N:
            out[mask] = sum(vec)
            return
        ps = [0]
        for x in vec:
            ps.append(ps[-1] + x)
        tot = ps[-1]
        down = [tot - x for x in ps]
        rec(t + 1, ps, mask)  # ascent at position t
        rec(t + 1, down, mask | (1 << (t - 1)))  # descent at position t

    rec(1, [1], 0)
    return out


def mask_to_set(m: int) -> frozenset[int]:
    out = []
    i = 1
    while m:
        if m & 1:
            out.append(i)
        m >>= 1
        i += 1
    return frozenset(out)


def popcount(x: int) -> int:
    return bin(x).count("1")


# ------------------------------------------------------------------------------------------
# Posets given by acyclic orientations (in-neighbour masks)
# ------------------------------------------------------------------------------------------


def count_lin_ext(n: int, pred: list[int]) -> int:
    """e(P) for the transitive closure P of a DAG on {0..n-1} (pred[x] = in-neighbours of x):
    the number of maximal chains in the lattice of down-sets."""
    layer = {0: 1}
    for _ in range(n):
        nxt: dict[int, int] = {}
        for mask, cnt in layer.items():
            for x in range(n):
                b = 1 << x
                if not (mask & b) and (pred[x] & ~mask) == 0:
                    key = mask | b
                    nxt[key] = nxt.get(key, 0) + cnt
        layer = nxt
    return layer.get((1 << n) - 1, 0)


def lin_ext_words(n: int, pred: list[int], labels) -> set[tuple[int, ...]]:
    """All linear extensions of the closure of a DAG, as words over `labels`."""
    out: set[tuple[int, ...]] = set()
    word: list[int] = []

    def rec(mask: int) -> None:
        if mask == (1 << n) - 1:
            out.add(tuple(word))
            return
        for x in range(n):
            b = 1 << x
            if not (mask & b) and (pred[x] & ~mask) == 0:
                word.append(labels[x])
                rec(mask | b)
                word.pop()

    rec(0)
    return out


def closure(n: int, succ: list[int]) -> list[int]:
    """above[x] = mask of the y with x < y in the transitive closure (Warshall, bit sets)."""
    r = list(succ)
    for k in range(n):
        bk, rk = 1 << k, r[k]
        for i in range(n):
            if r[i] & bk:
                r[i] |= rk
                if i == k:
                    rk = r[k]
    return r


def comparable_pairs(n: int, succ: list[int]) -> frozenset:
    up = closure(n, succ)
    return frozenset(frozenset((x, y)) for x in range(n) for y in range(n) if up[x] >> y & 1)


def succ_to_pred(n: int, succ: list[int]) -> list[int]:
    pred = [0] * n
    for x in range(n):
        for y in range(n):
            if succ[x] >> y & 1:
                pred[y] |= 1 << x
    return pred


def is_acyclic(n: int, succ: list[int]) -> bool:
    indeg = [0] * n
    for x in range(n):
        for y in range(n):
            if succ[x] >> y & 1:
                indeg[y] += 1
    stack = [x for x in range(n) if indeg[x] == 0]
    seen = 0
    while stack:
        x = stack.pop()
        seen += 1
        for y in range(n):
            if succ[x] >> y & 1:
                indeg[y] -= 1
                if indeg[y] == 0:
                    stack.append(y)
    return seen == n


# ------------------------------------------------------------------------------------------
# The cycle C_n
# ------------------------------------------------------------------------------------------


def cyc_orient(n: int, J: int) -> tuple[list[int], list[int]]:
    """O_J: out- and in-neighbour masks. Edge e joins e and e+1 (mod n), e -> e+1 iff bit e."""
    succ, pred = [0] * n, [0] * n
    for e in range(n):
        a, b = e, (e + 1) % n
        if not (J >> e) & 1:
            a, b = b, a
        succ[a] |= 1 << b
        pred[b] |= 1 << a
    return succ, pred


def cyc_types(n: int, J: int):
    """(sinks, sources, through vertices) of O_J, from in- and out-degrees."""
    succ, pred = cyc_orient(n, J)
    sinks = [v for v in range(n) if succ[v] == 0]
    sources = [v for v in range(n) if pred[v] == 0]
    through = [v for v in range(n) if succ[v] and pred[v]]
    return sinks, sources, through


def cyc_e(n: int, J: int) -> int:
    return count_lin_ext(n, cyc_orient(n, J)[1])


def sink_formula(n: int, J: int, beta_nm1: list[int]) -> int:
    """E.2: e(P_O) = sum over sinks v of beta_{n-1}(S_{O minus v}), from the orientation."""
    succ, _ = cyc_orient(n, J)
    total = 0
    for v in range(n):
        if succ[v]:
            continue
        ys = [(v + i) % n for i in range(1, n)]  # y_1, ..., y_{n-1}
        S = 0
        for i in range(1, n - 1):  # the edge {y_i, y_{i+1}}; i in S iff y_{i+1} -> y_i
            if succ[ys[i]] >> ys[i - 1] & 1:
                S |= 1 << (i - 1)
        total += beta_nm1[S]
    return total


def sink_formula_bits(n: int, J: int, beta_nm1: list[int], full: int) -> int:
    """The same sum with bit operations: the sinks are the v with bit v-1 of J set and bit v
    clear, and S_{O minus v} is the complement of J read from edge v+1 on."""
    nJ = full ^ J
    sinks = (((J << 1) | (J >> (n - 1))) & full) & nJ
    low = (1 << (n - 2)) - 1
    total = 0
    while sinks:
        b = sinks & -sinks
        s = b.bit_length() % n  # = (v + 1) mod n
        total += beta_nm1[((nJ >> s) | (nJ << (n - s))) & low]
        sinks ^= b
    return total


def act(n: int, J: int, g: list[int]) -> int:
    """The cycle vector of g(O_J) for an automorphism g of C_n (a vertex map)."""
    out = 0
    for e in range(n):
        a, b = e, (e + 1) % n
        if not (J >> e) & 1:
            a, b = b, a
        ga, gb = g[a], g[b]
        if (ga + 1) % n == gb:
            out |= 1 << ga
        elif (gb + 1) % n != ga:
            raise ValueError("not an automorphism")
    return out


def dihedral(n: int) -> list[list[int]]:
    return [[(v + r) % n for v in range(n)] for r in range(n)] + \
           [[(r - v) % n for v in range(n)] for r in range(n)]


def necklaces(n: int) -> list[int]:
    """Lexicographically least representatives of the binary words of length n under rotation
    (FKM algorithm), as masks (bit e = letter e), with their rotation-orbit sizes."""
    out = []
    a = [0] * (n + 1)

    def gen(t: int, p: int) -> None:
        if t > n:
            if n % p == 0:
                out.append(sum(a[i + 1] << i for i in range(n)))
            return
        a[t] = a[t - p]
        gen(t + 1, p)
        for j in range(a[t - p] + 1, 2):
            a[t] = j
            gen(t + 1, t)

    gen(1, 1)
    return out


def rotation_orbit(n: int, J: int) -> set[int]:
    full = (1 << n) - 1
    return {((J << r) | (J >> (n - r))) & full for r in range(n)}


# ------------------------------------------------------------------------------------------
# Sections
# ------------------------------------------------------------------------------------------


def check_numbers(c: Checker, E: list[int]) -> None:
    c.check("Seidel E_n = OEIS A000111 (n <= 26)", E[:27], A000111)
    c.check("Seidel E_n = EC1 (1.55) (n <= 150)", euler_155(150), E[:151])
    for n in range(0, 9):
        ps = list(permutations(range(1, n + 1)))
        c.check(f"E_{n} = #alternating (EC1 p. 39)", sum(map(is_alt, ps)), E[n])
        c.check(f"E_{n} = #reverse alternating", sum(map(is_revalt, ps)), E[n])
    rows = entringer_rows(10)
    c.check("Entringer rows 0-6 = EC1 p. 144 = the table of section C", rows[:7], EC1_ROWS)
    c.check("Entringer rows 0-9 = OEIS A008281", [x for r in rows[:10] for x in r], A008281)
    c.check("OEIS A008282 = Entringer rows 1-10 without the zero column",
            [x for r in rows[1:11] for x in r[1:]], A008282)
    for n in range(0, 8):
        firsts = Counter(w[0] for w in permutations(range(1, n + 2)) if is_alt(w))
        c.check(f"E_(n,k) = #alternating perms of [n+1] with first term k+1, n={n}",
                [firsts[k + 1] for k in range(n + 1)], rows[n])
    c.check("E_(n,n) = E_n (n <= 9)", [rows[n][n] for n in range(10)], E[:10])
    c.note("numbers: E_n (brute force n <= 8, (1.55) n <= 150, A000111), E_(n,k) (n <= 7)")


def parikh_literal(w, k: int) -> list[list[int]]:
    """psi_{M_k}(w) as the literal product of the generators I + E_{l,l+1} (thesis Def 2.8):
    right multiplication by I + E_{l,l+1} adds column l to column l+1 (1-based)."""
    m = [[int(r == s) for s in range(k + 1)] for r in range(k + 1)]
    for letter in w:
        for r in range(k + 1):
            m[r][letter] += m[r][letter - 1]
    return m


def check_A(c: Checker, sw: dict, beta: dict) -> None:
    # The column-addition product agrees with full matrix multiplication (parikh.py).
    agree = all(parikh_literal(w, 3) == parikh_matrix_product(w, 3)
                for L in range(6) for w in product((1, 2, 3), repeat=L))
    agree &= all(parikh_literal(p, n) == parikh_matrix_product(p, n)
                 for n in range(1, 5) for p in permutations(range(1, n + 1)))
    c.ok("literal Parikh product = matrix multiplication (ternary words <= 5, S_n n <= 4)", agree)

    # A.1: m_{i,j+1} = |p|_{i..j} = prod_{t=i}^{j-1} psi_2(p)_t, and psi_2(p) = phi_B(D(p^-1)).
    for n in range(1, 8):
        full = (1 << (n - 1)) - 1
        bad = []
        by_m, by_v, by_d = defaultdict(set), defaultdict(set), defaultdict(set)
        for p in permutations(range(1, n + 1)):
            m = parikh_literal(p, n)
            v = psi2(p)
            d = dmask(inv(p))
            if v != full ^ d:
                bad.append(("A2", p))
            for i in range(1, n + 1):
                if m[i - 1][i - 1] != 1 or any(m[r][i - 1] for r in range(i, n + 1)):
                    bad.append(("fixed entries", p))
                for j in range(i, n + 1):
                    prod_bits = int(all(v >> (t - 1) & 1 for t in range(i, j)))
                    if m[i - 1][j] != prod_bits:
                        bad.append(("A1 product", p, i, j))
                    if n <= 6 and m[i - 1][j] != occ(p, tuple(range(i, j + 1))):
                        bad.append(("A1 subword count", p, i, j))
            key = tuple(map(tuple, m))
            by_m[key].add(p)
            by_v[v].add(p)
            by_d[d].add(p)
        c.ok(f"A.1 (A1), (A2) for every p in S_{n}", not bad, str(bad[:3]))
        parts = [{frozenset(s) for s in g.values()} for g in (by_m, by_v, by_d)]
        c.ok(f"A.1 equal matrix <=> equal psi_2 <=> equal D(p^-1), n={n}",
             parts[0] == parts[1] == parts[2] and len(parts[0]) == 2 ** (n - 1))
    c.note("A.1: literal generator products for S_n, n <= 7 (subword counts n <= 6)")

    # A.2: 2^{n-1} classes C_n(S) of sizes beta_n(S); the decreasing-blocks construction.
    for n in range(1, 10):
        r2, _, dd = sw[n]
        full = (1 << (n - 1)) - 1
        c.check(f"A.2 number of Parikh classes, n={n}", len(r2), 2 ** (n - 1))
        c.ok(f"A.2 |C_n(S)| = #{{s : D(s) = S}}, n={n}",
             all(r2[v] == dd[full ^ v] for v in range(full + 1)))
        c.check(f"A.2 beta_n by brute force = last-letter DP, n={n}",
                [dd[S] for S in range(full + 1)], beta[n])
        if n <= 8:
            c.ok(f"A.2 inclusion-exclusion (EC1 (2.15)) = beta_n, n={n}",
                 all(beta_pie(mask_to_set(S), n) == dd[S] for S in range(full + 1)))
        if n <= 7:
            c.ok(f"A.2 determinant (EC1 (2.16)) = beta_n, n={n}",
                 all(beta_det(mask_to_set(S), n) == dd[S] for S in range(full + 1)))
    for n in range(1, 11):
        full = (1 << (n - 1)) - 1
        ok = True
        for S in range(full + 1):
            comp = [i for i in range(1, n) if not (S >> (i - 1)) & 1]  # a_1 < ... < a_r
            cuts = [0] + comp + [n]
            word = []
            for t in range(1, len(cuts)):
                word.extend(range(cuts[t], cuts[t - 1], -1))  # block a_{t-1}+1..a_t, decreasing
            ok &= sorted(word) == list(range(1, n + 1)) and dmask(word) == S
        c.ok(f"A.2 decreasing blocks give descent set S, every S, n={n}", ok)
    for n in range(1, 15):
        full = (1 << (n - 1)) - 1
        c.ok(f"A.2 beta_n(S) = beta_n(complement), n={n}",
             all(beta[n][S] == beta[n][full ^ S] for S in range(full + 1)))
    c.note("A.2: classes and beta_n by brute force n <= 9, (2.15) n <= 8, (2.16) n <= 7, "
           "construction n <= 10, complement symmetry n <= 14")

    # A.3: Parikh classes = commutation classes; = reduced words of c(p) = s_{p_1}...s_{p_n}.
    for n in range(1, 8):
        ps = list(permutations(range(1, n + 1)))
        index = {p: i for i, p in enumerate(ps)}
        parent = list(range(len(ps)))

        def find(x: int) -> int:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        unit_swaps_ok = True
        for i, p in enumerate(ps):
            for k in range(n - 1):
                a, b = p[k], p[k + 1]
                q = p[:k] + (b, a) + p[k + 2:]
                if abs(a - b) >= 2:
                    ra, rb = find(i), find(index[q])
                    if ra != rb:
                        parent[ra] = rb
                elif psi2(q) == psi2(p):
                    unit_swaps_ok = False
        comm = defaultdict(set)
        park = defaultdict(set)
        for i, p in enumerate(ps):
            comm[find(i)].add(p)
            park[psi2(p)].add(p)
        c.ok(f"A.3 commutation classes = Parikh classes, n={n}",
             {frozenset(s) for s in comm.values()} == {frozenset(s) for s in park.values()})
        c.ok(f"A.3 swapping letters that differ by 1 changes psi_2, n={n}", unit_swaps_ok)
    for n in range(1, 7):
        def coxeter(word) -> tuple[int, ...]:
            img = list(range(1, n + 2))  # one-line notation of s_{w_1} ... s_{w_L} in S_{n+1}
            for letter in word:
                img[letter - 1], img[letter] = img[letter], img[letter - 1]
            return tuple(img)

        shorter = set()
        for L in range(n):
            for w in product(range(1, n + 1), repeat=L):
                shorter.add(coxeter(w))
        words = defaultdict(set)
        for w in product(range(1, n + 1), repeat=n):
            words[coxeter(w)].add(w)
        ok = True
        for p in permutations(range(1, n + 1)):
            cp = coxeter(p)
            red = words[cp]
            cls = {q for q in permutations(range(1, n + 1)) if psi2(q) == psi2(p)}
            ok &= cp not in shorter  # length of c(p) is n: the word p is reduced
            ok &= red == cls  # Red(c(p)) = the Parikh class; all reduced words are permutations
            ok &= len(red) == beta[n][psi2(p)]  # = beta_n(I), I the 1-positions of psi_2
            ok &= len({psi2(w) for w in red}) == 1  # NT23's I_w is read from any reduced word
        c.ok(f"A.3 Parikh class of p = Red(s_p1...s_pn) in S_{n + 1}, n={n}", ok)
    c.note("A.3: commutation classes n <= 7; reduced words of Coxeter elements n <= 6 "
           "(all words of length <= n over [n])")

    # A.4: alphabet graphs.
    graphs = []
    for n in range(1, 5):
        pairs = list(combinations(range(n), 2))
        for m in range(1 << len(pairs)):
            graphs.append((n, [pairs[i] for i in range(len(pairs)) if m >> i & 1]))
    rnd = random.Random(20261018)
    for n, count, max_edges in ((5, 40, 10), (6, 12, 9)):
        pairs = list(combinations(range(n), 2))
        for _ in range(count):
            k = rnd.randint(1, max_edges)
            graphs.append((n, sorted(rnd.sample(pairs, k))))
    graphs.append((5, list(combinations(range(5), 2))))  # K_5
    graphs.append((6, [(i, i + 1) for i in range(5)] + [(0, 5)]))  # C_6
    bad = []
    for n, edges in graphs:
        fib = Counter()
        for p in permutations(range(n)):
            pos = [0] * n
            for i, v in enumerate(p):
                pos[v] = i
            fib[tuple(int(pos[a] < pos[b]) for a, b in edges)] += 1
        acyclic = set()
        for bits in product((0, 1), repeat=len(edges)):
            succ = [0] * n
            for (a, b), x in zip(edges, bits):
                if x:
                    succ[a] |= 1 << b
                else:
                    succ[b] |= 1 << a
            if is_acyclic(n, succ):
                acyclic.add(bits)
                if fib[bits] != count_lin_ext(n, succ_to_pred(n, succ)):
                    bad.append(("size", n, edges, bits))
        if set(fib) != acyclic:
            bad.append(("image", n, edges))
        # (-1)^n chi_G(-1) by Whitney's expansion chi_G(k) = sum_A (-1)^{|A|} k^{c(A)}.
        total = 0
        for A in range(1 << len(edges)):
            parent = list(range(n))
            comps, size = n, 0
            for i, (a, b) in enumerate(edges):
                if A >> i & 1:
                    size += 1
                    while parent[a] != a:
                        a = parent[a]
                    while parent[b] != b:
                        b = parent[b]
                    if a != b:
                        parent[a] = b
                        comps -= 1
            total += (-1) ** (size + comps + n)
        if total != len(acyclic):
            bad.append(("Stanley count", n, edges, total, len(acyclic)))
    c.ok(f"A.4 fibres = acyclic orientations, sizes e(P_O), count (-1)^n chi_G(-1), "
         f"{len(graphs)} graphs", not bad, str(bad[:3]))
    for n in range(1, 7):
        edges = list(combinations(range(n), 2))
        keys = Counter(tuple(int(p.index(a) < p.index(b)) for a, b in edges)
                       for p in permutations(range(n)))
        c.ok(f"A.4 psi_(K_n) is injective, n={n}", max(keys.values()) == 1)
    c.note(f"A.4: all graphs on <= 4 vertices, 40 + 12 seeded random graphs on 5 and 6 "
           f"vertices, K_5, C_6 ({len(graphs)} graphs)")


def check_B(c: Checker, E: list[int], sw: dict, beta: dict) -> None:
    pairs_total = 0
    for n in range(2, 15):
        full = (1 << (n - 1)) - 1
        a = sum(1 << (t - 1) for t in range(1, n) if t % 2 == 0)  # a_n = (0,1,0,1,...)
        b = sum(1 << (t - 1) for t in range(1, n) if t % 2 == 1)  # b_n = (1,0,1,0,...)
        rho = [beta[n][full ^ v] for v in range(full + 1)]  # rho_2(v) = beta_n(zero set of v)
        if n <= 9:
            r2 = sw[n][0]
            c.ok(f"B.1 rho_2 by brute force = beta_n(phi_B^-1(v)), n={n}",
                 all(r2[v] == rho[v] for v in range(full + 1)))
        top = max(rho)
        c.check(f"B.1(ii) max rho_2 = E_n, n={n}", top, E[n])
        c.check(f"B.1(ii) argmax = {{a_n, b_n}}, n={n}",
                {v for v in range(full + 1) if rho[v] == top}, {a, b})
        lowmask = (1 << (n - 2)) - 1
        alt = [(v ^ (v >> 1)) & lowmask for v in range(full + 1)]
        omega_ok = True
        for v in range(full + 1):  # omega(phi_B^-1(v)) = alt(v), with EC1's definition of omega
            S = mask_to_set(full ^ v)
            omega = {i for i in range(1, n - 1) if (i in S) != (i + 1 in S)}
            alt_v = {i for i in range(1, n - 1) if (v >> (i - 1) & 1) != (v >> i & 1)}
            omega_ok &= omega == alt_v == set(mask_to_set(alt[v]))
        c.ok(f"B.1 omega(phi_B^-1(v)) = alt(v) for every v, n={n}", omega_ok)
        whole = {v for v in range(full + 1) if alt[v] == lowmask}
        c.check(f"EC1 (1.65): omega(S) = [n-2] iff S odd or even, n={n}", whole, {a, b})
        if n <= 10:
            nested = proper = weak = strict = 0
            for u in range(full + 1):
                au = alt[u]
                for v in range(full + 1):
                    av = alt[v]
                    if au & ~av == 0:  # alt(u) is contained in alt(v)
                        nested += 1
                        weak += rho[u] <= rho[v]
                        if au != av:
                            proper += 1
                            strict += rho[u] < rho[v]
            pairs_total += proper
            c.check(f"B.1(i) non-strict, n={n}", weak, nested)
            c.check(f"B.1(i) strict, n={n}", strict, proper)
            c.check(f"B.1(i) number of strictly nested pairs, n={n}", proper,
                    4 * (3 ** (n - 2) - 2 ** (n - 2)))
    c.check("B.1(i) strictly nested pairs, 2 <= n <= 10", pairs_total, 37320)
    for n in range(1, 9):
        a = sum(1 << (t - 1) for t in range(1, n) if t % 2 == 0)
        b = sum(1 << (t - 1) for t in range(1, n) if t % 2 == 1)
        ok = True
        for p in permutations(range(1, n + 1)):
            q = inv(p)
            ok &= (psi2(p) == a) == is_alt(q) and (psi2(p) == b) == is_revalt(q)
        c.ok(f"B.1(iii) A_n = {{p : p^-1 alternating}}, B_n likewise, n={n}", ok)
    A4 = sorted("".join(map(str, p)) for p in permutations(range(1, 5)) if psi2(p) == 0b010)
    B4 = sorted("".join(map(str, p)) for p in permutations(range(1, 5)) if psi2(p) == 0b101)
    c.check("B.1 example A_4", A4, ["2143", "2413", "2431", "4213", "4231"])
    c.check("B.1 example B_4", B4, ["1324", "1342", "3124", "3142", "3412"])
    c.check("B.1 remark: n = 2, both classes have E_2 = 1 element", sorted(sw[2][0].values()), [1, 1])
    c.note("B.1: (ii) for 2 <= n <= 14 (brute force n <= 9); (i) for n <= 10, "
           f"{pairs_total} strictly nested pairs; (iii) n <= 8")


def check_C(c: Checker, E: list[int]) -> None:
    rows = entringer_rows(10)
    prev = Counter({(0, 1): 1})  # g_empty(1, 1) = 1
    for n in range(2, 9):
        a = sum(1 << (t - 1) for t in range(1, n) if t % 2 == 0)
        b = sum(1 << (t - 1) for t in range(1, n) if t % 2 == 1)
        posA1, posB1, posAn, posBn = Counter(), Counter(), Counter(), Counter()
        valA1, valB1, valAn, valBn = Counter(), Counter(), Counter(), Counter()
        g = Counter()
        for p in permutations(range(1, n + 1)):
            v = psi2(p)
            p1, pn = p.index(1) + 1, p.index(n) + 1
            g[(v, pn)] += 1
            if v == a:
                posA1[p1] += 1
                posAn[pn] += 1
                valA1[p[0]] += 1
                valAn[p[-1]] += 1
            if v == b:
                posB1[p1] += 1
                posBn[pn] += 1
                valB1[p[0]] += 1
                valBn[p[-1]] += 1
        P = range(1, n + 1)
        row = rows[n - 1]
        c.check(f"C.1 A_n by pos(1), n={n}", [posA1[p] for p in P], [row[p - 1] for p in P])
        c.check(f"C.1 B_n by pos(1), n={n}", [posB1[p] for p in P], [row[n - p] for p in P])
        same, flip = [row[p - 1] for p in P], [row[n - p] for p in P]
        c.check(f"C.2 A_n by pos(n), n={n}", [posAn[p] for p in P], same if n % 2 else flip)
        c.check(f"C.2 B_n by pos(n), n={n}", [posBn[p] for p in P], flip if n % 2 else same)
        cnj = {j: comb(n - 1, j - 1) * E[j - 1] * E[n - j] for j in P}
        c.check(f"C.4 A_n by p(1), n={n}", [valA1[j] for j in P], [cnj[j] * (j % 2 == 0) for j in P])
        c.check(f"C.4 A_n by p(n), n={n}", [valAn[j] for j in P], [cnj[j] * (j % 2 == 1) for j in P])
        c.check(f"C.4 B_n by p(1), n={n}", [valB1[j] for j in P], [cnj[j] * (j % 2 == 1) for j in P])
        c.check(f"C.4 B_n by p(n), n={n}", [valBn[j] for j in P], [cnj[j] * (j % 2 == 0) for j in P])
        ok = True
        for v in range(1 << (n - 1)):
            vp, last = v & ((1 << (n - 2)) - 1), v >> (n - 2) & 1
            for p in P:
                qs = range(1, p) if last else range(p, n)
                ok &= g[(v, p)] == sum(prev[(vp, q)] for q in qs)
        c.ok(f"C.3 last-letter recurrence, every v and p, n={n}", ok)
        prev = g
        if n == 4:
            c.check("C.2 example: A_4 by pos(1)", [posA1[p] for p in P], [0, 1, 2, 2])
            c.check("C.2 example: A_4 by pos(4)", [posAn[p] for p in P], [2, 2, 1, 0])
            c.check("C.4 example: A_4 by p(1)", [valA1[j] for j in P], [0, 3, 0, 2])
        if n == 6:
            c.check("C.4 example: A_6 by p(1)", [valA1[j] for j in P], [0, 25, 0, 20, 0, 16])
    for n in range(1, 41):
        cnj = [comb(n - 1, j - 1) * E[j - 1] * E[n - j] for j in range(1, n + 1)]
        ev, od = sum(cnj[1::2]), sum(cnj[0::2])
        c.check(f"C.4 E_n = sum over even j = sum over odd j, n={n}", (ev, od) == (E[n], E[n]), n >= 2)
    c.ok("EC1 p. 55: E_(n+1) = sum_(j odd) C(n,j) E_j E_(n-j), 1 <= n <= 40",
         all(E[n + 1] == sum(comb(n, j) * E[j] * E[n - j] for j in range(1, n + 1, 2))
             for n in range(1, 41)))
    c.note("C.1-C.4 by brute force for 2 <= n <= 8; the E_n identity for n <= 40 (fails at n = 1)")


def check_D(c: Checker) -> None:
    for n in range(1, 8):
        bad = []
        for p in permutations(range(1, n + 1)):
            m = parikh_literal(p, n)
            q = inv(p)
            runs, cur = [], 1
            for i in range(1, n):
                if q[i - 1] < q[i]:
                    cur += 1
                else:
                    runs.append(cur)
                    cur = 1
            runs.append(cur)
            des = popcount(dmask(q))
            for j in range(1, n + 1):
                diag = sum(m[r][r + j] for r in range(n - j + 1))
                cons = sum(1 for s in range(n - j + 1) if all(q[s + t] < q[s + t + 1] for t in range(j - 1)))
                runform = sum(max(L - j + 1, 0) for L in runs)
                if not diag == cons == runform:
                    bad.append((p, j))
                if j == 1 and diag != n:
                    bad.append((p, "j=1"))
                if j == 2 and diag != n - 1 - des:
                    bad.append((p, "j=2"))
                if j == n and diag != int(p == tuple(range(1, n + 1))):
                    bad.append((p, "j=n"))
        c.ok(f"D.1 diagonal sums = consecutive 12..j in p^-1 = run-length form, n={n}", not bad, str(bad[:3]))
    c.note("D.1: literal matrices for S_n, n <= 7, every j, with the j = 1, 2, n cases")


def check_E(c: Checker, E: list[int], sw: dict, beta: dict) -> None:
    t0 = time.perf_counter()
    # E.0: degrees versus the criteria on J; sinks = maximal elements; sinks = sources in number.
    for n in range(3, 11):
        full = (1 << n) - 1
        ok = True
        for J in range(full + 1):
            sinks, sources, through = cyc_types(n, J)
            bit = [(J >> e) & 1 for e in range(n)]
            ok &= set(through) == {v for v in range(n) if bit[v - 1] == bit[v]}
            ok &= set(sinks) == {v for v in range(n) if (bit[v - 1], bit[v]) == (1, 0)}
            ok &= set(sources) == {v for v in range(n) if (bit[v - 1], bit[v]) == (0, 1)}
            ok &= len(sinks) == len(sources)
            if J not in (0, full):
                succ, pred = cyc_orient(n, J)
                up = closure(n, succ)
                ok &= {v for v in range(n) if up[v] == 0} == set(sinks)
                ok &= {v for v in range(n) if not any(up[u] >> v & 1 for u in range(n))} == set(sources)
                ok &= all((sinks[i] + 1) % n != sinks[j] for i in range(len(sinks)) for j in range(len(sinks)))
                ok &= len(sinks) <= n // 2
        c.ok(f"E.0 through iff J_(i-1) = J_i, sink iff (1,0); #sinks = #sources; sinks = maximal; "
             f"no adjacent sinks, n={n}", ok)
    for n in range(3, 8):
        ok = True
        for p in permutations(range(1, n + 1)):
            pos = positions(p)
            sinks, _, through = cyc_types(n, cycle_vector(p))
            for v in range(n):
                i, lo, hi = v + 1, (v - 1) % n + 1, (v + 1) % n + 1
                before = (pos[lo] < pos[i]) + (pos[hi] < pos[i])
                ok &= (v in sinks) == (before == 2)
                ok &= (v in through) == (before == 1)
                ok &= (v in through) == ((pos[lo] < pos[i] < pos[hi]) or (pos[hi] < pos[i] < pos[lo]))
        c.ok(f"E.0 letter i is a sink iff both cyclic neighbours precede it; through iff one does, n={n}", ok)

    # E.1: psi_C(p) = phi_B(cDes(p^-1)); 2^n - 2 nonempty fibres; fibres = linear extensions.
    for n in range(3, 10):
        full = (1 << n) - 1
        rc = sw[n][1]
        if n <= 7:
            ok = True
            fibres = defaultdict(set)
            for p in permutations(range(1, n + 1)):
                lit = sum(occ(p, (i, i + 1)) << (i - 1) for i in range(1, n)) | (occ(p, (n, 1)) << (n - 1))
                ok &= lit == cycle_vector(p) == cyclic_ascent_mask(inv(p))
                fibres[lit].add(p)
            c.ok(f"E.1 psi_C(p) by subword counts = cyclic-ascent indicator of p^-1, n={n}", ok)
            c.ok(f"E.1 each fibre = linear extensions of P_(O_J) as words, n={n}",
                 all(fibres[J] == lin_ext_words(n, cyc_orient(n, J)[1], range(1, n + 1))
                     for J in range(1, full)))
        c.check(f"E.1 nonempty fibres are exactly the J other than 0^n, 1^n, n={n}",
                set(rc), set(range(1, full)))
        c.ok(f"E.1 fibre size = e(P_(O_J)) (down-set DP), n={n}",
             all(rc[J] == cyc_e(n, J) for J in range(1, full)))
    by4 = sorted("".join(map(str, p)) for p in permutations(range(1, 5)) if cycle_vector(p) == 0b0101)
    c.check("E.1 example n = 4, J = (1,0,1,0)", by4, ["1324", "1342", "3124", "3142"])
    by5 = sorted("".join(map(str, p)) for p in permutations(range(1, 6)) if cycle_vector(p) == 0b10101)
    c.check("E.1 example n = 5, J* = (1,0,1,0,1)", by5,
            ["35124", "35142", "35412", "51324", "51342", "53124", "53142", "53412"])

    # E.2: Lemmas 1-3 and the sink formula; the even maximum and its sigma-descriptions.
    for N in range(1, 10):
        ok = True
        for Q in range(1 << (N - 1)):  # orientations of the path y_1 - ... - y_N
            pred = [0] * N
            S = 0
            for i in range(1, N):
                if Q >> (i - 1) & 1:  # y_{i+1} -> y_i
                    pred[i - 1] |= 1 << i
                    S |= 1 << (i - 1)
                else:
                    pred[i] |= 1 << (i - 1)
            ok &= count_lin_ext(N, pred) == beta[N][S] == sw[N][2][S]
        c.ok(f"E.2 Lemma 3: e(P_Q) = beta_N(S_Q) for every orientation Q of a path, N={N}", ok)
    for n in range(3, 10):
        ok = True
        for J in range(1, (1 << n) - 1):
            succ, pred = cyc_orient(n, J)
            up = closure(n, succ)
            e = count_lin_ext(n, pred)
            maxima = [v for v in range(n) if up[v] == 0]
            rest = 0
            for v in maxima:  # e(P minus v), P minus v the induced subposet
                keep = [u for u in range(n) if u != v]
                idx = {u: i for i, u in enumerate(keep)}
                sub_pred = [0] * (n - 1)
                for u in keep:
                    for w in keep:
                        if up[u] >> w & 1:
                            sub_pred[idx[w]] |= 1 << idx[u]
                rest += count_lin_ext(n - 1, sub_pred)
            ok &= e == rest
        c.ok(f"E.2 Lemma 1: e(P) = sum over maximal v of e(P - v), all O_J, n={n}", ok)
    for n in range(3, 13):
        c.ok(f"E.2 sink formula = down-set DP, every acyclic J, n={n}",
             all(sink_formula(n, J, beta[n - 1]) == cyc_e(n, J) for J in range(1, (1 << n) - 1)))
    for n in range(3, 19):
        full = (1 << n) - 1
        reps = necklaces(n) if n > 12 else range(1, full)
        c.ok(f"E.2 sink formula, bit version = orientation version, n={n}",
             all(sink_formula_bits(n, J, beta[n - 1], full) == sink_formula(n, J, beta[n - 1])
                 for J in reps if J not in (0, full)))
    for n in (4, 6, 8):
        Kev = sum(1 << e for e in range(0, n, 2))  # J = (1,0,...,1,0): even letters are sinks
        Kod = sum(1 << e for e in range(1, n, 2))  # J = (0,1,...,0,1)
        c.check(f"E.2 K^ev has the even letters as sinks, n={n}",
                [v + 1 for v in cyc_types(n, Kev)[0]], list(range(2, n + 1, 2)))
        fib_ev = {inv(p) for p in permutations(range(1, n + 1)) if cycle_vector(p) == Kev}
        fib_od = {inv(p) for p in permutations(range(1, n + 1)) if cycle_vector(p) == Kod}
        up_down = {s for s in permutations(range(1, n + 1)) if is_revalt(s) and s[-1] > s[0]}
        down_up = {s for s in permutations(range(1, n + 1)) if is_alt(s) and s[-1] < s[0]}
        c.check(f"E.2 crown fibre K^ev in sigma terms (Kreweras's circular up-down), n={n}", fib_ev, up_down)
        c.check(f"E.2 crown fibre K^od in sigma terms, n={n}", fib_od, down_up)
    c.check("OEIS A024255 example (sigma form of K^ev, n = 4)",
            sorted("".join(map(str, inv(p))) for p in permutations(range(1, 5)) if cycle_vector(p) == 0b0101),
            ["1324", "1423", "2314", "2413"])

    # E.3a: the almost-bipartite orientations; one dihedral orbit; e = E_n/2.
    for n in range(3, 16, 2):
        full = (1 << n) - 1
        ab = {J for J in range(1, full) if len(cyc_types(n, J)[2]) == 1}
        c.check(f"E.3a there are 2n almost-bipartite J, n={n}", len(ab), 2 * n)
        Jstar = sum(1 << e for e in range(0, n, 2))
        c.check(f"E.3a J* has through vertex 1, with n -> 1 -> 2, n={n}",
                (cyc_types(n, Jstar)[2], cyc_orient(n, Jstar)[0][n - 1] >> 0 & 1,
                 cyc_orient(n, Jstar)[0][0] >> 1 & 1), ([0], 1, 1))
        orbit = [act(n, Jstar, g) for g in dihedral(n)]
        c.ok(f"E.3a the dihedral group acts simply transitively on them, n={n}",
             set(orbit) == ab and len(set(orbit)) == 2 * n)
        c.ok(f"E.3a e(P_O) = E_n/2 for all 2n of them, n={n}",
             all(2 * cyc_e(n, J) == E[n] for J in ab))
    for n in range(3, 10, 2):
        ps = permutations(range(1, n + 1))
        c.check(f"E.3a #(reverse alternating t with t_n < t_1) = E_n/2, n={n}",
                2 * sum(1 for t in ps if is_revalt(t) and t[-1] < t[0]), E[n])
    for n in (3, 5, 7):
        Jstar = sum(1 << e for e in range(0, n, 2))
        fib = {inv(p) for p in permutations(range(1, n + 1)) if cycle_vector(p) == Jstar}
        c.check(f"E.3a J* fibre in sigma terms, n={n}", fib,
                {s for s in permutations(range(1, n + 1)) if is_revalt(s) and s[-1] < s[0]})

    # E.3b: the comparability steps of the proof; n = 3; Lemma 4.
    c.ok("E.3b n = 3: every acyclic orientation has one directed 2-path and e = 1",
         all(len(cyc_types(3, J)[2]) == 1 and cyc_e(3, J) == 1 for J in range(1, 7)))
    for n in range(5, 12, 2):
        full = (1 << n) - 1
        cyc_edges = {frozenset((e, (e + 1) % n)) for e in range(n)}
        ok, strict_pairs = True, 0
        for J in range(1, full):
            sinks, _, through = cyc_types(n, J)
            succ, _ = cyc_orient(n, J)
            comO = comparable_pairs(n, succ)
            ab = len(through) == 1
            for bv in through:
                av = next(u for u in ((bv - 1) % n, (bv + 1) % n) if succ[u] >> bv & 1)
                cv = next(u for u in ((bv - 1) % n, (bv + 1) % n) if succ[bv] >> u & 1)
                s2 = [0] * n  # O_abc: a -> b -> c, and the path c = y_1, ..., y_2m = a alternates
                s2[av] |= 1 << bv
                s2[bv] |= 1 << cv
                step = 1 if cv == (bv + 1) % n else -1
                ys = [(cv + step * i) % n for i in range(n - 1)]
                for i in range(1, n - 1):  # edge {y_i, y_(i+1)}, y_i a sink for odd i
                    y, z = ys[i - 1], ys[i]
                    if i % 2 == 1:
                        s2[z] |= 1 << y
                    else:
                        s2[y] |= 1 << z
                J2 = sum(1 << e for e in range(n) if s2[e] >> ((e + 1) % n) & 1)
                ok &= cyc_types(n, J2)[2] == [bv]
                com2 = comparable_pairs(n, s2)
                ok &= com2 == cyc_edges | {frozenset((av, cv))}
                ok &= com2 <= comO
                ok &= (com2 < comO) == (not ab)
                strict_pairs += com2 < comO
        c.ok(f"E.3b Com(P_(O_abc)) = E(C_n) + {{a,c}}, inside Com(P_O), properly iff O is not "
             f"almost bipartite; all acyclic O and through b, n={n}", ok)
        c.note(f"E.3b n={n}: {strict_pairs} pairs (O, b) with proper inclusion")
    for n in range(4, 8):
        data = []
        for J in range(1, (1 << n) - 1):
            succ, pred = cyc_orient(n, J)
            data.append((comparable_pairs(n, succ), count_lin_ext(n, pred)))
        ok = all(eP <= eQ and (comQ == comP or eP < eQ)
                 for comP, eP in data for comQ, eQ in data if comQ <= comP)
        c.ok(f"E.3b Lemma 4 on all pairs of acyclic orientations of C_n, n={n}", ok)
    rnd = random.Random(1405488)
    tested = 0
    ok = True
    for _ in range(3000):
        n = 7
        order = list(range(n))
        rnd.shuffle(order)
        rank = {v: i for i, v in enumerate(order)}
        succP = [0] * n
        for x, y in combinations(range(n), 2):
            if rnd.random() < 0.35:
                lo, hi = (x, y) if rank[x] < rank[y] else (y, x)
                succP[lo] |= 1 << hi
        comP = comparable_pairs(n, succP)
        sub = [pr for pr in sorted(tuple(sorted(q)) for q in comP)
               if rnd.random() < 0.7]  # a random subgraph of Com(P)
        rnd.shuffle(order)
        rank = {v: i for i, v in enumerate(order)}
        succQ = [0] * n
        for x, y in sub:
            lo, hi = (x, y) if rank[x] < rank[y] else (y, x)
            succQ[lo] |= 1 << hi
        comQ = comparable_pairs(n, succQ)
        if comQ <= comP:
            tested += 1
            eP = count_lin_ext(n, succ_to_pred(n, succP))
            eQ = count_lin_ext(n, succ_to_pred(n, succQ))
            ok &= eP <= eQ and (comQ == comP or eP < eQ)
    c.ok(f"E.3b Lemma 4 on {tested} seeded random pairs of 7-element posets", ok and tested > 500)

    # E.3 remarks.
    for n in range(3, 16, 2):
        m = n // 2
        ok = True
        for J in range(1, (1 << n) - 1):
            sinks, sources, through = cyc_types(n, J)
            ok &= len(sinks) == len(sources)
            ok &= len(sinks) == m if len(through) == 1 else len(sinks) <= m - 1
        c.ok(f"E.3 remark: #sinks = m if almost bipartite, else <= m-1, n={n}", ok)
    holds = [m for m in range(1, 301) if (m - 1) * E[2 * m] > Fraction(E[2 * m + 1], 2)]
    c.check("E.3 remark: (m-1) E_2m > E_(2m+1)/2 exactly for 4 <= m <= 300", holds, list(range(4, 301)))
    c.check("E.3 remark: m = 4 values", (3 * E[8], E[9] // 2), (4155, 3968))
    c.ok("Iriarte Ex. 4.6 bounds hold for E_(2m+1)/2, 1 <= m <= 40",
         all(Fraction(factorial(2 * m + 1), 3 ** (2 * m - 2) * 6) <= Fraction(E[2 * m + 1], 2)
             <= Fraction((2 * m + 1) * E[2 * m], 2) for m in range(1, 41)))
    c.note(f"E.0-E.3: {time.perf_counter() - t0:.1f} s")

    # E.4: the table, by three methods.
    t1 = time.perf_counter()
    found = {}
    for n in range(3, 10):  # brute force over S_n
        rc = sw[n][1]
        top = max(rc.values())
        found[n] = (top, sum(1 for J in rc if rc[J] == top), {J for J in rc if rc[J] == top})
    for n in range(3, 15):  # down-set DP: all J for n <= 10, rotation classes beyond
        full = (1 << n) - 1
        if n <= 10:
            vals = {J: cyc_e(n, J) for J in range(1, full)}
            c.ok(f"E.4 rotation invariance of e(P_(O_J)), n={n}",
                 all(vals[J] == vals[((J << 1) | (J >> (n - 1))) & full] for J in vals))
            if n <= 9:
                c.ok(f"E.4 down-set DP = brute force, fibre by fibre, n={n}",
                     all(vals[J] == sw[n][1][J] for J in vals))
            top = max(vals.values())
            arg = {J for J in vals if vals[J] == top}
        else:
            vals = {J: cyc_e(n, J) for J in necklaces(n) if J not in (0, full)}
            top = max(vals.values())
            arg = set().union(*(rotation_orbit(n, J) for J in vals if vals[J] == top))
        dp = (top, len(arg), arg)
        if n in found:
            c.check(f"E.4 brute force = down-set DP, n={n}", found[n], dp)
        found[n] = dp
    for n in range(3, 19):  # the sink formula of E.2 with an exact beta table
        full = (1 << n) - 1
        reps = [J for J in necklaces(n) if J not in (0, full)]
        vals = {J: sink_formula_bits(n, J, beta[n - 1], full) for J in reps}
        top = max(vals.values())
        arg = set().union(*(rotation_orbit(n, J) for J in reps if vals[J] == top))
        sf = (top, len(arg), arg)
        if n in found:
            c.check(f"E.4 sink formula = earlier method, n={n}", sf, found[n])
        found[n] = sf
    for n in range(3, 19):
        top, count, arg = found[n]
        m = n // 2
        full = (1 << n) - 1
        c.check(f"E.4 table row n={n}", (top, count), E4_TABLE[n])
        if n % 2 == 0:
            Kev = sum(1 << e for e in range(0, n, 2))
            c.check(f"E.2 max = m E_(2m-1) at exactly the two crowns, n={n}",
                    (top, arg), (m * E[n - 1], {Kev, Kev << 1}))
            c.check(f"E.4 = OEIS A024255, n={n}", top, A024255[m])
        else:
            ab = {J for J in range(1, full) if len(cyc_types(n, J)[2]) == 1} if n <= 15 else None
            c.check(f"E.3b max = E_n/2, n={n}", 2 * top, E[n])
            if ab is not None:
                c.check(f"E.3b argmax = the almost-bipartite J, n={n}", arg, ab)
            else:
                c.ok(f"E.3b argmax = the almost-bipartite J, n={n}",
                     len(arg) == 2 * n and all(len(cyc_types(n, J)[2]) == 1 for J in arg))
            c.check(f"E.4 = OEIS A024283, n={n}", top, A024283[m])
    c.check("OEIS A024255: a(n) = n E_(2n-1) (n <= 17)", A024255[1:], [k * E[2 * k - 1] for k in range(1, 18)])
    c.check("OEIS A024283: a(n) = E_(2n+1)/2 (1 <= n <= 16)", A024283[1:], [E[2 * k + 1] // 2 for k in range(1, 17)])
    c.note(f"E.4: brute force 3 <= n <= 9; down-set DP n <= 14; sink formula n <= 18 "
           f"({time.perf_counter() - t1:.1f} s)")


def check_G(c: Checker) -> None:
    t0 = time.perf_counter()
    contents = []
    for k in range(2, 6):
        for total in range(k, G2_MAX_TOTAL + 1):
            for cut in combinations(range(1, total), k - 1):
                b = (0,) + cut + (total,)
                contents.append(tuple(b[i + 1] - b[i] for i in range(k)))
    bad = []
    nwords = 0
    for content in contents:
        k = len(content)
        words = multiset_words(list(content))
        nwords += len(words)
        index = {w: i for i, w in enumerate(words)}
        parent = list(range(len(words)))

        def find(x: int) -> int:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        for i, w in enumerate(words):
            for p in range(len(w) - 1):
                if abs(w[p] - w[p + 1]) >= 2:
                    q = w[:p] + (w[p + 1], w[p]) + w[p + 2:]
                    ra, rb = find(i), find(index[q])
                    if ra != rb:
                        parent[ra] = rb
        classes = defaultdict(list)
        projections = defaultdict(set)
        for i, w in enumerate(words):
            classes[find(i)].append(w)
            projections[tuple(tuple(x for x in w if x in (j, j + 1)) for j in range(1, k))].add(w)
        if {frozenset(v) for v in classes.values()} != {frozenset(v) for v in projections.values()}:
            bad.append(("classes != projection classes", content))
        offset = [0] * (k + 2)
        for j in range(1, k + 1):
            offset[j + 1] = offset[j] + content[j - 1]
        N = sum(content)
        info = []  # (size, transitive, words)
        for ws in classes.values():
            w = ws[0]
            seen = [0] * (k + 1)
            occ_id = []
            for x in w:
                occ_id.append(offset[x] + seen[x])
                seen[x] += 1
            letter = [0] * N
            for p, x in enumerate(w):
                letter[occ_id[p]] = x
            succ = [0] * N
            for p in range(N):
                for q in range(p + 1, N):
                    if abs(w[p] - w[q]) <= 1:
                        succ[occ_id[p]] |= 1 << occ_id[q]
            e = count_lin_ext(N, succ_to_pred(N, succ))
            if e != len(ws):
                bad.append(("class size != e(heap)", content, w))
            up = closure(N, succ)
            transitive = all(abs(letter[x] - letter[y]) <= 1
                             for x in range(N) for y in range(N) if up[x] >> y & 1)
            info.append((len(ws), transitive, set(ws)))
        top = max(s for s, _, _ in info)
        if {i for i, (s, _, _) in enumerate(info) if s == top} != {i for i, (_, t, _) in enumerate(info) if t}:
            bad.append(("largest != transitive", content))
        odd_first = tuple(x for x in range(1, k + 1, 2) for _ in range(content[x - 1])) + \
            tuple(x for x in range(2, k + 1, 2) for _ in range(content[x - 1]))
        even_first = tuple(x for x in range(2, k + 1, 2) for _ in range(content[x - 1])) + \
            tuple(x for x in range(1, k + 1, 2) for _ in range(content[x - 1]))
        for alt_word in (odd_first, even_first):
            if not any(alt_word in ws and s == top for s, _, ws in info):
                bad.append(("alternating block class not largest", content, alt_word))
        zsucc = [0] * N  # Z(n): chains, with every odd-letter occurrence below the adjacent even ones
        for x in range(N):
            for y in range(N):
                lx = next(j for j in range(1, k + 1) if offset[j] <= x < offset[j + 1])
                ly = next(j for j in range(1, k + 1) if offset[j] <= y < offset[j + 1])
                if (lx == ly and x < y) or (abs(lx - ly) == 1 and lx % 2 == 1):
                    zsucc[x] |= 1 << y
        if count_lin_ext(N, succ_to_pred(N, zsucc)) != top:
            bad.append(("max != e(Z(n))", content))
        nmax = sum(1 for s, _, _ in info if s == top)
        want = comb(content[0] + content[1], content[0]) if k == 2 else (content[1] + 1 if k == 3 else 2)
        if nmax != want:
            bad.append(("number of largest classes", content, nmax, want))
        if all(min(content[i], content[i + 1]) == 1 for i in range(k - 1)):
            fib = defaultdict(set)
            for w in words:
                fib[tuple(occ(w, (j, j + 1)) for j in range(1, k))].add(w)
            if {frozenset(v) for v in fib.values()} != {frozenset(v) for v in classes.values()}:
                bad.append(("isolated: psi_2 fibres != classes", content))
            a0 = tuple(content[j - 1] * content[j] if j % 2 == 1 else 0 for j in range(1, k))
            a1 = tuple(content[j - 1] * content[j] if j % 2 == 0 else 0 for j in range(1, k))
            if not (len(fib[a0]) == len(fib[a1]) == top == max(len(v) for v in fib.values())):
                bad.append(("isolated: alternating vectors not maximal", content))
    c.ok(f"G.2 classes = heaps; largest = transitive; alternating blocks largest; "
         f"{len(contents)} contents", not bad, str(bad[:3]))
    tops = {}
    for content in ((1, 2, 1), (2, 2, 2), (1, 3, 1), (2, 3, 2)):
        words = multiset_words(list(content))
        sizes = Counter()
        for w in words:
            sizes[tuple(tuple(x for x in w if x in (j, j + 1)) for j in (1, 2))] += 1
        top = max(sizes.values())
        tops[content] = sum(1 for v in sizes.values() if v == top)
    c.check("G.2 numbers of largest classes", tops, {(1, 2, 1): 3, (2, 2, 2): 3, (1, 3, 1): 4, (2, 3, 2): 4})
    c.note(f"G.2: {len(contents)} contents with 2 <= k <= 5 letters and total <= {G2_MAX_TOTAL}, "
           f"{nwords} words ({time.perf_counter() - t0:.1f} s)")


def main() -> int:
    start = time.perf_counter()
    c = Checker("R5 opening and cyclic companion (notes/r5-opening.md)")
    E = [1]
    row = [1]
    for _ in range(620):  # Seidel's boustrophedon, independent of permutations
        new = [0]
        for x in reversed(row):
            new.append(new[-1] + x)
        row = new
        E.append(row[-1])
    check_numbers(c, E)
    sw = {n: sweep(n) for n in range(1, 10)}
    beta = {N: beta_table(N) for N in range(1, 18)}
    c.note(f"setup: S_n swept for n <= 9, beta tables for N <= 17 ({time.perf_counter() - start:.1f} s)")
    check_A(c, sw, beta)
    check_B(c, E, sw, beta)
    check_C(c, E)
    check_D(c)
    check_E(c, E, sw, beta)
    check_G(c)
    c.note(f"total {time.perf_counter() - start:.1f} s")
    return c.finish()


if __name__ == "__main__":
    sys.exit(main())
