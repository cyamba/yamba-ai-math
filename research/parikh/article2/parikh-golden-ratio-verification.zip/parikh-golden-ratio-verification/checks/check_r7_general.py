"""R7, general k: largest Parikh classes and psi_2 fibres for non-isolated path contents.
Checks for notes/explore-r7-general.md.  Python 3.11+, standard library only,
deterministic; accepts and ignores unknown arguments (run_all.py passes --max-n); exits
non-zero on any failure.  Add --slow for the k = 9 rows of (2^k) (about 15 s more).

Objects.  Content n = (n_1, ..., n_k), all n_i >= 1.  psi_2(w) = (|w|_{12}, ..., |w|_{(k-1)k}).
A Parikh class is the set of words of content n with equal Parikh matrix, i.e. equal
|w|_{j(j+1)...l} for all j < l.  e(Z(n)) is the size of the alternating trace class
(projections alternately "all i before all i+1" and "all i+1 before all i").

Two independent methods.
  * Brute force: enumerate every word, compute every |w|_{j..l} by a left-to-right scan.
  * Transfer DP (copied from notes/r7-scripts/general/pathdp.py): adjacent binary
    projections lam, gap state L of the letters below the current chain, and for the
    full matrix the vectors F_j(s) = #occurrences of j..(i-1) before the s-th i.

What is checked (bounds as stated in the note).
  A. DP = brute force: the whole map (psi_2, higher entries) -> class size, and the psi_2
     table by meet in the middle at every split letter, for every content with k >= 3 and
     total <= 8, and for (2^5), (3,3,3), (2,3,2,3).
  B. (2^k): e(Z), largest psi_2 fibre (unique, central), largest Parikh class with all its
     maximisers, largest non-alternating class, number of classes in the central fibre.
     Brute force for k <= 5 (and the number of classes, k <= 5); DP for k <= 8 (k = 9 with
     --slow).  For k >= 6 the largest non-alternating classes are exactly the four
     end-relaxed vectors.
  C. Central fibre of (2^k): every higher entry is 0 or 2; the classes correspond exactly
     to the "QP-descent sets" of the label words (P = (1,1), Q = (0,2)); there are F_k
     (Fibonacci) classes.  Brute force k <= 5, DP k <= 8.
  D. Relaxation lemma: for every content with k >= 4 and total <= 8 (and (2^5),
     (2,3,2,3)), every alternating
     pattern, every set S of pairwise non-adjacent edges and every area vector on S, the
     psi_2 fibre (areas off S as in the pattern) is a single Parikh class (brute force).
  E. (3^k): brute force (3,3,3,3): largest class 798 > e(Z) = 662, attained exactly at the
     four end-relaxed vectors; psi_2 max 2560 at (3,6,3), (6,3,6).  DP: (3^5) largest class
     66024 > 57400 at (3,9,0,6), (6,0,9,3) only.  Relaxed classes beat e(Z) for (3^k),
     k = 6, 7 (exact relaxed class sizes, which are lower bounds for the largest class).
  F. Scan, k >= 4, total <= 10: classification of every content (alternating / tie /
     relaxed / other) reproduces the recorded counts; brute-force cross-check of the
     largest class and its multiplicity for total <= 8; the {1,2} end-block rule (C4) on
     every {1,2}-content with k >= 4 and total <= 10.
  G. (2^k), 4 <= k <= 9: the end-ratio formula e(Z) = sum C(p+2,2), R_left = sum
     (p+1)(q+1) + C(m+2,2) over the gap profile (p, m, q) of the 2-chain in the alternating
     class on letters 2..k; brute force of R_left for k <= 5.
"""

from __future__ import annotations

import sys
import time
from functools import lru_cache
from itertools import combinations, combinations_with_replacement
from itertools import product as iproduct
from math import comb, factorial, prod
from operator import mul

from parikh import Checker

START = time.perf_counter()
SLOW = "--slow" in sys.argv[1:]

# ---------------------------------------------------------------------------
# Brute force
# ---------------------------------------------------------------------------


def words(n):
    n = list(n)
    total = sum(n)
    out = []
    w = []

    def rec():
        if len(w) == total:
            out.append(tuple(w))
            return
        for a in range(len(n)):
            if n[a]:
                n[a] -= 1
                w.append(a + 1)
                rec()
                w.pop()
                n[a] += 1

    rec()
    return out


def keys_of(w, k):
    c = [[0] * (k + 2) for _ in range(k + 2)]
    for ch in w:
        row = ch - 1
        for j in range(1, ch):
            c[j][ch] += c[j][row]
        c[ch][ch] += 1
    psi2 = tuple(c[i][i + 1] for i in range(1, k))
    rest = tuple(c[j][l] for l in range(3, k + 1) for j in range(1, l - 1))
    return psi2, rest


def brute(n):
    k = len(n)
    p2, full = {}, {}
    for w in words(n):
        a, b = keys_of(w, k)
        p2[a] = p2.get(a, 0) + 1
        full[(a, b)] = full.get((a, b), 0) + 1
    return p2, full


def in_alt_class(w, n, first_full):
    """Is w in the alternating trace class?  Checked on the binary projections."""
    k = len(n)
    full = first_full
    for i in range(1, k):
        proj = [ch for ch in w if ch in (i, i + 1)]
        want = [i] * n[i - 1] + [i + 1] * n[i] if full else [i + 1] * n[i] + [i] * n[i - 1]
        if proj != want:
            return False
        full = not full
    return True


# ---------------------------------------------------------------------------
# Transfer DP (copy of notes/r7-scripts/general/pathdp.py)
# ---------------------------------------------------------------------------


@lru_cache(maxsize=None)
def lambdas(ni, nj):
    return tuple(combinations_with_replacement(range(ni + 1), nj))


@lru_cache(maxsize=None)
def lambdas_by_area(ni, nj):
    out = {}
    for lam in lambdas(ni, nj):
        out.setdefault(sum(lam), []).append(lam)
    return out


@lru_cache(maxsize=None)
def compositions(total, parts):
    if parts == 1:
        return ((total,),)
    return tuple((f,) + r for f in range(total + 1) for r in compositions(total - f, parts - 1))


@lru_cache(maxsize=None)
def gap_counts(lam, ni):
    a = [0] * (ni + 1)
    for t in lam:
        a[t] += 1
    return tuple(a)


@lru_cache(maxsize=None)
def transfer(L, lam):
    ni = len(L) - 1
    a = gap_counts(lam, ni)
    states = {((), 0): 1}
    for g in range(ni + 1):
        new = {}
        for (closed, acc), m in states.items():
            for comp in compositions(L[g], a[g] + 1):
                c2 = closed
                ac = acc + comp[0]
                for r in range(1, a[g] + 1):
                    c2 = c2 + (ac,)
                    ac = comp[r]
                if g < ni:
                    ac += 1
                new[(c2, ac)] = new.get((c2, ac), 0) + m
        states = new
    out = {}
    for (closed, acc), m in states.items():
        out[closed + (acc,)] = out.get(closed + (acc,), 0) + m
    return tuple(out.items())


@lru_cache(maxsize=None)
def lastw(L, lam):
    a = gap_counts(lam, len(L) - 1)
    return prod(comb(L[g] + a[g], a[g]) for g in range(len(L)))


def trace_size(n, lams):
    D = {(0,) * (n[0] + 1): 1}
    for i in range(len(n) - 1):
        if i == len(n) - 2:
            return sum(w * lastw(L, lams[i]) for L, w in D.items())
        new = {}
        for L, w in D.items():
            for Lp, m in transfer(L, lams[i]):
                new[Lp] = new.get(Lp, 0) + w * m
        D = new
    return 1


def alt_lams(n, first_full):
    out, full = [], first_full
    for i in range(len(n) - 1):
        out.append((n[i],) * n[i + 1] if full else (0,) * n[i + 1])
        full = not full
    return out


def alt_psi2(n):
    k = len(n)
    return (tuple(n[i] * n[i + 1] if i % 2 == 0 else 0 for i in range(k - 1)),
            tuple(0 if i % 2 == 0 else n[i] * n[i + 1] for i in range(k - 1)))


def e_alt(n):
    return trace_size(n, alt_lams(n, True)) if len(n) > 1 else 1


def fwd_states(n, upto):
    D = {((), (0,) * (n[0] + 1)): 1}
    for i in range(upto - 1):
        new = {}
        for (xs, L), w in D.items():
            for lam in lambdas(n[i], n[i + 1]):
                xs2 = xs + (sum(lam),)
                for Lp, m in transfer(L, lam):
                    new[(xs2, Lp)] = new.get((xs2, Lp), 0) + w * m
        D = new
    return D


def psi2_mitm(n, m=None):
    k = len(n)
    if m is None:
        m = (k + 1) // 2
    m = max(2, min(k - 1, m))
    left = fwd_states(n, m)
    rev = tuple(reversed(n[m - 1:]))
    right = {}
    for (ys, R), w in fwd_states(rev, k - m + 1).items():
        xr = tuple(n[k - 1 - j] * n[k - 2 - j] - ys[j] for j in range(len(ys)))[::-1]
        right[(xr, R)] = right.get((xr, R), 0) + w
    Rs = sorted({R for (_, R) in right})
    Ridx = {R: r for r, R in enumerate(Rs)}
    rg = {}
    for (xr, R), w in right.items():
        rg.setdefault(xr, [0] * len(Rs))[Ridx[R]] += w
    lg = {}
    for (xl, L), w in left.items():
        lg.setdefault(xl, []).append((L, w))
    out = {}
    for xl, items in lg.items():
        u = [0] * len(Rs)
        for L, w in items:
            for r, R in enumerate(Rs):
                u[r] += w * prod(comb(L[g] + R[g], L[g]) for g in range(len(L)))
        for xr, v in rg.items():
            out[xl + xr] = sum(map(mul, u, v))
    return out


def classes_in_fibre(n, x):
    k = len(n)
    D = {((0,) * (n[0] + 1), (), ()): 1}
    for i in range(k - 1):
        lams = lambdas_by_area(n[i], n[i + 1]).get(x[i], [])
        last = i == k - 2
        new = {}
        for (L, F, key), w in D.items():
            P = []
            for f in F:
                ps = [0]
                for v in f:
                    ps.append(ps[-1] + v)
                P.append(ps)
            for lam in lams:
                Fp = tuple(tuple(ps[t] for t in lam) for ps in P)
                key2 = key + tuple(sum(f) for f in Fp)
                if last:
                    new[key2] = new.get(key2, 0) + w * lastw(L, lam)
                else:
                    for Lp, m in transfer(L, lam):
                        st = (Lp, Fp + (lam,), key2)
                        new[st] = new.get(st, 0) + w * m
        D = new
    return D


def largest_class(n, tab=None):
    """(best, winners) over all Parikh classes; prunes fibres smaller than e(Z)."""
    tab = psi2_mitm(n) if tab is None else tab
    best = e_alt(n)
    winners = []
    for s, x in sorted(((s, x) for x, s in tab.items() if s >= best), reverse=True):
        if s < best:
            break
        for key, size in classes_in_fibre(n, x).items():
            if size > best:
                best, winners = size, [(x, key)]
            elif size == best:
                winners.append((x, key))
    return best, winners


def relaxed(n, first_full, S):
    k = len(n)
    D = {((), (0,) * (n[0] + 1)): 1}
    full = first_full
    for i in range(k - 1):
        lams = lambdas(n[i], n[i + 1]) if i in S else (
            ((n[i],) * n[i + 1],) if full else ((0,) * n[i + 1],))
        full = not full
        new = {}
        for (xs, L), w in D.items():
            for lam in lams:
                xs2 = xs + (sum(lam),) if i in S else xs
                if i == k - 2:
                    new[xs2] = new.get(xs2, 0) + w * lastw(L, lam)
                else:
                    for Lp, m in transfer(L, lam):
                        new[(xs2, Lp)] = new.get((xs2, Lp), 0) + w * m
        D = new
    return D


def indep_sets(m):
    return [c for r in range(1, m + 1) for c in combinations(range(m), r)
            if all(c[j + 1] - c[j] >= 2 for j in range(len(c) - 1))]


def own_areas(n, first_full, S):
    return tuple(n[i] * n[i + 1] if (i % 2 == 0) == first_full else 0 for i in sorted(S))


def pattern_vector(n, first_full, S, xs):
    a, b = alt_psi2(n)
    base = list(a if first_full else b)
    for i, v in zip(sorted(S), xs):
        base[i] = v
    return tuple(base)


def best_proper_relaxation(n):
    best = 0
    for S in indep_sets(len(n) - 1):
        for ff in (True, False):
            own = own_areas(n, ff, S)
            for xs, size in relaxed(n, ff, set(S)).items():
                if xs != own:
                    best = max(best, size)
    return best


def comps(total, parts):
    if parts == 1:
        yield (total,)
        return
    for f in range(1, total - parts + 2):
        for r in comps(total - f, parts - 1):
            yield (f,) + r


def fib(k):
    a, b = 1, 1
    for _ in range(k - 1):
        a, b = b, a + b
    return a


# ---------------------------------------------------------------------------
# Recorded values (notes/explore-r7-general.md, tables 1-3)
# ---------------------------------------------------------------------------

EZ2 = {1: 1, 2: 1, 3: 6, 4: 53, 5: 840, 6: 18717, 7: 585984, 8: 24004425, 9: 1258008192}
PSI2MAX2 = {2: 2, 3: 12, 4: 132, 5: 2372, 6: 62304, 7: 2261668, 8: 108184432,
            9: 6600715188}
MMAX2 = {2: 2, 3: 6, 4: 56, 5: 844, 6: 18717, 7: 585984, 8: 24004425, 9: 1258008192}
NONALT2 = {6: 16098, 7: 490728, 8: 20326650, 9: 1060140888}
CENTRAL_BEST2 = {3: 6, 4: 56, 5: 844, 6: 15450, 7: 471674, 8: 15892120, 9: 815999564}
NCLASSES2 = {2: 5, 3: 30, 4: 173, 5: 993}


def main() -> int:
    chk = Checker("R7 general k: largest Parikh classes and psi_2 fibres (explore-r7-general)")

    # ---- A. DP = brute force -------------------------------------------------------
    cases = [n for T in range(3, 9) for k in range(3, T + 1) for n in comps(T, k)
             if n <= n[::-1]]
    cases += [(2, 2, 2, 2, 2), (3, 3, 3), (2, 3, 2, 3)]
    brute_cache = {}
    nA = 0
    for n in cases:
        p2, full = brute(n)
        brute_cache[n] = (p2, full)
        for m in range(2, len(n)):
            chk.check(f"A psi2 table by meet in the middle at letter {m}, {n}", psi2_mitm(n, m), p2)
        dp = {}
        for x in p2:
            for key, s in classes_in_fibre(n, x).items():
                dp[(x, key)] = s
        chk.check(f"A Parikh classes by transfer DP = brute force, {n}", dp, full)
        nA += 1
    chk.note(f"A: {nA} contents compared with brute force ({time.perf_counter() - START:.1f} s)")

    # ---- B. (2^k) --------------------------------------------------------------------
    for k in range(2, 6):
        n = (2,) * k
        p2, full = brute_cache.get(n) or brute(n)
        ez_b = sum(1 for w in words(n) if in_alt_class(w, n, True))
        chk.check(f"B brute e(Z(2^{k}))", ez_b, EZ2[k])
        chk.check(f"B DP e(Z(2^{k}))", e_alt(n), EZ2[k])
        mx = max(p2.values())
        chk.check(f"B brute psi2 max (2^{k}) and argmax", (mx, [x for x in p2 if p2[x] == mx]),
                  (PSI2MAX2[k], [(2,) * (k - 1)]))
        M = max(full.values())
        chk.check(f"B brute largest Parikh class (2^{k})", M, MMAX2[k])
        chk.check(f"B brute number of Parikh classes (2^{k})", len(full), NCLASSES2[k])
        win = sorted(x for (x, key), s in full.items() if s == M)
        if k == 3:
            want = sorted([(0, 4), (2, 2), (2, 2), (4, 0)])
        elif k == 2:
            want = [(2,)]
        elif k == 4:
            want = [(2, 2, 2), (2, 2, 2)]
        else:
            want = [(2, 2, 2, 2)]
        chk.check(f"B brute psi2 vectors of the largest classes (2^{k})", win, want)
    for k in range(6, 10 if SLOW else 9):
        n = (2,) * k
        tab = psi2_mitm(n)
        chk.check(f"B sum of psi2 fibres = multinomial (2^{k})", sum(tab.values()),
                  factorial(2 * k) // 2 ** k)
        mx = max(tab.values())
        chk.check(f"B psi2 max (2^{k}) unique at the centre", (mx, [x for x in tab if tab[x] == mx]),
                  (PSI2MAX2[k], [(2,) * (k - 1)]))
        chk.check(f"B e(Z(2^{k}))", e_alt(n), EZ2[k])
        best, win = largest_class(n, tab)
        chk.check(f"B largest Parikh class (2^{k}) = e(Z), exactly the alternating pair",
                  (best, sorted(x for x, key in win)), (EZ2[k], sorted(alt_psi2(n))))
        # largest non-alternating class: refine every fibre >= the recorded value
        alt = set(alt_psi2(n))
        thr = NONALT2[k]
        top, where = 0, []
        for x, s in tab.items():
            if s >= thr and x not in alt:
                for key, size in classes_in_fibre(n, x).items():
                    if size > top:
                        top, where = size, [x]
                    elif size == top:
                        where.append(x)
        ends = sorted([(2,) + alt_psi2(n)[1][1:], alt_psi2(n)[0][:-1] + (2,),
                       (2,) + alt_psi2(n)[0][1:], alt_psi2(n)[1][:-1] + (2,)])
        chk.check(f"B largest non-alternating class (2^{k}): value and the 4 end-relaxed vectors",
                  (top, sorted(where)), (NONALT2[k], ends))
    chk.note(f"B done ({time.perf_counter() - START:.1f} s)")

    # ---- C. central fibre of (2^k) ---------------------------------------------------
    P, Q = (1, 1), (0, 2)
    for k in range(3, 9):
        n = (2,) * k
        x = (2,) * (k - 1)
        cl = classes_in_fibre(n, x)
        chk.check(f"C central fibre (2^{k}): number of classes = F_{k}", len(cl), fib(k))
        chk.ok(f"C central fibre (2^{k}): all higher entries in {{0,2}}",
               all(v in (0, 2) for key in cl for v in key))
        if k in CENTRAL_BEST2:
            chk.check(f"C central fibre (2^{k}): largest class", max(cl.values()), CENTRAL_BEST2[k])
        # classes <-> QP-descent sets: entry of [j,l] is 2 iff labels j..l-1 avoid "QP"
        agg = {}
        for lab in iproduct((P, Q), repeat=k - 1):
            T = frozenset(i for i in range(k - 2) if lab[i] == Q and lab[i + 1] == P)
            pred = tuple(0 if any(j - 1 <= i < l - 2 for i in T) else 2
                         for l in range(3, k + 1) for j in range(1, l - 1))
            agg[pred] = agg.get(pred, 0) + trace_size(n, list(lab))
        chk.check(f"C central fibre (2^{k}): classes = unions over QP-descent sets", agg, cl)
        if k <= 5:
            p2, full = brute_cache.get(n) or brute(n)
            bc = {key: s for (xx, key), s in full.items() if xx == x}
            chk.check(f"C brute central fibre classes (2^{k})", bc, cl)

    # ---- D. relaxation lemma (brute force) ------------------------------------------
    nD = 0
    for n, (p2, full) in brute_cache.items():
        k = len(n)
        if k < 4:
            continue
        per = {}
        for (x, key) in full:
            per[x] = per.get(x, 0) + 1
        for S in indep_sets(k - 1):
            for ff in (True, False):
                rel = relaxed(n, ff, set(S))
                for xs, size in rel.items():
                    v = pattern_vector(n, ff, S, xs)
                    ok = per.get(v) == 1 and p2.get(v) == size
                    nD += 1
                    if not ok:
                        chk.ok(f"D relaxed fibre is one class, {n} {ff} {S} {xs}", False,
                               f"classes {per.get(v)}, fibre {p2.get(v)}, relaxed {size}")
    chk.ok(f"D relaxation lemma on {nD} relaxed fibres", nD > 1000)

    # ---- E. (3^k) --------------------------------------------------------------------
    n = (3, 3, 3, 3)
    p2, full = brute(n)
    M = max(full.values())
    win = sorted(x for (x, key), s in full.items() if s == M)
    chk.check("E brute (3^4): e(Z), largest class, its psi2 vectors",
              (sum(1 for w in words(n) if in_alt_class(w, n, True)), M, win),
              (662, 798, [(0, 9, 3), (3, 9, 0), (6, 0, 9), (9, 0, 6)]))
    mx = max(p2.values())
    chk.check("E brute (3^4): psi2 max and argmax", (mx, sorted(x for x in p2 if p2[x] == mx)),
              (2560, [(3, 6, 3), (6, 3, 6)]))
    chk.check("E DP (3^4) largest class", largest_class(n)[0], 798)
    n = (3,) * 5
    best, win = largest_class(n)
    chk.check("E DP (3^5): largest class and its psi2 vectors",
              (e_alt(n), best, sorted(x for x, key in win)),
              (57400, 66024, [(3, 9, 0, 6), (6, 0, 9, 3)]))
    for k, (ez, two) in {6: (8063656, 8568624), 7: (1942824800, 2085268500)}.items():
        n = (3,) * k
        r = max(s for xs, s in relaxed(n, True, {0, k - 2}).items()
                if xs != own_areas(n, True, {0, k - 2}))
        chk.check(f"E (3^{k}): e(Z) and the best proper two-end relaxation (> e(Z))",
                  (e_alt(n), r, r > ez), (ez, two, True))
    chk.note(f"E done ({time.perf_counter() - START:.1f} s)")

    # ---- F. scan k >= 4, total <= 10 ------------------------------------------------
    kinds = {}
    n12 = 0
    for T in range(4, 11):
        for k in range(4, T + 1):
            for n in comps(T, k):
                if n > n[::-1]:
                    continue
                iso = all(min(n[i], n[i + 1]) == 1 for i in range(k - 1))
                ez = e_alt(n)
                best, win = largest_class(n)
                altset = set(alt_psi2(n))
                na = sum(1 for x, key in win if x in altset)
                if best == ez:
                    kind = "alt" if len(win) == na else "alt-tie"
                else:
                    kind = "relax" if best_proper_relaxation(n) == best else "other"
                kinds[(iso, kind)] = kinds.get((iso, kind), 0) + 1
                if max(n) <= 2:  # C4, the {1,2} end-block rule
                    pred = not (n[:3] == (2, 2, 1) or n[-3:] == (1, 2, 2)) and n not in (
                        (2, 2, 2, 2), (2, 2, 2, 2, 2))
                    chk.check(f"F {{1,2}} end-block rule {n}", kind == "alt", pred)
                    n12 += 1
                if T <= 8:
                    p2, full = brute_cache[n] if n in brute_cache else brute(n)
                    M = max(full.values())
                    chk.check(f"F brute largest class and multiplicity {n}",
                              (M, sum(1 for s in full.values() if s == M)), (best, len(win)))
    chk.check("F scan k>=4, total<=10: (isolated, kind) counts", dict(sorted(kinds.items())),
              SCAN_WANT)
    chk.note(f"F done ({time.perf_counter() - START:.1f} s); {n12} {{1,2}}-contents checked against C4")

    # ---- G. end-ratio formula for (2^k) ---------------------------------------------
    # u runs over the alternating class Z' on letters 2..k (edge 2 empty, edge 3 full, ...);
    # (p, m, q) = letters of u before / between / after its two 2's.  Then
    # e(Z) = sum C(p+2,2) and R_left = sum (p+1)(q+1) + C(m+2,2).
    for k in range(4, 10):
        n = (2,) * k
        lams = []
        for j in range(1, k - 1):  # complemented right part: edge j <-> original edge k-j
            xo = 0 if (k - j) % 2 == 0 else 4
            lams.append((2, 2) if 4 - xo == 4 else (0, 0))
        D = {(0, 0, 0): 1}
        for lam in lams:
            new = {}
            for L, w in D.items():
                for Lp, m in transfer(L, lam):
                    new[Lp] = new.get(Lp, 0) + w * m
            D = new
        den = sum(w * comb(L[0] + 2, 2) for L, w in D.items())
        num = sum(w * ((L[0] + 1) * (L[2] + 1) + comb(L[1] + 2, 2)) for L, w in D.items())
        rel = relaxed(n, True, {0})
        chk.check(f"G (2^{k}): end-ratio formula (e(Z), R_left)", (den, num), (e_alt(n), rel[(2,)]))
        if k <= 5:
            # brute force: words of the relaxed class at area 2 = words with psi2 (2, alt...)
            p2, full = brute_cache.get(n) or brute(n)
            v = (2,) + alt_psi2(n)[0][1:]
            chk.check(f"G brute (2^{k}): relaxed class at {v}", p2[v], num)
    chk.note(f"G done ({time.perf_counter() - START:.1f} s)")
    return chk.finish()


# notes/r7-scripts/general/out/scan14.jsonl, totals 4..10 (scan.py)
SCAN_WANT = {(False, "alt"): 113, (False, "other"): 10, (False, "relax"): 114, (True, "alt"): 216}

if __name__ == "__main__":
    sys.exit(main())
