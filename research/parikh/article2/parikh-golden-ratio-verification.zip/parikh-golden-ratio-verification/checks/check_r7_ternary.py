"""R7 (ternary data): checks for notes/explore-r7-ternary.md.

Python standard library only; deterministic; accepts and ignores unknown arguments
(run_all.py passes e.g. --max-n).  Exit status is non-zero on any failure.

Content (a,b,c) over 1 < 2 < 3, all positive; x = |w|_12, y = |w|_23, z = |w|_123
(scattered).  P(x,y) = psi_2-fibre size; rho(x,y,z) = Parikh-class size.

Three independent methods are used:
  BF   brute-force enumeration of words, subword counts by index tuples (definition);
  DP   word-prefix DP for psi_2 with Kronecker packing (same idea as
       notes/r7-scripts/ternary/tern.py, re-implemented here);
  PR   profile model: explicit enumeration of profile pairs (A, C) with weight
       prod_g C(a_g + c_g, a_g) (notes/partition-route-audit.md s.3).

What is checked (bounds as stated in the note):
  1. DP == BF (psi_2) and PR == BF (every Parikh class), every content, total <= 9.
  2. Reversal, reverse-complement and complement act on (x,y,z) as stated, BF, total <= 8.
  3. b even, (a,c) != (1,1): unique psi_2 maximiser at the centre (ab/2, bc/2):
     BF total <= 10; DP total <= 19 (every content).  COUNTEREXAMPLES at total 20:
     (5,10,5) and (7,6,7), fibre values confirmed by DP and PR independently.
     E1 (maximisers within {centre, centre +- (1,-1)}), E2 (centre unique if ab/2 or bc/2
     is even), E3 (every failure has a,c odd, b = 2 mod 4 -- the contrapositive of E2 --
     and its maximisers are exactly centre +- (1,-1), strictly):
     DP, total <= 30 (BF total <= 10).  DP: (23,6,23) fails, (25,6,25) has the centre unique.
  4. b odd >= 3, (a,c) != (1,1): O1 maximisers = one reversal pair or the unique integral
     centre, except the 4-point ties listed in the note; O3 (2x-ab)(2y-bc) <= 0;
     O2' for a <= c: |2x-ab| <= min(a,3) and |2y-bc| <= c (roles swapped when a > c);
     DP total <= 30, BF total <= 10.
  5. (2,b,2): F1/F2 psi_2 maxima, PR b <= 16, BF b <= 5; the z = 0 closed sum == PR for
     b <= 12, largest class == M0(b) for 6 <= b <= 12 (PR); M0(b) == floor((b^2+9b+36)/14)
     for 16 <= b <= 30 (closed sum).
  6. (a,2,c): H1 (centre unique psi_2 max), H2 (largest class = max(C(a+c,a), boundary
     fibres)), H3 (closed form of P(0,y)), H4 (C(a+c,a) largest iff c(c-1) <= a(a+c-1)),
     b = 2 formula, a + c <= 30; formula == BF for a + c <= 8.
  7. Small Parikh-class facts by BF: trace max C(a+c,a) <= largest class <= largest psi_2
     fibre for total <= 9; (1,2,3): largest class 5, trace max 4, psi_2 max 6 at (1,3);
     (2,2,2): 6 at four classes; (2,2,4): 16 at
     (0,6,0),(4,2,4), not on the central fibre (central max 15).
"""

from __future__ import annotations

import itertools
import sys
import time
from math import comb, factorial

FAIL = []


def check(cond, msg):
    if not cond:
        FAIL.append(msg)
        print("FAIL:", msg)


def multinom(a, b, c):
    return factorial(a + b + c) // (factorial(a) * factorial(b) * factorial(c))


# ---------------------------------------------------------------------- BF
def words(a, b, c):
    n = a + b + c
    for p1 in itertools.combinations(range(n), a):
        rest = [p for p in range(n) if p not in p1]
        for p2 in itertools.combinations(rest, b):
            w = [3] * n
            for p in p1:
                w[p] = 1
            for p in p2:
                w[p] = 2
            yield tuple(w)


def sub(w, u):
    return sum(1 for idx in itertools.combinations(range(len(w)), len(u))
               if all(w[i] == s for i, s in zip(idx, u)))


def bf_classes(a, b, c):
    out = {}
    for w in words(a, b, c):
        k = (sub(w, (1, 2)), sub(w, (2, 3)), sub(w, (1, 2, 3)))
        out[k] = out.get(k, 0) + 1
    return out


def project(rho):
    P = {}
    for (x, y, z), m in rho.items():
        P[(x, y)] = P.get((x, y), 0) + m
    return P


# ---------------------------------------------------------------------- DP
def dp_psi2(a, b, c):
    """dict (x,y) -> P(x,y), word-prefix DP packed in one integer."""
    X, Y = a * b, b * c
    bits = 8 * ((multinom(a, b, c).bit_length() + 8) // 8)
    row = (Y + 1) * bits
    prev = None
    for i in range(a + 1):
        cur = [[0] * (c + 1) for _ in range(b + 1)]
        for j in range(b + 1):
            for k in range(c + 1):
                if i == j == k == 0:
                    v = 1
                else:
                    v = (prev[j][k] if i else 0)
                    if j:
                        v += cur[j - 1][k] << (i * row)
                    if k:
                        v += cur[j][k - 1] << (j * bits)
                cur[j][k] = v
        prev = cur
    n = prev[b][c]
    w = bits // 8
    raw = n.to_bytes((X + 1) * (Y + 1) * w, "little")
    out = {}
    for idx in range((X + 1) * (Y + 1)):
        m = int.from_bytes(raw[idx * w:(idx + 1) * w], "little")
        if m:
            out[(idx // (Y + 1), idx % (Y + 1))] = m
    return out


# ---------------------------------------------------------------------- PR
def mono(length, top, increasing, total=None):
    """Monotone integer sequences of given length with values in [0, top] (optionally sum)."""
    def rec(pos, lo, acc, s):
        if pos == length:
            if total is None or s == total:
                yield tuple(acc)
            return
        for v in range(lo, top + 1):
            if total is not None and s + v * (length - pos) > total:
                break
            if total is not None and s + v + top * (length - pos - 1) < total:
                continue
            acc.append(v)
            yield from rec(pos + 1, v, acc, s + v)
            acc.pop()
    for seq in rec(0, 0, [], 0):
        yield seq if increasing else seq[::-1]


def weight(A, C, a, c):
    b = len(A)
    ag = [A[0]] + [A[g] - A[g - 1] for g in range(1, b)] + [a - A[-1]]
    cg = [c - C[0]] + [C[g - 1] - C[g] for g in range(1, b)] + [C[-1]]
    w = 1
    for u, v in zip(ag, cg):
        w *= comb(u + v, u)
    return w


def pr_classes(a, b, c, x=None, y=None):
    """Parikh classes by explicit profile pairs; optionally restricted to one (x, y)."""
    out = {}
    As = list(mono(b, a, True, x))
    Cs = list(mono(b, c, True, y))  # increasing; reversed below to make C decreasing
    for A in As:
        sa = sum(A)
        for Cr in Cs:
            C = Cr[::-1]
            k = (sa, sum(C), sum(s * t for s, t in zip(A, C)))
            out[k] = out.get(k, 0) + weight(A, C, a, c)
    return out


def contents(lo, hi, a_le_c=False):
    for n in range(lo, hi + 1):
        for a in range(1, n - 1):
            for b in range(1, n - a):
                c = n - a - b
                if a_le_c and a > c:
                    continue
                yield a, b, c


def argmax(d):
    M = max(d.values())
    return M, sorted(k for k, v in d.items() if v == M)


# ---------------------------------------------------------------------- tests
def t1():
    n = 0
    for a, b, c in contents(3, 9):
        bf = bf_classes(a, b, c)
        check(dp_psi2(a, b, c) == project(bf), f"DP psi2 != BF at {(a, b, c)}")
        check(pr_classes(a, b, c) == bf, f"PR classes != BF at {(a, b, c)}")
        n += 1
    print(f"[1] DP == BF (psi_2) and PR == BF (all Parikh classes): {n} contents, total <= 9")


def t2():
    n = 0
    for a, b, c in contents(3, 8):
        for w in words(a, b, c):
            x, y, z = sub(w, (1, 2)), sub(w, (2, 3)), sub(w, (1, 2, 3))
            r = w[::-1]
            check((sub(r, (1, 2)), sub(r, (2, 3)), sub(r, (1, 2, 3))) ==
                  (a * b - x, b * c - y, a * b * c - a * y - c * x + z), f"reversal {w}")
            comp = tuple(4 - s for s in w)
            check((sub(comp, (1, 2)), sub(comp, (2, 3)), sub(comp, (1, 2, 3))) ==
                  (b * c - y, a * b - x, a * b * c - a * y - c * x + z), f"complement {w}")
            rc = comp[::-1]
            check((sub(rc, (1, 2)), sub(rc, (2, 3)), sub(rc, (1, 2, 3))) == (y, x, z),
                  f"reverse-complement {w}")
            n += 1
    print(f"[2] reversal / complement / reverse-complement formulas: {n} words, total <= 8")


def b_even_tests(a, b, c, P):
    X, Y = a * b, b * c
    cx, cy = X // 2, Y // 2
    M, am = argmax(P)
    ok_unique = am == [(cx, cy)]
    e1 = set(am) <= {(cx, cy), (cx + 1, cy - 1), (cx - 1, cy + 1)}
    e2 = ok_unique if (cx % 2 == 0 or cy % 2 == 0) else True
    e3 = ok_unique or (a % 2 == 1 and c % 2 == 1 and b % 4 == 2
                       and am == [(cx - 1, cy + 1), (cx + 1, cy - 1)])
    return ok_unique, e1, e2, e3


def b_odd_tests(a, b, c, P):
    X, Y = a * b, b * c
    M, am = argmax(P)
    o1 = (len(am) == 2 and (X - am[0][0], Y - am[0][1]) == am[1]) or \
         (len(am) == 1 and 2 * am[0][0] == X and 2 * am[0][1] == Y)
    o3 = all((2 * x - X) * (2 * y - Y) <= 0 for x, y in am)
    if a <= c:
        o2 = all(abs(2 * x - X) <= min(a, 3) and abs(2 * y - Y) <= c for x, y in am)
    else:
        o2 = all(abs(2 * y - Y) <= min(c, 3) and abs(2 * x - X) <= a for x, y in am)
    return am, o1, o2, o3


O1_EXCEPTIONS = {(1, 3, 4), (1, 5, 4), (1, 7, 4), (3, 5, 4), (1, 5, 8), (1, 5, 9),
                 (3, 9, 4), (2, 3, 13), (1, 3, 17)}  # a <= c, total <= 30 (note s.2.2)


def t3_t4():
    t0 = time.time()
    # brute force part
    nb = 0
    for a, b, c in contents(3, 10):
        if (a, c) == (1, 1):
            continue
        P = project(bf_classes(a, b, c))
        if b % 2 == 0:
            u, e1, e2, e3 = b_even_tests(a, b, c, P)
            check(u and e1 and e2 and e3, f"BF b-even centre at {(a, b, c)}")
        elif b >= 3:
            am, o1, o2, o3 = b_odd_tests(a, b, c, P)
            key = (a, b, c) if a <= c else (c, b, a)
            check((o1 or key in O1_EXCEPTIONS) and o2 and o3, f"BF b-odd at {(a, b, c)}")
        nb += 1
    # DP part, a <= c (reverse-complement covers a > c; verified in [2])
    fails20 = []
    nd = 0
    for a, b, c in contents(3, 30, a_le_c=True):
        if (a, c) == (1, 1) or b == 1:
            continue
        P = dp_psi2(a, b, c)
        if b % 2 == 0:
            u, e1, e2, e3 = b_even_tests(a, b, c, P)
            check(e1 and e2 and e3, f"DP E1-E3 at {(a, b, c)}")
            if a + b + c <= 19:
                check(u, f"DP unique centre fails at {(a, b, c)} (total <= 19)")
            elif not u:
                fails20.append((a, b, c))
        else:
            am, o1, o2, o3 = b_odd_tests(a, b, c, P)
            check(o1 or (a, b, c) in O1_EXCEPTIONS, f"DP O1 at {(a, b, c)}: {am}")
            check(o2 and o3, f"DP O2'/O3 at {(a, b, c)}: {am}")
        nd += 1
    expected = [(5, 10, 5), (7, 6, 7), (5, 10, 7), (7, 6, 9), (5, 14, 5), (7, 6, 11),
                (7, 10, 7), (9, 6, 9), (7, 10, 9), (9, 6, 11), (7, 10, 11), (9, 6, 13),
                (11, 6, 11), (7, 10, 13), (11, 6, 13)]
    check(sorted(fails20) == sorted(expected), f"counterexample list (total <= 30): {fails20}")
    # the two smallest counterexamples by an independent method (PR on the three fibres)
    for (a, b, c), vals in (((5, 10, 5), (111322, 111460)), ((7, 6, 7), (484020, 484422))):
        cx, cy = a * b // 2, b * c // 2
        pc = sum(pr_classes(a, b, c, cx, cy).values())
        p1 = sum(pr_classes(a, b, c, cx + 1, cy - 1).values())
        p2 = sum(pr_classes(a, b, c, cx - 1, cy + 1).values())
        P = dp_psi2(a, b, c)
        check((pc, p1) == vals and p1 == p2 and P[(cx, cy)] == pc and P[(cx + 1, cy - 1)] == p1,
              f"counterexample values at {(a, b, c)}: PR {pc, p1, p2}")
        check(argmax(P) == (p1, [(cx - 1, cy + 1), (cx + 1, cy - 1)]), f"argmax {(a, b, c)}")
    # the b = 6 island beyond the scan (DP only): (23,6,23) still fails, (25,6,25) does not
    for (a, b, c), fails in (((23, 6, 23), True), ((25, 6, 25), False)):
        cx, cy = a * b // 2, b * c // 2
        M, am = argmax(dp_psi2(a, b, c))
        want = [(cx - 1, cy + 1), (cx + 1, cy - 1)] if fails else [(cx, cy)]
        check(am == want, f"b = 6 island boundary at {(a, b, c)}: {am}")
    print(f"[3] b even: unique centre for every content with total <= 19 (BF <= 10); "
          f"E1-E3 to total 30; counterexamples at total 20..30: {len(fails20)} "
          f"(PR-confirmed (5,10,5): 111460 > 111322, (7,6,7): 484422 > 484020)")
    print(f"[4] b odd >= 3: O1 (with the listed 4-point ties), O2', O3 to total 30 "
          f"(BF <= 10).  {nb} BF contents, {nd} DP contents ({time.time() - t0:.1f} s)")


def t5():
    t0 = time.time()

    def prof2(b):
        out = []
        for p in range(b + 1):
            for q in range(b - p + 1):
                out.append([0] * p + [1] * q + [2] * (b - p - q))
        return out

    def dist2b2(b):
        rho = {}
        As = prof2(b)
        for A in As:
            for Cr in As:
                C = Cr[::-1]
                k = (sum(A), sum(C), sum(s * t for s, t in zip(A, C)))
                rho[k] = rho.get(k, 0) + weight(A, C, 2, 2)
        return rho

    def rho0(b, x, y):
        tot = 0
        for L in range(max(b - x, 1), (2 * b - x) // 2 + 1):
            q, r = 2 * (b - L) - x, x - (b - L)
            if q < 0 or r < 0 or L > b - 1:
                continue
            aL = 1 if q >= 1 else 2
            for rp in range(max(0, y - L), y // 2 + 1):
                qp = y - 2 * rp
                CL = 0 if rp + qp < L else (1 if qp >= 1 else 2)
                tot += comb(aL + CL, aL)
        return tot

    def M0(b):
        return max(rho0(b, x, y) for x in range(1, 2 * b + 1) for y in range(1, 2 * b + 1))

    for b in range(1, 17):
        rho = dist2b2(b)
        if b <= 5:
            check(rho == bf_classes(2, b, 2), f"(2,{b},2) PR != BF")
        P = project(rho)
        M, am = argmax(P)
        h = b // 2
        if b % 2 == 0:
            check(am == [(b, b)] and M == (h + 2) * (h + 3), f"F1 b={b}")
        else:
            check(am == [(b - 1, b + 1), (b + 1, b - 1)] and M == (h + 2) * (h + 3)
                  and P[(b, b)] == (h + 1) * (h + 4), f"F2 b={b}")
        if b <= 12:
            for x in range(1, 2 * b + 1):
                for y in range(1, 2 * b + 1):
                    check(rho.get((x, y, 0), 0) == rho0(b, x, y), f"rho0 {(b, x, y)}")
            if b >= 6:
                check(max(rho.values()) == M0(b), f"largest class (2,{b},2) != M0")
    for b in range(16, 31):
        check(M0(b) == (b * b + 9 * b + 36) // 14, f"M0 floor formula b={b}")
    print(f"[5] (2,b,2): F1/F2 for b <= 16 (BF b <= 5); z = 0 closed sum b <= 12; largest "
          f"class = M0(b) for 6 <= b <= 12; M0 = floor((b^2+9b+36)/14), 16 <= b <= 30 "
          f"({time.time() - t0:.1f} s)")


def t6():
    t0 = time.time()

    def classes(a, c):
        rho = {}
        for x in range(2 * a + 1):
            for y in range(2 * c + 1):
                for d in range(x % 2, min(x, 2 * a - x) + 1, 2):
                    a0, a2 = (x - d) // 2, a - (x + d) // 2
                    for e in range(y % 2, min(y, 2 * c - y) + 1, 2):
                        c0, c2 = c - (y + e) // 2, (y - e) // 2
                        k = (x, y, (x * y - d * e) // 2)
                        rho[k] = rho.get(k, 0) + comb(a0 + c0, a0) * comb(d + e, d) * comb(a2 + c2, a2)
        return rho

    n = 0
    for s in range(2, 31):
        for a in range(1, s // 2 + 1):
            c = s - a
            rho = classes(a, c)
            if s <= 8:
                check(rho == bf_classes(a, 2, c), f"(a,2,c) formula != BF at {(a, c)}")
            P = project(rho)
            M_, am = argmax(P)
            if (a, c) != (1, 1):
                check(am == [(a, c)], f"H1 {(a, c)}")
            M = max(rho.values())
            bnd = max(v for (x, y), v in P.items() if x in (0, 2 * a) or y in (0, 2 * c))
            check(M == max(comb(a + c, a), bnd), f"H2 {(a, c)}")
            for m in range(2 * c + 1):
                cl = sum(comb(a + c - i, a) for i in range((m + 1) // 2, min(m, c) + 1))
                check(P[(0, 2 * c - m)] == cl, f"H3 {(a, c, m)}")
            check((c * (c - 1) <= a * (a + c - 1)) == (M == comb(a + c, a)), f"H4 {(a, c)}")
            n += 1
    print(f"[6] (a,2,c), a <= c, a + c <= 30: H1-H4 on {n} contents (BF a + c <= 8) "
          f"({time.time() - t0:.1f} s)")


def t7():
    for a, b, c in contents(3, 9):
        bf = bf_classes(a, b, c)
        M = max(bf.values())
        P = project(bf)
        check(comb(a + c, a) <= M <= max(P.values()), f"chain at {(a, b, c)}")
    r = bf_classes(1, 2, 3)
    check(argmax(r) == (5, [(0, 4, 0), (2, 2, 2)]), "(1,2,3)")
    check(argmax(project(r)) == (6, [(1, 3)]) and project(r)[(0, 6)] == comb(4, 1) == 4,
          "(1,2,3) psi2 max 6 at (1,3); alternating fibre = trace max 4")
    r = bf_classes(2, 2, 2)
    check(argmax(r) == (6, [(0, 4, 0), (2, 2, 0), (2, 2, 2), (4, 0, 0)]), "(2,2,2)")
    r = bf_classes(2, 2, 4)
    check(argmax(r) == (16, [(0, 6, 0), (4, 2, 4)]), "(2,2,4)")
    check(max(v for (x, y, z), v in r.items() if (x, y) == (2, 4)) == 15, "(2,2,4) central")
    print("[7] trace max <= largest Parikh class <= largest psi_2 fibre (BF, total <= 9); "
          "(1,2,3), (2,2,2), (2,2,4) values")


def main():
    t0 = time.time()
    t1()
    t2()
    t3_t4()
    t5()
    t6()
    t7()
    print(f"check_r7_ternary: {'FAILED' if FAIL else 'all passed'} in {time.time() - t0:.1f} s")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
