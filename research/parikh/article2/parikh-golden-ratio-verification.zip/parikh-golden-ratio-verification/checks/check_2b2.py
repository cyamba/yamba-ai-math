"""check_2b2: the largest Parikh class of content (2,b,2) (Target 6, Conjecture 2B2).

Claims of notes/proof-2b2.md (finalised 21 October 2026), re-typed here. Nothing is imported
from notes/ or from the prover's scripts (notes/article2-scripts/proof-2b2/); every count below
is implemented afresh.

Python standard library only; deterministic (no randomness); exact integer and rational
arithmetic (no floats). Unknown command-line arguments are ignored (run_all.py passes e.g.
--max-n); --full selects the slow ranges given in brackets below. Exit status is non-zero on any
failure. The last line is "check_2b2: N checks, F failures, T s [PASS|FAIL]". A passing run is
evidence on the stated finite ranges (VERIFIED). The theorems are proved in the note; the only
steps of those proofs that rest on computation are the cases 16 <= b <= 19 of Theorem 1(iii),
the values M(1..15) and the maximiser lists for b <= 19 (Theorem 1(v)), all exhaustive
computations, which sections [H] and [J] redo here by brute force over all words.

Structure: one pass over b = 0..BW enumerates every word once per b (W2, plus W1 and LV on the
smaller ranges) and runs every word-level check of [A]-[D], [H], [J], [K]; each b's classes are
then discarded (at b = 100 they number about a million). The formula-level parts of [C], [D]
and [H], and [E]-[G], [I], follow. Mutation tests that alter one claim or one counting method
at a time (notes/article2-scripts/proof-2b2/mutation_tests_2b2.py) confirm that each is caught.

Setting
-------
Content (2,b,2), letters 1 < 2 < 3. x = |w|_12, y = |w|_23, y' = 2b - y = |w|_32,
z = |w|_123, z' = |w|_321 (scattered subwords). The content being fixed, the Parikh matrix is
determined by (x,y,z); rho(x,y,z) is the class size and M(b) the largest class.
Mstar(b) = floor((b^2+9b+36)/14), f(d) = (d-2)(d+1)/2, V(S) = floor((S+2)^2/4) - f(2S-b).

Methods (independent implementations)
-------------------------------------
 W1  literal words: every arrangement of 1,1,2^b,3,3 as a string; |w|_u counted by the
     generic subsequence DP; levels (2s to the right of each 1 and 3) read off the string;
     4x4 Parikh matrices as products of elementary matrices.            [b <= 9 (12); PM 6 (8)]
 W2  slot enumeration: a word is (t1 <= t2 <= t3 <= t4, an order of 1133), t_i = number of 2s
     before the i-th non-2 letter; a bijection with the words. x, y, z, z' from pairwise
     2-counts; checked equal to W1 class by class.                                [b <= 40 (100)]
 LV  level enumeration in the note's (h2, g1) coordinates, used only for Lemma 2.1's internal
     claims (and checked equal to W2 class by class).                             [b <= 20 (40)]
 P   z = 0 classes by order pattern: z = 0 forces equal slots per pattern, leaving an O(1)
     lattice count per cell (pairs u <= v in a box). Derived independently of the note's
     (H,G) box; checked equal to W2 on every cell.       [cells: b <= 120 (250); scans b <= 160 (400)]
 IE  Theorem 1(ii) as stated, with c(d) and N_d by inclusion-exclusion of triangles.
 R   Lemma 3.2 (piecewise form) as stated in the note's table.

Claims tested (note section in brackets)
---------------------------------------
 [A] [s1] W1 = W2 as multisets of (x,y,z,z'); word totals (b+4)!/(4 b!); Lemma 1.1 in level
     coordinates on every literal word and z - z' = 2x - 2y' on every word; Lemma 1.0 (every
     pair of level multisets occurs, with prod C(alpha+gamma, alpha) words); reversal maps
     (x,y,z,z') to (2b-x, 2b-y, z', z) word by word and class by class; Parikh-matrix classes
     are exactly the (x,y,z) classes.
 [B] [s2, Thm 1(i), Remark 2] thin classes (z, z' >= 1) have at most b+4 words; rho(b,b,b) = b+4
     for b even; the largest thin class is b+4 exactly at (b,b,b) (b even), b+3 exactly at
     (b-1,b+1,b-1), (b,b,b), (b+1,b-1,b-1) (b odd >= 3), 4 at (1,1,1) (b = 1). Lemma 2.1's
     internals (LV): |L| <= b+1; weights K > 1 only where h2+g1 is x or y', at most one point of
     each kind; excess <= 2 (x < y') or <= 3 (x = y'). The s5 remark: z = t+ + (x-y'-t)+ +
     (x-s)+ + (s-y')+ and min(z,z') = l1-distance of (t,s) to the square.
 [C] [s3, Thm 1(ii), Lemmas 3.1-3.2] W2 = P = IE = R on every cell (all of [0,2b]^2 for
     b <= BW; x+y <= 2b+2 beyond); the z' = 0 clause (reversal); rho(x,y,0) = rho(y,x,0); R2/R3
     agree at d = m and R3/R4 at d = M; beta = 0 in R1, R2, R5.
 [D] [s6, credit] [Y26a] Thm 2 (3.1)-(3.2) and Thm 6 (5.1) at a = c = 2, re-typed: on
     x+y >= 3b the fibre is the single class z0 = 2x+2y-4b with p2(j)p2(i)+eps_b(i,j) words;
     on x+y = 3b-1 with x,y <= 2b-2 exactly z0 (p2 p2 + 1 + [j=2] + [i=2]) and z0+1 (one word);
     by reversal these are Theorem 1(ii) on d <= 0 and on d = 1 with x,y >= 2; [Y26a] Fig. 1,
     Fig. 3 and Table 1 word lists for (2,3,2).
 [E] [s3.3, Lemma 3.3, s7.3] (a)-(f) cell by cell with rho from P, including the equality case
     of (c) and the beta bounds; for b >= 20 every cell outside R2 is < Mstar(b); the region
     maxima of s7.3 for b = 16..21, 40, 80.
 [F] [Lemma 3.4] 7*4g(S) = 2(b^2+9b+36) - (7S-4b-4)^2 identically; V(S) <= Mstar(b) for every S
     in [-10, 2b+10]; V(S) = Mstar(b) implies |S - (4b+4)/7| < 3/4.       [b <= 1000 (5000)]
 [G] [Table 3.4] the 18 rows as printed (products, f values, constants), the zero sets of
     V(8q+s) - Mstar(14q+r), its q-independence and both expansions (q in [-3,60]), both
     q-thresholds (max 3/2 only at (0,1); <= 1 for r >= 7; 1/2 at r = 6), R2 membership for
     every b >= 20, and rho = Mstar(b) at the table point by P for 20 <= b <= scan limit.
 [H] [Thm 1(iii)] W2: M(b) = Mstar(b) for 16 <= b <= BW; maximiser sets: the s4 table (with
     reversal images) for 16 <= b <= 20, the predicted set for 20 <= b <= BW; 2, 4 or 6
     maximisers, 6 iff b mod 14 in {0,5,7,12}. P: M0(b) = Mstar(b) for 16 <= b <= BZ; for
     b >= 20 the z = 0 maximisers are the predicted ones (S in {floor, ceil}(S*), x, y even,
     |x-y| <= 2, 1/2/3 of them); every z = 0 maximiser has d >= 3 for b >= 16.
     [--full also b in {500, 701, 997, 1000, 1001}.]
 [I] [Thm 1(iv)] Mstar(b) - (b^2+9b)/14 = kappa(b mod 7), kappa = (2,16/7,17/7,17/7,16/7,2,18/7)
     [b < 20000 (100000)]; b(b+9) mod 14 lies in {0,6,8,10}, so the constant 36 in Mstar can be
     any c in [36,41] (and no other c in [20,60]).
 [J] [Thm 1(v)] M(1..15) = 6,6,7,8,8,11,11,13,16,16,19,22,23,26,29; M = Mstar fails exactly on
     {1..9,11,12,14,15} within range; b = 4: unique maximiser (4,4,4), 8 words; some maximiser
     has z = 0 or z' = 0 for every b != 4; every maximiser does iff b in {1,3} or b >= 6; the
     thin ties at b = 2 and b = 5.
 [K] [s5, s6 consistency] sum_z rho = Theorem D(iii) (proof-antidiagonal.md s4, re-typed) on
     every cell; (2,3,2): 210 words in 70 classes, two self-mirror classes of sizes 4 and 6
     (AAP08 Example 19, p. 106, via notes/priority-r7-scan.md s1.3); T4 at x = y = b
     (notes/ternary-defect-theorems.md s4).
"""

from __future__ import annotations

import sys
import time
from collections import Counter
from fractions import Fraction
from itertools import combinations
from math import comb, factorial

FULL = "--full" in sys.argv[1:]
T0 = time.perf_counter()

if FULL:
    BS, BPM, BW, BL, BC, BZ, BV, BK = 12, 8, 100, 40, 250, 400, 5000, 100000
    SAMPLES = (500, 701, 997, 1000, 1001)
else:
    BS, BPM, BW, BL, BC, BZ, BV, BK = 9, 6, 40, 20, 120, 160, 1000, 20000
    SAMPLES = ()

FAIL: list[tuple[str, str]] = []
NCHECK = [0]
TAGS = "ABCDEFGHIJK"


def check(tag: str, ok: bool, msg: str) -> bool:
    NCHECK[0] += 1
    if not ok:
        FAIL.append((tag, msg))
        print(f"  FAIL [{tag}] {msg}", flush=True)
    return bool(ok)


def head(tag: str, title: str) -> float:
    print(f"[{tag}] {title}", flush=True)
    return time.perf_counter()


def status(tag: str, msg: str) -> None:
    bad = sum(1 for t, _ in FAIL if t == tag)
    print(f"  [{tag}] {'PASS' if bad == 0 else f'FAIL ({bad})'}: {msg}", flush=True)


# ---------------------------------------------------------------------------------------------
# small arithmetic
# ---------------------------------------------------------------------------------------------

def mstar(b: int) -> int:
    return (b * b + 9 * b + 36) // 14


def fpar(d: int) -> int:
    """f(d) = (d-2)(d+1)/2 (always an integer)."""
    num = (d - 2) * (d + 1)
    assert num % 2 == 0
    return num // 2


def vfun(b: int, S: int) -> int:
    return (S + 2) * (S + 2) // 4 - fpar(2 * S - b)


def p2(n: int) -> int:
    """Partitions of n into at most 2 parts."""
    return n // 2 + 1 if n >= 0 else 0


def ceil_half(n: int) -> int:
    return -((-n) // 2)


# ---------------------------------------------------------------------------------------------
# W1: literal words
# ---------------------------------------------------------------------------------------------

def words_literal(b: int):
    n = b + 4
    for ones in combinations(range(n), 2):
        rest = [p for p in range(n) if p not in ones]
        for threes in combinations(rest, 2):
            w = ["2"] * n
            for p in ones:
                w[p] = "1"
            for p in threes:
                w[p] = "3"
            yield "".join(w)


def occ(w: str, u: str) -> int:
    """Number of occurrences of u as a scattered subword of w (generic DP)."""
    c = [1] + [0] * len(u)
    for ch in w:
        for j in range(len(u), 0, -1):
            if u[j - 1] == ch:
                c[j] += c[j - 1]
    return c[len(u)]


def stats_literal(w: str):
    return occ(w, "12"), occ(w, "23"), occ(w, "123"), occ(w, "321")


def levels_literal(w: str):
    """1-levels and 3-levels (number of 2s to the right), each sorted."""
    hs, gs = [], []
    for i, ch in enumerate(w):
        if ch in "13":
            lev = w.count("2", i + 1)
            (hs if ch == "1" else gs).append(lev)
    return tuple(sorted(hs)), tuple(sorted(gs))


def parikh_matrix(w: str):
    """4x4 Parikh matrix as the product of elementary matrices I + E_{k,k+1}."""
    m = [[int(i == j) for j in range(4)] for i in range(4)]
    for ch in w:
        k = int(ch)  # letter k adds column k-1 to column k (right multiplication)
        for i in range(4):
            m[i][k] += m[i][k - 1]
    return tuple(tuple(r) for r in m)


# ---------------------------------------------------------------------------------------------
# W2: slot enumeration (all words)
# ---------------------------------------------------------------------------------------------

def classes_slots(b: int) -> Counter:
    """Counter over (x, y, z, z') of all words of content (2,b,2).

    The non-2 letters L1..L4 have t1 <= t2 <= t3 <= t4 twos before them. For the six orders of
    1133: x = sum over 1s of (b - t), y = sum over 3s of t, z = sum over (1 before 3) of the 2s
    between, z' = sum over (3 before 1) of the 2s between."""
    cnt: Counter = Counter()
    B2 = 2 * b
    for t1 in range(b + 1):
        for t2 in range(t1, b + 1):
            for t3 in range(t2, b + 1):
                for t4 in range(t3, b + 1):
                    cnt[(B2 - t1 - t2, t3 + t4, 2 * (t3 + t4 - t1 - t2), 0)] += 1           # 1133
                    cnt[(B2 - t1 - t3, t2 + t4, (t2 - t1) + (t4 - t1) + (t4 - t3), t3 - t2)] += 1  # 1313
                    cnt[(B2 - t1 - t4, t2 + t3, (t2 - t1) + (t3 - t1), (t4 - t2) + (t4 - t3))] += 1  # 1331
                    cnt[(B2 - t2 - t3, t1 + t4, (t4 - t2) + (t4 - t3), (t2 - t1) + (t3 - t1))] += 1  # 3113
                    cnt[(B2 - t2 - t4, t1 + t3, t3 - t2, (t2 - t1) + (t4 - t1) + (t4 - t3))] += 1  # 3131
                    cnt[(B2 - t3 - t4, t1 + t2, 0, 2 * (t3 + t4 - t1 - t2))] += 1           # 3311
    return cnt


# ---------------------------------------------------------------------------------------------
# P: z = 0 classes by order pattern (O(1) per cell)
# ---------------------------------------------------------------------------------------------

def pairs_le(a1: int, a2: int, c1: int, c2: int) -> int:
    """#{(u,v) : a1 <= u <= a2, c1 <= v <= c2, u <= v}."""
    if a1 > a2 or c1 > c2:
        return 0
    tot = 0
    lo, hi = max(c1, a1), min(c2, a2)
    if lo <= hi:
        tot += (hi - lo + 1) * (lo + hi - 2 * a1 + 2) // 2
    lo2 = max(c1, a2 + 1)
    if lo2 <= c2:
        tot += (c2 - lo2 + 1) * (a2 - a1 + 1)
    return tot


def rho0_pat(b: int, x: int, y: int) -> int:
    """rho(x,y,0) by the six orders of 1133; xb = 2b - x = sum of the 2s before the 1s."""
    xb = 2 * b - x
    tot = 0
    if y % 2 == 0:
        t = y // 2
        if xb == y and t <= b:
            tot += 2                                   # 1133 and 1313: all four slots equal
        if t <= xb - t <= b:
            tot += 1                                   # 1331: t1=t2=t3=t <= t4
    if xb % 2 == 0:
        t = xb // 2
        if t <= b and 0 <= y - t <= t:
            tot += 1                                   # 3113: t1 <= t2=t3=t4=t
    lo = max((y + 1) // 2, xb - b)
    hi = min(y, xb // 2)
    if lo <= hi:
        tot += hi - lo + 1                             # 3131: t1 <= t2=t3=t <= t4
    tot += pairs_le((y + 1) // 2, y, max(0, xb - b), xb // 2)   # 3311: t2 <= t3
    return tot


# ---------------------------------------------------------------------------------------------
# IE: Theorem 1(ii) as stated (inclusion-exclusion); R: Lemma 3.2 (piecewise form)
# ---------------------------------------------------------------------------------------------

def tri(k: int) -> int:
    return (k + 1) * (k + 2) // 2 if k >= 0 else 0


def box_le(X: int, Y: int, k: int) -> int:
    """#{(u,v) in [0,X]x[0,Y] : u+v <= k}."""
    return tri(k) - tri(k - X - 1) - tri(k - Y - 1) + tri(k - X - Y - 2)


def beta_note(b: int, x: int, y: int) -> int:
    X, eps = divmod(x, 2)
    Y, eta = divmod(y, 2)
    d = x + y - b
    return ((eps == 0 and X <= d <= X + Y) + (eta == 0 and Y <= d <= X + Y)
            + 2 * (eps == 0 and eta == 0 and d == X + Y))


def rho0_box(b: int, x: int, y: int) -> int:
    """Lemma 3.1, first form: H in [ceil(x/2), x], G in [ceil(y/2), y], H + G <= b; weight 1 if
    H + G < b and C(alpha+gamma, alpha) if H + G = b, alpha = 1 + [x = 2H], gamma = 1 + [y = 2G]."""
    tot = 0
    for H in range(ceil_half(x), x + 1):
        for G in range(ceil_half(y), y + 1):
            if H + G < b:
                tot += 1
            elif H + G == b:
                al, ga = 1 + (x == 2 * H), 1 + (y == 2 * G)
                tot += comb(al + ga, al)
    return tot


def rho0_ie(b: int, x: int, y: int) -> int:
    X, Y = x // 2, y // 2
    d = x + y - b
    c = (X + 1) * (Y + 1) - box_le(X, Y, d - 1)
    N = box_le(X, Y, d) - box_le(X, Y, d - 1)
    return c + N + beta_note(b, x, y)


def region(b: int, x: int, y: int) -> str:
    X, Y = x // 2, y // 2
    d = x + y - b
    m, M = min(X, Y), max(X, Y)
    if d <= -1:
        return "R1"
    if d <= m - 1:
        return "R2"
    if d < M:
        return "R3"
    if d == M:
        return "DM"
    if d <= X + Y:
        return "R4"
    return "R5"


def F_r3(m: int, M: int, d: int) -> int:
    num = (m + 1) * (2 * (M - d + 2) + m)
    assert num % 2 == 0
    return num // 2


def F_r4(e: int) -> int:
    return (e + 1) * (e + 4) // 2


def rho0_pw(b: int, x: int, y: int) -> int:
    X, Y = x // 2, y // 2
    d = x + y - b
    m, M = min(X, Y), max(X, Y)
    if d <= -1:
        F = (X + 1) * (Y + 1)
    elif d <= m - 1:
        F = (X + 1) * (Y + 1) - fpar(d)
    elif d <= M:
        F = F_r3(m, M, d)
    elif d <= X + Y:
        F = F_r4(X + Y - d)
    else:
        F = 0
    return F + beta_note(b, x, y)


# ---------------------------------------------------------------------------------------------
# predicted maximisers (Theorem 1(iii))
# ---------------------------------------------------------------------------------------------

def predicted_S(b: int) -> list[int]:
    ms = mstar(b)
    return [S for S in range(0, 2 * b + 1) if vfun(b, S) == ms]


def predicted_z0(b: int) -> set:
    out = set()
    for S in predicted_S(b):
        X, Y = S // 2, S - S // 2
        out.add((2 * X, 2 * Y))
        out.add((2 * Y, 2 * X))
    return out


def predicted_all(b: int) -> set:
    out = set()
    for (x, y) in predicted_z0(b):
        out.add((x, y, 0))
        out.add((2 * b - x, 2 * b - y, 4 * b - 2 * x - 2 * y))
    return out


# the s4 table of the note (z = 0 maximisers, 16 <= b <= 20)
TABLE4 = {
    16: (31, {(8, 12), (10, 10), (12, 8)}),
    17: (34, {(10, 10), (10, 12), (12, 10)}),
    18: (37, {(10, 12), (12, 10), (12, 12)}),
    19: (40, {(10, 12), (10, 14), (12, 10), (12, 12), (14, 10)}),
    20: (44, {(12, 12)}),
}

M_SMALL = [6, 6, 7, 8, 8, 11, 11, 13, 16, 16, 19, 22, 23, 26, 29]   # b = 1..15
FAILSET = {1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 14, 15}

# s7.3 of the note: largest z = 0 class outside R2, by region (R1, R3 with d < M, d = M, R4 with d > M)
REGION_TABLE = {
    16: (31, 20, 31, 29, 22), 17: (34, 25, 34, 29, 29), 18: (37, 25, 36, 37, 29),
    19: (40, 30, 40, 37, 29), 20: (44, 30, 43, 37, 37), 21: (47, 36, 46, 46, 37),
    40: (142, 110, 133, 121, 106), 80: (511, 420, 463, 407, 407),
}

# Table 3.4 of the note: r -> (floor((r^2+9r+36)/14), [(s, (floor(s/2)+1)(ceil(s/2)+1), f(2s-r))])
TABLE34 = {
    0: (2, [(0, 1, -1), (1, 2, 0)]),
    1: (3, [(1, 2, -1)]),
    2: (4, [(2, 4, 0)]),
    3: (5, [(2, 4, -1)]),
    4: (6, [(3, 6, 0)]),
    5: (7, [(3, 6, -1), (4, 9, 2)]),
    6: (9, [(4, 9, 0)]),
    7: (10, [(4, 9, -1), (5, 12, 2)]),
    8: (12, [(5, 12, 0)]),
    9: (14, [(6, 16, 2)]),
    10: (16, [(6, 16, 0)]),
    11: (18, [(7, 20, 2)]),
    12: (20, [(7, 20, 0), (8, 25, 5)]),
    13: (23, [(8, 25, 2)]),
}


# ---------------------------------------------------------------------------------------------
# [D] data: [Y26a] Thms 2 and 6 at a = c = 2; Table 1
# ---------------------------------------------------------------------------------------------

def eps_b(b: int, i: int, j: int) -> int:
    """[Y26a] (3.2) at a = c = 2."""
    if i + j < b:
        return 0
    if i > 0 and j > 0:
        return 1
    return 2      # a = 2 if j = 0, c = 2 if i = 0 (disjoint since b >= 1)


TABLE1 = {   # [Y26a] Table 1, p. 12 (content (2,3,2)): (j, i, z) -> words
    (1, 1, 8): {"1212323"},
    (1, 2, 6): {"1212332", "1213223", "1231223"},
    (2, 2, 4): {"1221332", "1223132", "1223312", "2112332", "2113223", "2131223", "2311223"},
    (2, 2, 5): {"1232123"},
}


# ---------------------------------------------------------------------------------------------
# [K] data: Theorem D(iii) (proof-antidiagonal.md s4, re-typed)
# ---------------------------------------------------------------------------------------------

def n_v(b: int, v: int) -> int:
    return v // 2 - max(0, v - b) + 1


def P_diii(b: int, x: int, y: int) -> int:
    yp = 2 * b - y
    if x == yp:
        n = n_v(b, x)
        return n * n + 3 * n + 2 * (x % 2 == 0)
    lo, hi = max(0, x - b, yp - b), min(b, x, yp)
    H = max(0, hi - lo + 1)
    return (n_v(b, x) * n_v(b, yp) + H + (x % 2 == 0 and lo <= x // 2 <= hi)
            + (yp % 2 == 0 and lo <= yp // 2 <= hi))


# ---------------------------------------------------------------------------------------------
# the word pass: every check that needs all classes of a given b ([A], [B], [C], [D], [H], [J],
# [K] word parts); each b's classes are discarded after use
# ---------------------------------------------------------------------------------------------

def literal_checks(b: int, C: Counter, R: dict, st: dict) -> None:
    lit: Counter = Counter()
    groups: Counter = Counter()
    ok11 = okrev = True
    for w in words_literal(b):
        x, y, z, zp = stats_literal(w)
        lit[(x, y, z, zp)] += 1
        st["nlit"] += 1
        hs, gs = levels_literal(w)
        groups[(hs, gs)] += 1
        yp = occ(w, "32")
        if not (x == sum(hs) and yp == sum(gs) and y + yp == 2 * b
                and z == sum(max(0, h - g) for h in hs for g in gs)
                and zp == sum(max(0, g - h) for h in hs for g in gs)):
            ok11 = False
        if stats_literal(w[::-1]) != (2 * b - x, 2 * b - y, zp, z):
            okrev = False
    check("A", lit == C, f"W1 == W2 as multisets of (x,y,z,z'), b = {b}")
    check("A", ok11, f"Lemma 1.1 in level coordinates on every literal word, b = {b}")
    check("A", okrev, f"reversal maps (x,y,z,z') to (2b-x,2b-y,z',z) word by word, b = {b}")
    pairs = [(h1, h2) for h2 in range(b + 1) for h1 in range(h2 + 1)]
    ok10 = len(groups) == len(pairs) ** 2
    for (hs, gs), n in groups.items():
        K = 1
        for lev in set(hs) | set(gs):
            al, ga = hs.count(lev), gs.count(lev)
            K *= comb(al + ga, al)
        if K != n:
            ok10 = False
    check("A", ok10, f"Lemma 1.0 (onto; fibre sizes prod C(alpha+gamma,alpha)), b = {b}")
    if b <= BPM:
        bym: Counter = Counter()
        pair: dict = {}
        ok = True
        for w in words_literal(b):
            pm = parikh_matrix(w)
            x, y, z, _ = stats_literal(w)
            bym[pm] += 1
            if pm in pair and pair[pm] != (x, y, z):
                ok = False
            pair[pm] = (x, y, z)
            if not (pm[0][1] == 2 and pm[1][2] == b and pm[2][3] == 2 and pm[0][2] == x
                    and pm[1][3] == y and pm[0][3] == z):
                ok = False
        ok = ok and len(set(pair.values())) == len(pair) == len(R)
        ok = ok and all(R[pair[pm]] == n for pm, n in bym.items())
        check("A", ok, f"Parikh-matrix classes == (x,y,z) classes, b = {b}")
    if b == 3:
        got: dict = {}
        for w in words_literal(3):
            x, y, z, _ = stats_literal(w)
            got.setdefault((6 - x, 6 - y, z), set()).add(w)
        check("D", all(got.get(k, set()) == v for k, v in TABLE1.items()), "[Y26a] Table 1 word lists")


def level_checks(b: int, R: dict, st: dict) -> None:
    """Lemma 2.1's internals in (h2, g1) coordinates, the s5 remark, and LV == W2."""
    lv: dict = {}
    ok_int = ok_rem = True
    ok_IJ = all(len(range(ceil_half(v), min(v, b) + 1)) <= b // 2 + 1
                and len(range(max(0, v - b), v // 2 + 1)) <= b // 2 + 1 for v in range(0, 2 * b + 1))
    check("B", ok_IJ, f"|I|, |J| <= floor(b/2) + 1 (s1), b = {b}")
    for x in range(0, 2 * b + 1):
        I = range(ceil_half(x), min(x, b) + 1)
        for yp in range(0, 2 * b + 1):
            J = range(max(0, yp - b), yp // 2 + 1)
            pts: dict = {}
            for h2 in I:
                h1 = x - h2
                for g1 in J:
                    g2 = yp - g1
                    z = sum(max(0, h - g) for h in (h1, h2) for g in (g1, g2))
                    zp = sum(max(0, g - h) for h in (h1, h2) for g in (g1, g2))
                    K = 1
                    for lev in {h1, h2, g1, g2}:
                        al = (h1 == lev) + (h2 == lev)
                        ga = (g1 == lev) + (g2 == lev)
                        K *= comb(al + ga, al)
                    key = (x, 2 * b - yp, z)
                    lv[key] = lv.get(key, 0) + K
                    st["npts"] += 1
                    t, s = h2 - g1, h2 + g1
                    zz = max(0, t) + max(0, x - yp - t) + max(0, x - s) + max(0, s - yp)
                    tl, th = min(0, x - yp), max(0, x - yp)
                    sl, sh = min(x, yp), max(x, yp)
                    dist = max(0, tl - t, t - th) + max(0, sl - s, s - sh)
                    if zz != z or min(z, zp) != dist:
                        ok_rem = False
                    if x <= yp and min(z, zp) >= 1:
                        pts.setdefault(z, []).append((h2, g1, K))
            if x <= yp:
                for delta, L in pts.items():
                    if len(L) > b + 1:
                        ok_int = False
                    if any((h2 + g1) not in (x, yp) for (h2, g1, K) in L if K > 1):
                        ok_int = False
                    if sum(1 for (h2, g1, K) in L if h2 + g1 == x) > 1:
                        ok_int = False
                    if sum(1 for (h2, g1, K) in L if h2 + g1 == yp) > 1:
                        ok_int = False
                    ex = sum(K - 1 for (_, _, K) in L)
                    if ex > (3 if x == yp else 2):
                        ok_int = False
                    if sum(K for (_, _, K) in L) > b + 4:
                        ok_int = False
                    st["worst_L"] = max(st["worst_L"], len(L) - b)
                    st["worst_ex"] = max(st["worst_ex"], ex)
    check("B", ok_int, f"Lemma 2.1 internals, b = {b}")
    check("B", ok_rem, f"s5 remark (z = phi(t) + psi(sigma), l1-distance to the square), b = {b}")
    check("B", lv == R, f"level enumeration == W2 on every class, b = {b}")


def word_pass() -> None:
    t0 = head("W", f"one pass over all words of content (2,b,2), 0 <= b <= {BW}")
    st = {"nlit": 0, "ncls": 0, "npts": 0, "worst_L": 0, "worst_ex": 0, "ncellC": 0,
          "nchamber": 0, "nlayer": 0, "ncellK": 0, "thin": [], "vals": [], "bad": set(),
          "some_bad": [], "every_ok": []}
    for b in range(0, BW + 1):
        C = classes_slots(b)
        R: dict = {}
        for (x, y, z, zp), n in C.items():
            R[(x, y, z)] = n
        st["ncls"] += len(C)
        # [A]
        check("A", len(R) == len(C), f"z' is a function of (x,y,z), b = {b}")
        check("A", sum(C.values()) == factorial(b + 4) // (4 * factorial(b)), f"word total, b = {b}")
        check("A", all(z - zp == 2 * x - 2 * (2 * b - y) for (x, y, z, zp) in C),
              f"z - z' = 2x - 2y' on every word, b = {b}")
        check("A", all(C.get((2 * b - x, 2 * b - y, zp, z), 0) == n for (x, y, z, zp), n in C.items()),
              f"rho(x,y,z) = rho(2b-x,2b-y,z') on every class, b = {b}")
        if b <= BS:
            literal_checks(b, C, R, st)
        if 1 <= b <= BL:
            level_checks(b, R, st)
        if b == 0:
            continue
        # [B] thin classes
        best, arg = 0, []
        for (x, y, z, zp), n in C.items():
            if z >= 1 and zp >= 1:
                if n > best:
                    best, arg = n, [(x, y, z)]
                elif n == best:
                    arg.append((x, y, z))
        arg.sort()
        check("B", best <= b + 4, f"thin bound b+4, b = {b}")
        if b % 2 == 0:
            check("B", R.get((b, b, b), 0) == b + 4, f"rho(b,b,b) = b+4 for b even, b = {b}")
            check("B", best == b + 4 and arg == [(b, b, b)], f"thin maximum b+4 only at (b,b,b), b = {b}")
        elif b >= 3:
            check("B", best == b + 3 and arg == [(b - 1, b + 1, b - 1), (b, b, b), (b + 1, b - 1, b - 1)],
                  f"thin maximum b+3 at the three classes, b = {b}")
        else:
            check("B", best == 4 and arg == [(1, 1, 1)], "thin maximum 4 at (1,1,1), b = 1")
        st["thin"].append((b, best, arg))
        # [C] every cell: W2 = P = IE = R; z' = 0 clause; symmetry
        ok = ok_rev = ok_sym = True
        for x in range(0, 2 * b + 1):
            for y in range(0, 2 * b + 1):
                v = R.get((x, y, 0), 0)
                st["ncellC"] += 1
                if not (v == rho0_pat(b, x, y) == rho0_ie(b, x, y) == rho0_pw(b, x, y)):
                    ok = False
                if b <= BL and v != rho0_box(b, x, y):
                    ok = False
                if v != R.get((y, x, 0), 0):
                    ok_sym = False
                z0 = 2 * x + 2 * y - 4 * b
                if z0 >= 0 and R.get((x, y, z0), 0) != rho0_pat(b, 2 * b - x, 2 * b - y):
                    ok_rev = False
        check("C", ok, f"W2 == P == IE == R on every cell, b = {b}")
        check("C", ok_rev, f"z' = 0 classes = reversal of z = 0 classes, b = {b}")
        check("C", ok_sym, f"rho(x,y,0) = rho(y,x,0), b = {b}")
        # [D] [Y26a] Thms 2 and 6, whole fibres
        fib: dict = {}
        for (x, y, z), n in R.items():
            fib.setdefault((x, y), {})[z] = n
        ok2 = ok6 = True
        for x in range(0, 2 * b + 1):
            for y in range(0, 2 * b + 1):
                j, i = 2 * b - x, 2 * b - y
                z0 = 4 * b - 2 * j - 2 * i
                F = fib.get((x, y), {})
                if i + j <= b:
                    st["nchamber"] += 1
                    if F != {z0: p2(j) * p2(i) + eps_b(b, i, j)}:
                        ok2 = False
                elif i + j == b + 1 and i >= 2 and j >= 2:
                    st["nlayer"] += 1
                    if F != {z0: p2(j) * p2(i) + 1 + (j == 2) + (i == 2), z0 + 1: 1}:
                        ok6 = False
        check("D", ok2, f"[Y26a] Thm 2 at a = c = 2 (whole fibre), b = {b}")
        check("D", ok6, f"[Y26a] Thm 6 at a = c = 2 (whole fibre), b = {b}")
        # [H], [J]: maxima and maximisers
        Mb = max(R.values())
        argm = sorted(k for k, v in R.items() if v == Mb)
        if b <= 15:
            st["vals"].append(Mb)
        if Mb != mstar(b):
            st["bad"].add(b)
        flags = [k[2] == 0 or k[2] - 2 * k[0] - 2 * k[1] + 4 * b == 0 for k in argm]
        if not any(flags):
            st["some_bad"].append(b)
        if all(flags):
            st["every_ok"].append(b)
        thin_max = [k for k, fl in zip(argm, flags) if not fl]
        if b == 4:
            check("J", argm == [(4, 4, 4)] and Mb == 8, "b = 4: unique maximiser (4,4,4), 8 words")
        if b == 2:
            check("J", thin_max == [(2, 2, 2)] and Mb == 6, f"b = 2: thin tie (2,2,2), got {thin_max}")
        if b == 5:
            check("J", thin_max == [(4, 6, 4), (5, 5, 5), (6, 4, 4)] and Mb == 8,
                  f"b = 5: thin ties, got {thin_max}")
        if b >= 16:
            check("H", Mb == mstar(b), f"M(b) = Mstar(b) by W2, b = {b}")
            sarg = set(argm)
            if b in TABLE4:
                mexp, z0s = TABLE4[b]
                exp = ({(x, y, 0) for (x, y) in z0s}
                       | {(2 * b - x, 2 * b - y, 4 * b - 2 * x - 2 * y) for (x, y) in z0s})
                check("H", Mb == mexp and sarg == exp, f"maximisers = s4 table with reversal images, b = {b}")
            if b == 21:
                check("H", {k for k in sarg if k[2] != 0} == {(28, 30, 32), (30, 28, 32), (30, 30, 36)},
                      "b = 21: the z' = 0 maximisers are (28,30,32), (30,28,32), (30,30,36)")
            if b >= 20:
                check("H", sarg == predicted_all(b), f"maximisers = predicted set (W2), b = {b}")
                six = b % 14 in (0, 5, 7, 12)
                check("H", len(argm) in (2, 4, 6) and (len(argm) == 6) == six,
                      f"2/4/6 maximisers, 6 iff b mod 14 in {{0,5,7,12}}, b = {b}")
        # [K] D(iii) totals, T4, (2,3,2)
        tot: dict = {}
        for (x, y, z), n in R.items():
            tot[(x, y)] = tot.get((x, y), 0) + n
        ok = True
        for x in range(0, 2 * b + 1):
            for y in range(0, 2 * b + 1):
                st["ncellK"] += 1
                if tot.get((x, y), 0) != P_diii(b, x, y):
                    ok = False
        check("K", ok, f"sum_z rho = D(iii), b = {b}")
        h = b // 2
        zs = {z: n for (x, y, z), n in R.items() if x == b and y == b}
        exp = {b - 2 * r: 2 * (h - r) + 4 + 2 * (b % 2 == 0 and r == h) for r in range(0, h + 1)}
        check("K", zs == exp, f"T4 at (b,b), b = {b}")
        if b == 3:
            selfm = sorted(n for (x, y, z, zp), n in C.items() if (x, y, z) == (6 - x, 6 - y, zp))
            st["selfm"] = selfm
            check("K", sum(R.values()) == 210 and len(R) == 70 and selfm == [4, 6],
                  f"(2,3,2): 210 words, 70 classes, self-mirror sizes {selfm}")
        del C, R, fib, tot
    # [J] summary checks
    check("J", st["vals"] == M_SMALL, f"M(1..15) = {st['vals']}")
    check("J", st["bad"] == {b for b in FAILSET if b <= BW}, f"M = Mstar fails exactly on {sorted(st['bad'])}")
    check("J", st["some_bad"] == [4], f"some maximiser has z = 0 or z' = 0 for every b != 4 (exceptions {st['some_bad']})")
    check("J", st["every_ok"] == [b for b in range(1, BW + 1) if b in (1, 3) or b >= 6],
          "every maximiser has z = 0 or z' = 0 iff b in {1,3} or b >= 6")
    print(f"[W] word pass done ({time.perf_counter() - t0:.1f} s)", flush=True)
    status("A", f"W1 == W2 and Lemmas 1.0, 1.1 and word-level reversal on all {st['nlit']} literal words "
                f"(0 <= b <= {BS}); Parikh-matrix classes == (x,y,z) classes (b <= {BPM}); word totals, "
                f"z - z' = 2x - 2y' and class reversal on all {st['ncls']} classes (0 <= b <= {BW})")
    status("B", f"thin classes, 1 <= b <= {BW}: max <= b+4; b even: b+4 exactly at (b,b,b); b odd >= 3: b+3 "
                f"exactly at (b-1,b+1,b-1), (b,b,b), (b+1,b-1,b-1); b = 1: 4 at (1,1,1). Lemma 2.1 internals "
                f"on every thin level set with x <= y', 1 <= b <= {BL}: |L| <= b+1 (max |L| - b = "
                f"{st['worst_L']}), K > 1 only where h2+g1 is x or y' (at most one point of each kind), "
                f"excess <= 2 or 3 (max {st['worst_ex']}); level enumeration == W2; s5 identity on all "
                f"{st['npts']} level points. First rows (b, max, maximisers): "
                + "; ".join(f"{b}:{m}:{a}" for b, m, a in st["thin"][:5]))
    status("C", f"every cell of [0,2b]^2, 1 <= b <= {BW} ({st['ncellC']} cells): W2 == P == IE == R (and == the "
                f"box sum of Lemma 3.1's first form for b <= {BL}); the z' = 0 clause; x <-> y symmetry")
    status("D", f"[Y26a] Thm 2 on {st['nchamber']} chamber cells and Thm 6 on {st['nlayer']} first-layer cells "
                f"agree with the W2 fibres exactly, 1 <= b <= {BW}; Table 1 (p. 12) word for word")
    status("H", f"W2: M(b) = Mstar(b) for 16 <= b <= {BW}; maximisers = the s4 table (16..20) and the "
                f"predicted set (20..{BW}); 2/4/6 of them by the mod-14 rule")
    status("J", f"M(1..15) = {st['vals']}; failures of M = Mstar within 1..{BW}: {sorted(st['bad'])}; b = 4 "
                f"unique (4,4,4); thin ties at b = 2, 5; every maximiser has z = 0 or z' = 0 exactly for "
                f"b in {{1,3}} and 6 <= b <= {BW}")
    status("K", f"sum_z rho = D(iii) on {st['ncellK']} cells and T4 at (b,b), 1 <= b <= {BW}; (2,3,2): 210 words "
                f"in 70 classes, self-mirror classes of sizes {st.get('selfm')}")


# ---------------------------------------------------------------------------------------------
# [C], [D] formula parts (beyond the word range)
# ---------------------------------------------------------------------------------------------

def formulas_CD() -> None:
    t0 = head("C/D", f"formula parts: P == IE == R for {BW} < b <= {BC}; piecewise boundaries; "
                     f"Theorem 1(ii) on d <= 1 against [Y26a]")
    ncell = 0
    for b in range(BW + 1, BC + 1):
        ok = True
        for x in range(0, 2 * b + 1):
            for y in range(0, min(2 * b, 2 * b + 2 - x) + 1):
                ncell += 1
                if not (rho0_pat(b, x, y) == rho0_ie(b, x, y) == rho0_pw(b, x, y)):
                    ok = False
        check("C", ok, f"P == IE == R, b = {b}")
    ok = True
    for X in range(0, 60):
        for Y in range(0, 60):
            m, M = min(X, Y), max(X, Y)
            if m >= 1 and (X + 1) * (Y + 1) - fpar(m) != F_r3(m, M, m):
                ok = False
            if F_r3(m, M, M) != F_r4(X + Y - M):
                ok = False
    check("C", ok, "R2/R3 agree at d = m and R3/R4 at d = M")
    ok = True
    for b in range(1, BC + 1, 7):
        for x in range(0, 2 * b + 1):
            for y in range(0, 2 * b + 1):
                if region(b, x, y) in ("R1", "R2", "R5") and beta_note(b, x, y) != 0:
                    ok = False
    check("C", ok, "beta = 0 in R1, R2 and R5")
    status("C", f"P == IE == R on every cell with x + y <= 2b + 2, {BW + 1} <= b <= {BC} ({ncell} cells); "
                f"R2/R3 agree at d = m and R3/R4 at d = M (X, Y < 60); beta = 0 in R1, R2, R5")
    ok = True
    n = 0
    for b in range(1, BC + 1):
        for x in range(0, b + 2):
            for y in range(0, b + 2 - x):
                d = x + y - b
                if d <= 0:
                    n += 1
                    if rho0_ie(b, x, y) != p2(x) * p2(y) + eps_b(b, y, x):
                        ok = False
                elif d == 1 and x >= 2 and y >= 2:
                    n += 1
                    if rho0_ie(b, x, y) != p2(x) * p2(y) + 1 + (x == 2) + (y == 2):
                        ok = False
    check("D", ok, "Theorem 1(ii) on d <= 0 and on d = 1 (x, y >= 2) == [Y26a] Thms 2, 6 reversed")
    status("D", f"Theorem 1(ii) equals the reversed [Y26a] values on all {n} cells with d <= 0 or "
                f"(d = 1, x, y >= 2), 1 <= b <= {BC}")
    print(f"[C/D] done ({time.perf_counter() - t0:.1f} s)", flush=True)


# ---------------------------------------------------------------------------------------------
# [E] Lemma 3.3 cell by cell; s7.3 region maxima
# ---------------------------------------------------------------------------------------------

def secE() -> None:
    t0 = head("E", "Lemma 3.3 (a)-(f) cell by cell; non-R2 cells < Mstar(b) for b >= 20; s7.3 table")
    ncell = 0
    for b in range(1, BC + 1):
        ms = mstar(b)
        ok = ok20 = True
        worst = {"R1": 0, "R3": 0, "DM": 0, "R4": 0, "R5": 0}
        for x in range(0, 2 * b + 1):
            X, eps = divmod(x, 2)
            for y in range(0, 2 * b + 1 - x):
                Y, eta = divmod(y, 2)
                ncell += 1
                rho = rho0_pat(b, x, y)
                j = eps + eta
                S = X + Y
                d = x + y - b
                D = 2 * S - b
                m, M = min(X, Y), max(X, Y)
                reg = region(b, x, y)
                bet = beta_note(b, x, y)
                if reg == "R1":
                    good = 16 * rho <= (b + 3) ** 2 and bet == 0
                elif reg == "R2":
                    if 2 * S < b:
                        good = (d in (0, 1) and bet == 0 and rho == (X + 1) * (Y + 1) + 1
                                and 16 * (rho - 1) <= (b + 3) ** 2)
                    else:
                        eq = abs(X - Y) <= 1 and (j == 0 or (D == 0 and j == 1))
                        good = rho <= vfun(b, S) and (rho == vfun(b, S)) == eq and bet == 0
                elif reg == "R3":
                    good = (bet <= 1 and 2 * (rho - 1) <= (m + 1) * (b + 4 - 2 * m)
                            and 16 * (rho - 1) <= (b + 6) ** 2)
                elif reg == "DM":
                    if m >= 1:
                        good = bet <= 2 and 2 * (rho - 2) <= (m + 1) * (m + 4) and 3 * m <= b
                    else:
                        good = rho <= 6
                elif reg == "R4":
                    e = X + Y - d
                    if e >= 1:
                        good = bet <= 2 and 2 * (rho - 2) <= (e + 1) * (e + 4) and 3 * e <= b - 2
                    else:
                        good = rho <= 6
                else:
                    good = rho == 0
                if not good:
                    ok = False
                if reg != "R2":
                    if rho > worst[reg]:
                        worst[reg] = rho
                    if b >= 20 and rho >= ms:
                        ok20 = False
        check("E", ok, f"Lemma 3.3 (a)-(f) and the equality case of (c), b = {b}")
        check("E", ok20 or b < 20, f"every non-R2 cell < Mstar(b) for b >= 20, b = {b}")
        if b in REGION_TABLE:
            exp = REGION_TABLE[b]
            got = (ms, worst["R1"], worst["R3"], worst["DM"], worst["R4"])
            check("E", got == exp, f"s7.3 region maxima at b = {b}: {got} vs {exp}")
    check("E", region(16, 8, 12) == "R3" and 8 + 12 - 16 == min(4, 6),
          "s4: the b = 16 maximiser (8,12,0) lies in R3 with d = m")
    shown = [b for b in REGION_TABLE if b <= BC]
    status("E", f"Lemma 3.3 (a)-(f), the equality case of (c) and the beta bounds on {ncell} cells "
                f"(x + y <= 2b), 1 <= b <= {BC}; for 20 <= b <= {BC} no cell outside R2 reaches Mstar(b); "
                f"the s7.3 table reproduced for b in {shown}")
    print(f"[E] done ({time.perf_counter() - t0:.1f} s)", flush=True)


# ---------------------------------------------------------------------------------------------
# [F] Lemma 3.4
# ---------------------------------------------------------------------------------------------

def secF() -> None:
    t0 = head("F", "Lemma 3.4: the parabola identity and V(S) <= Mstar(b)")
    ok_id = ok_le = ok_win = True
    for b in range(0, BV + 1):
        ms = mstar(b)
        for S in range(-10, 2 * b + 11):
            D = 2 * S - b
            G4 = (S + 2) ** 2 - 2 * (D - 2) * (D + 1)          # 4 g(S)
            if 7 * G4 != 2 * (b * b + 9 * b + 36) - (7 * S - 4 * b - 4) ** 2:
                ok_id = False
            V = vfun(b, S)
            if not (4 * V <= G4 and V <= ms):
                ok_le = False
            if V == ms and not 4 * abs(7 * S - 4 * b - 4) < 21:
                ok_win = False
    check("F", ok_id, "7 * 4g(S) = 2(b^2+9b+36) - (7S-4b-4)^2")
    check("F", ok_le, "V(S) <= g(S) and V(S) <= Mstar(b)")
    check("F", ok_win, "V(S) = Mstar(b) implies |S - S*| < 3/4")
    ok = all((Fraction(4 * b + 18, 7) ** 2 / 4 - (Fraction(b + 8, 7) - 2) * (Fraction(b + 8, 7) + 1) / 2)
             == Fraction(b * b + 9 * b + 36, 14) for b in range(0, 200))
    check("F", ok, "g(S*) = (b^2+9b+36)/14")
    check("F", Fraction(26, 49) < Fraction(9, 16), "sqrt(26/49) < 3/4")
    status("F", f"identity, V <= g, V <= Mstar and the 3/4 window for every S in [-10, 2b+10], "
                f"0 <= b <= {BV}; g(S*) exact for b < 200; 26/49 < 9/16")
    print(f"[F] done ({time.perf_counter() - t0:.1f} s)", flush=True)


# ---------------------------------------------------------------------------------------------
# [G] Table 3.4
# ---------------------------------------------------------------------------------------------

def secG() -> None:
    t0 = head("G", "Table 3.4: rows, zero sets, expansions, thresholds, R2 membership")
    ok_rows = ok_zero = ok_exp = ok_thr = ok_memb = True
    tmax = Fraction(-100)
    targ: list = []
    for r in range(14):
        const, rows = TABLE34[r]
        if const != (r * r + 9 * r + 36) // 14:
            ok_rows = False
        listed = [s for (s, _, _) in rows]
        for (s, prod, fv) in rows:
            if prod != (s // 2 + 1) * (ceil_half(s) + 1) or fv != fpar(2 * s - r) or prod - fv != const:
                ok_rows = False

        def delta(s: int) -> int:
            return (s // 2 + 1) * (ceil_half(s) + 1) - fpar(2 * s - r) - const
        zeros = [s for s in range(-20, 41) if delta(s) == 0]
        if zeros != listed or any(delta(s) > 0 for s in range(-20, 41)):
            ok_zero = False
        for q in range(-3, 61):
            b = 14 * q + r
            if mstar(b) != 14 * q * q + (2 * r + 9) * q + const:
                ok_exp = False
            for s in range(-5, 16):
                S = 8 * q + s
                X, Y = S // 2, S - S // 2
                if (X + 1) * (Y + 1) - fpar(2 * S - b) != 14 * q * q + (2 * r + 9) * q + delta(s) + const:
                    ok_exp = False
                if vfun(b, S) - mstar(b) != delta(s):
                    ok_exp = False
        for s in listed:
            t1 = Fraction(r - 2 * s, 2)
            t2 = Fraction(2 * s - r - s // 2 + 1, 2)
            if t1 > 0 or t2 > Fraction(3, 2) or (t2 == Fraction(3, 2) and (r, s) != (0, 1)):
                ok_thr = False
            if r >= 7 and t2 > 1:
                ok_thr = False
            if r == 6 and t2 != Fraction(1, 2):
                ok_thr = False
            if t2 > tmax:
                tmax, targ = t2, [(r, s)]
            elif t2 == tmax:
                targ.append((r, s))
            qmin = -((-(20 - r)) // 14)                   # least q with 14q + r >= 20
            if not (qmin >= t1 and qmin >= t2):
                ok_thr = False
            for q in range(qmin, 215):                    # every b = 14q + r in [20, 3000)
                b = 14 * q + r
                S = 8 * q + s
                X, Y = S // 2, S - S // 2
                if region(b, 2 * X, 2 * Y) != "R2":
                    ok_memb = False
    check("G", ok_rows, "Table 3.4 rows as printed")
    check("G", ok_zero, "listed s = zeros of V(8q+s) - Mstar(14q+r), never positive (s in [-20,40])")
    check("G", ok_exp, "both expansions and q-independence (q in [-3,60], s in [-5,15])")
    check("G", ok_thr, "thresholds: first <= 0; second <= 3/2 (only at (0,1)), <= 1 for r >= 7, 1/2 at r = 6")
    check("G", ok_memb, "table point in R2 for every b >= 20 (to b < 3000)")
    ok = ok_set = True
    for b in range(20, BZ + 1):
        q, r = divmod(b, 14)
        ms = mstar(b)
        tableS = sorted(8 * q + s for (s, _, _) in TABLE34[r][1])
        if predicted_S(b) != tableS:
            ok_set = False
        for S in tableS:
            X, Y = S // 2, S - S // 2
            if rho0_pat(b, 2 * X, 2 * Y) != ms:
                ok = False
    check("G", ok_set, "{S : V(S) = Mstar(b)} = table values, 20 <= b <= BZ")
    check("G", ok, "rho(2X,2Y,0) = Mstar(b) at the table point (count P), 20 <= b <= BZ")
    status("G", f"18 rows as printed; zero sets; expansions; thresholds (second maximum {tmax} at {targ}); "
                f"R2 membership for 20 <= b < 3000; for 20 <= b <= {BZ} the table S are exactly the S with "
                f"V(S) = Mstar(b), each attaining Mstar(b) by the count P")
    print(f"[G] done ({time.perf_counter() - t0:.1f} s)", flush=True)


# ---------------------------------------------------------------------------------------------
# [H] Theorem 1(iii): z = 0 scans by the count P
# ---------------------------------------------------------------------------------------------

def z0_scan(b: int):
    """Largest z = 0 class over x + y <= 2b (z = 0 forces x + y <= 2b, Lemma 1.1, [A])."""
    best, arg = -1, []
    for x in range(0, 2 * b + 1):
        for y in range(0, 2 * b + 1 - x):
            v = rho0_pat(b, x, y)
            if v > best:
                best, arg = v, [(x, y)]
            elif v == best:
                arg.append((x, y))
    return best, arg


def secH() -> None:
    t0 = head("H", f"Theorem 1(iii): z = 0 scans by the count P, 16 <= b <= {BZ}"
                   + (f" and b in {SAMPLES}" if SAMPLES else ""))
    mind = 10 ** 9
    for b in list(range(16, BZ + 1)) + list(SAMPLES):
        best, arg = z0_scan(b)
        check("H", best == mstar(b), f"M0(b) = Mstar(b) by P, b = {b}")
        mind = min(mind, min(x + y - b for (x, y) in arg))
        if b >= 20:
            Sst = Fraction(4 * b + 4, 7)
            lo, hi = Sst.numerator // Sst.denominator, -((-Sst.numerator) // Sst.denominator)
            good = set(arg) == predicted_z0(b)
            for (x, y) in arg:
                S = x // 2 + y // 2
                good = (good and x % 2 == 0 and y % 2 == 0 and abs(x - y) <= 2
                        and abs(S - Sst) < Fraction(3, 4) and S in (lo, hi))
            three = b % 14 in (0, 5, 7, 12)
            good = good and len(arg) in (1, 2, 3) and (len(arg) == 3) == three
            check("H", good, f"z = 0 maximiser structure, b = {b}")
    check("H", mind >= 3, f"every z = 0 maximiser has d >= 3 for b >= 16 (min {mind})")
    status("H", f"P: M0(b) = Mstar(b) for 16 <= b <= {BZ}" + (f" and b in {SAMPLES}" if SAMPLES else "")
           + f"; for b >= 20 the z = 0 maximisers are exactly the predicted ones (x, y even, |x-y| <= 2, "
           f"S in {{floor, ceil}}(S*), 1/2/3 of them by the mod-14 rule); min d over all of them = {mind}")
    print(f"[H] done ({time.perf_counter() - t0:.1f} s)", flush=True)


# ---------------------------------------------------------------------------------------------
# [I] Theorem 1(iv)
# ---------------------------------------------------------------------------------------------

def secI() -> None:
    t0 = head("I", "Theorem 1(iv): the period-7 quasi-polynomial")
    kappa = [Fraction(2), Fraction(16, 7), Fraction(17, 7), Fraction(17, 7), Fraction(16, 7),
             Fraction(2), Fraction(18, 7)]
    ok = all(14 * mstar(b) - (b * b + 9 * b) == 14 * kappa[b % 7] for b in range(0, BK))
    check("I", ok, "Mstar(b) - (b^2+9b)/14 = kappa(b mod 7)")
    # remark under Theorem 1(iv): b(b+9) mod 14 lies in {0,6,8,10}, so the constant 36 may be
    # replaced by any c in [36, 41] (and by no other c in [20, 60])
    res = sorted({(b * (b + 9)) % 14 for b in range(0, 14)})
    same = [c for c in range(20, 61)
            if all((b * b + 9 * b + c) // 14 == mstar(b) for b in range(0, 2000))]
    check("I", res == [0, 6, 8, 10] and same == [36, 37, 38, 39, 40, 41],
          f"b(b+9) mod 14 in {res}; constants giving Mstar: {same}")
    status("I", f"kappa = (2, 16/7, 17/7, 17/7, 16/7, 2, 18/7) for 0 <= b < {BK}; b(b+9) mod 14 in {res}, "
                f"so floor((b^2+9b+c)/14) = Mstar(b) exactly for c in {same} (c in [20, 60], b < 2000)")
    print(f"[I] done ({time.perf_counter() - t0:.1f} s)", flush=True)


def self_test() -> None:
    """The helper counts against brute force on small boxes (exhaustive, deterministic)."""
    ok = True
    for a1 in range(-2, 6):
        for a2 in range(-2, 6):
            for c1 in range(-2, 6):
                for c2 in range(-2, 6):
                    br = sum(1 for u in range(a1, a2 + 1) for v in range(c1, c2 + 1) if u <= v)
                    if br != pairs_le(a1, a2, c1, c2):
                        ok = False
    for X in range(0, 9):
        for Y in range(0, 9):
            for k in range(-3, 20):
                br = sum(1 for u in range(X + 1) for v in range(Y + 1) if u + v <= k)
                if br != box_le(X, Y, k):
                    ok = False
    check("C", ok, "helper counts pairs_le and box_le against brute force")


def main() -> int:
    print("== check_2b2: the largest Parikh class of (2,b,2) (notes/proof-2b2.md)"
          + ("  [--full]" if FULL else ""), flush=True)
    print(f"   ranges: literal words b <= {BS}, Parikh matrices b <= {BPM}, all words (W2) b <= {BW}, "
          f"levels b <= {BL}, formula cells b <= {BC}, z = 0 scans b <= {BZ}, Lemma 3.4 b <= {BV}, "
          f"kappa b < {BK}", flush=True)
    self_test()
    word_pass()
    formulas_CD()
    secE()
    secF()
    secG()
    secH()
    secI()
    dt = time.perf_counter() - T0
    print("summary: " + "  ".join(f"[{t}] {'ok' if not any(f == t for f, _ in FAIL) else 'FAIL'}" for t in TAGS))
    status_s = "PASS" if not FAIL else "FAIL"
    print(f"check_2b2: {NCHECK[0]} checks, {len(FAIL)} failures, {dt:.1f} s  [{status_s}]", flush=True)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
