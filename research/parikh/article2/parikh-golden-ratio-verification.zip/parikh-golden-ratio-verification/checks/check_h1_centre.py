"""check_h1_centre: H1 for content (a,2,c) and the centre value (notes/proof-h1-centre.md).

Claims of notes/proof-h1-centre.md (finalised 21 October 2026), re-typed here; nothing is
imported from notes/ or from the prover's scripts (notes/article2-scripts/proof-h1/).

Python standard library only; deterministic; exact integer and rational arithmetic (floats only
in printed summaries). Unknown command-line arguments are ignored (run_all.py passes e.g.
--max-n); --full selects the slow ranges shown in brackets below. Exit status is non-zero on any
failure. The last line is "check_h1_centre: N checks, F failures, T s  [PASS|FAIL]". A passing
run is evidence on the stated finite ranges (VERIFIED). The theorems are proved in the note; no
step of those proofs rests on this file.

Setting
-------
Content (a,2,c), letters 1 < 2 < 3; x = |w|_12, y = |w|_23 (scattered subwords),
P(x,y) = #{w : (|w|_12, |w|_23) = (x,y)}, 0 <= x <= 2a, 0 <= y <= 2c; n = a + c,
M = floor(n/2), kappa = c - a, y' = 2c - y, sigma = x + y', tau = y' - x; centre (a,c);
for a = c, D(x) = P(x, 2a - x). W_t(j) = C(t,(t+j)/2) (+-1 walks of length t from 0 to j);
G_h(j) = sum_{i<=h} 2^(h-i) W_i(j); O_m(j,k) = #{(Z,u): Z planar simple walk of length m,
0 <= u <= m, X(u) = j, Y(m) = k}; T = {kappa/2} (n even), {(kappa-1)/2, (kappa+1)/2} (n odd);
Xi(m) = #{(Z,u): Z of length M, u <= m, X(u) = 0, Y(M) in T}.

Claims tested (note section in brackets)
---------------------------------------
 L1    [s2] the map w -> (omega, t1, t2) is a bijection onto Omega x {t1 <= t2};
       x = sum (t_i - omega(t_i))/2, |w|_32 = sum (t_i + omega(t_i))/2 = 2c - y; hence (1.1).
 Sym   [s2] reversal P(x,y) = P(2a-x, 2c-y); RC P_{a,c}(x,y) = P_{c,a}(y,x); sum P = N =
       (n+2)!/(a! 2! c!) [s8, statistical reading].
 Rot   [s1] the rotation (lambda, rho) -> ((lambda+rho)/2, (lambda-rho)/2) is a bijection onto
       the planar walks; L0 [s1] #{Z of length L : Y(L) = j} = W_{2L}(2j).
 L3    [s2] the fold (2.1) in every cell with sigma <= n; (2.2) at the centre; the bijection of
       Step 2 (inverse formulas and the two equivalences) and the involution of Step 5.
 L4    [s3] (3.1) O_m(j,k) = (m+1) sum_h C(m,h)/(h+1) W_{m-h}(k) G_h(j), exactly.
 L5    [s3] G_h(-j) = G_h(j) < G_h(0) for j != 0; G_h = its occupation-count definition.
 C6    [s3] O_m(0,-k) = O_m(0,k); O_m(j,k) <= O_m(0,k), strict iff j != 0 and |k| <= m.
 L7    [s5] G_h(0) = (h+1) C(h, floor(h/2)).
 L8    [s5] O_m(0,k) = (m+1) W_m(k+rho) W_m(k-rho), rho = (m-k) mod 2, |k| <= m.
 A-C   [s4] Step A: P(a,c) = Xi(M) and |j0| <= M on T (both orders of a, c); Step B (4.1):
       B_m = Xi(m), P(x,y) <= B_m for sigma <= n, Xi nondecreasing; (S1): Xi(m) < Xi(M) iff
       m <= M-2 or (m = M-1 and not (n even and a odd)), and the explicit (S1) walks of the note
       (both directions when j0 = 0); Step C: for a <= c every off-centre cell with sigma <= n
       is (S1) or exactly one of cases 1-5, the (S2) terms named in each case exist (positive
       weight, |k| <= m, one nonzero level), and P(x,y) < B_m there; Xi(M-1) = Xi(M) when n is
       even and a odd; the antidiagonal form of s6 and the reduction of s9 item 2 (a = c).
 T1(i) [s0] H1: for (a,c) != (1,1) the centre is the unique maximiser of P; (1,1): exactly
       (0,2), (1,1), (2,0), value 2. Corollary 2: D(x) < D(a) = (a+1) C(a, floor(a/2))^2.
 T1(ii)[s0, s5] P(a,c) = sum_{p,q} C(p+q,p)^2 C(n-2p-2q, a-2p) = (M+1) C(M,floor(a/2))
       C(n-M,ceil(a/2)) = the case-by-case form; symmetric in a, c.
 AP    [s8] Andrews-Paule, J. Symbolic Comput. 16 (1993), re-typed from the authors' copy:
       (2.2) L(m,n) = sum_{i<=m/2} sum_{j<=n/2} C(i+j,j)^2 C(m+n-2i-2j, n-2j)
       = floor((m+n+1)/2)! floor((m+n+2)/2)! / (floor(m/2)! floor((m+1)/2)! floor(n/2)!
       floor((n+1)/2)!); (2.3) L(0,n) = L(n,0) = floor(n/2)+1; (2.4) L(m,n) - L(m-1,n) -
       L(m,n-1) = C((m+n)/2, m/2)^2 if m, n even, else 0 (both sides); (1.1)
       sum_{i,j<=N} C(i+j,j)^2 C(4N-2i-2j, 2N-2j) = (2N+1) C(2N,N)^2; L(c,a) = the double sum
       of T1(ii), and the right side of (2.2) at (c,a) = its closed form.
 Num   [s0, s6, s7, s8] the quoted numbers: the a = 4 profile, D(4..6) at a = 6, a = 60
       (D(60) = 61 C(60,30)^2, D(59)/D(60) = 0.8722 to 4 places, the largest off-centre D at
       x = 59, 61), (1,2,1) values 2,2,2, (2,2,2) maximum 12 at (2,2), the sign pattern of
       D(x+1) - D(x) (-+-+...-, then a final run of +; full alternation exactly for a = 2, 4, 6),
       the a = 3 profile, the runner-up of (1,2,c), 7 <= c (exactly at (1,c-1), (1,c+1), ratio
       M/(M+1); 25/26, 100/101, 150/151 at c = 50, 200, 300) and of
       (2,2,199) (201/202), the k = 2 example [5 choose 2]_q = 1,1,2,2,2,1,1 (|w|_12 over the
       words with two 1s and three 2s), the OEIS query sequences, the s7 word, cell and content
       counts.

Methods (independent implementations)
-------------------------------------
 WE   word enumeration (positions of the 2s, then of the 1s); |w|_12, |w|_23 by a left-to-right
      scan, equal to the literal definition (index pairs) on the smaller range.
 LDP  last-letter (prefix) DP over (#1, #2, #3) for the whole psi_2-array, bivariate polynomials
      packed into one integer; appending 2 adds #1 to x, appending 3 adds #2 to y. It uses no
      levels, no walks and no formula of the note.
 OW   Lemma 1's walk form by enumeration of omega and (t1, t2) (the definition of (1.1)).
 PW   literal enumeration of all 4^m planar walks, occupation counted step by step.
 PDP  planar-walk counts by step DPs: N_u(X,Y) (2-D step DP) and V_t(d) (vertical increment,
      1-D DP with weights 1, 2, 1). O_m(j,k) = sum_u sum_i N_u(j,i) V_{m-u}(k-i) and
      Xi(m) = sum_{u<=m} sum_{j0 in T} sum_i N_u(0,i) V_{M-u}(j0-i). No rotation, no Lemma 0,
      no (3.1).
 1W   all +-1 walks of length h enumerated, occupation of each level counted.
 FORM the note's formulas re-typed: W, G (its sum), (3.1), Lemma 8, (2.1), (2.2), (4.1),
      Theorem 1(ii) in three forms; the Andrews-Paule formulas (2.2)-(2.4), (1.1).

Sections and ranges, default [--full]
-------------------------------------
 [1] WE = LDP every cell, a + c <= 10 [11] (a, c >= 1); scan = literal, a + c <= 7 [8]; L1 word
     by word, a + c <= 9 [10]; OW = LDP every cell, a + c <= 11 [13].
 [2] Rot m <= 6 [7]; L0 by PW, L <= 7 [8], and by PDP, L <= 30 [50]; PW = PDP for O_m, m <= 7
     [8]; L4, C6, L8 by PDP, m <= 30 [40], |j|, |k| <= m+1; 1W = G, h <= 12 [16]; G table = G,
     h <= 60; L5, L7, h <= 300 [500], 1 <= |j| <= h+2.
 [3] L3 Steps 2 and 5 structurally: omega of length <= 10 [13], planar walks m <= 6 [7]; (2.1)
     with PDP = LDP in every cell with sigma <= n, all a, c >= 1, a + c <= 20 [28]; (2.2),
     a + c <= 36 [50].
 [4] A-C: Steps A, B and (S1) for all a, c >= 1, 3 <= a + c <= 30 [40] (both orders); Step C
     for a <= c on the same range; the (S1) walks; the antidiagonal form and the s9 item 2
     reduction for a = c <= 14 [20].
 [5] T1(i) by LDP full arrays: all a, c >= 1, a + c <= 60 [100] (both orders), plus thin
     contents a <= 3, c <= 150 [300] (both orders), plus a = c <= 50 [80]; Sym on all of them.
 [6] T1(ii) three forms, 0 <= a, c <= 60 [100]; = LDP centre on the [5] range; AP (2.2)-(2.4),
     0 <= m, n <= 60 [100]; AP (1.1), N <= 80 [150]; symmetry in a, c.
 [7] Num (the sign pattern for 2 <= a <= 40 [60]; the (1,2,c) runner-up for 7 <= c <= 150
     [300], plus c = 200 and 300).

Outcome (21 October 2026, Python 3.11.9)
----------------------------------------
See the bottom of notes/proof-h1-centre.md s7 and the logs
notes/article2-scripts/proof-h1/check_default.log and check_full.log.
"""

from __future__ import annotations

import sys
import time
from collections import defaultdict
from fractions import Fraction
from itertools import combinations, product
from math import comb, factorial, lcm

FULL = "--full" in sys.argv[1:]
T0 = time.perf_counter()

if FULL:
    WE_T, LIT_T, L1W_T, OW_T = 11, 8, 10, 13
    ROT_M, L0_PW, L0_PDP, PW_M, OM_M, G1W_H, GH = 7, 8, 50, 8, 40, 16, 500
    FOLD_OM_N, FOLD_PW_M, FOLD_T, CENTRE_T = 13, 7, 28, 50
    STEP_T, ANTI_A = 40, 20
    H1_T, THIN_A, THIN_C, DIAG_A = 100, 3, 300, 80
    CF_T, AP_T, AP11_N = 100, 100, 150
    SIGN_A, RU_C = 60, 300
else:
    WE_T, LIT_T, L1W_T, OW_T = 10, 7, 9, 11
    ROT_M, L0_PW, L0_PDP, PW_M, OM_M, G1W_H, GH = 6, 7, 30, 7, 30, 12, 300
    FOLD_OM_N, FOLD_PW_M, FOLD_T, CENTRE_T = 10, 6, 20, 36
    STEP_T, ANTI_A = 30, 14
    H1_T, THIN_A, THIN_C, DIAG_A = 60, 3, 150, 50
    CF_T, AP_T, AP11_N = 60, 60, 80
    SIGN_A, RU_C = 40, 150

FAIL: list[str] = []
NCHECK = [0]


def check(cond: bool, msg: str) -> bool:
    NCHECK[0] += 1
    if not cond:
        FAIL.append(msg)
        if len(FAIL) <= 40:
            print("FAIL:", msg, flush=True)
    return cond


def section(title: str) -> None:
    print(f"[{time.perf_counter() - T0:7.1f} s] {title}", flush=True)


def say(text: str) -> None:
    print("           " + text, flush=True)


# ------------------------------------------------------------------ basics
def C(n: int, k: int) -> int:
    """Binomial with the note's convention: 0 unless 0 <= k <= n."""
    return comb(n, k) if 0 <= k <= n else 0


def W(t: int, j: int) -> int:
    """+-1 walks of length t from 0 to j (the note's W_t(j))."""
    if t < 0 or abs(j) > t or (t + j) % 2:
        return 0
    return comb(t, (t + j) // 2)


def G(h: int, j: int) -> int:
    """The note's G_h(j) = sum_{i<=h} 2^(h-i) W_i(j), exactly as typed (O(h))."""
    return sum((1 << (h - i)) * W(i, j) for i in range(h + 1))


_GT: list = []


def Gv(h: int, j: int) -> int:
    """G_h(j) from the table G_h = 2 G_{h-1} + W_h (same numbers; [2] compares it with G)."""
    while len(_GT) <= h:
        t = len(_GT)
        prev = _GT[-1] if _GT else {}
        _GT.append({i: 2 * prev.get(i, 0) + W(t, i) for i in range(-t - 2, t + 3)})
    return _GT[h].get(j, 0)


def nwords(a: int, c: int) -> int:
    return factorial(a + c + 2) // (factorial(a) * 2 * factorial(c))


def target_set(a: int, c: int) -> list[int]:
    n, kap = a + c, c - a
    if n % 2 == 0:
        return [kap // 2]
    return [(kap - 1) // 2, (kap + 1) // 2]


# ------------------------------------------------------------------ WE (words)
def words(a: int, c: int):
    """Every word of content (a,2,c) exactly once: positions of the two 2s, then of the 1s."""
    L = a + c + 2
    for twos in combinations(range(L), 2):
        rest = [p for p in range(L) if p not in twos]
        for ones in combinations(rest, a):
            w = [3] * L
            for p in twos:
                w[p] = 2
            for p in ones:
                w[p] = 1
            yield tuple(w)


def scan(w) -> tuple[int, int]:
    n1 = n2 = x = y = 0
    for ch in w:
        if ch == 1:
            n1 += 1
        elif ch == 2:
            x += n1
            n2 += 1
        else:
            y += n2
    return x, y


def literal(w, u) -> int:
    """Occurrences of the two-letter word u as a scattered subword (index pairs)."""
    return sum(1 for i, j in combinations(range(len(w)), 2) if (w[i], w[j]) == u)


# ------------------------------------------------------------------ LDP (prefix DP)
_LDP: dict = {}


def ldp(a: int, c: int, cache: bool | None = None):
    """Full psi_2-array arr[x][y] of content (a,2,c) by the last-letter DP over (#1,#2,#3).
    Arrays with a + c <= 40 are cached (they are reused by several sections)."""
    key = (a, c)
    if key in _LDP:
        return _LDP[key]
    if cache is None:
        cache = a + c <= 40
    X, Y = 2 * a + 1, 2 * c + 1
    N = nwords(a, c)
    B = 8 * ((N.bit_length() + 1 + 7) // 8)
    prev = None
    for i in range(a + 1):
        cur = [[0] * (c + 1) for _ in range(3)]
        for j in range(3):
            row = cur[j]
            for k in range(c + 1):
                if i == 0 and j == 0 and k == 0:
                    row[k] = 1
                    continue
                v = prev[j][k] if i else 0
                if j:
                    v += cur[j - 1][k] << (B * i)        # append 2: x += #1
                if k:
                    v += row[k - 1] << (B * X * j)       # append 3: y += #2
                row[k] = v
        prev = cur
    v = prev[2][c]
    nb = B // 8
    raw = v.to_bytes(nb * X * Y, "little")
    arr = [[int.from_bytes(raw[(x + X * y) * nb:(x + X * y + 1) * nb], "little")
            for y in range(Y)] for x in range(X)]
    if cache:
        _LDP[key] = arr
    return arr


def contents(tmax: int, tmin: int = 2):
    for t in range(tmin, tmax + 1):
        for a in range(1, t):
            yield a, t - a


# ------------------------------------------------------------------ PW and PDP (planar walks)
STEPS = ((1, 0), (-1, 0), (0, 1), (0, -1))


def pw_occupation(m: int) -> dict:
    """O_m(j,k) by literal enumeration of all 4^m planar walks."""
    O: dict = defaultdict(int)
    for st in product(STEPS, repeat=m):
        X = Y = 0
        xs = [0]
        for dx, dy in st:
            X += dx
            Y += dy
            xs.append(X)
        for xv in xs:
            O[(xv, Y)] += 1
    return O


_N: list = [{(0, 0): 1}]
_V: list = [{0: 1}]


def Nu(u: int) -> dict:
    """N_u(X,Y): planar walks of length u ending at (X,Y), by a 2-D step DP."""
    while len(_N) <= u:
        nxt: dict = defaultdict(int)
        for (X, Y), v in _N[-1].items():
            for dx, dy in STEPS:
                nxt[(X + dx, Y + dy)] += v
        _N.append(dict(nxt))
    return _N[u]


def Vt(t: int) -> dict:
    """V_t(d): planar walks of length t with vertical increment d (weights 1, 2, 1)."""
    while len(_V) <= t:
        nxt: dict = defaultdict(int)
        for d, v in _V[-1].items():
            nxt[d + 1] += v
            nxt[d - 1] += v
            nxt[d] += 2 * v
        _V.append(dict(nxt))
    return _V[t]


_O: dict = {}


def O_pdp(m: int) -> dict:
    """The table O_m(j,k) by PDP (splitting at time u; no rotation, no Lemma 0)."""
    if m in _O:
        return _O[m]
    O: dict = defaultdict(int)
    for u in range(m + 1):
        V = Vt(m - u)
        for (X, Y), v in Nu(u).items():
            for d, w in V.items():
                O[(X, Y + d)] += v * w
    _O[m] = dict(O)
    return _O[m]


def Om(m: int, j: int, k: int) -> int:
    return O_pdp(m).get((j, k), 0)


def Xi_pdp(a: int, c: int) -> list[int]:
    """Xi(m), 0 <= m <= M, counted directly from planar walks of length M (PDP)."""
    n = a + c
    M = n // 2
    T = target_set(a, c)
    out, acc = [], 0
    for u in range(M + 1):
        V = Vt(M - u)
        for (X, Y), v in Nu(u).items():
            if X == 0:
                acc += v * sum(V.get(j0 - Y, 0) for j0 in T)
        out.append(acc)
    return out


# ------------------------------------------------------------------ the note's formulas (FORM)
def O_formula(m: int, j: int, k: int) -> tuple[int, int]:
    """(3.1) as an exact fraction num/L with L = lcm(1, ..., m+1):
    (m+1) sum_h [C(m,h)/(h+1)] W_{m-h}(k) G_h(j) = num / L."""
    L = lcm(*range(1, m + 2))
    num = (m + 1) * sum(C(m, h) * (L // (h + 1)) * W(m - h, k) * Gv(h, j) for h in range(m + 1))
    return num, L


def O0_lemma8(m: int, k: int) -> int:
    rho = (m - k) % 2
    return (m + 1) * W(m, k + rho) * W(m, k - rho)


def fold(a: int, c: int, x: int, y: int) -> int:
    """(2.1), with O_m from PDP."""
    n, kap = a + c, c - a
    yp = 2 * c - y
    sig, tau = x + yp, yp - x
    assert sig <= n
    m, r = divmod(sig, 2)
    E = (0,) if r == 0 else (1, -1)
    tot = 0
    for eps in E:
        lev = (tau - eps) // 2
        assert (tau - eps) % 2 == 0
        for k in range(-m - 1, m + 2):
            wgt = W(n - 2 * m - r, kap - eps + 2 * k)
            if wgt:
                tot += Om(m, k + lev, k) * wgt
    return tot


def centre_22(a: int, c: int) -> int:
    """(2.2)."""
    n, kap = a + c, c - a
    if n % 2 == 0:
        return Om(n // 2, 0, -kap // 2)
    return sum(Om((n - 1) // 2, 0, (eps - kap) // 2) for eps in (1, -1))


def B_formula(a: int, c: int, m: int) -> int:
    """(4.1): B_m = sum_k O_m(0,k) W_{n-2m}(kappa + 2k)."""
    n, kap = a + c, c - a
    return sum(Om(m, 0, k) * W(n - 2 * m, kap + 2 * k) for k in range(-m - 1, m + 2))


def double_sum(a: int, c: int) -> int:
    n = a + c
    return sum(C(p + q, p) ** 2 * C(n - 2 * p - 2 * q, a - 2 * p)
               for p in range(a // 2 + 1) for q in range(c // 2 + 1))


def closed_unified(a: int, c: int) -> int:
    n = a + c
    M = n // 2
    return (M + 1) * C(M, a // 2) * C(n - M, (a + 1) // 2)


def closed_cases(a: int, c: int) -> int:
    """Theorem 1(ii), case by case."""
    n = a + c
    M = n // 2
    if a % 2 == 0 and c % 2 == 0:
        return (M + 1) * C(M, a // 2) ** 2
    if a % 2 == 1 and c % 2 == 1:
        return (M + 1) * C(M, (a - 1) // 2) * C(M, (a + 1) // 2)
    e = a if a % 2 == 0 else c
    return (M + 1) * C(M, e // 2) * C(M + 1, e // 2)


def ap_rhs(m: int, n: int) -> Fraction:
    """Right side of Andrews-Paule (2.2) (as a Fraction, to test integrality)."""
    f = factorial
    return Fraction(f((m + n + 1) // 2) * f((m + n + 2) // 2),
                    f(m // 2) * f((m + 1) // 2) * f(n // 2) * f((n + 1) // 2))


# ======================================================================== [1]
def sec1() -> None:
    section(f"[1] words, Lemma 1, the walk form (1.1): WE a+c <= {WE_T}, literal <= {LIT_T}, "
            f"L1 per word <= {L1W_T}, OW <= {OW_T}")
    nw = ncell = 0
    for a, c in contents(WE_T):
        arr = ldp(a, c)
        cnt: dict = defaultdict(int)
        lit = a + c <= LIT_T
        l1 = a + c <= L1W_T
        images = set()
        n = a + c
        for w in words(a, c):
            x, y = scan(w)
            cnt[(x, y)] += 1
            nw += 1
            if lit:
                check((x, y) == (literal(w, (1, 2)), literal(w, (2, 3))), f"[1] scan = literal {w}")
            if l1:
                # Lemma 1: omega from the {1,3}-word, t1 <= t2 = letters 1, 3 before each 2
                om, ts, h = [0], [], 0
                for ch in w:
                    if ch == 2:
                        ts.append(len(om) - 1)
                    else:
                        h += 1 if ch == 3 else -1
                        om.append(h)
                t1, t2 = ts
                check(len(om) == n + 1 and om[-1] == c - a and t1 <= t2, f"[1] L1 shape {w}")
                xv = (t1 - om[t1]) // 2 + (t2 - om[t2]) // 2
                y32 = (t1 + om[t1]) // 2 + (t2 + om[t2]) // 2
                check(xv == x and y32 == literal(w, (3, 2)) == 2 * c - y, f"[1] L1 counts {w}")
                images.add((tuple(om), t1, t2))
        if l1:
            check(len(images) == nwords(a, c) == comb(n, c) * (n + 1) * (n + 2) // 2,
                  f"[1] L1 bijection ({a},{c})")
        for x in range(2 * a + 1):
            for y in range(2 * c + 1):
                check(arr[x][y] == cnt.get((x, y), 0), f"[1] WE = LDP ({a},{c}) at ({x},{y})")
                ncell += 1
    say(f"WE = LDP on {ncell} cells ({nw} words); scan = literal for a + c <= {LIT_T}; "
        f"Lemma 1 word by word for a + c <= {L1W_T}")
    ncell = 0
    for a, c in contents(OW_T):
        n = a + c
        tally: dict = defaultdict(int)
        for ups in combinations(range(n), c):
            s = set(ups)
            om = [0]
            for t in range(n):
                om.append(om[-1] + (1 if t in s else -1))
            for t1 in range(n + 1):
                for t2 in range(t1, n + 1):
                    tally[(t1 + t2, om[t1] + om[t2])] += 1
        arr = ldp(a, c)
        for x in range(2 * a + 1):
            for y in range(2 * c + 1):
                yp = 2 * c - y
                check(arr[x][y] == tally.get((x + yp, yp - x), 0), f"[1] (1.1) ({a},{c}) ({x},{y})")
                ncell += 1
    say(f"walk form (1.1) by enumeration = LDP on {ncell} cells (a + c <= {OW_T})")


# ======================================================================== [2]
def sec2() -> None:
    section(f"[2] planar walks: rotation m <= {ROT_M}; Lemma 0; PW = PDP m <= {PW_M}; "
            f"(3.1), Cor 6, Lemma 8 for m <= {OM_M}; Lemmas 5, 7 for h <= {GH}")
    for m in range(ROT_M + 1):
        imgs = set()
        ok = True
        for lam in product((1, -1), repeat=m):
            for rho in product((1, -1), repeat=m):
                st = tuple(((l + r) // 2, (l - r) // 2) for l, r in zip(lam, rho))
                ok &= all(s in STEPS for s in st)
                imgs.add(st)
        check(ok and len(imgs) == 4 ** m, f"[2] rotation bijection m={m}")
    for L in range(L0_PW + 1):
        cnt: dict = defaultdict(int)
        for st in product(STEPS, repeat=L):
            cnt[sum(dy for _, dy in st)] += 1
        for j in range(-L - 1, L + 2):
            check(cnt.get(j, 0) == W(2 * L, 2 * j), f"[2] Lemma 0 PW L={L} j={j}")
    for L in range(L0_PDP + 1):
        V = Vt(L)
        for j in range(-L - 1, L + 2):
            check(V.get(j, 0) == W(2 * L, 2 * j), f"[2] Lemma 0 PDP L={L} j={j}")
    for m in range(PW_M + 1):
        O1, O2 = pw_occupation(m), O_pdp(m)
        check(O1 == O2, f"[2] PW = PDP, m={m}")
    n4 = 0
    for m in range(OM_M + 1):
        for k in range(-m - 1, m + 2):
            o0 = Om(m, 0, k)
            check(o0 == Om(m, 0, -k), f"[2] C6 symmetry m={m} k={k}")
            if abs(k) <= m:
                check(o0 == O0_lemma8(m, k), f"[2] Lemma 8 m={m} k={k}")
            for j in range(-m - 1, m + 2):
                o = Om(m, j, k)
                num, den = O_formula(m, j, k)
                check(num == o * den, f"[2] (3.1) m={m} j={j} k={k}")
                check(o <= o0, f"[2] C6 <= m={m} j={j} k={k}")
                check((o < o0) == (j != 0 and abs(k) <= m), f"[2] C6 strict iff m={m} j={j} k={k}")
                n4 += 1
    say(f"rotation bijective (m <= {ROT_M}); Lemma 0 (PW L <= {L0_PW}, PDP L <= {L0_PDP}); "
        f"PW = PDP (m <= {PW_M}); (3.1), Cor 6 and Lemma 8 on {n4} triples (m <= {OM_M})")
    for h in range(G1W_H + 1):
        occ: dict = defaultdict(int)
        for st in product((1, -1), repeat=h):
            s = 0
            occ[0] += 1
            for d in st:
                s += d
                occ[s] += 1
        for j in range(-h - 2, h + 3):
            check(occ.get(j, 0) == G(h, j), f"[2] G = occupation h={h} j={j}")
    for h in range(61):
        check(all(Gv(h, j) == G(h, j) for j in range(-h - 2, h + 3)), f"[2] G table = G h={h}")
    for h in range(GH + 1):
        g0 = Gv(h, 0)
        check(g0 == (h + 1) * C(h, h // 2), f"[2] Lemma 7 h={h}")
        for j in range(1, h + 3):
            gj = Gv(h, j)
            check(gj == Gv(h, -j) and gj < g0, f"[2] Lemma 5 h={h} j={j}")
    say(f"G_h = occupation count (h <= {G1W_H}); table = sum (h <= 60); Lemma 5 and Lemma 7 "
        f"for h <= {GH}")


# ======================================================================== [3]
def sec3() -> None:
    section(f"[3] the fold: Steps 2, 5 (n <= {FOLD_OM_N}, m <= {FOLD_PW_M}); (2.1) = LDP, "
            f"a+c <= {FOLD_T}; (2.2), a+c <= {CENTRE_T}")
    n2 = 0
    for n in range(0, FOLD_OM_N + 1):
        for st in product((1, -1), repeat=n):
            om = [0]
            for d in st:
                om.append(om[-1] + d)
            for sig in range(0, n + 1):
                m, r = divmod(sig, 2)
                eps = om[m + r] - om[m]
                omm = [om[m - u] - om[m] for u in range(m + 1)]
                omp = [om[m + r + u] - om[m + r] for u in range(n - m - r + 1)]
                rec = [None] * (n + 1)
                rec[m] = -omm[m]
                for u in range(m + 1):
                    rec[m - u] = omm[u] - omm[m]
                for u in range(n - m - r + 1):
                    rec[m + r + u] = omp[u] - omm[m] + eps
                ok = rec == om and eps in ((0,) if r == 0 else (1, -1))
                ok &= (om[n] == omp[n - m - r] + eps - omm[m])
                for s in range(m + 1):
                    ok &= (om[m - s] + om[m + r + s] == omm[s] + omp[s] + eps - 2 * omm[m])
                check(ok, f"[3] Step 2 n={n} sigma={sig} omega={st}")
                n2 += 1
    n5 = 0
    for m in range(FOLD_PW_M + 1):
        for st in product(STEPS, repeat=m):
            X, Y = [0], [0]
            for dx, dy in st:
                X.append(X[-1] + dx)
                Y.append(Y[-1] + dy)
            Xh = [X[m - u] - X[m] for u in range(m + 1)]
            Yh = [Y[m] - Y[m - u] for u in range(m + 1)]
            steps_h = [(Xh[u + 1] - Xh[u], Yh[u + 1] - Yh[u]) for u in range(m)]
            back_x = [Xh[m - u] - Xh[m] for u in range(m + 1)]
            back_y = [Yh[m] - Yh[m - u] for u in range(m + 1)]
            ok = all(s in STEPS for s in steps_h) and back_x == X and back_y == Y
            ok &= all(Xh[m - s] == X[s] - X[m] for s in range(m + 1)) and Yh[m] == Y[m]
            check(ok, f"[3] Step 5 m={m} {st}")
            n5 += 1
    say(f"Step 2 bijection and equivalences on {n2} (omega, sigma) pairs; Step 5 involution on "
        f"{n5} planar walks")
    nf = 0
    for a, c in contents(FOLD_T):
        arr = ldp(a, c)
        n = a + c
        for x in range(2 * a + 1):
            for y in range(2 * c + 1):
                if x + 2 * c - y <= n:
                    check(fold(a, c, x, y) == arr[x][y], f"[3] (2.1) ({a},{c}) ({x},{y})")
                    nf += 1
    nc = 0
    for a, c in contents(CENTRE_T):
        check(centre_22(a, c) == ldp(a, c)[a][c], f"[3] (2.2) ({a},{c})")
        nc += 1
    say(f"(2.1) = LDP on {nf} cells with sigma <= n (a + c <= {FOLD_T}); (2.2) on {nc} contents")


# ======================================================================== [4]
def s1_walk(M: int, u: int, j0: int, updir: int):
    """The explicit (S1) walk of the note (Step C); updir is used only when j0 = 0."""
    steps = []
    if u <= M - 1:
        aj = abs(j0)
        v = u if aj >= u else (aj if (u - aj) % 2 == 0 else aj + 1)
        d = (1 if j0 > 0 else -1) if j0 != 0 else updir
        if (u - v) % 2 or v > u or v < 0:
            return None
        steps += [(0, d)] * v + [(1, 0), (-1, 0)] * ((u - v) // 2)
        rem = j0 - d * v
        if M - u - abs(rem) < 0:
            return None
        steps += [(0, 1 if rem > 0 else -1)] * abs(rem) + [(1, 0)] * (M - u - abs(rem))
    else:
        if (M - abs(j0)) % 2 or abs(j0) > M:
            return None
        d = 1 if j0 >= 0 else -1
        steps += [(0, d)] * abs(j0) + [(1, 0), (-1, 0)] * ((M - abs(j0)) // 2)
    return steps


def walk_ok(steps, M: int, u: int, j0: int) -> bool:
    if steps is None or len(steps) != M or any(s not in STEPS for s in steps):
        return False
    X = sum(dx for dx, _ in steps[:u])
    Y = sum(dy for _, dy in steps)
    return X == 0 and Y == j0


def s1_note(a: int, c: int, m: int) -> bool:
    n = a + c
    M = n // 2
    return m <= M - 2 or (m == M - 1 and not (n % 2 == 0 and a % 2 == 1))


def case_of(a: int, c: int, sig: int):
    n = a + c
    M = n // 2
    m = sig // 2
    if s1_note(a, c, m):
        return "S1"
    cases = []
    if sig == n and n % 2 == 0:
        cases.append(1)
    if sig == n and n % 2 == 1:
        cases.append(2)
    if sig == n - 1 and n % 2 == 1:
        cases.append(3)
    if sig == n - 1 and n % 2 == 0 and a % 2 == 1:
        cases.append(4)
    if sig == n - 2 and n % 2 == 0 and a % 2 == 1:
        cases.append(5)
    return cases[0] if len(cases) == 1 else ("none" if not cases else "several")


def named_terms(a: int, c: int, case: int, sig: int, tau: int):
    """The (S2) terms (eps, k) named in the note for each case, and which must have |k| <= m."""
    kap = c - a
    if case == 1:
        return [(0, -kap // 2)]
    if case == 2:
        return [(1, (1 - kap) // 2)]
    if case == 3:
        return [(0, (-kap - 1) // 2), (0, (-kap + 1) // 2)]
    if case == 4:
        return [(1, -kap // 2), (1, 1 - kap // 2)]
    if case == 5:
        return [(0, -kap // 2), (0, -kap // 2 + 1)]
    raise ValueError(case)


def sec4() -> None:
    section(f"[4] Steps A-C: all a, c >= 1 with 3 <= a+c <= {STEP_T}; antidiagonal a = c <= {ANTI_A}")
    ncont = ncells = nS1w = 0
    hist: dict = defaultdict(int)
    for a, c in contents(STEP_T, 3):
        n, kap = a + c, c - a
        M = n // 2
        T = target_set(a, c)
        arr = ldp(a, c)
        cen = arr[a][c]
        Xi = Xi_pdp(a, c)
        ncont += 1
        check(all(abs(j0) <= M for j0 in T), f"[4] |j0| <= M ({a},{c})")
        check(Xi[M] == cen, f"[4] Step A: P(a,c) = Xi(M) ({a},{c})")
        for m in range(M + 1):
            check(B_formula(a, c, m) == Xi[m], f"[4] Step B: B_m = Xi(m) ({a},{c}) m={m}")
            if m < M:
                check(Xi[m] <= Xi[m + 1], f"[4] Xi nondecreasing ({a},{c}) m={m}")
            check((Xi[m] < Xi[M]) == s1_note(a, c, m), f"[4] (S1) set ({a},{c}) m={m}")
        if n % 2 == 0 and a % 2 == 1:
            check(Xi[M - 1] == Xi[M], f"[4] Xi(M-1) = Xi(M) when n even, a odd ({a},{c})")
        # the explicit (S1) walks
        for m in range(M + 1):
            if not s1_note(a, c, m):
                continue
            if m <= M - 2:
                u = m + 1
                for j0 in T:
                    dirs = (1, -1) if j0 == 0 else (1,)
                    for d in dirs:
                        check(walk_ok(s1_walk(M, u, j0, d), M, u, j0),
                              f"[4] (S1) walk u={u} j0={j0} dir={d} ({a},{c})")
                        nS1w += 1
            else:
                good = [j0 for j0 in T if (j0 - M) % 2 == 0]
                check(len(good) >= 1, f"[4] (S1) parity j0 = M mod 2 exists ({a},{c})")
                for j0 in good:
                    check(walk_ok(s1_walk(M, M, j0, 1), M, M, j0), f"[4] (S1) walk u=M ({a},{c})")
                    nS1w += 1
        # Step B bound and Step C, cell by cell
        for x in range(2 * a + 1):
            for y in range(2 * c + 1):
                yp = 2 * c - y
                sig, tau = x + yp, yp - x
                P = arr[x][y]
                if (x, y) != (a, c) and (a, c) != (1, 1):
                    check(P < cen, f"[4] strict ({a},{c}) ({x},{y})")
                if sig > n:
                    continue
                m, r = divmod(sig, 2)
                Bm = Xi[m]
                check(P <= Bm, f"[4] P <= B_m ({a},{c}) ({x},{y})")
                if a > c or (x, y) == (a, c) or (a, c) == (1, 1):
                    continue
                ncells += 1
                cs = case_of(a, c, sig)
                hist[cs] += 1
                if cs == "S1":
                    continue
                if not check(cs in (1, 2, 3, 4, 5), f"[4] case list incomplete ({a},{c}) ({x},{y}): {cs}"):
                    continue
                if cs in (1, 2):
                    check(tau != kap, f"[4] sigma = n forces tau != kappa ({a},{c}) ({x},{y})")
                terms = named_terms(a, c, cs, sig, tau)
                levels = []
                for eps, k in terms:
                    wgt = W(n - 2 * m - r, kap - eps + 2 * k)
                    check(wgt > 0 and abs(k) <= m and (tau - eps) % 2 == 0,
                          f"[4] case {cs} term ({a},{c}) ({x},{y}) eps={eps} k={k}")
                    levels.append(k + (tau - eps) // 2)
                check(any(lv != 0 for lv in levels), f"[4] case {cs} nonzero level ({a},{c}) ({x},{y})")
                if len(levels) == 2:
                    check(abs(levels[0] - levels[1]) == 1, f"[4] case {cs} levels differ by 1 ({a},{c})")
                if cs in (1, 2):
                    check(levels[0] == (tau - kap) // 2, f"[4] case {cs} level ({a},{c}) ({x},{y})")
                check(P < Bm, f"[4] (S2) strict P < B_m ({a},{c}) ({x},{y})")
    say(f"Steps A, B and the (S1) set on {ncont} contents (both orders); {nS1w} explicit (S1) walks "
        f"verified; Step C on {ncells} off-centre cells with sigma <= n, a <= c: "
        f"{dict(sorted(hist.items(), key=str))}")
    # the antidiagonal (s6) and the reduction of s9 item 2
    na = 0
    for a in range(1, ANTI_A + 1):
        arr = ldp(a, a)
        for x in range(a + 1):
            D = arr[x][2 * a - x]
            form = sum(Om(x, k, k) * W(2 * (a - x), 2 * k) for k in range(-x - 1, x + 2))
            check(form == D, f"[4] antidiagonal form a={a} x={x}")
            if a >= 2 and x <= a - 1:
                cs = case_of(a, a, 2 * x)
                want = "S1" if (x <= a - 2 or a % 2 == 0) else 5
                check(cs == want, f"[4] s9 item 2 reduction a={a} x={x}: {cs}")
            na += 1
    say(f"antidiagonal form D(x) = sum_k O_x(k,k) W_2(a-x)(2k) and the s9 item 2 case reduction "
        f"on {na} cells (a = c <= {ANTI_A})")


# ======================================================================== [5]
def h1_one(a: int, c: int, arr) -> None:
    N = nwords(a, c)
    cen = arr[a][c]
    mx = max(max(r) for r in arr)
    best = [(x, y) for x in range(2 * a + 1) for y in range(2 * c + 1) if arr[x][y] == mx]
    check(sum(map(sum, arr)) == N, f"[5] total N ({a},{c})")
    check(cen == closed_unified(a, c), f"[5] centre value ({a},{c})")
    if (a, c) == (1, 1):
        check(best == [(0, 2), (1, 1), (2, 0)] and mx == 2, f"[5] (1,1) ties {best}")
    else:
        check(best == [(a, c)], f"[5] H1 ({a},{c}): {best[:4]}")
    check(all(arr[x][y] == arr[2 * a - x][2 * c - y]
              for x in range(2 * a + 1) for y in range(2 * c + 1)), f"[5] reversal ({a},{c})")


def sec5() -> None:
    section(f"[5] H1 by LDP: a+c <= {H1_T}; thin a <= {THIN_A}, c <= {THIN_C}; a = c <= {DIAG_A}")
    pairs = {(a, c) for a, c in contents(H1_T) if a <= c}
    pairs |= {(min(a, c), max(a, c)) for a in range(1, THIN_A + 1) for c in range(1, THIN_C + 1)}
    pairs |= {(a, a) for a in range(1, DIAG_A + 1)}
    nc = ncor = 0
    for a, c in sorted(pairs, key=lambda p: (p[0] + p[1], p)):
        arr = ldp(a, c)
        h1_one(a, c, arr)
        nc += 1
        if a != c:
            arr2 = ldp(c, a)
            h1_one(c, a, arr2)
            nc += 1
            check(all(arr[x][y] == arr2[y][x] for x in range(2 * a + 1) for y in range(2 * c + 1)),
                  f"[5] RC ({a},{c})")
        else:
            check(all(arr[x][y] == arr[y][x] for x in range(2 * a + 1) for y in range(2 * a + 1)),
                  f"[5] RC ({a},{a})")
            if a >= 2:
                D = [arr[x][2 * a - x] for x in range(2 * a + 1)]
                check(all(D[x] < D[a] for x in range(2 * a + 1) if x != a)
                      and D[a] == (a + 1) * C(a, a // 2) ** 2, f"[5] Corollary 2 a={a}")
                ncor += 1
    say(f"H1 on {nc} contents (both orders): the centre is the unique maximiser, with value "
        f"(M+1)C(M,floor(a/2))C(n-M,ceil(a/2)), for (a,c) != (1,1); (1,1): (0,2),(1,1),(2,0) tie "
        f"at 2; sum = N, reversal, RC; Corollary 2 for {ncor} values 2 <= a <= {DIAG_A}")


# ======================================================================== [6]
def sec6() -> None:
    section(f"[6] Theorem 1(ii) and Andrews-Paule: forms 0 <= a,c <= {CF_T}; AP (2.2)-(2.4) "
            f"0 <= m,n <= {AP_T}; (1.1) N <= {AP11_N}")
    L: dict = {}
    for a in range(0, max(CF_T, AP_T) + 1):
        for c in range(0, max(CF_T, AP_T) + 1):
            L[(a, c)] = double_sum(a, c)
    for a in range(0, CF_T + 1):
        for c in range(0, CF_T + 1):
            ds = L[(a, c)]
            check(ds == closed_unified(a, c) == closed_cases(a, c) == closed_unified(c, a),
                  f"[6] T1(ii) forms ({a},{c})")
    # Andrews-Paule (2.2): L_AP(m, n) with the roles (m, n) = (c, a)
    for m in range(0, AP_T + 1):
        for n in range(0, AP_T + 1):
            lap = sum(C(i + j, j) ** 2 * C(m + n - 2 * i - 2 * j, n - 2 * j)
                      for i in range(m // 2 + 1) for j in range(n // 2 + 1))
            rhs = ap_rhs(m, n)
            check(rhs.denominator == 1 and lap == rhs, f"[6] AP (2.2) ({m},{n})")
            check(lap == L[(n, m)] and rhs == closed_unified(n, m), f"[6] AP (2.2) = T1(ii) at (c,a) = ({m},{n})")
    for n in range(0, AP_T + 1):
        check(L[(n, 0)] == L[(0, n)] == n // 2 + 1 == ap_rhs(0, n) == ap_rhs(n, 0), f"[6] AP (2.3) n={n}")
    for m in range(1, AP_T + 1):
        for n in range(1, AP_T + 1):
            want = C((m + n) // 2, m // 2) ** 2 if (m % 2 == 0 and n % 2 == 0) else 0
            lhs = L[(n, m)] - L[(n, m - 1)] - L[(n - 1, m)]
            rhs = ap_rhs(m, n) - ap_rhs(m - 1, n) - ap_rhs(m, n - 1)
            check(lhs == want and rhs == want, f"[6] AP (2.4) ({m},{n})")
    for N in range(0, AP11_N + 1):
        s1 = sum(C(i + j, j) ** 2 * C(4 * N - 2 * i - 2 * j, 2 * N - 2 * j)
                 for i in range(N + 1) for j in range(N + 1))
        s2 = sum(C(i + j, i) ** 2 * C(4 * N - 2 * i - 2 * j, 2 * N - 2 * i)
                 for i in range(N + 1) for j in range(N + 1))
        check(s1 == s2 == (2 * N + 1) * C(2 * N, N) ** 2 == closed_unified(2 * N, 2 * N),
              f"[6] AP (1.1) N={N}")
    say(f"double sum = unified = case form, symmetric in a, c (0 <= a, c <= {CF_T}); AP (2.2) exact "
        f"and integral, = T1(ii) under (m,n) = (c,a), (2.3), (2.4) for both sides (m, n <= {AP_T}); "
        f"(1.1) for N <= {AP11_N}")


# ======================================================================== [7]
def sec7() -> None:
    section(f"[7] quoted numbers; sign pattern 2 <= a <= {SIGN_A}; (1,2,c) runner-up 7 <= c <= {RU_C}")
    A4 = ldp(4, 4)
    D4 = [A4[x][8 - x] for x in range(9)]
    check(D4 == [70, 40, 96, 88, 180, 88, 96, 40, 70] and 180 == 5 * 6 ** 2, f"[7] a=4 profile {D4}")
    A3 = ldp(3, 3)
    check([A3[x][6 - x] for x in range(7)] == [20, 12, 30, 36, 30, 12, 20], "[7] a=3 profile")
    A6 = ldp(6, 6)
    D6 = [A6[x][12 - x] for x in range(13)]
    check(D6[4:7] == [1620, 1608, 2800] and 2800 == 7 * 20 ** 2, f"[7] a=6 D(4..6) {D6[4:7]}")
    A60 = ldp(60, 60)
    D60 = [A60[x][120 - x] for x in range(121)]
    r = Fraction(D60[59], D60[60])
    check(D60[60] == 61 * comb(60, 30) ** 2, "[7] a=60 centre")
    check(Fraction(87215, 100000) <= r < Fraction(87225, 100000), f"[7] a=60 ratio {float(r)}")
    off = max(D60[x] for x in range(121) if x != 60)
    check([x for x in range(121) if x != 60 and D60[x] == off] == [59, 61], "[7] a=60 largest off-centre D at 59, 61")
    check([ldp(1, 1)[x][2 - x] for x in range(3)] == [2, 2, 2], "[7] (1,2,1) antidiagonal 2,2,2")
    A222 = ldp(2, 2)
    mx = max(max(row) for row in A222)
    check(mx == 12 and [(x, y) for x in range(5) for y in range(5) if A222[x][y] == mx] == [(2, 2)],
          "[7] (2,2,2) maximum 12 at (2,2)")
    # sign pattern of D(x+1) - D(x)
    alt_full = []
    q40 = None
    for a in range(2, SIGN_A + 1):
        arr = ldp(a, a)
        D = [arr[x][2 * a - x] for x in range(2 * a + 1)]
        s = ["+" if D[x + 1] > D[x] else ("-" if D[x + 1] < D[x] else "0") for x in range(a)]
        q = 0
        while q < a and s[a - 1 - q] == "+":
            q += 1
        pre = s[:a - q]
        ok = q >= 1 and len(pre) % 2 == 1 and all(pre[i] == ("-" if i % 2 == 0 else "+") for i in range(len(pre)))
        check(ok, f"[7] sign pattern a={a}: {''.join(s)}")
        if q == 1:
            alt_full.append(a)
        if a == 40:
            q40 = q
    check(alt_full == [2, 4, 6], f"[7] full alternation exactly for a = 2, 4, 6: {alt_full}")
    check(q40 == 9, f"[7] final run of + has length 9 at a = 40: {q40}")
    # runner-up of (1,2,c) and (2,2,199)
    def runner(a, c):
        arr = ldp(a, c)
        cen = arr[a][c]
        sec = max(v for row in arr for v in row if v < cen)
        cells = [(x, y) for x in range(2 * a + 1) for y in range(2 * c + 1) if arr[x][y] == sec]
        return Fraction(sec, cen), cells
    nr = 0
    for c in sorted(set(range(7, RU_C + 1)) | {200, 300}):
        rr, cells = runner(1, c)
        M = (1 + c) // 2
        check(rr == Fraction(M, M + 1) and cells == [(1, c - 1), (1, c + 1)], f"[7] (1,2,{c}) runner-up {rr} {cells}")
        nr += 1
    r50, _ = runner(1, 50)
    r200, _ = runner(1, 200)
    r300, _ = runner(1, 300)
    check(r50 == Fraction(25, 26) and r200 == Fraction(100, 101) and r300 == Fraction(150, 151),
          "[7] (1,50), (1,200), (1,300) ratios")
    r2, cells2 = runner(2, 199)
    check(r2 == Fraction(201, 202) and cells2 == [(2, 198), (2, 200)], f"[7] (2,2,199) runner-up {r2} {cells2}")
    # k = 2 background (s8): |w|_12 over the words with two 1s and three 2s (= [5 choose 2]_q)
    qb: dict = defaultdict(int)
    for ones in combinations(range(5), 2):
        w = [1 if p in ones else 2 for p in range(5)]
        qb[literal(w, (1, 2))] += 1
    check([qb[i] for i in range(7)] == [1, 1, 2, 2, 2, 1, 1], f"[7] [5 choose 2]_q {dict(qb)}")
    # OEIS query sequences (s8)
    Dc = [closed_unified(a, a) for a in range(0, 11)]
    check(Dc[:7] == [1, 2, 12, 36, 180, 600, 2800], "[7] OEIS query 1")
    check(Dc[1:10:2] == [2, 36, 600, 9800, 158760], "[7] OEIS query 2 (odd a)")
    check(Dc[0:11:2] == [1, 12, 180, 2800, 44100, 698544], "[7] OEIS query 3 (even a)")
    check(all(ldp(a, a)[a][a] == Dc[a] for a in range(1, 11)), "[7] OEIS values = LDP centres")
    # s7 counts
    w58 = sum(nwords(a, c) for a in range(1, 6) for c in range(1, 6) if a + c <= 8)
    w8 = sum(nwords(a, c) for a, c in contents(8))
    c10 = sum((2 * a + 1) * (2 * c + 1) for a, c in contents(10))
    c22 = sum((2 * a + 1) * (2 * c + 1) for a, c in contents(22))
    n50 = sum(1 for _ in contents(50))
    check((w58, w8, c10, c22, n50) == (14870, 18614, 2685, 49819, 1225), f"[7] s7 counts {(w58, w8, c10, c22, n50)}")
    say(f"a=3 profile 20,12,30,36,...; a=4 profile {D4}; a=6 D(4..6) = {D6[4:7]}; a=60: D(59)/D(60) = {float(r):.6f}, "
        f"largest off-centre D at x = 59, 61; (1,2,1) 2,2,2; (2,2,2) 12 at (2,2)")
    say(f"sign pattern (-+)^p - (+)^q for 2 <= a <= {SIGN_A}; q = 1 exactly for a = 2, 4, 6; q = 9 at a = 40")
    say(f"(1,2,c) runner-up at (1,c-1),(1,c+1) with ratio M/(M+1) for {nr} values of c "
        f"(7 <= c <= {RU_C}, and 200, 300); (2,2,199): 201/202 at (2,198),(2,200); OEIS sequences; "
        f"s7 counts 14,870 / 18,614 / 2,685 / 49,819 / 1,225")


def main() -> int:
    print("== check_h1_centre: H1 for (a,2,c) and the centre value (notes/proof-h1-centre.md)"
          + ("  [--full]" if FULL else ""), flush=True)
    sec1()
    sec2()
    sec3()
    sec4()
    sec5()
    sec6()
    sec7()
    dt = time.perf_counter() - T0
    status = "PASS" if not FAIL else "FAIL"
    print(f"check_h1_centre: {NCHECK[0]} checks, {len(FAIL)} failures, {dt:.1f} s  [{status}]", flush=True)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
