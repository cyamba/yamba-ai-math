"""Theorem A (rigidity) and Lemma 3.2 of notes/article2-design.md, section 3, and every
computational claim of the proof note notes/proof-rigidity-local.md (Phase 1b).

Evidence, not proof. A pass means the claims hold on the exact ranges printed at run time
(VERIFIED there), nothing more. The one exception is the certificate in section A-iv(GF), which
makes the generating functions of notes/proof-rigidity-local.md section 8 exact (see there).

    python3 checks/check_rigidity.py          # default ranges, under a minute
    python3 checks/check_rigidity.py --full   # larger ranges, several minutes

Any other argument (run_all.py passes --max-n N) is ignored. Standard library only, exact integer
arithmetic, deterministic (no randomness), at most two worker processes. The exit status is
non-zero on any failure. The last line reads "check_rigidity: N checks, F failures, T s".

History: written for the Phase 0c gate (20 Oct 2026); extended (never weakened) by the finaliser
of the rigidity proof round on 21 Oct 2026 with the sections marked [+] below.

Notation
--------
Words over the ordered alphabet 1 < 2 < ... < k; subwords are scattered, never contiguous. A
content n = (n_1, ..., n_k) is positive when every n_i >= 1. |w|_{i..j} counts the occurrences
of the consecutive word i(i+1)...j. Two words of one content are in the same Parikh class when
they agree on every |w|_{i..j}, 1 <= i < j <= k (the entries of the Parikh matrix).
psi_2(w) = (x_1, ..., x_{k-1}) with x_i = |w|_{i(i+1)}; a psi_2-fibre is the set of words of
content n with a given psi_2.

Rigidity rule. For a consecutive triple i (1 <= i <= k-2) put (a,b,c) = (n_i, n_{i+1}, n_{i+2})
and (u,v) = (x_i, x_{i+1}); gamma(m,n) = {0..mn} if min(m,n) <= 1, else {0, 1, mn-1, mn}. The
triple is RIGID if
    (E)  u in {0, ab} or v in {0, bc};     (N)  u + v <= b;
    (Ch) (ab-u) + (bc-v) <= b;             (G)  u in gamma(a,b) and v in gamma(b,c).
In the code the tag "G" is the design note's (Gamma).

What is tested (ranges: see RANGES below and the printed notes)
--------------------------------------------------------------
A-i(1)  k = 3, profile level. For the l-th 2 of a word, A_l = #1's before it and C_l = #3's
        after it; A runs over all nondecreasing vectors in [0,a]^b and C over all nonincreasing
        vectors in [0,c]^b, x = sum A, y = sum C, z = sum A_l C_l (every pair is realised by a
        word, notes/proof-r2-extrema.md Lemma 1.1, re-tested at word level in A-i(3)). For every
        cell (x,y) the set Z of values A.C is computed from all pairs. Tested: |Z| = 1 iff rigid;
        under each rule that holds, Z is the stated value:
            (N)  Z = {0};   (Ch)  Z = {cx + ay - abc};
            (E)  Z = {0} if x = 0 or y = 0, Z = {ay} if x = ab, Z = {cx} if y = bc
                 (every sub-case that applies is tested; they never disagree);
            (G)  the profile sets for x and for y are singletons, they equal the explicit
                 profiles of unique_A / unique_C below, and Z = {A.C} for those profiles.
        Also: an A-profile set (C-profile set) is a singleton iff x in gamma(a,b) (y in
        gamma(b,c)), and min Z, max Z equal the PROVED z_min, z_max of proof-r2-extrema.md.
A-i(2)  k = 3, formula level, all 1 <= a,b,c <= FORMULA_MAX and every cell: rigid iff
        z_min = z_max, with z_max = bqt + qs + tr + max(0, r+s-b) (x = bq+r, y = bt+s) and
        z_min = ac(Q+T-b) + aS + cR if Q+T >= b, RS if Q+T = b-1, 0 if Q+T <= b-2
        (x = aQ+R, y = cT+S); both formulas are PROVED in notes/proof-r2-extrema.md. In rigid
        cells the forced value z_max is also compared with the rule's value (as in A-i(1)).
A-i(3)  k = 3, word level, every positive content with a+b+c <= K3_WORD_TOTAL: all words, z
        constant on the (x,y)-fibre iff rigid, the values of A-i(1), every (x,y) in the box is
        attained, x = sum A, y = sum C, z = A.C per word, and the realised profile pairs are
        exactly all monotone pairs (Lemma 1.1 (a), (b) of proof-r2-extrema.md).
A-ii    k = 4, 5, 6 (and 3), every positive content up to the printed totals, all words: a
        psi_2-fibre is one Parikh class iff every consecutive triple is rigid. Every psi_2 vector
        of the box prod [0, n_i n_{i+1}] is attained (full-box support, known: Mateescu-Salomaa
        2004 (IJFCS), Lemma 1, per notes/partition-route-audit.md) - tested too.
    [+] On every fibre of the same contents (plus EXTRA_MERGED): |w|_{i..i+2} is constant on the
        fibre iff triple i is rigid; the fibre is one class iff the whole fourth diagonal is
        constant on it (Corollary 4.1 of the note); if every triple inside [j,l] is rigid then
        |w|_{j..l} is constant on the fibre (Remark 4.2, entrywise sufficiency); and the number
        of single-class fibres equals the transfer-matrix walk count 1^T T_1 ... T_{k-2} 1
        (Theorem A(iv)(1)).
A-iii   for the same contents: psi_2 determines the Parikh matrix on the whole content iff
        min(n_i, n_{i+1}) = 1 for every i.
    [+] The witnesses of the proof of Corollary A(iii): for a, b >= 2 the triple (a,b,c) at
        (u,v) = (2, b-1), and for b, c >= 2 at (b-1, 2), is not rigid (all a,b,c <= 15).
A-iv    content (2^k): the number of vectors in {0..4}^{k-1} all of whose triples are rigid, by
        brute force over vectors and by the 5x5 transfer matrix T[u][v] = [(u,v) rigid for
        (a,b,c) = (2,2,2)] (count = sum of the entries of T^(k-2)); the values 20, 86, 364, 1548
        for k = 3..6; transfer values for k = 7..12 are printed. At word level for (2^k), k up to
        POW2_WORD_K: the single-class fibres are exactly the rigid vectors.
    [+] Section 6 of the note, exactly: a_7 = 6576 and a_8 = 27944; the five non-rigid pairs of
        (2,2,2) and the row sums (5,4,2,4,5) of T; T commutes with u -> 4-u; the reduction
        a_k = (2,2,1) M^(k-2) (1,1,1)^T with M = [[2,2,1],[2,2,0],[2,0,0]] for 2 <= k <= 41;
        det(theta I - M) = theta^3 - 4 theta^2 - 2 theta + 4; det M = -4 and M (1/2,0,0)^T =
        (1,1,1)^T (so the formula gives a_1 = 1); the recurrence a_k = 4a_{k-1} + 2a_{k-2} -
        4a_{k-3} for 4 <= k <= 41 (a_1 = 1, a_2 = 5); both generating-function identities to
        order t^41; no rational root of 4t^3 - 2t^2 - 4t + 1; sign changes of the cubic in
        (-2,-1), (0,1) and (4.249, 4.25); M^2 > 0 entrywise; and 4.249 < a_k/a_{k-1} < 4.25 for
        12 <= k <= 40.
A-iv(GF) [+] Section 8 of the note: for the contents (2^k), (3^k), (4^k), (5^k) and the periodic
        patterns (1,2), (2,3), (1,2,2), with S(t) = sum_{k>=2} count_k t^(k-2), the claimed
        S = N/Q holds coefficientwise for k = 2..41. CERTIFICATE (exact, not evidence): the
        counts satisfy the recurrence with characteristic polynomial chi_Pi(x^p) (Pi = T_1...T_p,
        size D = n_1 n_2 + 1, p the period), so if H = S_true - N/Q vanishes to order
        B = pD + max(deg Q, deg N + 1) then H = 0 (H * x^{pD} chi_Pi(1/x^p) * Q is a polynomial
        of degree < B with unit constant term factor); the script checks B <= 40 terms. Also
        the brute force over vectors for small k, and the printed counts.
L3.2    Lemma 3.2, on every word of every positive content up to the printed totals, for every
        j < m < l:
            D := |w|_{j..l} - Y |w|_{j..m} - G |w|_{m..l} + n_m G Y = sum_t (G - beta_t)(Y - V_t),
        with G = |w|_{j..m-1}, Y = |w|_{m+1..l}, beta_t = #occurrences of j..m whose letter m is
        the t-th m (= #occurrences of j..m-1 before the t-th m), V_t = #occurrences of m..l
        whose letter m is the t-th m (= #occurrences of m+1..l after it). Tested: the identity;
        0 <= beta_t <= G and 0 <= V_t <= Y for every t (so every term, and D, is >= 0); D = 0
        whenever w avoids the scattered subword (m+1) m (m-1); and, for (j,l) = (m-1, m+1),
        D = |w|_{(m+1) m (m-1)} exactly (for m = 2 this is |w|_321; in general it is the count
        of the scattered subword (m+1) m (m-1), NOT |w|_321 of the letters 1,2,3). On the
        smaller printed range: D equals the determinant of the 3x3 minor of the Parikh matrix
        (rows j, m, m+1; columns m, m+1, l+1; matrix built as the literal product of the
        generator matrices, entry (r, s+1) = |w|_{r..s}).
        Convention for the degenerate cases j = m or l = m (outside the lemma's j < m < l): the
        empty word occurs once, so |w|_{m..m-1} = |w|_{m+1..m} = 1 and beta_t = V_t = 1. Then
        both sides are 0 (the minor has two equal rows if j = m, two equal columns if l = m);
        this is tested on the smaller range.
        With j < m < l, G and Y are counts of nonempty words and no convention is needed.
        Worked examples (from occ() alone): D(332121; 1,2,3) = |w|_321 = 6;
        D(432312; 2,3,4) = |w|_432 = 3 while |w|_321 = 1; 4321 contains 321 but
        D(4321; 1,2,4) = 0, so the converse of the vanishing claim is false once j < m-1 or
        l > m+1 (at (j,l) = (m-1,m+1) it holds, D being the pattern count).
        Result: the identity holds as stated; no correction was needed.
    [+] (d), the exact criterion: D > 0 iff some occurrence of (m+1) m (m-1) has its m+1
        starting an occurrence of (m+1)..l and its m-1 ending an occurrence of j..(m-1); on
        CRIT_TOTAL by chain lengths from both dynamic programmes, and on the smaller range by
        brute force over position triples with occ(). (f): the decreasing word
        k^{n_k} ... 1^{n_1} has D = 0 and contains (m+1) m (m-1) for every wide (j,m,l)
        (j < m-1 or l > m+1), for every positive content with k <= DESC_K and n_i <= DESC_N;
        4321 at (1,3,4) (a j < m-1 case: G = |w|_12 = 0, contains 432). Corollary 2.1: on every
        L3.2 word and every middle letter m, (N') u + v <= b implies |w|_{j..l} = 0 for all
        j <= m-1, l >= m+1, and (Ch') (ab-u) + (bc-v) <= b implies |w|_{(m+1)m(m-1)} = 0 and
        the formula (2.1) |w|_{j..l} = Y |w|_{j..m} + G |w|_{m..l} - b G Y for all such j, l.
L1.1 [+] Section 1 and the two encodings of section 3. On every word of the smaller range: the
        edge projections lambda^(e)_t = #e's before the t-th (e+1) are nondecreasing in
        [0, n_e], of length n_{e+1}, with sum x_e; eq. (1.1) |w|_{j..l} = 1^T B_j...B_{l-1} 1 with
        (B_e)_{r,s} = [r-th e precedes s-th e+1] = [r <= lambda^(e)_s]; the projection tuples of
        all words of the content are the whole product of the monotone-sequence sets (Lemma 1.1);
        and the insertion construction of the proof of Lemma 1.1 realises every tuple of that
        product. On every ternary word of A-i(3): C_t = #{s : lambda^(2)_s >= t} and
        lambda^(2)_s = #{t : C_t >= c-s+1}; at profile level (b, c <= CONJ_BC) the two maps are
        mutually inverse bijections between the nondecreasing lambda in [0,b]^c and the
        nonincreasing C in [0,c]^b with the same sum.
P3.4 [+] Section 3. Lemma 3.3 (a)-(d) and Lemma 3.3' by enumerating all monotone profiles
        (1 <= a, b <= LEMMA33_AB; the C side with c = a): A^bal and A^conc (resp. C^bal, C^conc)
        attain the max and min of every prefix (suffix) sum, P_h free iff b-h < x < ab-h, a step
        A_h < A_{h+1} exists iff b-h <= x <= ab-h (and the explicit step profile of the proof
        has one), the same for C, uniqueness iff gamma, and the free index max(1, b-x+1) of the
        proof of 3.3'. Summation by parts (3.1), both forms, on every profile pair for
        a, c <= SBP_AC, b <= SBP_B. On the A-i(1) range, against the brute-force value sets Z:
        Proposition 3.4 (literal: z constant iff no h in [1,b-1] satisfies (i) or (ii)), with
        the explicit witnesses of its proof (A^bal.C - A^conc.C > 0 for a C stepping at an
        (i)-index; A.C^bal - A.C^conc > 0 for an A stepping at an (ii)-index); Corollary 3.5
        (a,b,c >= 2: the forced cells are exactly the box boundary, x+y <= b, (ab-x)+(bc-y) <= b
        and the points (1,bc-1), (ab-1,1), with Z = {c-1}, {a-1} there); and the [Y26a] Thm 6
        layer of Remark 3 (a,c >= 2, i = bc-y >= 2, j = ab-x >= 2, i+j = b+1: Z = {z0, z0+1},
        z0 = abc - cj - ai). On the A-i(2) range: the criterion of Prop 3.4 holds iff the cell is
        not rigid (bitmask form; the literal per-h form on a, c <= 4).
WIT  [+] The necessity half of Theorem A(ii), constructively. For every vector x of every
        content in the WIT ranges and every non-rigid triple i: take the first h of Prop 3.4,
        the explicit profiles of its proof (A^bal vs A^conc against a C stepping at h, or an A
        stepping at h against C^bal vs C^conc), convert C to lambda^(i+1) by conjugation, put
        the balanced sequence on every other edge, and build both words by the insertion
        construction of Lemma 1.1. Tested: both words have the content and psi_2 = x, and
        different |w|_{i..i+2}. Plus the example of the note: content (2,2,2,2), x = (1,2,1),
        43212143 and 21434321 have |w|_123 = 1, 0 and also |w|_234 = 0, 1.
EXA  [+] Examples quoted in the note, at word level: (2,3,2) at (2,1) has z = 0 on the whole
        fibre (2 not in gamma(2,3), rule (N)) and at (4,5) has z = 6 = lambda ((Ch)); (3,2,3) at
        (2,2) has z in {0, 2}; the two (3,5,3) fibres worked in TR536 section 4: at (7,7) the
        z-values are 1..9 except 3, at (7,6) they are 0..8 (both cells non-rigid); Remark 4.2: (2,2,1,1), x = (2,1,0) has 12 words, two classes,
        |w|_123 in {0,1} (412321 gives 1, 421132 gives 0) and |w|_{1..4} = |w|_{2..4} = 0;
        partition-route-audit.md section 2: 12321 and 21132 have content (2,2,1), psi_2 = (2,1)
        and |w|_123 = 1, 0.

Independence
------------
* Profiles (A-i(1), P3.4) are enumerated from scratch; the rule and the formulas are separate
  code. The explicit profiles of the proofs (A^bal, A^conc, step profiles) are separate small
  functions, tested against the enumerated sets.
* Words are enumerated exhaustively. Interval counts come from a left-to-right dynamic
  programme; they are compared with a right-to-left one on every word, and with
  checks/parikh.py's occ() (generic subword count) on the smaller range. Criterion (d) is tested
  by two methods (chains from both programmes; brute force with occ()).
* A-ii/A-iii use an exhaustive state-merged search: the set of Parikh matrices of all words of a
  content, built letter by letter while merging equal (prefix matrix) states. This is exact
  because the matrix of w.m depends only on the matrix of w and on m. On the printed "plain"
  range, the set it returns is compared with the set obtained word by word.
* A-iv: brute force over vectors and the transfer matrix are two separate counts; the hand
  derivation of section 6 (matrix M, recurrence, series) is checked against both.
"""

from __future__ import annotations

import sys
import time
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, combinations_with_replacement, product
from math import comb, prod
from operator import mul
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from parikh import interval, occ  # noqa: E402  (word-level subword counts, cross-check only)

FULL = "--full" in sys.argv[1:]
WORKERS = 2

# ---------------------------------------------------------------------------
# Ranges
# ---------------------------------------------------------------------------

if FULL:
    RANGES = dict(
        PROFILE_AC=7, PROFILE_B=8,                 # A-i(1), P3.4: a, c <= 7, b <= 8
        FORMULA_MAX=20,                            # A-i(2): a, b, c <= 20
        K3_WORD_TOTAL=12,                          # A-i(3): a+b+c <= 12
        LEMMA_TOTAL={3: 12, 4: 11, 5: 9},          # L3.2: words, by alphabet size
        MERGED_TOTAL={3: 13, 4: 13, 5: 13, 6: 13},  # A-ii / A-iii (state-merged search)
        PLAIN_TOTAL={3: 12, 4: 11, 5: 9, 6: 9},    # word-by-word cross-check of the search
        SMALL_TOTAL=8,                             # occ() cross-check, minor, degenerate cases,
                                                   # L1.1 on words, brute-force (d)
        VEC_BRUTE_K=10,                            # A-iv brute force over vectors
        POW2_WORD_K=6,                             # A-iv word level, (2^k)
        LEMMA33_AB=10,                             # P3.4: Lemma 3.3 profiles, a, b <= 10
        SBP_AC=5, SBP_B=6,                         # P3.4: (3.1) on every profile pair
        CONJ_BC=8,                                 # L1.1: conjugation at profile level
        CRIT_TOTAL={3: 12, 4: 11, 5: 9},           # L3.2(d) by chains: every L3.2 word
        DESC_K=7, DESC_N=3,                        # L3.2(f): decreasing words
        WIT=((4, 4, 12), (5, 3, 11), (6, 2, 12)),  # WIT: (k, max n_i, max total)
        EXTRA_MERGED=((4, 4, 4), (5, 5, 5), (3, 3, 3, 3), (2, 3, 2, 3, 2), (1, 2, 2, 1, 2, 2, 1)),
    )
else:
    RANGES = dict(
        PROFILE_AC=5, PROFILE_B=6,
        FORMULA_MAX=15,
        K3_WORD_TOTAL=10,
        LEMMA_TOTAL={3: 10, 4: 9, 5: 9},
        MERGED_TOTAL={3: 10, 4: 10, 5: 10, 6: 10},
        PLAIN_TOTAL={3: 10, 4: 9, 5: 9, 6: 8},
        SMALL_TOTAL=6,
        VEC_BRUTE_K=8,
        POW2_WORD_K=5,
        LEMMA33_AB=8,
        SBP_AC=4, SBP_B=5,
        CONJ_BC=6,
        CRIT_TOTAL={3: 10, 4: 9, 5: 9},
        DESC_K=6, DESC_N=3,
        WIT=((4, 3, 10), (5, 2, 10)),
        EXTRA_MERGED=((4, 4, 4),),
    )
TRANSFER_K = 12
GF_TERMS = 40                       # A-iv(GF): coefficients n = 0..39, i.e. k = 2..41
EXPECTED_POW2 = {3: 20, 4: 86, 5: 364, 6: 1548, 7: 6576, 8: 27944}
MAX_MSGS = 6


# ---------------------------------------------------------------------------
# Recording
# ---------------------------------------------------------------------------


class Rec:
    """Per-section check counts and failure messages; picklable, merged in the parent."""

    def __init__(self) -> None:
        self.sec: dict[str, list] = {}
        self.stats: dict = defaultdict(int)
        self.extra: dict = {}

    def _s(self, sec: str) -> list:
        s = self.sec.get(sec)
        if s is None:
            s = self.sec[sec] = [0, 0, []]
        return s

    def ok(self, sec: str, cond: bool, msg) -> bool:
        s = self._s(sec)
        s[0] += 1
        if not cond:
            s[1] += 1
            if len(s[2]) < MAX_MSGS:
                s[2].append(msg() if callable(msg) else msg)
        return cond

    def add(self, sec: str, n: int) -> None:
        self._s(sec)[0] += n

    def fail(self, sec: str, msg: str) -> None:
        s = self._s(sec)
        s[1] += 1
        if len(s[2]) < MAX_MSGS:
            s[2].append(msg)

    def merge(self, other: "Rec") -> None:
        for sec, (n, f, msgs) in other.sec.items():
            s = self._s(sec)
            s[0] += n
            s[1] += f
            s[2].extend(msgs[: max(0, MAX_MSGS - len(s[2]))])
        for key, val in other.stats.items():
            self.stats[key] += val


# ---------------------------------------------------------------------------
# The rule of Theorem A (tested object; nothing below derives it from brute force)
# ---------------------------------------------------------------------------


@lru_cache(maxsize=None)
def gamma_set(m: int, n: int) -> frozenset:
    return frozenset(range(m * n + 1)) if min(m, n) <= 1 else frozenset((0, 1, m * n - 1, m * n))


def rigid_tags(a: int, b: int, c: int, u: int, v: int) -> tuple:
    """The rules (E), (N), (Ch), (G) that hold for the triple; empty tuple = not rigid.

    This one function is the rule under test everywhere in this file."""
    ab, bc = a * b, b * c
    tags = []
    if u == 0 or u == ab or v == 0 or v == bc:
        tags.append("E")
    if u + v <= b:
        tags.append("N")
    if (ab - u) + (bc - v) <= b:
        tags.append("Ch")
    if u in gamma_set(a, b) and v in gamma_set(b, c):
        tags.append("G")
    return tuple(tags)


def unique_A(a: int, b: int, x: int) -> tuple:
    """The unique nondecreasing A in [0,a]^b with sum x, for x in gamma(a,b)."""
    if b == 1:
        return (x,)
    if a == 1:
        return (0,) * (b - x) + (1,) * x
    return {0: (0,) * b, 1: (0,) * (b - 1) + (1,),
            a * b - 1: (a - 1,) + (a,) * (b - 1), a * b: (a,) * b}[x]


def unique_C(b: int, c: int, y: int) -> tuple:
    """The unique nonincreasing C in [0,c]^b with sum y, for y in gamma(b,c)."""
    if b == 1:
        return (y,)
    if c == 1:
        return (1,) * y + (0,) * (b - y)
    return {0: (0,) * b, 1: (1,) + (0,) * (b - 1),
            b * c - 1: (c,) * (b - 1) + (c - 1,), b * c: (c,) * b}[y]


def predicted(tag: str, a: int, b: int, c: int, x: int, y: int) -> set:
    """The value set that Theorem A(i) predicts for z under one rule."""
    if tag == "N":
        return {0}
    if tag == "Ch":
        return {c * x + a * y - a * b * c}
    if tag == "E":
        vals = set()
        if x == 0 or y == 0:
            vals.add(0)
        if x == a * b:
            vals.add(a * y)
        if y == b * c:
            vals.add(c * x)
        return vals
    return {sum(map(mul, unique_A(a, b, x), unique_C(b, c, y)))}


def e_subcase(a: int, b: int, c: int, x: int, y: int) -> str:
    parts = []
    if x == 0 or y == 0:
        parts.append("0")
    if x == a * b:
        parts.append("ay")
    if y == b * c:
        parts.append("cx")
    return "+".join(parts)


def z_max_formula(a: int, b: int, c: int, x: int, y: int) -> int:
    q, r = divmod(x, b)
    t, s = divmod(y, b)
    return b * q * t + q * s + t * r + max(0, r + s - b)


def z_min_formula(a: int, b: int, c: int, x: int, y: int) -> int:
    Q, R = divmod(x, a)
    T, S = divmod(y, c)
    if Q + T >= b:
        return a * c * (Q + T - b) + a * S + c * R
    if Q + T == b - 1:
        return R * S
    return 0


# ---------------------------------------------------------------------------
# [+] The explicit objects of the proofs in notes/proof-rigidity-local.md, section 3
# ---------------------------------------------------------------------------


def dot(A, C) -> int:
    return sum(map(mul, A, C))


def spread(total: int, length: int) -> tuple:
    """`total` spread as evenly as possible over `length` positions, nondecreasing."""
    if length == 0:
        return ()
    q, r = divmod(total, length)
    return (q,) * (length - r) + (q + 1,) * r


def A_bal(a: int, b: int, x: int) -> tuple:
    """Balanced profile (q^{b-r}, (q+1)^r), x = bq + r."""
    return spread(x, b)


def A_conc(a: int, b: int, x: int) -> tuple:
    """Concentrated profile A_t = min(a, max(0, x - (b-t)a))."""
    return tuple(min(a, max(0, x - (b - t) * a)) for t in range(1, b + 1))


def A_step(a: int, b: int, x: int, h: int) -> tuple:
    """The profile of the proof of Lemma 3.3(b) (meant to have A_h < A_{h+1})."""
    x2 = min(x, (b - h) * a)
    return spread(x - x2, h) + spread(x2, b - h)


def C_bal(b: int, c: int, y: int) -> tuple:
    return A_bal(c, b, y)[::-1]


def C_conc(b: int, c: int, y: int) -> tuple:
    return A_conc(c, b, y)[::-1]


def C_step(b: int, c: int, y: int, h: int) -> tuple:
    """Lemma 3.3(d) by reversal (meant to have C_h > C_{h+1})."""
    return A_step(c, b, y, b - h)[::-1]


def crit34(a: int, b: int, c: int, x: int, y: int) -> tuple:
    """Proposition 3.4, literally: the first h in [1, b-1] satisfying (i), and the first
    satisfying (ii) (None when there is none). z is constant iff both are None."""
    hi = hii = None
    for h in range(1, b):
        if hi is None and b - h < x < a * b - h and h <= y <= b * c - b + h:
            hi = h
        if hii is None and b - h <= x <= a * b - h and h < y < b * c - b + h:
            hii = h
    return hi, hii


def conj_C_to_lam(C: tuple, c: int) -> tuple:
    """lambda_s = #{t : C_t >= c - s + 1}, s = 1..c (2's before the s-th 3)."""
    return tuple(sum(1 for Ct in C if Ct >= c - s + 1) for s in range(1, c + 1))


def conj_lam_to_C(lam: tuple, b: int) -> tuple:
    """C_t = #{s : lambda_s >= t}, t = 1..b (3's after the t-th 2)."""
    return tuple(sum(1 for ls in lam if ls >= t) for t in range(1, b + 1))


def projections(w: tuple, k: int) -> tuple:
    """lambda^(e)_t = number of letters e before the t-th letter e+1, for e = 1..k-1."""
    lam: list = [[] for _ in range(k + 1)]
    seen = [0] * (k + 2)
    for ch in w:
        if ch >= 2:
            lam[ch - 1].append(seen[ch - 1])
        seen[ch] += 1
    return tuple(tuple(lam[e]) for e in range(1, k))


def insert_word(content: tuple, lams) -> tuple:
    """The construction in the proof of Lemma 1.1: start from 1^{n_1}; for e = 1..k-1 insert
    the n_{e+1} letters e+1, the t-th immediately before the (lambda_t + 1)-th letter e (at the
    end if lambda_t = n_e), for t = 1, 2, ... in this order."""
    word = [1] * content[0]
    for e in range(1, len(content)):
        lam = lams[e - 1]
        new, t, seen = [], 0, 0
        for ch in word:
            if ch == e:
                while t < len(lam) and lam[t] == seen:
                    new.append(e + 1)
                    t += 1
                seen += 1
            new.append(ch)
        while t < len(lam):
            new.append(e + 1)
            t += 1
        word = new
    return tuple(word)


def interval_counts(w: tuple, k: int) -> list:
    """cnt[i][j] = |w|_{i..j} for 1 <= i <= j <= k (left-to-right dynamic programme)."""
    cnt = [[0] * (k + 2) for _ in range(k + 2)]
    for ch in w:
        for i in range(1, ch):
            cnt[i][ch] += cnt[i][ch - 1]
        cnt[ch][ch] += 1
    return cnt


@lru_cache(maxsize=None)
def trans_matrix(a: int, b: int, c: int) -> tuple:
    """(T)_{u,v} = [(a,b,c; u,v) rigid], u in [0,ab], v in [0,bc]."""
    return tuple(tuple(int(bool(rigid_tags(a, b, c, u, v))) for v in range(b * c + 1))
                 for u in range(a * b + 1))


def transfer_count(content: tuple) -> int:
    """1^T T_1 ... T_{k-2} 1 (Theorem A(iv)(1)); for k = 2 the box size n_1 n_2 + 1."""
    vec = [1] * (content[0] * content[1] + 1)
    for i in range(len(content) - 2):
        a, b, c = content[i], content[i + 1], content[i + 2]
        T = trans_matrix(a, b, c)
        vec = [sum(vec[u] * T[u][v] for u in range(a * b + 1)) for v in range(b * c + 1)]
    return sum(vec)


def masks_A(a: int, b: int) -> tuple:
    """Bitmasks over h in [1,b-1]: HA[x] = {h : b-h <= x <= ab-h} (A can step at h),
    HAi[x] = {h : b-h < x < ab-h} (P_h free), straight from the statement of Prop 3.4."""
    HA, HAi = [], []
    for x in range(a * b + 1):
        m1 = m2 = 0
        for h in range(1, b):
            if b - h <= x <= a * b - h:
                m1 |= 1 << h
            if b - h < x < a * b - h:
                m2 |= 1 << h
        HA.append(m1)
        HAi.append(m2)
    return HA, HAi


def masks_C(b: int, c: int) -> tuple:
    """HC[y] = {h : h <= y <= bc-b+h} (C can step at h), HCi[y] = {h : h < y < bc-b+h}."""
    HC, HCi = [], []
    for y in range(b * c + 1):
        m1 = m2 = 0
        for h in range(1, b):
            if h <= y <= b * c - b + h:
                m1 |= 1 << h
            if h < y < b * c - b + h:
                m2 |= 1 << h
        HC.append(m1)
        HCi.append(m2)
    return HC, HCi


# ---------------------------------------------------------------------------
# A-i(1): profile level, k = 3  (+ P3.4 against the same value sets)
# ---------------------------------------------------------------------------


def task_profile(a: int, b: int, c: int, sbp_ac: int = 0, sbp_b: int = 0) -> Rec:
    rec = Rec()
    S = "A-i(1) profile level"
    S34 = "P3.4 Prop 3.4, Cor 3.5, layer, (3.1) (profile level)"
    Ax: dict = defaultdict(list)
    for A in combinations_with_replacement(range(a + 1), b):  # nondecreasing
        Ax[sum(A)].append(A)
    Cy: dict = defaultdict(list)
    for C in combinations_with_replacement(range(c + 1), b):
        Cy[sum(C)].append(C[::-1])  # nonincreasing
    Aset = {x: set(v) for x, v in Ax.items()}
    Cset = {y: set(v) for y, v in Cy.items()}
    gA, gC = gamma_set(a, b), gamma_set(b, c)
    for x in range(a * b + 1):
        u = len(Ax[x]) == 1
        rec.ok(S, len(Ax[x]) >= 1 and u == (x in gA), lambda: f"A-profiles ({a},{b},{c}) x={x}")
        if u:
            rec.ok(S, Ax[x][0] == unique_A(a, b, x), lambda: f"unique A ({a},{b}) x={x}")
    for y in range(b * c + 1):
        u = len(Cy[y]) == 1
        rec.ok(S, len(Cy[y]) >= 1 and u == (y in gC), lambda: f"C-profiles ({a},{b},{c}) y={y}")
        if u:
            rec.ok(S, Cy[y][0] == unique_C(b, c, y), lambda: f"unique C ({b},{c}) y={y}")
    st = rec.stats
    big = a >= 2 and b >= 2 and c >= 2
    for x in range(a * b + 1):
        As = Ax[x]
        for y in range(b * c + 1):
            Cs = Cy[y]
            Z = {sum(map(mul, A, C)) for A in As for C in Cs}
            st["A-i(1) pairs"] += len(As) * len(Cs)
            st["A-i(1) cells"] += 1
            tags = rigid_tags(a, b, c, x, y)
            rec.ok(S, (len(Z) == 1) == bool(tags),
                   lambda: f"(a,b,c)=({a},{b},{c}) (x,y)=({x},{y}): |Z|={len(Z)}, tags={tags}")
            rec.ok(S, (min(Z), max(Z)) == (z_min_formula(a, b, c, x, y), z_max_formula(a, b, c, x, y)),
                   lambda: f"extrema ({a},{b},{c}) ({x},{y}): {min(Z), max(Z)}")
            if tags:
                st["A-i(1) rigid cells"] += 1
                st["A-i(1) rigid by " + "+".join(tags)] += 1
                for tag in tags:
                    rec.ok(S, Z == predicted(tag, a, b, c, x, y),
                           lambda: f"value under {tag}: ({a},{b},{c}) ({x},{y}) Z={sorted(Z)}")
                    if tag == "E":
                        st["A-i(1) (E) sub-case z=" + e_subcase(a, b, c, x, y)] += 1
            # [+] Proposition 3.4 (literal), with the explicit witnesses of its proof
            hi, hii = crit34(a, b, c, x, y)
            rec.ok(S34, (len(Z) == 1) == (hi is None and hii is None),
                   lambda: f"Prop 3.4 at ({a},{b},{c}) ({x},{y}): |Z|={len(Z)}, h(i)={hi}, h(ii)={hii}")
            if hi is not None:
                Cw = C_step(b, c, y, hi)
                rec.ok(S34, Cw in Cset[y] and Cw[hi - 1] > Cw[hi]
                       and dot(A_bal(a, b, x), Cw) > dot(A_conc(a, b, x), Cw),
                       lambda: f"(i)-witness fails at ({a},{b},{c}) ({x},{y}) h={hi}")
            if hii is not None:
                Aw = A_step(a, b, x, hii)
                rec.ok(S34, Aw in Aset[x] and Aw[hii - 1] < Aw[hii]
                       and dot(Aw, C_bal(b, c, y)) > dot(Aw, C_conc(b, c, y)),
                       lambda: f"(ii)-witness fails at ({a},{b},{c}) ({x},{y}) h={hii}")
            # [+] Corollary 3.5 (a, b, c >= 2), straight from its statement
            if big:
                exp = (x in (0, a * b) or y in (0, b * c) or x + y <= b
                       or (a * b - x) + (b * c - y) <= b or (x, y) in ((1, b * c - 1), (a * b - 1, 1)))
                rec.ok(S34, (len(Z) == 1) == exp,
                       lambda: f"Cor 3.5 shape at ({a},{b},{c}) ({x},{y}): |Z|={len(Z)}")
                if (x, y) == (1, b * c - 1):
                    rec.ok(S34, Z == {c - 1}, lambda: f"Cor 3.5 value at (1,bc-1), ({a},{b},{c}): {Z}")
                if (x, y) == (a * b - 1, 1):
                    rec.ok(S34, Z == {a - 1}, lambda: f"Cor 3.5 value at (ab-1,1), ({a},{b},{c}): {Z}")
            # [+] Remark 3: the [Y26a] Thm 6 layer i + j = b + 1 (i, j >= 2, a, c >= 2)
            if a >= 2 and c >= 2:
                i_, j_ = b * c - y, a * b - x
                if i_ >= 2 and j_ >= 2 and i_ + j_ == b + 1:
                    z0 = a * b * c - c * j_ - a * i_
                    rec.ok(S34, Z == {z0, z0 + 1} and not tags,
                           lambda: f"layer i+j=b+1 at ({a},{b},{c}) ({x},{y}): Z={sorted(Z)}, z0={z0}")
                    st["P3.4 layer cells"] += 1
    # [+] (3.1), both forms, on every profile pair (small range)
    if 2 <= b <= sbp_b and a <= sbp_ac and c <= sbp_ac:
        n_pairs = bad = 0
        for x in range(a * b + 1):
            for A in Ax[x]:
                P = [sum(A[:h]) for h in range(b)]
                for y in range(b * c + 1):
                    for C in Cy[y]:
                        n_pairs += 1
                        f1 = C[b - 1] * x + sum((C[h - 1] - C[h]) * P[h] for h in range(1, b))
                        f2 = A[0] * y + sum((A[h] - A[h - 1]) * sum(C[h:]) for h in range(1, b))
                        if not (dot(A, C) == f1 == f2):
                            bad += 1
                            rec.fail(S34, f"(3.1) fails: A={A} C={C}")
        rec.add(S34, n_pairs - bad)
        st["P3.4 (3.1) pairs"] += n_pairs
    return rec


# ---------------------------------------------------------------------------
# [+] P3.4: Lemma 3.3 and Lemma 3.3' by profile enumeration
# ---------------------------------------------------------------------------


def task_lemma33(a: int, b: int) -> Rec:
    rec = Rec()
    S = "P3.4 Lemma 3.3 and 3.3'"
    byx: dict = defaultdict(list)
    for A in combinations_with_replacement(range(a + 1), b):
        byx[sum(A)].append(A)
    for x in range(a * b + 1):
        As = byx[x]
        Aset = set(As)
        Ab, Ac = A_bal(a, b, x), A_conc(a, b, x)
        rec.ok(S, Ab in Aset and Ac in Aset, lambda: f"A^bal or A^conc not in A({x}), (a,b)=({a},{b})")
        rec.ok(S, (len(As) == 1) == (x in gamma_set(a, b)), lambda: f"3.3' at (a,b,x)=({a},{b},{x})")
        if a >= 2 and b >= 2 and 2 <= x <= a * b - 2:
            h0 = max(1, b - x + 1)
            rec.ok(S, 1 <= h0 <= b - 1 and b - h0 < x < a * b - h0,
                   lambda: f"free index of 3.3' fails at (a,b,x)=({a},{b},{x})")
        for h in range(1, b):
            P = [sum(A[:h]) for A in As]
            lo, hi = min(P), max(P)
            rec.ok(S, lo == sum(Ac[:h]) and hi == sum(Ab[:h]),
                   lambda: f"3.3(a) extremes at (a,b,x,h)=({a},{b},{x},{h})")
            rec.ok(S, (lo < hi) == (b - h < x < a * b - h), lambda: f"3.3(a) freeness at ({a},{b},{x},{h})")
            step = any(A[h - 1] < A[h] for A in As)
            rec.ok(S, step == (b - h <= x <= a * b - h), lambda: f"3.3(b) at ({a},{b},{x},{h})")
            if b - h <= x <= a * b - h:
                Aw = A_step(a, b, x, h)
                rec.ok(S, Aw in Aset and Aw[h - 1] < Aw[h], lambda: f"3.3(b) construction at ({a},{b},{x},{h})")
    c = a  # the C side, enumerated directly (not through the reversal argument)
    byy: dict = defaultdict(list)
    for Cr in combinations_with_replacement(range(c + 1), b):
        byy[sum(Cr)].append(Cr[::-1])
    for y in range(b * c + 1):
        Cs = byy[y]
        Cset = set(Cs)
        Cb, Cc = C_bal(b, c, y), C_conc(b, c, y)
        rec.ok(S, Cb in Cset and Cc in Cset, lambda: f"C^bal or C^conc not in C({y}), (b,c)=({b},{c})")
        rec.ok(S, (len(Cs) == 1) == (y in gamma_set(b, c)), lambda: f"3.3' (C) at ({b},{c},{y})")
        for h in range(1, b):
            Sv = [sum(C[h:]) for C in Cs]
            lo, hi = min(Sv), max(Sv)
            rec.ok(S, lo == sum(Cc[h:]) and hi == sum(Cb[h:]), lambda: f"3.3(c) extremes at ({b},{c},{y},{h})")
            rec.ok(S, (lo < hi) == (h < y < b * c - b + h), lambda: f"3.3(c) freeness at ({b},{c},{y},{h})")
            step = any(C[h - 1] > C[h] for C in Cs)
            rec.ok(S, step == (h <= y <= b * c - b + h), lambda: f"3.3(d) at ({b},{c},{y},{h})")
            if h <= y <= b * c - b + h:
                Cw = C_step(b, c, y, h)
                rec.ok(S, Cw in Cset and Cw[h - 1] > Cw[h], lambda: f"3.3(d) construction at ({b},{c},{y},{h})")
    return rec


# ---------------------------------------------------------------------------
# A-i(2): formula level, k = 3  (+ P3.4: criterion <=> not rigid)
# ---------------------------------------------------------------------------


def task_formula(b: int, M: int) -> Rec:
    rec = Rec()
    S = "A-i(2) formula level"
    S34 = "P3.4 Prop 3.4 criterion <=> not rigid (formula range)"
    cells = rigid = 0
    HCs = {c: masks_C(b, c) for c in range(1, M + 1)}
    for a in range(1, M + 1):
        ab = a * b
        HA, HAi = masks_A(a, b)
        for c in range(1, M + 1):
            bc = b * c
            ac = a * c
            HC, HCi = HCs[c]
            rows = [(y // b, y % b, y // c, y % c) for y in range(bc + 1)]
            for x in range(ab + 1):
                q, r = divmod(x, b)
                Q, R = divmod(x, a)
                # z_max and z_min of proof-r2-extrema.md, inlined for speed (same as the
                # functions z_max_formula / z_min_formula, which A-i(1) compares with brute force)
                zmax = [b * q * t + q * s + t * r + (r + s - b if r + s > b else 0)
                        for (t, s, T, S_) in rows]
                zmin = [(ac * (Q + T - b) + a * S_ + c * R) if Q + T >= b else
                        (R * S_ if Q + T == b - 1 else 0)
                        for (t, s, T, S_) in rows]
                eq = [p == m for p, m in zip(zmax, zmin)]
                if a <= 6 and c <= 6:   # the inlined copies agree with the functions
                    rec.ok(S, zmax == [z_max_formula(a, b, c, x, y) for y in range(bc + 1)] and
                           zmin == [z_min_formula(a, b, c, x, y) for y in range(bc + 1)],
                           lambda: f"inlined extrema differ from the functions at ({a},{b},{c}) x={x}")
                tags = [rigid_tags(a, b, c, x, y) for y in range(bc + 1)]
                cells += len(rows)
                bad = [y for y in range(bc + 1) if eq[y] != bool(tags[y])]
                for y in bad:
                    rec.fail(S, f"(a,b,c)=({a},{b},{c}) (x,y)=({x},{y}): "
                                f"z_min=z_max is {eq[y]}, rule tags {tags[y]}")
                rec.add(S, len(rows) - len(bad))
                # values in rigid cells: the forced value z_max against each applicable rule
                for y in range(bc + 1):
                    if tags[y]:
                        rigid += 1
                        z = zmax[y]
                        for tag in tags[y]:
                            rec.ok(S, predicted(tag, a, b, c, x, y) == {z},
                                   lambda: f"value under {tag}: ({a},{b},{c}) ({x},{y}) z={z}")
                # [+] Prop 3.4's criterion (some h with (i) or (ii)) <=> not rigid
                ha, hai = HA[x], HAi[x]
                crit = [((hai & HC[y]) | (ha & HCi[y])) != 0 for y in range(bc + 1)]
                badc = [y for y in range(bc + 1) if crit[y] == bool(tags[y])]
                for y in badc:
                    rec.fail(S34, f"criterion {crit[y]} but tags {tags[y]} at ({a},{b},{c}) ({x},{y})")
                rec.add(S34, bc + 1 - len(badc))
                if a <= 4 and c <= 4:   # the literal per-h form agrees with the bitmasks
                    for y in range(bc + 1):
                        hi, hii = crit34(a, b, c, x, y)
                        rec.ok(S34, (hi is not None or hii is not None) == crit[y],
                               lambda: f"literal and bitmask criteria differ at ({a},{b},{c}) ({x},{y})")
    rec.stats["A-i(2) cells"] += cells
    rec.stats["A-i(2) rigid cells"] += rigid
    return rec


# ---------------------------------------------------------------------------
# Words, contents, exhaustive searches
# ---------------------------------------------------------------------------


def compositions(total: int, k: int):
    """Positive contents (n_1..n_k) with the given total, lexicographic in the cut points."""
    for cuts in combinations(range(1, total), k - 1):
        prev, out = 0, []
        for cut in cuts + (total,):
            out.append(cut - prev)
            prev = cut
        yield tuple(out)


def words_of(content: tuple):
    """Every word of the content, in lexicographic order (next-permutation on a multiset)."""
    w = [m + 1 for m in range(len(content)) for _ in range(content[m])]
    n = len(w)
    while True:
        yield tuple(w)
        i = n - 2
        while i >= 0 and w[i] >= w[i + 1]:
            i -= 1
        if i < 0:
            return
        j = n - 1
        while w[j] <= w[i]:
            j -= 1
        w[i], w[j] = w[j], w[i]
        w[i + 1:] = w[:i:-1]


def interval_index(k: int) -> dict:
    idx = {}
    for i in range(1, k + 1):
        for j in range(i, k + 1):
            idx[i, j] = len(idx)
    return idx


def merged_matrices(content: tuple) -> set:
    """The set of Parikh matrices (flat tuple of |w|_{i..j}, i <= j, in interval_index order)
    of all words of the content, built letter by letter with equal states merged."""
    k = len(content)
    idx = interval_index(k)
    ops = [()] + [tuple((idx[i, m], idx[i, m - 1]) for i in range(1, m)) for m in range(1, k + 1)]
    single = [0] + [idx[m, m] for m in range(1, k + 1)]
    level = {(0,) * len(idx)}
    for _ in range(sum(content)):
        new: set = set()
        add = new.add
        for s in level:
            for m in range(1, k + 1):
                sm = single[m]
                if s[sm] < content[m - 1]:
                    t = list(s)
                    for tg, sr in ops[m]:
                        t[tg] += s[sr]
                    t[sm] += 1
                    add(tuple(t))
        level = new
    return level


def det3(M) -> int:
    return (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1])
            - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
            + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))


def task_content(content: tuple, opts: dict) -> Rec:
    """All checks that need the words (or the Parikh matrices) of one content."""
    rec = Rec()
    st = rec.stats
    k = len(content)
    n = sum(content)
    do_plain, do_lemma, do_merged = opts["plain"], opts["lemma"], opts["merged"]
    do_small, do_k3, do_crit = opts["small"], opts["k3"], opts.get("crit", False)
    idx = interval_index(k)
    flat_order = [(i, j) for (i, j) in idx]  # insertion order = index order
    K2 = k + 2
    base = [0] * (K2 * K2)
    for i in range(1, k + 2):
        base[i * K2 + i - 1] = 1   # the empty word i..i-1 occurs once
    triples = [(j, m, l) for j in range(1, k + 1) for m in range(j + 1, k + 1)
               for l in range(m + 1, k + 1)]
    degenerate = [(j, m, l) for j in range(1, k + 1) for m in range(j, k + 1)
                  for l in range(m, k + 1) if j == m or m == l]
    flat_idx = [i * K2 + j for (i, j) in flat_order]
    L, LX = "L3.2 minor identity", "cross-checks"
    LD, L21, L11 = "L3.2(d) exact criterion", "L3.2 Cor 2.1 (N'), (Ch'), (2.1)", "L1.1 projections, (1.1), conjugation"
    BIG = k + 5

    plain_set: set = set()
    proj_set: set = set()
    if do_k3:
        a, b, c = content
        fib3: dict = defaultdict(set)
        pairs_seen: set = set()

    if do_plain or do_lemma or do_k3:
        n_words = 0
        lem_checks = 0
        lx_checks = 0
        crit_checks = 0
        c21_checks = 0
        l11_checks = 0
        for w in words_of(content):
            n_words += 1
            # forward pass: cnt[i][j] = |prefix|_{i..j}; beta[p][j] = |prefix before p|_{j..m-1}
            # [+] low[p] = least j such that j..w[p] occurs ending at p
            cnt = base[:]
            beta = []
            pos: dict = defaultdict(list)
            if do_crit:
                low = [0] * n
                lowbest = [BIG] * (k + 2)
            for p, m in enumerate(w):
                col = m - 1
                beta.append([cnt[j * K2 + col] for j in range(m + 1)])
                pos[m].append(p)
                for j in range(1, m + 1):
                    cnt[j * K2 + m] += cnt[j * K2 + col]
                if do_crit:
                    lb = lowbest[m - 1]
                    lo = lb if lb < m else m
                    low[p] = lo
                    if lo < lowbest[m]:
                        lowbest[m] = lo
            if do_plain:
                plain_set.add(tuple(cnt[f] for f in flat_idx))
            if do_k3:
                x, y, z = cnt[K2 + 2], cnt[2 * K2 + 3], cnt[K2 + 3]
                A, ones = [], 0
                for ch in w:
                    if ch == 1:
                        ones += 1
                    elif ch == 2:
                        A.append(ones)
                C, threes = [], 0
                for ch in reversed(w):
                    if ch == 3:
                        threes += 1
                    elif ch == 2:
                        C.append(threes)
                C.reverse()
                if not (x == sum(A) and y == sum(C) and z == sum(map(mul, A, C))):
                    rec.fail("A-i(3) word level", f"profile model fails on {w}")
                pairs_seen.add((tuple(A), tuple(C)))
                fib3[x, y].add(z)
                # [+] the two encodings of edge 2 (section 3 of the note)
                lam2, twos = [], 0
                for ch in w:
                    if ch == 2:
                        twos += 1
                    elif ch == 3:
                        lam2.append(twos)
                l11_checks += 1
                if not (tuple(C) == conj_lam_to_C(tuple(lam2), b) and tuple(lam2) == conj_C_to_lam(tuple(C), c)):
                    rec.fail(L11, f"conjugation lambda^(2) <-> C fails on {w}")
            if do_small:
                # [+] projections, their validity, and eq. (1.1) via B-matrix products
                lams = projections(w, k)
                proj_set.add(lams)
                for e in range(1, k):
                    lam = lams[e - 1]
                    l11_checks += 1
                    if not (len(lam) == content[e] and all(0 <= lam[t] <= content[e - 1] for t in range(len(lam)))
                            and all(lam[t] <= lam[t + 1] for t in range(len(lam) - 1))
                            and sum(lam) == cnt[e * K2 + e + 1]):
                        rec.fail(L11, f"projection {e} of {w} invalid: {lam}")
                for j in range(1, k):
                    vec = [1] * content[j - 1]
                    for e in range(j, k):
                        pre = [0]
                        for v_ in vec:
                            pre.append(pre[-1] + v_)
                        vec = [pre[ls] for ls in lams[e - 1]]
                        l11_checks += 1
                        if sum(vec) != cnt[j * K2 + e + 1]:
                            rec.fail(L11, f"(1.1) fails on {w} for |w|_{{{j}..{e + 1}}}")
            if not do_lemma:
                continue
            # backward pass: suf[i][l] = |suffix|_{i..l}; V[p][l] = |suffix after p|_{m+1..l}
            # [+] reach[p] = largest l such that w[p]..l occurs starting at p
            suf = base[:]
            V = [None] * n
            if do_crit:
                reach = [0] * n
                reachbest = [0] * (k + 3)
            for p in range(n - 1, -1, -1):
                m = w[p]
                r1 = (m + 1) * K2
                V[p] = [suf[r1 + l] for l in range(k + 1)]
                rm = m * K2
                for l in range(m, k + 1):
                    suf[rm + l] += suf[r1 + l]
                if do_crit:
                    rb = reachbest[m + 1]
                    rr = rb if rb > m else m
                    reach[p] = rr
                    if rr > reachbest[m]:
                        reachbest[m] = rr
            lx_checks += 1
            if any(cnt[f] != suf[f] for f in flat_idx):
                rec.fail(LX, f"forward and backward interval counts differ on {w}")
            if do_crit:
                # [+] for the t-th letter m at p: Lc[p] = largest reach of an m+1 before p,
                # Jc[p] = least low of an m-1 after p (criterion (d) of Lemma 3.2)
                Lc = [0] * n
                Jc = [BIG] * n
                runmax = [0] * (k + 3)
                for p, m in enumerate(w):
                    Lc[p] = runmax[m + 1]
                    if reach[p] > runmax[m]:
                        runmax[m] = reach[p]
                runmin = [BIG] * (k + 3)
                for p in range(n - 1, -1, -1):
                    m = w[p]
                    Jc[p] = runmin[m - 1]
                    if low[p] < runmin[m]:
                        runmin[m] = low[p]
            # |w|_{(m+1) m (m-1)} for 2 <= m <= k-1, one pass
            c1 = [0] * (k + 2)
            c2 = [0] * (k + 2)
            c3 = [0] * (k + 2)
            for ch in w:
                c3[ch + 1] += c2[ch + 1]   # ch plays m-1 for m = ch+1
                c2[ch] += c1[ch]           # ch plays m
                c1[ch - 1] += 1            # ch plays m+1 for m = ch-1
            for (j, m, l) in triples:
                G = cnt[j * K2 + m - 1]
                Y = cnt[(m + 1) * K2 + l]
                D = cnt[j * K2 + l] - Y * cnt[j * K2 + m] - G * cnt[m * K2 + l] + cnt[m * K2 + m] * G * Y
                rhs = 0
                nonneg = True
                ex = False
                for p in pos[m]:
                    bt = beta[p][j]
                    vt = V[p][l]
                    if bt < 0 or bt > G or vt < 0 or vt > Y:
                        nonneg = False
                    rhs += (G - bt) * (Y - vt)
                    if do_crit and Lc[p] >= l and Jc[p] <= j:
                        ex = True
                lem_checks += 2
                if D != rhs:
                    rec.fail(L, f"identity fails: w={w} (j,m,l)=({j},{m},{l}) D={D} sum={rhs}")
                if not (nonneg and D >= 0):
                    rec.fail(L, f"nonnegativity fails: w={w} (j,m,l)=({j},{m},{l})")
                if do_crit:
                    crit_checks += 1
                    if (D > 0) != ex:
                        rec.fail(LD, f"criterion (d) fails: w={w} (j,m,l)=({j},{m},{l}) D={D}")
                pat = c3[m]
                if pat == 0:
                    lem_checks += 1
                    st["L3.2 instances avoiding (m+1)m(m-1)"] += 1
                    if D != 0:
                        rec.fail(L, f"vanishing fails: w={w} (j,m,l)=({j},{m},{l}) D={D}")
                elif D == 0:
                    st["L3.2 instances with D=0 that contain (m+1)m(m-1)"] += 1
                    if j == m - 1 and l == m + 1:   # impossible there: D is the pattern count
                        st["L3.2 converse failures at (m-1,m,m+1)"] += 1
                    if j < m - 1 and l == m + 1:
                        st["L3.2 converse failures with j < m-1, l = m+1"] += 1
                    if j == m - 1 and l > m + 1:
                        st["L3.2 converse failures with j = m-1, l > m+1"] += 1
                if j == m - 1 and l == m + 1:
                    lem_checks += 1
                    if D != pat:
                        rec.fail(L, f"D != |w|_(m+1)m(m-1): w={w} m={m} D={D} pattern={pat}")
                st["L3.2 instances"] += 1
                if D > 0:
                    st["L3.2 instances with D>0"] += 1
            # [+] Corollary 2.1: (N') and (Ch') with (2.1), at every middle letter m
            for m in range(2, k):
                a_, b_, c_ = content[m - 2], content[m - 1], content[m]
                u_ = cnt[(m - 1) * K2 + m]
                v_ = cnt[m * K2 + m + 1]
                if u_ + v_ <= b_:
                    c21_checks += 1
                    st["Cor 2.1 (N') instances"] += 1
                    if any(cnt[j * K2 + l] for j in range(1, m) for l in range(m + 1, k + 1)):
                        rec.fail(L21, f"(N') fails: w={w} m={m}")
                if (a_ * b_ - u_) + (b_ * c_ - v_) <= b_:
                    c21_checks += 1
                    st["Cor 2.1 (Ch') instances"] += 1
                    okc = c3[m] == 0
                    for j in range(1, m):
                        G = cnt[j * K2 + m - 1]
                        for l in range(m + 1, k + 1):
                            Y = cnt[(m + 1) * K2 + l]
                            if cnt[j * K2 + l] != Y * cnt[j * K2 + m] + G * cnt[m * K2 + l] - b_ * G * Y:
                                okc = False
                    if not okc:
                        rec.fail(L21, f"(Ch') or (2.1) fails: w={w} m={m}")
            if do_small:
                # cross-check every count with parikh.occ (generic subword count)
                for (i, j) in flat_order:
                    lx_checks += 1
                    if cnt[i * K2 + j] != occ(w, interval(i, j)):
                        rec.fail(LX, f"|w|_{{{i}..{j}}} differs from occ() on {w}")
                for m in range(2, k):
                    lx_checks += 1
                    if c3[m] != occ(w, (m + 1, m, m - 1)):
                        rec.fail(LX, f"pattern count differs from occ() on {w}, m={m}")
                # the minor of the Parikh matrix, built as a literal product of generators
                P = [[int(r == s) for s in range(k + 1)] for r in range(k + 1)]
                for m in w:      # right-multiply by I + E_{m,m+1}: column m+1 += column m
                    for r in range(k + 1):
                        P[r][m] += P[r][m - 1]
                for (j, m, l) in triples:
                    G = cnt[j * K2 + m - 1]
                    Y = cnt[(m + 1) * K2 + l]
                    D = cnt[j * K2 + l] - Y * cnt[j * K2 + m] - G * cnt[m * K2 + l] + cnt[m * K2 + m] * G * Y
                    rows, cols = (j - 1, m - 1, m), (m - 1, m, l)
                    minor = [[P[r][s] for s in cols] for r in rows]
                    lem_checks += 1
                    if det3(minor) != D:
                        rec.fail(L, f"D is not the minor: w={w} (j,m,l)=({j},{m},{l})")
                    # [+] criterion (d) by brute force over position triples, counts from occ()
                    ex = False
                    for p1 in pos.get(m + 1, ()):
                        if l > m + 1 and occ(w[p1 + 1:], interval(m + 2, l)) == 0:
                            continue
                        for p3 in pos.get(m - 1, ()):
                            if p3 < p1 + 2:
                                continue
                            if j < m - 1 and occ(w[:p3], interval(j, m - 2)) == 0:
                                continue
                            if any(p1 < p2 < p3 for p2 in pos[m]):
                                ex = True
                                break
                        if ex:
                            break
                    crit_checks += 1
                    if (D > 0) != ex:
                        rec.fail(LD, f"criterion (d) (brute force) fails: w={w} (j,m,l)=({j},{m},{l})")
                # degenerate j = m or l = m with the empty-word convention: both sides 0
                for (j, m, l) in degenerate:
                    G = cnt[j * K2 + m - 1]
                    Y = cnt[(m + 1) * K2 + l]
                    D = cnt[j * K2 + l] - Y * cnt[j * K2 + m] - G * cnt[m * K2 + l] + cnt[m * K2 + m] * G * Y
                    rhs = sum((G - beta[p][j]) * (Y - V[p][l]) for p in pos[m])
                    lem_checks += 1
                    if not (D == 0 == rhs):
                        rec.fail(L, f"degenerate case: w={w} (j,m,l)=({j},{m},{l}) D={D} sum={rhs}")
        st[f"words enumerated, k={k}"] += n_words
        if do_lemma:
            st[f"L3.2 words, k={k}"] += n_words
            rec.add(L, lem_checks)
            rec.add(LX, lx_checks)
            rec.add(L21, c21_checks)
            if do_crit:
                st[f"L3.2(d) words, k={k}"] += n_words
        if crit_checks:
            rec.add(LD, crit_checks)
        if l11_checks:
            rec.add(L11, l11_checks)
        if do_small:
            # [+] Lemma 1.1: the projection tuples of all words fill the whole product, and the
            # insertion construction of its proof realises every tuple
            seqs = [list(combinations_with_replacement(range(content[e - 1] + 1), content[e]))
                    for e in range(1, k)]
            full = prod(comb(content[e - 1] + content[e], content[e]) for e in range(1, k))
            rec.ok(L11, len(proj_set) == full and all(len(s) == comb(content[e] + content[e + 1], content[e + 1])
                                                    for e, s in enumerate(seqs)),
                   lambda: f"{content}: {len(proj_set)} projection tuples, product has {full}")
            for tup in product(*seqs):
                wd = insert_word(content, tup)
                rec.ok(L11, projections(wd, k) == tup
                       and all(wd.count(m + 1) == content[m] for m in range(k)) and len(wd) == n,
                       lambda: f"insertion construction fails for {content}, tuple {tup}")
            st["L1.1 contents (words, product, insertion)"] += 1
        if do_k3:
            S3 = "A-i(3) word level"
            rec.add(S3, n_words)  # one profile-model check per word (failures recorded above)
            all_pairs = {(A, C[::-1])
                         for A in combinations_with_replacement(range(a + 1), b)
                         for C in combinations_with_replacement(range(c + 1), b)}
            rec.ok(S3, pairs_seen == all_pairs,
                   lambda: f"realised profile pairs differ from all monotone pairs for {content}")
            for x in range(a * b + 1):
                for y in range(b * c + 1):
                    Z = fib3.get((x, y))
                    if not rec.ok(S3, bool(Z), lambda: f"{content}: cell ({x},{y}) not attained"):
                        continue
                    tags = rigid_tags(a, b, c, x, y)
                    st["A-i(3) cells"] += 1
                    rec.ok(S3, (len(Z) == 1) == bool(tags),
                           lambda: f"{content} ({x},{y}): z-values {sorted(Z)}, tags {tags}")
                    if tags:
                        st["A-i(3) rigid cells"] += 1
                    for tag in tags:
                        rec.ok(S3, Z == predicted(tag, a, b, c, x, y),
                               lambda: f"{content} ({x},{y}) value under {tag}: {sorted(Z)}")

    # ---- A-ii / A-iii -------------------------------------------------------------------------
    mats = None
    if do_merged:
        mats = merged_matrices(content)
        if do_plain:
            rec.ok(LX, mats == plain_set,
                   lambda: f"state-merged search and word-by-word sets differ for {content}")
            st["merged = plain, contents"] += 1
    elif do_plain:
        mats = plain_set
    if mats is not None and k >= 3:
        S2, S3c = "A-ii psi_2-fibres", "A-iii completeness"
        SC = "A-ii Cor 4.1, per-triple constancy, Remark 4.2"
        p2 = [idx[i, i + 1] for i in range(1, k)]
        fib: dict = defaultdict(list)
        for s in mats:
            fib[tuple(s[i] for i in p2)].append(s)
        box = 1
        for i in range(k - 1):
            box *= content[i] * content[i + 1] + 1
        rec.ok(LX, len(fib) == box and all(0 <= v[i] <= content[i] * content[i + 1]
                                           for v in fib for i in range(k - 1)),
               lambda: f"psi_2 support of {content} is not the full box ({len(fib)} of {box})")
        p3 = [idx[i, i + 2] for i in range(1, k - 1)]
        ivals = [(j, l, idx[j, l]) for j in range(1, k - 1) for l in range(j + 2, k + 1)]
        single_vecs = []
        for v, lst in fib.items():
            ncls = len(lst)
            rigs = [bool(rigid_tags(content[i], content[i + 1], content[i + 2], v[i], v[i + 1]))
                    for i in range(k - 2)]
            rig = all(rigs)
            rec.ok(S2, (ncls == 1) == rig,
                   lambda: f"content {content} psi_2={v}: {ncls} classes, all triples rigid={rig}")
            if ncls == 1:
                single_vecs.append(v)
            # [+] |w|_{i..i+2} constant iff triple i rigid; Cor 4.1; Remark 4.2 entrywise
            const3 = [len({s[pp] for s in lst}) == 1 for pp in p3]
            rec.ok(SC, const3 == rigs,
                   lambda: f"content {content} psi_2={v}: constant fourth-diagonal entries {const3}, rigid {rigs}")
            rec.ok(SC, (ncls == 1) == all(const3),
                   lambda: f"Cor 4.1 fails: content {content} psi_2={v}")
            for (j, l, pidx) in ivals:
                if all(rigs[j - 1:l - 2]):
                    rec.ok(SC, len({s[pidx] for s in lst}) == 1,
                           lambda: f"Remark 4.2 fails: content {content} psi_2={v} [j,l]=[{j},{l}]")
        st[f"A-ii fibres, k={k}"] += len(fib)
        st[f"A-ii single-class fibres, k={k}"] += len(single_vecs)
        st[f"A-ii Parikh classes, k={k}"] += len(mats)
        st[f"A-ii contents, k={k}"] += 1
        all_single = len(single_vecs) == len(fib)
        crit = all(min(content[i], content[i + 1]) == 1 for i in range(k - 1))
        rec.ok(S3c, all_single == crit,
               lambda: f"content {content}: psi_2 determines the matrix={all_single}, criterion={crit}")
        st[f"A-iii contents, k={k}"] += 1
        st[f"A-iii contents where psi_2 determines the matrix, k={k}"] += int(all_single)
        # [+] Theorem A(iv)(1): single-class fibres = transfer-matrix walk count
        tc = transfer_count(content)
        rec.ok("A-iv transfer count = single-class fibres", tc == len(single_vecs),
               lambda: f"content {content}: transfer count {tc}, single-class fibres {len(single_vecs)}")
        rec.extra.setdefault("counts", {})[content] = len(single_vecs)
        if set(content) == {2}:
            rec.extra["pow2"] = (k, sorted(single_vecs), len(fib))
    return rec


# ---------------------------------------------------------------------------
# [+] WIT: the necessity half of Theorem A(ii), constructively
# ---------------------------------------------------------------------------


def task_wit(content: tuple) -> Rec:
    rec = Rec()
    S = "WIT A(ii) necessity witnesses"
    k = len(content)
    n = sum(content)
    boxes = [range(content[e] * content[e + 1] + 1) for e in range(k - 1)]
    n_vec = n_pairs = 0
    for x in product(*boxes):
        bal = [A_bal(content[e], content[e + 1], x[e]) for e in range(k - 1)]
        nonrigid = False
        for i in range(k - 2):          # triple on the letters i+1, i+2, i+3
            a, b, c = content[i], content[i + 1], content[i + 2]
            u, v = x[i], x[i + 1]
            if rigid_tags(a, b, c, u, v):
                continue
            nonrigid = True
            hi, hii = crit34(a, b, c, u, v)
            if hi is not None:
                Cw = C_step(b, c, v, hi)
                pairs = ((A_bal(a, b, u), Cw), (A_conc(a, b, u), Cw))
            elif hii is not None:
                Aw = A_step(a, b, u, hii)
                pairs = ((Aw, C_bal(b, c, v)), (Aw, C_conc(b, c, v)))
            else:
                rec.fail(S, f"non-rigid triple {i + 1} without a Prop 3.4 index: {content}, x={x}")
                continue
            vals = []
            for (A, C) in pairs:
                lams = list(bal)
                lams[i] = A
                lams[i + 1] = conj_C_to_lam(C, c)
                wd = insert_word(content, lams)
                cnt = interval_counts(wd, k)
                rec.ok(S, len(wd) == n and all(wd.count(m + 1) == content[m] for m in range(k))
                       and all(cnt[e][e + 1] == x[e - 1] for e in range(1, k)),
                       lambda: f"witness word {wd} not in the fibre of {x}, content {content}")
                vals.append(cnt[i + 1][i + 3])
            n_pairs += 1
            rec.ok(S, vals[0] != vals[1],
                   lambda: f"witnesses agree on |w|_{{{i + 1}..{i + 3}}} = {vals}: content {content}, x={x}")
        n_vec += nonrigid
    rec.stats["WIT non-rigid vectors"] += n_vec
    rec.stats["WIT (vector, non-rigid triple) pairs"] += n_pairs
    rec.stats["WIT contents"] += 1
    return rec


# ---------------------------------------------------------------------------
# A-iv: (2^k) rigid-vector counts
# ---------------------------------------------------------------------------


def pow2_rigid_vectors(k: int) -> list:
    """Brute force over {0..4}^{k-1}, evaluating the rule triple by triple."""
    return [v for v in product(range(5), repeat=k - 1)
            if all(rigid_tags(2, 2, 2, v[i], v[i + 1]) for i in range(k - 2))]


def pow2_transfer(kmax: int) -> dict:
    """Sum of the entries of T^(k-2), T[u][v] = [(u,v) rigid for (2,2,2)]."""
    T = [[int(bool(rigid_tags(2, 2, 2, u, v))) for v in range(5)] for u in range(5)]
    out = {}
    vec = [1] * 5                  # number of rigid vectors ending in each value (k = 2: 1 each)
    for k in range(3, kmax + 1):
        vec = [sum(vec[u] * T[u][v] for u in range(5)) for v in range(5)]
        out[k] = sum(vec)
    return out


def periodic_counts(pattern: tuple, kmax: int) -> dict:
    """count_k = number of rigid vectors of the length-k prefix of the periodic content."""
    content = tuple(pattern[i % len(pattern)] for i in range(kmax))
    vec = [1] * (content[0] * content[1] + 1)
    out = {2: sum(vec)}
    for k in range(3, kmax + 1):
        a, b, c = content[k - 3], content[k - 2], content[k - 1]
        T = trans_matrix(a, b, c)
        vec = [sum(vec[u] * T[u][v] for u in range(a * b + 1)) for v in range(b * c + 1)]
        out[k] = sum(vec)
    return out


def brute_rigid_count(content: tuple) -> int:
    k = len(content)
    boxes = [range(content[e] * content[e + 1] + 1) for e in range(k - 1)]
    return sum(1 for v in product(*boxes)
               if all(rigid_tags(content[i], content[i + 1], content[i + 2], v[i], v[i + 1])
                      for i in range(k - 2)))


def poly_mul_trunc(p: list, q: list, terms: int) -> list:
    out = [0] * terms
    for i, pi in enumerate(p[:terms]):
        if pi:
            for j, qj in enumerate(q[:terms - i]):
                out[i + j] += pi * qj
    return out


# The generating functions of notes/proof-rigidity-local.md, sections 6 and 8:
# S(t) = sum_{k>=2} count_k t^(k-2) = N(t)/Q(t) (coefficient lists, constant term first).
GF_CLAIMS = {
    (2,): ([5, 0, -4], [1, -4, -2, 4]),
    (3,): ([10, 4, -22, -8], [1, -4, -13, 18, 8]),
    (4,): ([17, -7, -62, 11, 18], [1, -5, -24, 63, -2, -18]),
    (5,): ([26, -8, -140, -36, 82, 32], [1, -5, -44, 106, 69, -66, -32]),
    (1, 2): ([3], [1, -3]),
    (2, 3): ([7, 32, -42, -96, 32, 64], [1, 0, -28, 0, 100, 0, -64]),
    (1, 2, 2): ([3, 14, 40], [1, 0, 0, -40]),
}
COUNT_CLAIMS = {   # printed in the note (section 8) and in out/transfer_gf.txt
    (3,): {3: 44, 4: 284, 5: 1520, 6: 8900, 7: 49896, 8: 285652},
    (4,): {3: 78, 4: 736, 5: 4492, 6: 35262, 7: 238212, 8: 1757228},
    (5,): {3: 122, 4: 1614, 5: 10646, 6: 109602, 7: 838680, 8: 7784930},
    (1, 2): {3: 9, 4: 27, 5: 81, 6: 243, 7: 729, 8: 2187},
    (2, 3): {3: 32, 4: 154, 5: 800, 6: 3644, 7: 19264, 8: 87080},
    (1, 2, 2): {3: 14, 4: 40, 5: 120, 6: 560, 7: 1600, 8: 4800},
}


def pval(coeffs_high_first, t: Fraction) -> Fraction:
    v = Fraction(0)
    for co in coeffs_high_first:
        v = v * t + co
    return v


def check_A_iv(total: Rec, R: dict) -> dict:
    """Section 6 of the note (hand derivation) and section 8 (GF certificates)."""
    S4 = "A-iv (2^k) rigid vectors"
    SG = "A-iv(GF) generating-function certificates"
    info = {}
    T = [[int(bool(rigid_tags(2, 2, 2, u, v))) for v in range(5)] for u in range(5)]
    nonrig = {(u, v) for u in range(5) for v in range(5) if not T[u][v]}
    total.ok(S4, nonrig == {(1, 2), (2, 1), (2, 2), (2, 3), (3, 2)}, lambda: f"non-rigid pairs {sorted(nonrig)}")
    total.ok(S4, [sum(row) for row in T] == [5, 4, 2, 4, 5], lambda: f"row sums {[sum(r) for r in T]}")
    total.ok(S4, all(T[4 - u][4 - v] == T[u][v] for u in range(5) for v in range(5)), "T is not reflection-invariant")
    # a_k for k = 1..41: a_1 = 1, a_2 = 5, a_k = 1^T T^{k-2} 1
    a = {1: 1, 2: 5}
    vec = [1] * 5
    for k in range(3, 42):
        vec = [sum(vec[u] * T[u][v] for u in range(5)) for v in range(5)]
        a[k] = sum(vec)
    info["a"] = a
    for k, want in EXPECTED_POW2.items():
        total.ok(S4, a[k] == want, lambda: f"a_{k} = {a[k]}, claimed {want}")
    Mx = [[2, 2, 1], [2, 2, 0], [2, 0, 0]]
    # the f-basis: T f0 = 2f0 + 2f1 + 2f2, T f1 = 2f0 + 2f1, T f2 = f0 (f0 = e0+e4, f1 = e1+e3, f2 = e2)
    f = [[1, 0, 0, 0, 1], [0, 1, 0, 1, 0], [0, 0, 1, 0, 0]]
    Tf = [[sum(T[u][v] * f[i][v] for v in range(5)) for u in range(5)] for i in range(3)]
    want_Tf = [[2 * f[0][u] + 2 * f[1][u] + 2 * f[2][u] for u in range(5)],
               [2 * f[0][u] + 2 * f[1][u] for u in range(5)], [f[0][u] for u in range(5)]]
    total.ok(S4, Tf == want_Tf, "T on the f-basis differs from section 6")
    mvec = [1, 1, 1]
    ok_red = a[2] == 2 * 1 + 2 * 1 + 1 * 1
    for k in range(3, 42):
        mvec = [sum(Mx[r][s] * mvec[s] for s in range(3)) for r in range(3)]
        ok_red = ok_red and (2 * mvec[0] + 2 * mvec[1] + mvec[2] == a[k])
    total.ok(S4, ok_red, "a_k = (2,2,1) M^(k-2) (1,1,1)^T fails for some 2 <= k <= 41")
    tr_ = sum(Mx[i][i] for i in range(3))
    minors2 = sum(Mx[i][i] * Mx[j][j] - Mx[i][j] * Mx[j][i] for i in range(3) for j in range(i + 1, 3))
    detM = det3(Mx)
    total.ok(S4, (tr_, minors2, detM) == (4, -2, -4),
             lambda: f"char. poly of M: theta^3 - {tr_} theta^2 + {minors2} theta - {detM}")
    half = [Fraction(1, 2), Fraction(0), Fraction(0)]
    total.ok(S4, [sum(Mx[r][s] * half[s] for s in range(3)) for r in range(3)] == [1, 1, 1]
             and 2 * half[0] + 2 * half[1] + half[2] == 1, "M (1/2,0,0)^T = (1,1,1)^T or a_1 = 1 fails")
    total.ok(S4, all(a[k] == 4 * a[k - 1] + 2 * a[k - 2] - 4 * a[k - 3] for k in range(4, 42)),
             "recurrence a_k = 4a_{k-1} + 2a_{k-2} - 4a_{k-3} fails")
    Q = [1, -4, -2, 4]
    s1 = poly_mul_trunc([0] + [a[k] for k in range(1, 42)], Q, 42)
    total.ok(S4, s1 == [0, 1, 1, -2] + [0] * 38, lambda: f"sum_{{k>=1}} a_k t^k * Q = {s1[:6]}...")
    s3 = poly_mul_trunc([0, 0, 0] + [a[k] for k in range(3, 42)], Q, 42)
    total.ok(S4, s3 == [0, 0, 0, 20, 6, -20] + [0] * 36, lambda: f"sum_{{k>=3}} a_k t^k * Q = {s3[:7]}...")
    cubic_t = [4, -2, -4, 1]          # 4t^3 - 2t^2 - 4t + 1, high first
    total.ok(S4, all(pval(cubic_t, Fraction(sg * p_, q_)) != 0 for sg in (1, -1) for p_ in (1,) for q_ in (1, 2, 4)),
             "4t^3 - 2t^2 - 4t + 1 has a rational root")
    total.ok(S4, all(pval(cubic_t, r_) != 0 for r_ in (Fraction(0), Fraction(1), Fraction(-1, 2))),
             "denominator shares a root with t(1-t)(1+2t)")
    cubic = [1, -4, -2, 4]            # theta^3 - 4 theta^2 - 2 theta + 4
    sgn = lambda t: pval(cubic, Fraction(t))  # noqa: E731
    total.ok(S4, sgn(-2) < 0 < sgn(-1) and sgn(1) < 0 < sgn(0)
             and sgn(Fraction(4249, 1000)) < 0 < sgn(Fraction(4250, 1000)),
             "sign changes of the characteristic polynomial")
    M2 = [[sum(Mx[r][t] * Mx[t][s] for t in range(3)) for s in range(3)] for r in range(3)]
    total.ok(S4, M2 == [[10, 8, 2], [8, 8, 2], [4, 4, 2]] and all(v > 0 for row in M2 for v in row),
             lambda: f"M^2 = {M2}")
    total.ok(S4, all(4249 * a[k - 1] < 1000 * a[k] < 4250 * a[k - 1] for k in range(12, 41)),
             "a_k / a_{k-1} not in (4.249, 4.25) for some 12 <= k <= 40")
    # A-iv(GF): exact certificates
    for pat, (N, Qp) in GF_CLAIMS.items():
        p = len(pat)
        D = pat[0] * pat[1 % p] + 1
        B = p * D + max(len(Qp) - 1, len(N))
        cnts = periodic_counts(pat, GF_TERMS + 1)
        seq = [cnts[k] for k in range(2, GF_TERMS + 2)]
        lhs = poly_mul_trunc(seq, Qp, GF_TERMS)
        total.ok(SG, B <= GF_TERMS and lhs == (N + [0] * GF_TERMS)[:GF_TERMS],
                 lambda: f"pattern {pat}: S*Q = {lhs[:8]}..., N = {N}, bound B = {B}")
        info.setdefault("gf", {})[pat] = (B, [cnts[k] for k in range(3, 9)])
        if pat in COUNT_CLAIMS:
            total.ok(SG, all(cnts[k] == v for k, v in COUNT_CLAIMS[pat].items()),
                     lambda: f"pattern {pat}: counts {[cnts[k] for k in range(3, 9)]}")
        # brute force over vectors for small k (the same rule, a separate count)
        for k in range(3, 9):
            content = tuple(pat[i % p] for i in range(k))
            if prod(content[e] * content[e + 1] + 1 for e in range(k - 1)) <= 30000:
                total.ok(SG, brute_rigid_count(content) == cnts[k],
                         lambda: f"pattern {pat}, k={k}: brute force differs from transfer")
    return info


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------


def run(fn, args):
    return fn(*args)


def word_table(content: tuple) -> list:
    """(word, x-vector, {interval: count}) for every word of the content, counts from occ()."""
    k = len(content)
    out = []
    for w in words_of(content):
        x = tuple(occ(w, (e, e + 1)) for e in range(1, k))
        out.append((w, x, {(i, j): occ(w, interval(i, j)) for i in range(1, k) for j in range(i + 1, k + 1)}))
    return out


def check_parent_extras(total: Rec, R: dict) -> dict:
    """Cheap sections run in the parent: L1.1 at profile level, L3.2(f), EXA, A-iii witnesses."""
    info = {}
    # L1.1: the conjugation is a bijection between the two profile sets
    L11 = "L1.1 projections, (1.1), conjugation"
    for b in range(1, R["CONJ_BC"] + 1):
        for c in range(1, R["CONJ_BC"] + 1):
            lams = list(combinations_with_replacement(range(b + 1), c))
            Cs = {Cr[::-1] for Cr in combinations_with_replacement(range(c + 1), b)}
            images = set()
            ok = True
            for lam in lams:
                C = conj_lam_to_C(lam, b)
                if not (C in Cs and sum(C) == sum(lam) and conj_C_to_lam(C, c) == lam):
                    ok = False
                images.add(C)
            total.ok(L11, ok and images == Cs, lambda: f"conjugation is not a bijection for (b,c)=({b},{c})")
    # L3.2(f): the decreasing word, every positive content, every wide (j,m,l)
    SL = "L3.2 minor identity"
    n_desc = 0
    for k in range(3, R["DESC_K"] + 1):
        for content in product(range(1, R["DESC_N"] + 1), repeat=k):
            wd = tuple(m for m in range(k, 0, -1) for _ in range(content[m - 1]))
            cnt = interval_counts(wd, k)
            for j in range(1, k + 1):
                for m in range(j + 1, k + 1):
                    for l in range(m + 1, k + 1):
                        if j == m - 1 and l == m + 1:
                            continue
                        G, Y = cnt[j][m - 1], cnt[m + 1][l]
                        D = cnt[j][l] - Y * cnt[j][m] - G * cnt[m][l] + content[m - 1] * G * Y
                        n_desc += 1
                        total.ok(SL, D == 0 and occ(wd, (m + 1, m, m - 1)) > 0,
                                 lambda: f"(f) fails for the decreasing word of {content}, (j,m,l)=({j},{m},{l})")
    info["desc"] = n_desc
    w4321 = (4, 3, 2, 1)
    G = occ(w4321, (1, 2))
    D134 = occ(w4321, (1, 2, 3, 4)) - occ(w4321, (4,)) * occ(w4321, (1, 2, 3)) - G * occ(w4321, (3, 4)) \
        + occ(w4321, (3,)) * G * occ(w4321, (4,))
    total.ok(SL, G == 0 and D134 == 0 and occ(w4321, (4, 3, 2)) == 1,
             "example 4321 at (1,3,4): G = |w|_12 = 0, D = 0, contains 432")
    # EXA: examples quoted in the note, at word level (counts from occ())
    SE = "EXA examples of the note (word level)"
    t232 = word_table((2, 3, 2))

    def zset(table, xv, ij=(1, 3)):
        return {cnts[ij] for (_, x, cnts) in table if x == xv}

    total.ok(SE, zset(t232, (2, 1)) == {0} and 2 not in gamma_set(2, 3)
             and "N" in rigid_tags(2, 3, 2, 2, 1), lambda: f"(2,3,2) at (2,1): {zset(t232, (2, 1))}")
    total.ok(SE, zset(t232, (4, 5)) == {6} and 4 not in gamma_set(2, 3)
             and "Ch" in rigid_tags(2, 3, 2, 4, 5) and 2 * 4 + 2 * 5 - 12 == 6,
             lambda: f"(2,3,2) at (4,5): {zset(t232, (4, 5))}")
    t323 = word_table((3, 2, 3))
    total.ok(SE, zset(t323, (2, 2)) == {0, 2} and not rigid_tags(3, 2, 3, 2, 2),
             lambda: f"(3,2,3) at (2,2): {zset(t323, (2, 2))}")
    t353 = word_table((3, 5, 3))     # TR536 section 4, pp. 6-7: the fibres (7,7) and (7,6)
    total.ok(SE, zset(t353, (7, 7)) == {1, 2, 4, 5, 6, 7, 8, 9} and not rigid_tags(3, 5, 3, 7, 7)
             and zset(t353, (7, 6)) == set(range(9)) and not rigid_tags(3, 5, 3, 7, 6),
             lambda: f"(3,5,3): (7,7) gives {sorted(zset(t353, (7, 7)))}, (7,6) gives {sorted(zset(t353, (7, 6)))}")
    t2211 = word_table((2, 2, 1, 1))
    fibre = [(w, cnts) for (w, x, cnts) in t2211 if x == (2, 1, 0)]
    classes = {tuple(sorted(cnts.items())) for (_, cnts) in fibre}
    d = {w: cnts for (w, cnts) in fibre}
    total.ok(SE, len(fibre) == 12 and len(classes) == 2
             and {cnts[(1, 3)] for (_, cnts) in fibre} == {0, 1}
             and all(cnts[(1, 4)] == 0 and cnts[(2, 4)] == 0 for (_, cnts) in fibre)
             and d.get((4, 1, 2, 3, 2, 1), {}).get((1, 3)) == 1
             and d.get((4, 2, 1, 1, 3, 2), {}).get((1, 3)) == 0
             and not rigid_tags(2, 2, 1, 2, 1),
             lambda: f"Remark 4.2 example: {len(fibre)} words, {len(classes)} classes")
    for wd, z in (((1, 2, 3, 2, 1), 1), ((2, 1, 1, 3, 2), 0)):
        total.ok(SE, tuple(wd.count(m) for m in (1, 2, 3)) == (2, 2, 1)
                 and (occ(wd, (1, 2)), occ(wd, (2, 3)), occ(wd, (1, 2, 3))) == (2, 1, z),
                 lambda: f"partition-route-audit witness {wd}")
    # WIT example of section 4
    SW = "WIT A(ii) necessity witnesses"
    for wd, want in (((4, 3, 2, 1, 2, 1, 4, 3), (1, 0)), ((2, 1, 4, 3, 4, 3, 2, 1), (0, 1))):
        total.ok(SW, tuple(wd.count(m) for m in (1, 2, 3, 4)) == (2, 2, 2, 2)
                 and tuple(occ(wd, (e, e + 1)) for e in (1, 2, 3)) == (1, 2, 1)
                 and (occ(wd, (1, 2, 3)), occ(wd, (2, 3, 4))) == want,
                 lambda: f"example witness {wd}")
    total.ok(SW, not rigid_tags(2, 2, 2, 1, 2), "triple 1 of (2,2,2,2) at x = (1,2,1) should not be rigid")
    # A-iii: the witnesses of the proof are not rigid
    S3c = "A-iii completeness"
    ok3 = True
    for a_ in range(1, 16):
        for b_ in range(1, 16):
            for c_ in range(1, 16):
                if a_ >= 2 and b_ >= 2 and rigid_tags(a_, b_, c_, 2, b_ - 1):
                    ok3 = False
                if b_ >= 2 and c_ >= 2 and rigid_tags(a_, b_, c_, b_ - 1, 2):
                    ok3 = False
    total.ok(S3c, ok3, "a witness of the proof of Corollary A(iii) is rigid")
    return info


def main() -> int:
    t0 = time.perf_counter()
    R = RANGES
    print("== check_rigidity: Theorem A (rigidity) and Lemma 3.2, notes/article2-design.md section 3"
          " and notes/proof-rigidity-local.md" + ("  [--full]" if FULL else ""), flush=True)

    jobs = []
    # content jobs (heaviest first, for load balance)
    max_total = {k: max(R["MERGED_TOTAL"].get(k, 0), R["PLAIN_TOTAL"].get(k, 0),
                        R["LEMMA_TOTAL"].get(k, 0), R["K3_WORD_TOTAL"] if k == 3 else 0)
                 for k in (3, 4, 5, 6)}
    pow2_contents = {(2,) * k for k in range(3, R["POW2_WORD_K"] + 1)}
    content_jobs = []
    for k in (3, 4, 5, 6):
        for total in range(k, max_total[k] + 1):
            for content in compositions(total, k):
                opts = dict(
                    merged=total <= R["MERGED_TOTAL"].get(k, 0) or content in pow2_contents
                    or content in R["EXTRA_MERGED"],
                    plain=total <= R["PLAIN_TOTAL"].get(k, 0),
                    lemma=total <= R["LEMMA_TOTAL"].get(k, 0),
                    k3=k == 3 and total <= R["K3_WORD_TOTAL"],
                )
                opts["small"] = opts["lemma"] and total <= R["SMALL_TOTAL"]
                opts["crit"] = opts["lemma"] and total <= R["CRIT_TOTAL"].get(k, 0)
                cost = 0
                if opts["plain"] or opts["lemma"] or opts["k3"]:
                    cost += total ** 2 * (5 if opts["lemma"] else 1) * k ** total
                if opts["merged"]:
                    cost += 2 * k ** total
                content_jobs.append((cost, (task_content, (content, opts))))
    have = {job[1][1][0] for job in content_jobs}
    for content in sorted(pow2_contents | set(R["EXTRA_MERGED"])):
        if content not in have:
            opts = dict(merged=True, plain=False, lemma=False, k3=False, small=False, crit=False)
            content_jobs.append((2 * len(content) ** sum(content), (task_content, (content, opts))))
    for a in range(1, R["PROFILE_AC"] + 1):
        for b in range(1, R["PROFILE_B"] + 1):
            for c in range(1, R["PROFILE_AC"] + 1):
                jobs.append(((a + 1) ** b * (c + 1) ** b,
                             (task_profile, (a, b, c, R["SBP_AC"], R["SBP_B"]))))
    for b in range(1, R["FORMULA_MAX"] + 1):
        jobs.append((10 ** 6 * b * b, (task_formula, (b, R["FORMULA_MAX"]))))
    for a in range(1, R["LEMMA33_AB"] + 1):
        for b in range(1, R["LEMMA33_AB"] + 1):
            jobs.append((comb(a + b, b) * b * b, (task_lemma33, (a, b))))
    wit_contents = []
    for (k, nmax, tmax) in R["WIT"]:
        for content in product(range(1, nmax + 1), repeat=k):
            if sum(content) <= tmax:
                wit_contents.append(content)
                cost = prod(content[e] * content[e + 1] + 1 for e in range(k - 1)) * sum(content) * k * 40
                jobs.append((cost, (task_wit, (content,))))
    jobs.extend(content_jobs)
    jobs.sort(key=lambda j: -j[0])

    total = Rec()
    pow2_words = {}
    counts_words = {}
    try:
        pool = ProcessPoolExecutor(max_workers=WORKERS)
        results = pool.map(run, [j[1][0] for j in jobs], [j[1][1] for j in jobs], chunksize=4)
    except (OSError, PermissionError, NotImplementedError):  # no subprocesses: run serially
        pool = None
        results = (run(fn, args) for _, (fn, args) in jobs)
    for res in results:
        total.merge(res)
        if "pow2" in res.extra:
            k, vecs, nfib = res.extra["pow2"]
            pow2_words[k] = (vecs, nfib)
        counts_words.update(res.extra.get("counts", {}))
    if pool is not None:
        pool.shutdown()
    t_par = time.perf_counter() - t0

    # ---- A-iv (cheap, in the parent) ---------------------------------------------------------
    S4 = "A-iv (2^k) rigid vectors"
    tr = pow2_transfer(TRANSFER_K)
    brute = {}
    for k in range(3, R["VEC_BRUTE_K"] + 1):
        brute[k] = pow2_rigid_vectors(k)
        total.ok(S4, len(brute[k]) == tr[k],
                 lambda: f"k={k}: brute force {len(brute[k])} vs transfer {tr[k]}")
    for k, want in EXPECTED_POW2.items():
        total.ok(S4, tr[k] == want, lambda: f"k={k}: transfer {tr[k]}, claimed {want}")
    for k in range(3, R["POW2_WORD_K"] + 1):
        got = pow2_words.get(k)
        if not total.ok(S4, got is not None, f"(2^{k}) word-level data missing"):
            continue
        vecs, nfib = got
        total.ok(S4, nfib == 5 ** (k - 1), lambda: f"(2^{k}): {nfib} fibres, box has {5 ** (k - 1)}")
        total.ok(S4, vecs == sorted(brute[k]),
                 lambda: f"(2^{k}): single-class vectors ({len(vecs)}) != rigid vectors ({len(brute[k])})")
    info4 = check_A_iv(total, R)
    # word-level single-class counts of the periodic contents, where computed
    for pat, claims in COUNT_CLAIMS.items():
        for k, want in claims.items():
            content = tuple(pat[i % len(pat)] for i in range(k))
            if content in counts_words:
                total.ok("A-iv(GF) generating-function certificates", counts_words[content] == want,
                         lambda: f"{content}: {counts_words[content]} single-class fibres at word level, claimed {want}")
                total.stats["A-iv(GF) word-level contents"] += 1

    # ---- L3.2 worked examples, from occ() alone ---------------------------------------------
    def D_occ(w, j, m, l):
        G, Y = occ(w, interval(j, m - 1)), occ(w, interval(m + 1, l))
        return (occ(w, interval(j, l)) - Y * occ(w, interval(j, m)) - G * occ(w, interval(m, l))
                + occ(w, (m,)) * G * Y)

    SL = "L3.2 minor identity"
    # (j,l) = (m-1,m+1): D is |w|_{(m+1) m (m-1)}; for m = 2 that is |w|_321
    total.ok(SL, D_occ((3, 3, 2, 1, 2, 1), 1, 2, 3) == occ((3, 3, 2, 1, 2, 1), (3, 2, 1)) == 6,
             "example D(332121; 1,2,3) = |w|_321 = 6")
    # m = 3 in a 4-letter word: D(2,3,4) = |w|_432, which differs from |w|_321 here
    w = (4, 3, 2, 3, 1, 2)
    total.ok(SL, (D_occ(w, 2, 3, 4), occ(w, (4, 3, 2)), occ(w, (3, 2, 1))) == (3, 3, 1),
             lambda: f"example D(432312; 2,3,4) = |w|_432: {D_occ(w, 2, 3, 4), occ(w, (4, 3, 2))}")
    # the converse of the vanishing claim fails for wider j..l: 4321 contains 321, D(1,2,4) = 0
    total.ok(SL, (occ((4, 3, 2, 1), (3, 2, 1)), D_occ((4, 3, 2, 1), 1, 2, 4)) == (1, 0),
             "example 4321: contains 321 but D(1,2,4) = 0")
    total.ok(SL, (occ((4, 3, 2, 1), (4, 3, 2)), D_occ((4, 3, 2, 1), 1, 3, 4)) == (1, 0),
             "example 4321: contains 432 but D(1,3,4) = 0")
    infoX = check_parent_extras(total, R)

    # ---- report ------------------------------------------------------------------------------
    st = total.stats
    note = lambda s: print(f"   {s}", flush=True)  # noqa: E731
    note(f"A-i(1) profile level: 1 <= a,c <= {R['PROFILE_AC']}, 1 <= b <= {R['PROFILE_B']}: "
         f"{st['A-i(1) cells']} cells, {st['A-i(1) pairs']} profile pairs, "
         f"{st['A-i(1) rigid cells']} rigid cells")
    for key in sorted(k for k in st if k.startswith("A-i(1) rigid by ") or k.startswith("A-i(1) (E)")):
        note(f"   {key[7:]}: {st[key]}")
    note(f"A-i(2) formula level: 1 <= a,b,c <= {R['FORMULA_MAX']}: {st['A-i(2) cells']} cells, "
         f"{st['A-i(2) rigid cells']} rigid; Prop 3.4 criterion <=> not rigid in every cell "
         f"(literal per-h form on a, c <= 4)")
    note(f"A-i(3) word level: positive (a,b,c), a+b+c <= {R['K3_WORD_TOTAL']}: "
         f"{st['words enumerated, k=3']} words, {st['A-i(3) cells']} cells, "
         f"{st['A-i(3) rigid cells']} rigid")
    note(f"P3.4: Lemma 3.3/3.3' on all profiles with 1 <= a, b <= {R['LEMMA33_AB']} (A side; C side "
         f"with c = a); Prop 3.4 with its witnesses, Cor 3.5 and the layer i+j = b+1 "
         f"({st['P3.4 layer cells']} cells) on the A-i(1) range; (3.1) on {st['P3.4 (3.1) pairs']} "
         f"profile pairs (a, c <= {R['SBP_AC']}, b <= {R['SBP_B']})")
    for k in (3, 4, 5, 6):
        note(f"A-ii k={k}: totals <= {R['MERGED_TOTAL'][k]} (state-merged search; word by word "
             f"<= {R['PLAIN_TOTAL'][k]}): {st[f'A-ii contents, k={k}']} contents, "
             f"{st[f'A-ii fibres, k={k}']} fibres, {st[f'A-ii single-class fibres, k={k}']} "
             f"single-class, {st[f'A-ii Parikh classes, k={k}']} classes")
    for k in (7,):
        if st[f"A-ii contents, k={k}"]:
            note(f"A-ii k={k}: {st[f'A-ii contents, k={k}']} extra contents, "
                 f"{st[f'A-ii fibres, k={k}']} fibres")
    note(f"A-ii extra contents (state-merged): {', '.join(map(str, R['EXTRA_MERGED']))}; on every fibre "
         f"also per-triple constancy, Cor 4.1, Remark 4.2 and the transfer count per content")
    for k in (3, 4, 5, 6):
        note(f"A-iii k={k}: {st[f'A-iii contents, k={k}']} contents, psi_2 determines the matrix "
             f"on {st[f'A-iii contents where psi_2 determines the matrix, k={k}']}")
    note("A-iv (2^k) rigid vectors, transfer matrix: "
         + ", ".join(f"k={k}: {tr[k]}" for k in range(3, TRANSFER_K + 1)))
    note(f"A-iv brute force over vectors agrees for k = 3..{R['VEC_BRUTE_K']}; word level "
         f"(single-class fibres = rigid vectors) for k = 3..{R['POW2_WORD_K']}; section 6 of the note "
         f"(M, recurrence, both series, roots, M^2 > 0, a_k/a_(k-1) for 12 <= k <= 40) exact; "
         f"a_40/a_39 = {info4['a'][40] / info4['a'][39]:.10f}")
    for pat, (B, cs) in info4["gf"].items():
        note(f"A-iv(GF) {pat}-periodic: N/Q certified (bound B = {B} <= {GF_TERMS} terms); counts k=3..8: {cs}")
    note(f"A-iv(GF) word-level single-class counts compared on {st['A-iv(GF) word-level contents']} "
         f"(content, claim) pairs")
    note("L3.2: " + ", ".join(f"k={k} totals <= {t}: {st[f'L3.2 words, k={k}']} words"
                              for k, t in sorted(R["LEMMA_TOTAL"].items()))
         + f"; {st['L3.2 instances']} (word, j<m<l) instances, {st['L3.2 instances with D>0']} "
           f"with D>0, {st['L3.2 instances avoiding (m+1)m(m-1)']} avoiding (m+1)m(m-1); "
           f"{st['L3.2 instances with D=0 that contain (m+1)m(m-1)']} with D=0 although w "
           f"contains (m+1)m(m-1), of which {st['L3.2 converse failures at (m-1,m,m+1)']} at "
           f"(j,l)=(m-1,m+1) (so the converse of the vanishing claim fails only for wider j..l), "
           f"{st['L3.2 converse failures with j < m-1, l = m+1']} with j < m-1 = l-2 and "
           f"{st['L3.2 converse failures with j = m-1, l > m+1']} with l > m+1 = j+2")
    note("L3.2(d) by chains: " + ", ".join(f"k={k}: {st[f'L3.2(d) words, k={k}']} words"
                                           for k in sorted(R["CRIT_TOTAL"]))
         + f"; by brute force over position triples: totals <= {R['SMALL_TOTAL']}")
    note(f"L3.2(f): decreasing word, k <= {R['DESC_K']}, n_i <= {R['DESC_N']}: {infoX['desc']} wide "
         f"(content, j, m, l) instances, all D = 0 with (m+1)m(m-1) present")
    n_N, n_Ch = st["Cor 2.1 (N') instances"], st["Cor 2.1 (Ch') instances"]
    note(f"Cor 2.1 on every L3.2 word: {n_N} (N') and {n_Ch} (Ch') instances")
    note(f"L1.1: projections, (1.1), the full product and the insertion construction on "
         f"{st['L1.1 contents (words, product, insertion)']} contents (totals <= {R['SMALL_TOTAL']}); "
         f"conjugation on every A-i(3) word and at profile level for b, c <= {R['CONJ_BC']}")
    note(f"WIT: {st['WIT contents']} contents ((k, max n_i, max total) in {list(R['WIT'])}), "
         f"{st['WIT non-rigid vectors']} non-rigid vectors, "
         f"{st['WIT (vector, non-rigid triple) pairs']} (vector, non-rigid triple) witness pairs built and checked")
    note(f"forward = backward interval counts on every L3.2 word; occ() cross-check, minor "
         f"determinant and degenerate cases: totals <= {R['SMALL_TOTAL']}; "
         f"state-merged = word-by-word on {st['merged = plain, contents']} contents")
    note(f"(parallel part {t_par:.1f} s with {WORKERS} workers)")

    n_checks = sum(s[0] for s in total.sec.values())
    n_fail = sum(s[1] for s in total.sec.values())
    for sec in sorted(total.sec):
        n, f, msgs = total.sec[sec]
        print(f"   {'ok  ' if f == 0 else 'FAIL'} {sec}: {n} checks, {f} failures", flush=True)
        for m in msgs:
            print(f"        - {m}")
    secs = time.perf_counter() - t0
    print(f"check_rigidity: {n_checks} checks, {n_fail} failures, {secs:.1f} s", flush=True)
    return 1 if n_fail else 0


if __name__ == "__main__":
    sys.exit(main())
