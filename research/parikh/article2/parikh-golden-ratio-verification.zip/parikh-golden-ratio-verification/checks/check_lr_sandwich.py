"""Article 2, Theorem F(iii)-(iv): the parity sandwich and its order-polytope transfer.

Gate check for Phase 1d: notes/article2-design.md, section 3 (Theorem F), section 4 (Target 4) and
section 8 (Phase 0b).  Python 3.11, standard library only.  The check is deterministic and uses
exact integer and Fraction arithmetic only: no float enters any assertion.  It accepts and ignores
unknown arguments (run_all.py passes e.g. --max-n), and --full runs the slow mode.  The exit status
is non-zero on any failure.

The question the gate answers: does the continuous transfer reproduce the discrete class sizes
EXACTLY?  It is answered by comparing the transfer with brute-force counts computed from scratch.
A passing check is evidence (VERIFIED, with the exact ranges below), not a proof.

SETTING (notes/proof-r7-switch.md section 1)
  Content (n^k): letters 1 < ... < k, each occurring n times, N = nk.  Edge i joins i and i+1, and
  x_i = |w|_{i(i+1)}.  The projection of w on edge 1 is lam = (lam_1 <= ... <= lam_n), where
  lam_t = number of 1's before the t-th 2.  Its area is sum(lam) = x_1.
  Z_k     The alternating class with edge 1 full, x = (n^2, 0, n^2, 0, ...).  As a poset of letter
          occurrences it is a fence of n-chains C_1 < C_2 > C_3 < C_4 > ...  Odd chains are LOW:
          each of their elements lies below every element of the neighbouring chains.  Even chains
          are HIGH.
  D_k(S)  For a set S of non-full edge-1 projections: the words whose edge-1 projection lies in S
          and which agree with Z_k on edges 2..k-1.  Those areas are extreme, so they fix the
          projections.  S_d is the set of all projections of area n^2 - d (the "edge-1 deficit"
          is d).  Then D_k(S_d) is the psi_2 fibre of (n^2 - d, 0, n^2, 0, ...).
  r_k(S)  = |D_k(S)| / e(Z_k).  For a singleton S = {lam}, write r_k(p) with p = lam_1: the size
          depends only on lam_1 (checked).

THE TRANSFER UNDER TEST (design, Target 4).  The bookkeeping below is worked out here.
  Stanley 1986: e(P) = |P|! vol O(P).  Collapse each low chain to its maximum t: the other n - 1
  elements lie below t, with weight w_n(t) = t^{n-1}/(n-1)!.  Collapse each high chain to its
  minimum m, with weight w_n(1-m).  A low chain lying entirely below a level u integrates to
  W_n(u) = u^n/n!.
  g_k(m) := the volume of C_3, ..., C_k given min C_2 = m.  Then
      g_2 = 1,   g_3 = W_n,   g_k = T g_{k-2},
      (T g)(m) = int_0^1 K(m, m') g(m') dm',   K(m, m') = w_n(1-m') W_n(min(m, m')).
  T is computed EXACTLY by splitting the integral at m' = m:
      (T g)(m) = int_0^m w_n(1-m') W_n(m') g(m') dm'  +  W_n(m) int_m^1 w_n(1-m') g(m') dm'.
  So every g_k is one polynomial in m with Fraction coefficients, of degree n(k-2).
  Edge-1 end weight.  For a projection lam with p = lam_1, the 2n elements of C_1 u C_2 form one
  chain, and min C_2 is its (p+1)-th element.  Its density is
      rho_p(m) = m^p/p! * (1-m)^{2n-1-p}/(2n-1-p)!.
  For Z (lam = (n, ..., n)), rho_n = W_n(m) w_n(1-m).  Then
      e(Z_k)   = N! int_0^1 rho_n(m) g_k(m) dm,
      |D_k(S)| = N! sum_{lam in S} int_0^1 rho_{lam_1}(m) g_k(m) dm,
  and rho_p / rho_n = c_p ((1-m)/m)^{n-p}, with c_p = n!(n-1)!/(p!(2n-1-p)!).
  Right-end relaxation (extra, for the two-end classes of F(iv)).  Let lam' be the projection of
  edge k-1, with lam'_t = number of (k-1)'s before the t-th k.
  - k even: C_{k-1} is low and meets C_{k-2} only through its maximum t.  With
    q = #{t : lam'_t < n}, the merged chain has density
    sigma(t) = t^{n-1+q}/(n-1+q)! (1-t)^{n-q}/(n-q)!, and the seed is G_4(m) = int_0^m sigma.
  - k odd: C_{k-1} is high and meets C_{k-2} only through its minimum m'.  With
    q = #{t : lam'_t = 0}, the density is sigma(m') = m'^q/q! (1-m')^{2n-1-q}/(2n-1-q)!, and the
    seed is G_5(m) = int_0^1 W_n(min(m, m')) sigma(m') dm'.
  Then G_k = T^j G_4 or T^j G_5, and the two-end class has N! sum int rho_{lam_1} G_k.  For Z's own
  right projection the seeds are g_4 and g_5 (checked).

DISCRETE METHODS (independent of the transfer and of each other; all written for this check)
  LIT    Literal enumeration of every word of (n^k) by depth-first search, with psi_2, the edge-1
         projection and, for the relevant fibres, the full Parikh key (all |w|_{j..l}).
         Spot-checked against checks/parikh.py occ (word-level subword counts).
  FIB    Class enumeration: a DP over the words, letter by letter, that counts the words with a
         prescribed psi_2.  The state is the number of copies of each letter placed, together with
         the partial area of every edge; it is pruned by the attainable area interval.
  TRACE  Linear extensions of a trace-class poset (all edge projections prescribed): a DP over
         the downsets (c_1, ..., c_k).  The s-th copy of a may be placed only when exactly
         lam^{(a-1)}_s copies of a-1, and exactly #{t : lam^{(a)}_t < s} copies of a+1, precede it.
  INS    Chain insertion: insert the chains 3, 4, ..., k one at a time.  A low chain goes before the
         first copy of the previous letter, a high chain after its last copy.  The state is that
         one position.
  LOG    The saved outputs of the earlier exploration and certification runs:
         notes/r7-scripts/general/out/{growth_2k, growth_3k, relax_2k, relax_3k}.txt and
         notes/r7-scripts/proof-switch/out/{c1_certify_k3_11, c1_certify_k12,
         end_relaxed_100_8_31}.txt.
  STURM  Exact sign of a polynomial on (0,1).  Divide out m^a (m-1)^b, take the square-free part,
         count roots in (0,1) with the Sturm sequence, isolate any roots by bisection, and evaluate
         p at rational points between them.
  BERN   A second, independent sign certificate: positive Bernstein coefficients on [0,1], with
         de Casteljau subdivision if needed.

SECTIONS
  [0] Toolkit self-tests: Beta integrals, division and gcd, and STURM/BERN on polynomials with known
      sign patterns.
  [1] Transfer identities:
      - T at rational points, recomputed by substituting before integrating;
      - g_4' = w_n(m) W_n(1-m);
      - the rho_p / rho_n identity;
      - the right seeds for Z's own projection are g_4 and g_5;
      - deg g_k = n(k-2).
      Mutation guard: three deliberately wrong variants must disagree with INS:
      - max(m, m') in K;
      - min C_2 taken as the p-th element (instead of the (p+1)-th);
      - g_3 = W_n(1-m).
      They disagree on 21, 20 and 14 of 28 values, i.e. on every value each variant can affect.
  [2] The discrete methods against each other (LIT = FIB = TRACE = INS), the single-class property
      of D_k(S_d), the dependence on lam_1 only, and the four end relaxations of equal size.
  [3] GATE (1), (2^k): the transfer against FIB, TRACE, INS and LOG.
  [4] GATE (2), (3^k): the transfer against FIB, TRACE, INS and LOG; the best one-end class.
  [5] GATE (3), r_3(n): the partition formula against the transfer, FIB, TRACE, INS and LIT, term
      by term.
  [6] Item (4), the three base likelihood-ratio inequalities, n = 2..8 (STURM and BERN), and their
      one-line proofs as polynomial identities.  Also: the full lr chain of the g_k, and a TP2
      guard for K on a rational grid.
  [7] Item (5), parity monotonicity of r_k, for every singleton p = lam_1 < n and every area class.
  [8] Theorem F(iv) consequences:
      - r_3(n) > 1 for 4 <= n <= 50, and the mu_1 <= 2 terms;
      - r_k(S_n) > 1 for n >= 4;
      - the n = 3 values and the (3^5) two-end class;
      - (3^3) is a tie at 20 (LIT, all classes);
      - n = 2: r_k <= r_4 = 50/53;
      - the bracket c_3 in [r_15, r_14];
      - the two-end classes, transfer against FIB and LOG.
  [9] Sweep: every transfer value computed anywhere in the run equals INS (it runs last, after
      [10], so it also covers every value [10] computes).
  [10] Finaliser (20 Oct 2026), one computational check for every claim of
      notes/proof-lr-sandwich.md, by brute force at small sizes and exact faster methods beyond
      (new discrete tools: INS in one pass up to kmax, FIB with free edges, word listing of a
      fibre, LIT class sizes, Euler numbers, the Mann-Whitney recurrence):
      [10a] Lemma 2.5 (degree, leading coefficient, g_k(0) = 0, g_k > 0 on (0,1]); Lemma 3.2 for
            n = 1; Lemmas 3.3-3.4 on pseudo-random pairs f <lr h (fixed LCG seed); the n = 1 chain.
      [10b] n = 1 (Remark 4.4): Euler numbers, |D_k| = k E_(k-1) - E_k, EM98 Fig. 5, A034428, LIT,
            the strict sandwich; the compact form of Thm 4.1(1); k = 2 (Cor 2.4(4)) against the
            Mann-Whitney recurrence of MW47 section 4.
      [10c] Cor 4.3 on every one-end relaxation fibre (FIB with the end edge free).
      [10d] n = 3: r_4 = 399/331; the nine (3^5) one-end values; all (3^5) fibres (A,0,9,B); the
            fibre (6,0,9,3) and its mirror listed word by word (one Parikh class); (3^3) and (3^2)
            classes; the best one-end class of (3^k) up to k = 20 [40].
      [10e] n = 2: Cor 5.6 for every area; a_0, a_1 by TRACE; (2^4) by LIT; the two-end
            relaxations ((2^3) by LIT; 4 <= k <= 9 [12] by FIB).
      [10f] Prop 5.2 details; Cor 5.7 (exact r_14, r_15; directed decimals; r_29, r_30; n = 2
            r_59, r_60); the [Y26a] Thm 2 overlap at k = 3.

RESULTS (VERIFIED: exact; default mode, with the --full extensions in brackets)
  Runtime on the authoring machine (8 cores):
  - default: 10 s at load average ~10, 29 s at ~158;
  - --full: 148 s at ~10, 470 s at ~150 (58 MB).
  Every --full run is logged in notes/article2-scripts/lr_sandwich/full_run_{1,2,3}.log.  Run 1
  predates the mutation guard, the sweep and the links g_{2j} <lr g_{2j+1}.
  With the finaliser's section [10] (20 Oct 2026): default 12-17 s at load ~9 (6,947 checks);
  --full 155-169 s at load ~9-10 (11,874 checks).  Logs of the final runs (about 12 s and 155 s):
  notes/article2-scripts/proof-sandwich/out/check_lr_sandwich_{default,full}.log.
  GATE PASS: the transfer reproduces every discrete count exactly, in 711 [856] gate comparisons.
  (1) (2^k).  e(Z_k) and every |D_k(lam)| (lam_1 = 0, 1), hence every area class (deficits 1..4):
      - INS, 2 <= k <= 26;
      - FIB (every area) and TRACE (every projection), k <= 12 [16];
      - LIT, k <= 5 [6];
      - LOG: c1_certify, k = 3..12 (k = 12: e(Z) = 610397072367165, R = 515181809220930);
        growth_2k, k = 2..26; relax_2k, k = 3..16; the end_relaxed ratios, k = 3..22 and 60.
      The best one-end class is the deficit-2 class for 3 <= k <= 26.
  (2) (3^k), 2 <= k <= 15.
      - e(Z_k) and every area class (deficits 1..9): INS for every k; FIB, k <= 11 [15];
        TRACE (every projection), k <= 9 [12]; LIT, k <= 4.
      - LOG: growth_3k (best one-end class), k = 2..15; relax_3k, k = 3..10.
      - The best one-end class is the deficit-3 class for every 3 <= k <= 15.
      - Its ratio is 1962796290/1942824800 at k = 7, and 1.026443 to 6 decimals at k = 15.
  (3) r_3(n) = sum_{mu |- n} C(2n - mu_1, n)/C(2n, n), against the transfer, FIB, TRACE and INS for
      n <= 8, and LIT for n <= 5 [6].  Term by term: |D_3(lam)| = C(n + lam_1, n), so the term of
      mu is C(2n - mu_1, n) with mu_1 = n - lam_1.  Values 71/70, 41/36, 32/21 at n = 4, 5, 6.
      For n = 1..8: 1/2, 2/3, 3/4, 71/70, 41/36, 32/21, 1951/1144, 13976/6435.
  (4) n = 2..8, by both STURM and BERN:
      - g_4' > 0 on (0,1);
      - (g_4/g_3)' < 0 and (g_5/g_3)' < 0 on (0,1).
      The inequalities are strict, which is more than the claimed weak monotonicity.  The one-line
      proofs hold as polynomial identities:
      - g_4' = w_n(m) W_n(1-m);
      - (Tg)' W_n - (Tg) W_n' = -W_n'(m) int_0^m w_n(1-m') W_n(m') g(m') dm', for g = g_2, g_3.
      Lr chain, by BERN, for n = 2..6 [2..8] and k <= 15:
        g_2 <lr g_4 <lr ... <lr g_14 <lr g_15 <lr g_13 <lr ... <lr g_5 <lr g_3.
      Every link is strict on (0,1): g_{2j} <lr g_{2j+2}, g_{2j+1} <lr g_{2j-1},
      g_{2j+2} <lr g_{2j+1} and g_{2j} <lr g_{2j+1}.  STURM confirms it for n = 2, 3 and
      k <= 9 [11].
  (5) r_3 < r_5 < ... < r_15 < r_14 < ... < r_4 < r_2, strictly:
      - for every singleton p = lam_1 in {0..n-1} (hence for every nonempty S, a sum of
        singletons) and for every area class;
      - for n = 2..6 [2..8] and 2 <= k <= 15;
      - [and for n = 2 up to k = 60, n = 3 up to k = 30].
      Every value used here equals INS (section [9]), and FIB in the ranges above.
  F(iv).
      - r_3(n) > 1 for 4 <= n <= 50; r_3 = 2/3, 3/4 at n = 2, 3.
      - The mu_1 <= 2 terms alone exceed 1 exactly for 6 <= n <= 50 (not for n = 4, 5).
      - r_k(S_n) > 1 for 4 <= n <= 8 and 3 <= k <= 15.
      - n = 3: r_4 = 798/662 and r_7 = 1962796290/1942824800.  r_k(S_3) > 1 for every
        4 <= k <= 15 except k = 5 (r_5 = 55020/57400).
      - (3^5): the two-end class (6,0,9,3) has 66024 > 57400 words.  (3^3): the largest class has
        20 = e(Z) words, attained by 6 classes.
      - n = 2: r_4(S_2) = 50/53 and r_k(S_2) <= 50/53 for 3 <= k <= 60.
      - n = 3: both parity limits lie in the open interval (r_15, r_14), inside
        (1.026442, 1.026594) (lower end truncated, upper end rounded up).  [With k <= 30: inside
        (r_29, r_30), within (1.026491718, 1.026491722); n = 2: inside (r_59, r_60), within
        (0.843915414, 0.843915415).  Consistent with the design's c_2 ~ 0.843915, c_3 ~ 1.02649.]
        (The 20 Oct gate run printed these brackets with rounded endpoints; [10f] asserts the
        directed ones.)
      - Two-end classes: transfer = FIB on every pair of end areas for (2^k), 4 <= k <= 9 [12],
        and (3^k), 4 <= k <= 7 [10]; = LOG (relax_2k, relax_3k, "two-end" column), k <= 16 and
        k <= 10.
  [10] (finaliser; default [--full]):
      - Lemma 2.5 for n = 1..6 [8], k <= 15; 40 [144] pseudo-random pairs for Lemmas 3.3-3.4, all
        strict; the n = 1 lr chain (25 links).
      - n = 1: |D_k| = k E_(k-1) - E_k and e(Z_k) = E_k for k <= 30, = EM98 Fig. 5 column 0
        (k = 3..12) = A034428 (k = 2..19); LIT k <= 8 [9]; strict sandwich k <= 30.  Compact form
        of Thm 4.1(1): 960 [2100] comparisons for n = 1..5, k <= 16 [n <= 6, k <= 20].  k = 2:
        words of (n, n) <-> projections; |S_A| = Mann-Whitney frequency, n <= 6.
      - Cor 4.3: 252 [368] one-end relaxation fibres: n = 2 with k <= 7 [8], n = 3 with k <= 5
        [6], n = 4 with k = 3 [k <= 4].
      - (3^5): one-end values 4410, 4410, 8820, 24780, 24780, 36330, 55020, 50610, 34650 (all
        < 57400); the largest two-end fibre (A,0,9,B) is (6,0,9,3) = 66024, one Parikh class
        (66024 words listed), and likewise its mirror.  (3^3): 218 classes, six of size 20.
        (3^2): the alternating classes have 1 word, the fibres x_1 = 3..6 have 3.  Best one-end
        class of (3^k): A = 6 for 3 <= k <= 20 [40].
      - n = 2: r_k(S_A) < 50/53 for 3 <= k <= 60 and A = 0..3 except r_4(S_2) = 50/53.  Two-end
        relaxations: (2^3) tie at 6 (classes (2,0,2), (2,2,2)); for 4 <= k <= 9 [12] the largest
        is at end areas (2,2), always below e(Z): 28, 680, 12692, 426720, 16942340, 899527392
        [, 58128195140, 4606648680480, 434586816546900].
      - r_14, r_15 exact; (r_15, r_14) inside (1.026442860, 1.026593038); (r_29, r_30) inside
        (1.0264917187, 1.0264917215); n = 2: (r_59, r_60) inside (0.843915414, 0.843915415).
      - [Y26a] Thm 2 (p. 5) by reversal: |D_3(S_A)| = p(A) for A < n and p(n) + n for A = n
        (n <= 6).
  No claim of Theorem F(iii)-(iv), and no number in the design's synthesis finding 1, was found
  false in these ranges, so no statement here is corrected.
  Not checked here: the TP2/basic-composition proof itself (only a grid guard, test pairs and
  its consequence, the lr chain); limits as k -> infinity; classes other than the
  relaxed-alternating ones (C1, C3 maximality).  The proof's own exact computations are also in
  notes/article2-scripts/proof-sandwich/{sandwich_exact.py, sandwich_final.py}.

Credit: e(P) = |P|! vol O(P) is Stanley, Two poset polytopes, Discrete Comput. Geom. 1 (1986).
The locator is a priority item (design section 7, P4) and is not checked here.  The transfer route
is the design panel's (unify's Theorem E).  The discrete definitions are those of
notes/proof-r7-switch.md sections 1, 6, 7 and notes/explore-r7-general.md section 5.
"""

from __future__ import annotations

import re
import sys
import time
from fractions import Fraction
from itertools import combinations, combinations_with_replacement
from math import comb, factorial
from pathlib import Path

ARGS = sys.argv[1:]
FULL = "--full" in ARGS
T0 = time.perf_counter()
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
GEN_OUT = ROOT / "notes" / "r7-scripts" / "general" / "out"
SW_OUT = ROOT / "notes" / "r7-scripts" / "proof-switch" / "out"

NCHECK = [0]
FAIL: list[str] = []
GATE_N = [0]
GATE_FAIL: list[str] = []


def ok(cond: bool, msg: str, gate: bool = False) -> bool:
    NCHECK[0] += 1
    if gate:
        GATE_N[0] += 1
    if not cond:
        FAIL.append(msg)
        if gate:
            GATE_FAIL.append(msg)
        print("  FAIL:", msg, flush=True)
    return bool(cond)


SEC_FAIL0 = [0]


def section(title: str) -> None:
    SEC_FAIL0[0] = len(FAIL)
    print(f"[{time.perf_counter() - T0:6.1f} s] {title}", flush=True)


def note(text: str) -> None:
    """A summary line; flagged if any check of the current section has failed."""
    bad = len(FAIL) - SEC_FAIL0[0]
    print("     " + text + (f"   [!! {bad} FAILURE(S) IN THIS SECTION]" if bad else ""), flush=True)


def dec(fr: Fraction, digits: int = 6) -> str:
    """Display only (never asserted): a Fraction rounded to `digits` decimals, exactly."""
    scaled = round(fr * 10 ** digits)
    sign = "-" if scaled < 0 else ""
    scaled = abs(scaled)
    return f"{sign}{scaled // 10 ** digits}.{scaled % 10 ** digits:0{digits}d}"


# =============================================================================================
# Exact polynomials in m: lists of Fractions, entry i = coefficient of m^i, trailing zeros trimmed
# =============================================================================================

ZERO, ONE = Fraction(0), Fraction(1)


def ptrim(a):
    a = list(a)
    while a and a[-1] == 0:
        a.pop()
    return a


def padd(a, b):
    out = [ZERO] * max(len(a), len(b))
    for i, c in enumerate(a):
        out[i] += c
    for i, c in enumerate(b):
        out[i] += c
    return ptrim(out)


def pscale(a, c):
    c = Fraction(c)
    return ptrim([x * c for x in a])


def psub(a, b):
    return padd(a, pscale(b, -1))


def pmul(a, b):
    if not a or not b:
        return []
    out = [ZERO] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b):
                out[i + j] += x * y
    return ptrim(out)


def pderiv(a):
    return ptrim([i * a[i] for i in range(1, len(a))])


def pint0(a):
    """The antiderivative vanishing at 0: m -> int_0^m a(t) dt."""
    return ptrim([ZERO] + [c / (i + 1) for i, c in enumerate(a)])


def peval(a, x):
    x = Fraction(x)
    v = ZERO
    for c in reversed(a):
        v = v * x + c
    return v


def integral01(a):
    return peval(pint0(a), 1)


def mono(i, c=1):
    return [ZERO] * i + [Fraction(c)]


def one_minus_pow(e):
    """(1 - m)^e."""
    return [Fraction(comb(e, i) * (-1) ** i) for i in range(e + 1)]


def pdivmod(a, b):
    a, b = ptrim(a), ptrim(b)
    if not b:
        raise ZeroDivisionError("polynomial division by zero")
    r = list(a)
    q = [ZERO] * max(len(a) - len(b) + 1, 0)
    lead = b[-1]
    while len(r) >= len(b):
        c = r[-1] / lead
        d = len(r) - len(b)
        q[d] = c
        for i, y in enumerate(b):
            r[i + d] -= c * y
        r.pop()  # its coefficient is now exactly 0
        r = ptrim(r)
    return ptrim(q), r


def pmonic(a):
    return pscale(a, 1 / a[-1])


def pgcd(a, b):
    a, b = ptrim(a), ptrim(b)
    while b:
        a, b = b, pdivmod(a, b)[1]
    return pmonic(a) if a else a


# ---------------------------------------------------------------------------------------------
# Exact sign tests on the open interval (0, 1)
# ---------------------------------------------------------------------------------------------


def strip_endpoints(p):
    """p = m^a (m - 1)^b r with r(0) != 0 and r(1) != 0; returns (a, b, r)."""
    p = ptrim(p)
    a = 0
    while p and p[0] == 0:
        p = p[1:]
        a += 1
    b = 0
    while p and peval(p, 1) == 0:
        p, rem = pdivmod(p, [Fraction(-1), ONE])
        assert not rem
        b += 1
    return a, b, p


def sturm_chain(s):
    chain = [s, pderiv(s)]
    while chain[-1]:
        r = pdivmod(chain[-2], chain[-1])[1]
        if not r:
            break
        chain.append(pscale(r, Fraction(-1) / abs(r[-1])))  # -rem, times a positive constant
    return [c for c in chain if c]


def sign_changes(chain, x):
    vals = [v for v in (peval(c, x) for c in chain) if v != 0]
    return sum(1 for i in range(len(vals) - 1) if (vals[i] > 0) != (vals[i + 1] > 0))


def sturm_signs_open01(p):
    """The set of signs (+1, 0, -1) that p takes on (0, 1), by Sturm sequences (exact)."""
    p = ptrim(p)
    if not p:
        return {0}
    _, b, r = strip_endpoints(p)
    s = pdivmod(r, pgcd(r, pderiv(r)))[0] if len(r) > 1 else r  # square-free part of r
    outer = -1 if b % 2 else 1  # sign of (m - 1)^b on (0, 1)
    if len(s) <= 1:
        return {outer * (1 if r[0] > 0 else -1)}
    chain = sturm_chain(s)
    if sign_changes(chain, 0) - sign_changes(chain, 1) == 0:
        return {outer * (1 if peval(r, 0) > 0 else -1)}
    # isolate the roots of s in (0, 1); test p between consecutive roots
    isolating = []
    stack = [(ZERO, ONE)]
    while stack:
        lo, hi = stack.pop()
        cnt = sign_changes(chain, lo) - sign_changes(chain, hi)
        if cnt == 0:
            continue
        if cnt == 1 and lo > 0 and hi < 1:
            isolating.append((lo, hi))
            continue
        mid = (lo + hi) / 2
        if peval(s, mid) == 0:  # an exact rational root: isolate it in a small interval
            d = (hi - lo) / 4
            while not (peval(s, mid - d) != 0 and peval(s, mid + d) != 0
                       and sign_changes(chain, mid - d) - sign_changes(chain, mid + d) == 1):
                d /= 2
            isolating.append((mid - d, mid + d))
            stack.append((lo, mid - d))
            stack.append((mid + d, hi))
        else:
            stack.append((lo, mid))
            stack.append((mid, hi))
    isolating.sort()
    tests = [isolating[0][0]] + [iv[1] for iv in isolating]
    signs = {0}
    for t in tests:
        assert 0 < t < 1
        v = peval(p, t)
        assert v != 0
        signs.add(1 if v > 0 else -1)
    return signs


def bernstein_coeffs(a):
    d = len(a) - 1
    return [sum(Fraction(comb(j, i), comb(d, i)) * a[i] for i in range(j + 1)) for j in range(d + 1)]


def de_casteljau_split(bc):
    left, right, cur = [], [], list(bc)
    while cur:
        left.append(cur[0])
        right.append(cur[-1])
        cur = [(cur[i] + cur[i + 1]) / 2 for i in range(len(cur) - 1)]
    return left, right[::-1]


def bernstein_positive01(r, maxdepth=48):
    """True iff r > 0 on [0, 1] is certified by positive Bernstein coefficients (with subdivision)."""
    r = ptrim(r)
    if not r:
        return False
    stack = [(bernstein_coeffs(r), 0)]
    while stack:
        bc, depth = stack.pop()
        if all(x > 0 for x in bc):
            continue
        if bc[0] <= 0 or bc[-1] <= 0 or depth >= maxdepth:
            return False
        left, right = de_casteljau_split(bc)
        stack.append((left, depth + 1))
        stack.append((right, depth + 1))
    return True


def bern_strict_sign_open01(p, sign):
    """Certify sign * p > 0 on (0, 1): write p = m^a (m-1)^b r, so p = m^a (1-m)^b ((-1)^b r)."""
    _, b, r = strip_endpoints(pscale(p, sign))
    return bernstein_positive01(pscale(r, -1 if b % 2 else 1))


# =============================================================================================
# The transfer
# =============================================================================================


def w_low(n):  # w_n(m) = m^{n-1}/(n-1)!
    return mono(n - 1, Fraction(1, factorial(n - 1)))


def w_high(n):  # w_n(1 - m)
    return pscale(one_minus_pow(n - 1), Fraction(1, factorial(n - 1)))


def W_low(n):  # W_n(m) = m^n/n!
    return mono(n, Fraction(1, factorial(n)))


def W_high(n):  # W_n(1 - m)
    return pscale(one_minus_pow(n), Fraction(1, factorial(n)))


def apply_T(g, n):
    """(T g)(m) = int_0^1 w_n(1-m') W_n(min(m, m')) g(m') dm', split at m' = m."""
    lower = pint0(pmul(pmul(w_high(n), W_low(n)), g))  # m' in [0, m]: min = m'
    F = pint0(pmul(w_high(n), g))
    upper = psub([peval(F, 1)], F)  # int_m^1 w_n(1-m') g(m') dm'
    return padd(lower, pmul(W_low(n), upper))  # m' in [m, 1]: min = m


def T_at_point(g, n, m0):
    """(T g)(m0), with m = m0 substituted BEFORE integrating the two pieces in m'."""
    m0 = Fraction(m0)
    piece_lo = pmul(pmul(w_high(n), W_low(n)), g)  # on [0, m0]
    piece_hi = pscale(pmul(w_high(n), g), peval(W_low(n), m0))  # on [m0, 1]
    A, B = pint0(piece_lo), pint0(piece_hi)
    return (peval(A, m0) - peval(A, 0)) + (peval(B, 1) - peval(B, m0))


G_CACHE: dict = {}


def g_poly(n, k):
    key = (n, k)
    if key not in G_CACHE:
        if k == 2:
            G_CACHE[key] = [ONE]
        elif k == 3:
            G_CACHE[key] = W_low(n)
        else:
            G_CACHE[key] = apply_T(g_poly(n, k - 2), n)
    return G_CACHE[key]


def rho(n, p):
    """Edge-1 end weight for lam_1 = p: the density of min C_2 = m in the merged chain C_1 u C_2."""
    return pscale(pmul(mono(p), one_minus_pow(2 * n - 1 - p)),
                  Fraction(1, factorial(p) * factorial(2 * n - 1 - p)))


S_CACHE: dict = {}


def transfer_single(n, k, p):
    """N! int_0^1 rho_p g_k: the transfer's value of |D_k(lam)| for lam_1 = p (p = n: e(Z_k))."""
    key = (n, k, p)
    if key not in S_CACHE:
        S_CACHE[key] = factorial(n * k) * integral01(pmul(rho(n, p), g_poly(n, k)))
    return S_CACHE[key]


def mutant_single(n, k, p, kind):
    """Deliberately WRONG variants of the transfer (mutation guard in section [1])."""
    def T_max(g):  # max(m, m') in place of min(m, m')
        F1 = pint0(pmul(w_high(n), g))
        part_lo = pmul(W_low(n), F1)  # m' in [0, m]: W_n(m) int_0^m w_n(1-m') g
        F2 = pint0(pmul(pmul(w_high(n), W_low(n)), g))
        return padd(part_lo, psub([peval(F2, 1)], F2))  # m' in [m, 1]: int_m^1 w W_n(m') g

    step = T_max if kind == "max" else (lambda g: apply_T(g, n))
    g = [ONE] if k % 2 == 0 else (W_high(n) if kind == "seed" else W_low(n))
    for _ in range((k - 2) // 2 if k % 2 == 0 else (k - 3) // 2):
        g = step(g)
    if kind == "shift" and p >= 1:  # min C_2 taken as the p-th element of the merged chain
        wt = pscale(pmul(mono(p - 1), one_minus_pow(2 * n - p)),
                    Fraction(1, factorial(p - 1) * factorial(2 * n - p)))
    else:
        wt = rho(n, p)
    return factorial(n * k) * integral01(pmul(wt, g))


def projections(n):
    """All projections of an n x n edge: weakly increasing tuples with entries in [0, n]."""
    return list(combinations_with_replacement(range(n + 1), n))


def transfer_area(n, k, area):
    """The transfer's value of the edge-1 relaxed class with area `area` (deficit n^2 - area)."""
    return sum(transfer_single(n, k, lam[0]) for lam in projections(n) if sum(lam) == area)


def right_seed(n, k, q):
    """G_4 (k even) or G_5 (k odd) for a right-end projection with statistic q (docstring)."""
    if k % 2 == 0:
        sigma = pscale(pmul(mono(n - 1 + q), one_minus_pow(n - q)),
                       Fraction(1, factorial(n - 1 + q) * factorial(n - q)))
        return pint0(sigma)
    sigma = pscale(pmul(mono(q), one_minus_pow(2 * n - 1 - q)),
                   Fraction(1, factorial(q) * factorial(2 * n - 1 - q)))
    lower = pint0(pmul(W_low(n), sigma))
    F = pint0(sigma)
    return padd(lower, pmul(W_low(n), psub([peval(F, 1)], F)))


def right_q(n, k, lamR):
    return sum(1 for t in lamR if t < n) if k % 2 == 0 else sum(1 for t in lamR if t == 0)


TWO_CACHE: dict = {}


def transfer_two_end(n, k, p, q):
    """N! int rho_p G_k for k >= 4, with G_k = T^j (right seed)."""
    key = (n, k, p, q)
    if key not in TWO_CACHE:
        G = right_seed(n, k, q)
        for _ in range((k - 4) // 2 if k % 2 == 0 else (k - 5) // 2):
            G = apply_T(G, n)
        TWO_CACHE[key] = factorial(n * k) * integral01(pmul(rho(n, p), G))
    return TWO_CACHE[key]


def transfer_two_end_area(n, k, A1, A2):
    projs = projections(n)
    return sum(transfer_two_end(n, k, lam[0], right_q(n, k, lamR))
               for lam in projs if sum(lam) == A1 for lamR in projs if sum(lamR) == A2)


# =============================================================================================
# Discrete methods
# =============================================================================================


def z_vector(n, k):
    """psi_2 of Z_k: edge i (1-based) full for i odd, 0 for i even."""
    return tuple(n * n if i % 2 == 1 else 0 for i in range(1, k))


def z_projection(n, i):
    return (n,) * n if i % 2 == 1 else (0,) * n


def relaxed_vectors(n, k, d):
    """The four end relaxations with deficit d: (pattern Z or Z', left or right end) -> psi_2."""
    out = {}
    for pat in ("Z", "Z'"):
        base = list(z_vector(n, k)) if pat == "Z" else [n * n - v for v in z_vector(n, k)]
        for end, i in (("left", 0), ("right", k - 2)):
            v = list(base)
            v[i] = v[i] - d if v[i] == n * n else v[i] + d
            out[(pat, end)] = tuple(v)
    return out


def ins_count(n, k, p):
    """INS: |D_k(lam)| for lam_1 = p (p = n gives e(Z_k)), by chain insertion."""
    if k == 2:
        return 1
    length = 2 * n
    state = {p + 1: 1}  # position of the first 2 in the fixed block of 1's and 2's
    for j in range(3, k + 1):
        new: dict = {}
        if j % 2 == 1:  # low chain j: every copy before position f; the last copy lands at l
            for f, c in state.items():
                for l in range(n, f + n):
                    new[l] = new.get(l, 0) + c * comb(l - 1, n - 1)
        else:  # high chain j: every copy after position l; the first copy lands at f
            for l, c in state.items():
                for f in range(l + 1, length + 2):
                    new[f] = new.get(f, 0) + c * comb(length + n - f, n - 1)
        length += n
        state = new
    return sum(state.values())


def fib_count(content, x):
    """FIB: the number of words of `content` with psi_2 = x."""
    k = len(content)
    cur = {(tuple([0] * k), tuple([0] * (k - 1))): 1}
    for _ in range(sum(content)):
        new: dict = {}
        for (c, ar), w in cur.items():
            for a in range(k):
                if c[a] == content[a]:
                    continue
                c2 = list(c)
                c2[a] += 1
                ar2 = list(ar)
                if a >= 1:
                    ar2[a - 1] += c[a - 1]  # this copy of a has c[a-1] copies of a-1 before it
                good = True
                for i in (a - 1, a):  # the edges touching letter a
                    if 0 <= i <= k - 2:
                        left = content[i + 1] - c2[i + 1]
                        lo = ar2[i] + left * c2[i]
                        hi = ar2[i] + left * content[i]
                        if lo > x[i] or hi < x[i]:
                            good = False
                            break
                if good:
                    key = (tuple(c2), tuple(ar2))
                    new[key] = new.get(key, 0) + w
        cur = new
    total = 0
    for (c, ar), w in cur.items():
        assert ar == tuple(x)
        total += w
    return total


def trace_count(content, projs):
    """TRACE: the number of words with projection projs[i] on edge i+1 (linear extensions)."""
    k = len(content)
    need = []
    for a in range(k):
        row = []
        for s in range(1, content[a] + 1):
            left = projs[a - 1][s - 1] if a >= 1 else None
            right = sum(1 for t in projs[a] if t < s) if a <= k - 2 else None
            row.append((left, right))
        need.append(row)
    cur = {tuple([0] * k): 1}
    for _ in range(sum(content)):
        new: dict = {}
        for c, w in cur.items():
            for a in range(k):
                if c[a] == content[a]:
                    continue
                left, right = need[a][c[a]]
                if left is not None and c[a - 1] != left:
                    continue
                if right is not None and c[a + 1] != right:
                    continue
                c2 = c[:a] + (c[a] + 1,) + c[a + 1:]
                new[c2] = new.get(c2, 0) + w
        cur = new
    return sum(cur.values())


def trace_single(n, k, lam):
    """TRACE for D_k({lam}): edge-1 projection lam, Z's projections on edges 2..k-1."""
    return trace_count((n,) * k, [lam] + [z_projection(n, i) for i in range(2, k)])


def full_key(word, k):
    """All |w|_{j..l}, 1 <= j < l <= k, by the incremental rule |wa|_{j..a} += |w|_{j..a-1}."""
    c = [[0] * (k + 2) for _ in range(k + 2)]
    for a in word:
        for j in range(1, a):
            c[j][a] += c[j][a - 1]
        c[a][a] += 1
    return tuple(c[j][l] for j in range(1, k + 1) for l in range(j + 1, k + 1))


LIT_CACHE: dict = {}


def lit_enumerate(n, k, select):
    """LIT: every word of (n^k).  Returns (fibre sizes by psi_2, counts by edge-1 projection among
    the words agreeing with Z on edges 2..k-1, sets of full keys for psi_2 in `select`, #words)."""
    ck = (n, k, frozenset(select))
    if ck in LIT_CACHE:
        return LIT_CACHE[ck]
    for (n0, k0, sel0), res in LIT_CACHE.items():  # a superset selection serves too
        if (n0, k0) == (n, k) and sel0 >= ck[2]:
            return res
    N = n * k
    rem = [0] + [n] * k
    seen = [0] * (k + 2)
    x = [0] * (k + 1)
    lam1: list = []
    word: list = []
    fib: dict = {}
    proj: dict = {}
    keys: dict = {}
    zrest = z_vector(n, k)[1:]
    total = [0]

    def rec(depth):
        if depth == N:
            total[0] += 1
            v = tuple(x[1:k])
            fib[v] = fib.get(v, 0) + 1
            if v[1:] == zrest:
                lt = tuple(lam1)
                proj[lt] = proj.get(lt, 0) + 1
            if v in select:
                keys.setdefault(v, set()).add(full_key(word, k))
            return
        for a in range(1, k + 1):
            if rem[a]:
                rem[a] -= 1
                if a >= 2:
                    x[a - 1] += seen[a - 1]
                if a == 2:
                    lam1.append(seen[1])
                seen[a] += 1
                word.append(a)
                rec(depth + 1)
                word.pop()
                seen[a] -= 1
                if a == 2:
                    lam1.pop()
                if a >= 2:
                    x[a - 1] -= seen[a - 1]
                rem[a] += 1

    rec(0)
    LIT_CACHE[ck] = (fib, proj, keys, total[0])
    return LIT_CACHE[ck]


# =============================================================================================
# Partitions and logs
# =============================================================================================


def partitions(n, maxpart=None):
    if maxpart is None:
        maxpart = n
    if n == 0:
        yield ()
        return
    for first in range(min(n, maxpart), 0, -1):
        for rest in partitions(n - first, first):
            yield (first,) + rest


def r3_formula(n):
    """sum over partitions mu of n of C(2n - mu_1, n)/C(2n, n) (explicit partitions)."""
    return Fraction(sum(comb(2 * n - mu[0], n) for mu in partitions(n)), comb(2 * n, n))


def largest_part_counts(nmax):
    """L[n][j] = number of partitions of n with largest part exactly j (0 <= j <= n)."""
    atmost = [[0] * (nmax + 1) for _ in range(nmax + 1)]  # atmost[j][s]: parts <= j
    for j in range(nmax + 1):
        atmost[j][0] = 1
    for j in range(1, nmax + 1):
        for s in range(1, nmax + 1):
            atmost[j][s] = atmost[j - 1][s] + (atmost[j][s - j] if s >= j else 0)
    return [[atmost[j][s] - (atmost[j - 1][s] if j else 0) for j in range(s + 1)]
            for s in range(nmax + 1)]


def read_text(path):
    try:
        return path.read_text()
    except OSError:
        ok(False, f"saved log missing: {path}")
        return ""


def parse_growth(path):
    """growth_*.txt rows 'k W ez C R | ...' -> {k: (W, ez, C, R)}."""
    out = {}
    for line in read_text(path).splitlines():
        t = line.split()
        if len(t) >= 5 and t[0].isdigit():
            out[int(t[0])] = tuple(int(v) for v in t[1:5])
    return out


def parse_relax(path):
    """relax_*.txt rows 'k ez one ratio two ratio ...' -> {k: (ez, one, two)}."""
    out = {}
    for line in read_text(path).splitlines():
        t = line.split()
        if len(t) >= 6 and t[0].isdigit():
            out[int(t[0])] = (int(t[1]), int(t[2]), int(t[4]))
    return out


def parse_c1(paths):
    """c1_certify outputs -> {k: (W, e(Z), R)}."""
    pat = re.compile(r"\(2\^(\d+)\): W = (\d+), fibres = \d+ \(sum asserted\), e\(Z\) = (\d+), "
                     r"end-relaxed R = (\d+)")
    out = {}
    for path in paths:
        for m in pat.finditer(read_text(path)):
            out[int(m.group(1))] = (int(m.group(2)), int(m.group(3)), int(m.group(4)))
    return out


def parse_end_relaxed_ratios(path):
    """end_relaxed log, line (4): 'k:0.xxxxxx' pairs -> {k: Fraction}."""
    for line in read_text(path).splitlines():
        if line.startswith("(4) R_k/e(Z_k):"):
            return {int(a): Fraction(b) for a, b in re.findall(r"(\d+):(\d+\.\d+)", line)}
    return {}


def close6(fr, logged):
    """|fr - logged| <= 1/2 * 10^-6: agreement with a value printed to 6 decimals (exact)."""
    return abs(fr - logged) <= Fraction(1, 2 * 10 ** 6)


# =============================================================================================
# [0] toolkit
# =============================================================================================


def sec0():
    section("[0] exact polynomial toolkit and sign tests")
    for a in range(7):
        for b in range(7):
            ok(integral01(pmul(mono(a), one_minus_pow(b)))
               == Fraction(factorial(a) * factorial(b), factorial(a + b + 1)), f"Beta({a},{b})")
    f = pmul(pmul([Fraction(-1, 3), ONE], [Fraction(-1, 2), ONE]), [Fraction(2), ONE, ONE])
    g = pmul([Fraction(-1, 2), ONE], [Fraction(5), Fraction(-7)])
    q, r = pdivmod(f, g)
    ok(padd(pmul(q, g), r) == ptrim(f) and len(r) < len(g), "pdivmod: f = q g + r")
    ok(pgcd(f, g) == [Fraction(-1, 2), ONE], "pgcd")
    lin = lambda c: [Fraction(-c), ONE]  # noqa: E731  (m - c)
    cases = [
        ("(m-1/3)(m-2/3)", pmul(lin(Fraction(1, 3)), lin(Fraction(2, 3))), {1, 0, -1}),
        ("(m-1/2)^2 (m+1)", pmul(pmul(lin(Fraction(1, 2)), lin(Fraction(1, 2))), lin(-1)), {1, 0}),
        ("-(m-1/4)^2 (m-3/4)^2",
         pscale(pmul(pmul(lin(Fraction(1, 4)), lin(Fraction(1, 4))),
                     pmul(lin(Fraction(3, 4)), lin(Fraction(3, 4)))), -1), {-1, 0}),
        ("m^3 (1-m)^2 (2-m)", pmul(pmul(mono(3), one_minus_pow(2)), [Fraction(2), -ONE]), {1}),
        ("m^2 - 1/2", [Fraction(-1, 2), ZERO, ONE], {-1, 0, 1}),
        ("(m-1/3)(m-1/2)^2(m-2/3)",
         pmul(pmul(lin(Fraction(1, 3)), lin(Fraction(2, 3))),
              pmul(lin(Fraction(1, 2)), lin(Fraction(1, 2)))), {1, 0, -1}),
        ("-(1-m)^3 m (3 - m)", pscale(pmul(pmul(one_minus_pow(3), mono(1)), [Fraction(3), -ONE]), -1),
         {-1}),
        ("(m - 1/1000)(m - 2/1000)", pmul(lin(Fraction(1, 1000)), lin(Fraction(2, 1000))),
         {1, 0, -1}),
    ]
    for name, P, want in cases:
        ok(sturm_signs_open01(P) == want, f"Sturm signs of {name}: {sturm_signs_open01(P)} != {want}")
        if want in ({1}, {-1}):
            ok(bern_strict_sign_open01(P, 1 if want == {1} else -1), f"Bernstein certificate {name}")
        else:
            ok(not bern_strict_sign_open01(P, 1) and not bern_strict_sign_open01(P, -1),
               f"Bernstein must not certify {name}")
    # Sturm root counts of products of known linear factors (distinct roots in (0,1))
    roots = [Fraction(1, 7), Fraction(2, 7), Fraction(1, 2), Fraction(3, 5), Fraction(6, 7),
             Fraction(-1, 3), Fraction(4, 3)]
    for mask in range(1, 2 ** len(roots)):
        P = [ONE]
        for i, c in enumerate(roots):
            if mask >> i & 1:
                P = pmul(P, lin(c))
        inside = sum(1 for i, c in enumerate(roots) if mask >> i & 1 and 0 < c < 1)
        chain = sturm_chain(P)
        ok(sign_changes(chain, 0) - sign_changes(chain, 1) == inside, f"Sturm count, mask {mask}")


# =============================================================================================
# [1] transfer identities
# =============================================================================================


def sec1():
    section("[1] transfer identities (T at points, base-case derivative, end weights, seeds)")
    pts = [Fraction(1, 7), Fraction(1, 2), Fraction(5, 6)]
    for n in range(2, 9):
        for kk in (2, 3, 4, 5):
            for m0 in pts:
                ok(peval(apply_T(g_poly(n, kk), n), m0) == T_at_point(g_poly(n, kk), n, m0),
                   f"T g_{kk} at m = {m0}, n = {n}")
        # g_4' = w_n(m) W_n(1-m), g_4(0) = 0  (one-line proof that g_4 increases)
        ok(pderiv(g_poly(n, 4)) == pmul(w_low(n), W_high(n)) and peval(g_poly(n, 4), 0) == 0,
           f"g_4' = w_n(m) W_n(1-m), n = {n}")
        for kk in range(2, 16):
            ok(len(g_poly(n, kk)) - 1 == n * (kk - 2), f"deg g_{kk} = n(k-2), n = {n}")
        # rho_p m^{n-p} = c_p (1-m)^{n-p} rho_n,  c_p = n!(n-1)!/(p!(2n-1-p)!)
        for p in range(n + 1):
            cp = Fraction(factorial(n) * factorial(n - 1), factorial(p) * factorial(2 * n - 1 - p))
            ok(pmul(rho(n, p), mono(n - p)) == pscale(pmul(one_minus_pow(n - p), rho(n, n)), cp),
               f"rho_p/rho_n = c_p ((1-m)/m)^(n-p), n = {n}, p = {p}")
        ok(rho(n, n) == pmul(W_low(n), w_high(n)), f"rho_n = W_n(m) w_n(1-m), n = {n}")
        # right seeds for Z's own right projection
        ok(right_seed(n, 4, 0) == g_poly(n, 4), f"right seed G_4 for Z = g_4, n = {n}")
        ok(right_seed(n, 5, n) == g_poly(n, 5), f"right seed G_5 for Z = g_5, n = {n}")
        # e(Z_3) = C(2n, n) and |D_3(lam)| = C(n + lam_1, n)
        ok(transfer_single(n, 3, n) == comb(2 * n, n), f"transfer e(Z_3) = C(2n,n), n = {n}")
    # mutation guard: wrong bookkeeping must be detected by the discrete comparison
    mutants = {
        "K with max(m, m') in place of min": "max",
        "end weight shifted one position (m^{p-1})": "shift",
        "odd seed g_3 = W_n(1 - m)": "seed",
    }
    for label, kind in mutants.items():
        miss = sum(1 for n in (2, 3) for k in range(3, 7) for p in range(n + 1)
                   if mutant_single(n, k, p, kind) != ins_count(n, k, p))
        ok(miss > 0, f"mutation guard: {label} is not detected")
        note(f"mutation '{label}': {miss} of 28 values (n = 2, 3; k = 3..6) differ from INS")


# =============================================================================================
# [2] the discrete methods against each other
# =============================================================================================


def sec2():
    section("[2] discrete methods: LIT = FIB = TRACE = INS; one class; lam_1 only; four ends")
    contents = [(2, 2), (2, 3), (2, 4), (2, 5), (3, 2), (3, 3), (3, 4), (4, 2), (4, 3), (5, 3)]
    if FULL:
        contents += [(2, 6), (6, 3)]
    try:
        sys.path.insert(0, str(HERE))
        from parikh import occ  # word-level subword counts only
    except ImportError:  # pragma: no cover
        occ = None
    for n, k in contents:
        zv = z_vector(n, k)
        rel = {d: relaxed_vectors(n, k, d) for d in range(1, n * n + 1)} if k >= 3 else {}
        left = {d: (n * n - d,) + zv[1:] for d in range(1, n * n + 1)}
        select = {zv} | set(left.values())
        fib, proj, keys, total = lit_enumerate(n, k, select)
        ok(total == factorial(n * k) // factorial(n) ** k, f"LIT word count ({n}^{k})")
        ok(fib.get(zv, 0) == fib_count((n,) * k, zv) == trace_single(n, k, (n,) * n)
           == ins_count(n, k, n) == transfer_single(n, k, n), f"e(Z) five ways ({n}^{k})")
        for lam in projections(n):
            c = proj.get(lam, 0)
            ok(c == trace_single(n, k, lam) == ins_count(n, k, lam[0]),
               f"|D(lam)| LIT = TRACE = INS ({n}^{k}) lam = {lam}")
            ok(c == proj.get((lam[0],) + (n,) * (n - 1), 0) or lam[0] == n,
               f"|D(lam)| depends on lam_1 only ({n}^{k}) lam = {lam}")
        for d in range(1, n * n + 1):
            x = left[d]
            size = fib.get(x, 0)
            ok(size == fib_count((n,) * k, x)
               == sum(trace_single(n, k, lam) for lam in projections(n) if sum(lam) == n * n - d)
               == sum(ins_count(n, k, lam[0]) for lam in projections(n) if sum(lam) == n * n - d),
               f"|D(S_d)| LIT = FIB = TRACE = INS ({n}^{k}) d = {d}")
            ok(len(keys.get(x, set())) == 1, f"D(S_d) is one Parikh class ({n}^{k}) d = {d}")
            if k >= 3:
                ok(len({fib.get(v, 0) for v in rel[d].values()}) == 1,
                   f"four end relaxations of equal size ({n}^{k}) d = {d}")
        ok(len(keys.get(zv, set())) == 1, f"Z is one Parikh class ({n}^{k})")
        if occ is not None and k <= 4:
            base = sum(([a] * n for a in range(1, k + 1)), [])
            for w in (tuple(sorted(base, key=lambda a: (a % 2, a))), tuple(base[::-1]),
                      tuple(base[i] for i in range(0, len(base), 2)) + tuple(base[i] for i in range(1, len(base), 2))):
                key = tuple(occ(w, tuple(range(j, l + 1))) for j in range(1, k + 1) for l in range(j + 1, k + 1))
                ok(full_key(w, k) == key, f"full_key = parikh.occ on {w}")
    note("contents " + ", ".join(f"({n}^{k})" for n, k in contents)
         + ": every word enumerated; every agreement holds")


# =============================================================================================
# [3] GATE (1): (2^k)
# =============================================================================================


def sec3():
    section("[3] GATE (1): (2^k), transfer vs FIB / TRACE / INS / LOG")
    n = 2
    K_INS, K_DP = 26, (16 if FULL else 12)
    for k in range(2, K_INS + 1):
        for p in range(n + 1):
            ok(transfer_single(n, k, p) == ins_count(n, k, p), f"(2^{k}) p = {p}: transfer = INS", gate=True)
    for k in range(2, K_DP + 1):
        for lam in projections(n):
            ok(transfer_single(n, k, lam[0]) == trace_single(n, k, lam),
               f"(2^{k}) lam = {lam}: transfer = TRACE", gate=True)
        for A in range(n * n + 1):
            x = (A,) + z_vector(n, k)[1:]
            ok(transfer_area(n, k, A) == fib_count((n,) * k, x), f"(2^{k}) area {A}: transfer = FIB",
               gate=True)
    ez = {k: transfer_single(n, k, n) for k in range(2, 61)}
    R = {k: transfer_area(n, k, 2) for k in range(2, 61)}
    ok([ez[k] for k in range(2, 8)] == [1, 6, 53, 840, 18717, 585984], "e(Z(2^k)), k = 2..7 (design P8)")
    ok(ez[12] == 610397072367165 and R[12] == 515181809220930, "k = 12: e(Z), R (design)", gate=True)
    c1 = parse_c1([SW_OUT / "c1_certify_k3_11.txt", SW_OUT / "c1_certify_k12.txt"])
    ok(sorted(c1) == list(range(3, 13)), "c1_certify logs cover k = 3..12")
    for k, (W, e, r) in c1.items():
        ok(W == factorial(2 * k) // 2 ** k and e == ez[k] and r == R[k],
           f"c1_certify k = {k}: e(Z), R = transfer", gate=True)
    gr = parse_growth(GEN_OUT / "growth_2k.txt")
    ok(sorted(gr) == list(range(2, 27)), "growth_2k covers k = 2..26")
    for k, (W, e, _C, r) in gr.items():
        ok(W == factorial(2 * k) // 2 ** k and e == ez[k] and (r == R[k] or (k == 2 and r == 0)),
           f"growth_2k k = {k}: e(Z), R = transfer", gate=True)
        best = max(transfer_area(n, k, A) for A in range(n * n))
        ok(k == 2 or best == R[k], f"(2^{k}): the best one-end class is the deficit-2 class")
    rl = parse_relax(GEN_OUT / "relax_2k.txt")
    ok(sorted(rl) == list(range(3, 17)), "relax_2k covers k = 3..16")
    for k, (e, one, _two) in rl.items():
        ok(e == ez[k] and one == R[k], f"relax_2k k = {k}: e(Z), one-end = transfer", gate=True)
    er = parse_end_relaxed_ratios(SW_OUT / "end_relaxed_100_8_31.txt")
    ok(sorted(er) == list(range(3, 23)) + [60], "end_relaxed log lists k = 3..22 and 60")
    for k, v in er.items():
        ok(close6(Fraction(R[k], ez[k]), v), f"end_relaxed ratio k = {k} (6 decimals)", gate=True)
    note(f"INS k <= {K_INS}; FIB, TRACE k <= {K_DP}; LOG: c1_certify k = 3..12, growth_2k k = 2..26, "
         "relax_2k k = 3..16, end_relaxed ratios k = 3..22, 60")
    note(f"k = 12: e(Z) = {ez[12]}, R = {R[12]}, R/e(Z) = {dec(Fraction(R[12], ez[12]))}")
    return ez, R


# =============================================================================================
# [4] GATE (2): (3^k)
# =============================================================================================


def sec4():
    section("[4] GATE (2): (3^k), transfer vs FIB / TRACE / INS / LOG")
    n, K = 3, 15
    K_FIB, K_TR = (15, 12) if FULL else (11, 9)
    for k in range(2, K + 1):
        for p in range(n + 1):
            ok(transfer_single(n, k, p) == ins_count(n, k, p), f"(3^{k}) p = {p}: transfer = INS", gate=True)
    for k in range(2, K_TR + 1):
        for lam in projections(n):
            ok(transfer_single(n, k, lam[0]) == trace_single(n, k, lam),
               f"(3^{k}) lam = {lam}: transfer = TRACE", gate=True)
    for k in range(2, K_FIB + 1):
        for A in range(n * n + 1):
            x = (A,) + z_vector(n, k)[1:]
            ok(transfer_area(n, k, A) == fib_count((n,) * k, x), f"(3^{k}) area {A}: transfer = FIB",
               gate=True)
    ez = {k: transfer_single(n, k, n) for k in range(2, K + 1)}
    best, arg = {}, {}
    for k in range(2, K + 1):
        sizes = {9 - A: transfer_area(n, k, A) for A in range(9)}
        best[k] = max(sizes.values())
        arg[k] = sorted(d for d, v in sizes.items() if v == best[k])
    ok([ez[k] for k in range(2, 6)] == [1, 20, 662, 57400], "e(Z(3^k)), k = 2..5 (design P8)")
    ok(all(arg[k] == [3] for k in range(3, K + 1)), f"best one-end class = deficit 3, k = 3..15: {arg}")
    gr = parse_growth(GEN_OUT / "growth_3k.txt")
    ok(sorted(gr) == list(range(2, 16)), "growth_3k covers k = 2..15")
    for k, (W, e, _C, r) in gr.items():
        ok(W == factorial(3 * k) // 6 ** k and e == ez[k] and (r == best[k] or (k == 2 and r == 0)),
           f"growth_3k k = {k}: e(Z), best one-end = transfer", gate=True)
    rl = parse_relax(GEN_OUT / "relax_3k.txt")
    ok(sorted(rl) == list(range(3, 11)), "relax_3k covers k = 3..10")
    for k, (e, one, _two) in rl.items():
        ok(e == ez[k] and one == best[k], f"relax_3k k = {k}: e(Z), one-end = transfer", gate=True)
    r7 = Fraction(best[7], ez[7])
    ok(best[7] == 1962796290 and ez[7] == 1942824800, "k = 7: 1962796290/1942824800 (design)", gate=True)
    ok(close6(Fraction(best[15], ez[15]), Fraction("1.026443")), "k = 15: ratio 1.026443 (6 dec.)",
       gate=True)
    note(f"INS k <= {K}; FIB (every area) k <= {K_FIB}; TRACE (every projection) k <= {K_TR}; "
         "LOG growth_3k k = 2..15, relax_3k k = 3..10")
    note(f"k = 7: r = {best[7]}/{ez[7]} = {dec(r7)}; k = 15: r = {dec(Fraction(best[15], ez[15]))}")


# =============================================================================================
# [5] GATE (3): r_3(n)
# =============================================================================================


def sec5():
    section("[5] GATE (3): r_3(n) = sum_mu C(2n-mu_1, n)/C(2n, n), n <= 8")
    vals = {}
    lit_max = 6 if FULL else 5
    for n in range(1, 9):
        ez = transfer_single(n, 3, n)
        num = transfer_area(n, 3, n * n - n)
        x = (n * n - n, 0)
        ok(ez == comb(2 * n, n) == ins_count(n, 3, n) == fib_count((n,) * 3, (n * n, 0)),
           f"e(Z(n^3)) = C(2n, n), n = {n}", gate=True)
        ok(num == fib_count((n,) * 3, x), f"r_3 numerator: transfer = FIB, n = {n}", gate=True)
        lams = [lam for lam in projections(n) if sum(lam) == n * n - n]
        ok(num == sum(trace_single(n, 3, lam) for lam in lams) == sum(ins_count(n, 3, lam[0]) for lam in lams),
           f"r_3 numerator: transfer = TRACE = INS, n = {n}", gate=True)
        # term by term: the projection lam <-> the partition mu = (n - lam_t) of n; size C(2n - mu_1, n)
        mus = sorted(tuple(sorted((n - t for t in lam if n - t > 0), reverse=True)) for lam in lams)
        ok(mus == sorted(partitions(n)), f"area n^2 - n projections <-> partitions of n, n = {n}")
        for lam in lams:
            ok(transfer_single(n, 3, lam[0]) == trace_single(n, 3, lam) == comb(2 * n - (n - lam[0]), n),
               f"|D_3(lam)| = C(2n - mu_1, n), n = {n}, lam = {lam}", gate=True)
        if n <= lit_max:
            fib, _p, _k, _t = lit_enumerate(n, 3, set())
            ok(fib.get(x, 0) == num and fib.get((n * n, 0), 0) == ez, f"r_3: LIT, n = {n}", gate=True)
        vals[n] = Fraction(num, ez)
        ok(vals[n] == r3_formula(n), f"r_3(n) = partition formula, n = {n}", gate=True)
    ok((vals[4], vals[5], vals[6]) == (Fraction(71, 70), Fraction(41, 36), Fraction(32, 21)),
       "r_3 = 71/70, 41/36, 32/21 at n = 4, 5, 6 (design)", gate=True)
    note("r_3(n), n = 1..8: " + ", ".join(f"{vals[n]}" for n in range(1, 9))
         + f"  (LIT for n <= {lit_max})")


# =============================================================================================
# [6] item (4): base likelihood-ratio inequalities, the lr chain, TP2 guard
# =============================================================================================


def wronskian(g, h):
    """g h' - g' h: nonnegative on (0, 1) iff h/g is nondecreasing there (g <=_lr h)."""
    return psub(pmul(g, pderiv(h)), pmul(pderiv(g), h))


def sec6():
    section("[6] item (4): base lr inequalities n = 2..8 (Sturm, Bernstein); lr chain; TP2 guard")
    for n in range(2, 9):
        g3, g4, g5 = g_poly(n, 3), g_poly(n, 4), g_poly(n, 5)
        A = pderiv(g4)  # g_4 increasing:  A > 0
        B = psub(pmul(pderiv(g4), g3), pmul(g4, pderiv(g3)))  # (g_4/g_3)' g_3^2 < 0
        C = psub(pmul(pderiv(g5), g3), pmul(g5, pderiv(g3)))  # (g_5/g_3)' g_3^2 < 0
        for name, P, sg in (("g_4'", A, 1), ("(g_4/g_3)'", B, -1), ("(g_5/g_3)'", C, -1)):
            ok(sturm_signs_open01(P) == {sg}, f"Sturm: {name} has sign {sg} on (0,1), n = {n}")
            ok(bern_strict_sign_open01(P, sg), f"Bernstein: {name} has sign {sg} on (0,1), n = {n}")
        # one-line proofs as identities: (T g)' W_n - (T g) W_n' = -W_n' int_0^m w_n(1-m') W_n g
        for g, P in ((g_poly(n, 2), B), (g3, C)):
            Aint = pint0(pmul(pmul(w_high(n), W_low(n)), g))
            ok(P == pscale(pmul(pderiv(W_low(n)), Aint), -1), f"identity behind (Tg/W_n)' <= 0, n = {n}")
    # the full lr chain of the g_k (evidence for "T preserves <=_lr" and for transitivity):
    # g_2 < g_4 < ... (even), ... < g_5 < g_3 (odd), g_{2j+2} < g_{2j+1} and g_{2j} < g_{2j+1}
    def chain_links(K):
        return ([(k, k + 2) for k in range(2, K - 1, 2)]
                + [(k + 2, k) for k in range(3, K - 1, 2)]
                + [(k + 1, k) for k in range(3, K, 2)]
                + [(k, k + 1) for k in range(2, K, 2)])

    nmax, K = (8 if FULL else 6), 15
    links = 0
    for n in range(2, nmax + 1):
        for a, b in chain_links(K):  # g_a <lr g_b strictly on (0, 1)
            ok(bern_strict_sign_open01(wronskian(g_poly(n, a), g_poly(n, b)), 1),
               f"Bernstein: g_{a} <lr g_{b}, n = {n}")
            links += 1
    st_n, st_k = (3, 11) if FULL else (3, 9)
    for n in range(2, st_n + 1):
        for a, b in chain_links(st_k):
            ok(sturm_signs_open01(wronskian(g_poly(n, a), g_poly(n, b))) == {1},
               f"Sturm: g_{a} <lr g_{b}, n = {n}")
    # TP2 guard for K(m, m') = w_n(1-m') W_n(min(m, m')) on a rational grid
    grid = [Fraction(i, 10) for i in range(1, 10)]
    for n in range(2, 9):
        Kf = lambda m, mp: peval(w_high(n), mp) * peval(W_low(n), min(m, mp))  # noqa: E731
        bad = 0
        for i1, m1 in enumerate(grid):
            for m2 in grid[i1 + 1:]:
                for j1, p1 in enumerate(grid):
                    for p2 in grid[j1 + 1:]:
                        if Kf(m1, p1) * Kf(m2, p2) < Kf(m1, p2) * Kf(m2, p1):
                            bad += 1
        ok(bad == 0, f"TP2 grid guard, n = {n}")
    note("base inequalities strict for n = 2..8 by Sturm and by Bernstein; identities hold")
    note(f"lr chain: {links} strict links by Bernstein (n = 2..{nmax}, k <= {K}); Sturm n <= {st_n}, "
         f"k <= {st_k}; TP2 grid guard n = 2..8")


# =============================================================================================
# [7] item (5): parity monotonicity
# =============================================================================================


def sandwich_ok(r, K):
    """r_3 < r_5 < ... (odd, strictly increasing), r_2 > r_4 > ... (even, strictly decreasing),
    and the last odd < the last even (so every odd value is below every even value)."""
    odd = [r[k] for k in range(3, K + 1, 2)]
    even = [r[k] for k in range(2, K + 1, 2)]
    inc = all(odd[i] < odd[i + 1] for i in range(len(odd) - 1))
    decr = all(even[i] > even[i + 1] for i in range(len(even) - 1))
    return inc and decr and odd[-1] < even[-1]


def sec7():
    section("[7] item (5): parity monotonicity r_3 < r_5 < ... < r_6 < r_4 < r_2")
    nmax, K = (8 if FULL else 6), 15
    count = 0
    for n in range(2, nmax + 1):
        for k in range(2, K + 1):
            for p in range(n + 1):
                ok(transfer_single(n, k, p) == ins_count(n, k, p), f"({n}^{k}) p = {p}: transfer = INS")
        ez = {k: transfer_single(n, k, n) for k in range(2, K + 1)}
        for p in range(n):
            r = {k: Fraction(transfer_single(n, k, p), ez[k]) for k in range(2, K + 1)}
            ok(sandwich_ok(r, K), f"sandwich, singleton lam_1 = {p}, n = {n}, k <= {K}")
            count += 1
        for A in range(n * n):
            r = {k: Fraction(transfer_area(n, k, A), ez[k]) for k in range(2, K + 1)}
            ok(sandwich_ok(r, K), f"sandwich, area class {A}, n = {n}, k <= {K}")
            count += 1
    extra = ""
    if FULL:
        for n, Kx in ((2, 60), (3, 30)):
            ez = {k: transfer_single(n, k, n) for k in range(2, Kx + 1)}
            for p in range(n):
                r = {k: Fraction(transfer_single(n, k, p), ez[k]) for k in range(2, Kx + 1)}
                ok(sandwich_ok(r, Kx), f"sandwich, singleton {p}, n = {n}, k <= {Kx}")
            for A in range(n * n):
                r = {k: Fraction(transfer_area(n, k, A), ez[k]) for k in range(2, Kx + 1)}
                ok(sandwich_ok(r, Kx), f"sandwich, area {A}, n = {n}, k <= {Kx}")
            rd = {k: Fraction(transfer_area(n, k, n * n - n), ez[k]) for k in (Kx - 1, Kx)}
            note(f"n = {n}, deficit {n}: both parity limits lie in (r_{Kx - 1}, r_{Kx}), inside "
                 f"({floor_dec(rd[Kx - 1], 9)}, {ceil_dec(rd[Kx], 9)}) (display: lower end truncated, "
                 "upper end rounded up)")
        extra = "; also n = 2 with k <= 60 and n = 3 with k <= 30"
    note(f"{count} sequences (singletons p < n and area classes), n = 2..{nmax}, 2 <= k <= {K}: "
         f"strict sandwich; every term = INS{extra}")


# =============================================================================================
# [8] Theorem F(iv)
# =============================================================================================


def sec8(ez2, R2):
    section("[8] Theorem F(iv): r_3 > 1, n = 3 values, (3^5) two-end, (3^3) tie, n = 2, brackets")
    L = largest_part_counts(50)
    for n in range(1, 51):
        r3 = Fraction(sum(L[n][j] * comb(2 * n - j, n) for j in range(1, n + 1)), comb(2 * n, n))
        if n <= 15:
            ok(r3 == r3_formula(n), f"largest-part DP = explicit partitions, n = {n}")
        if n >= 4:
            ok(r3 > 1, f"r_3(n) > 1, n = {n}")
        low = Fraction(sum(L[n][j] * comb(2 * n - j, n) for j in (1, 2) if j <= n), comb(2 * n, n))
        ok((low > 1) == (n >= 6), f"mu_1 <= 2 terms > 1 iff n >= 6 (n = {n})")
    ok(r3_formula(2) == Fraction(2, 3) and r3_formula(3) == Fraction(3, 4), "r_3 = 2/3, 3/4 at n = 2, 3")
    for n in range(4, 9):
        for k in range(3, 16):
            ok(transfer_area(n, k, n * n - n) > transfer_single(n, k, n), f"r_k(S_n) > 1, n = {n}, k = {k}")
    # n = 3
    e3 = {k: transfer_single(3, k, 3) for k in range(2, 16)}
    c3 = {k: transfer_area(3, k, 6) for k in range(2, 16)}
    ok(Fraction(c3[4], e3[4]) == Fraction(798, 662) and (c3[4], e3[4]) == (798, 662), "n = 3: r_4 = 798/662")
    ok((c3[7], e3[7]) == (1962796290, 1942824800), "n = 3: r_7 = 1962796290/1942824800")
    ok(all((c3[k] > e3[k]) == (k != 5) for k in range(4, 16)), "n = 3: r_k > 1 for 4 <= k <= 15 except 5")
    ok((c3[5], e3[5]) == (55020, 57400), "n = 3: r_5 = 55020/57400 < 1")
    two = transfer_two_end_area(3, 5, 6, 3)
    ok(two == 66024 == fib_count((3,) * 5, (6, 0, 9, 3)) == fib_count((3,) * 5, (3, 9, 0, 6)),
       "(3^5): two-end class (6,0,9,3) = (3,9,0,6) = 66024 (transfer, FIB)")
    ok(two > e3[5], "(3^5): 66024 > 57400")
    ok(Fraction(c3[15], e3[15]) < Fraction(c3[14], e3[14]), "bracket: r_15 < r_14 (n = 3)")
    # (3^3): every Parikh class by LIT; largest = 20 = e(Z), attained by 6 classes
    sizes: dict = {}
    words: list = []

    def rec(w, rem):
        if not any(rem):
            words.append(tuple(w))
            return
        for a in range(3):
            if rem[a]:
                rem[a] -= 1
                w.append(a + 1)
                rec(w, rem)
                w.pop()
                rem[a] += 1

    rec([], [3, 3, 3])
    for w in words:
        key = full_key(w, 3)
        sizes[key] = sizes.get(key, 0) + 1
    top = max(sizes.values())
    ok(len(words) == 1680 and top == 20 and sum(1 for v in sizes.values() if v == 20) == 6,
       "(3^3): largest class 20 = e(Z), attained by 6 classes")
    # n = 2: r_k <= r_4 = 50/53 for 3 <= k <= 60
    ok(Fraction(R2[4], ez2[4]) == Fraction(50, 53), "n = 2: r_4 = 50/53")
    ok(all(Fraction(R2[k], ez2[k]) <= Fraction(50, 53) for k in range(3, 61)), "n = 2: r_k <= 50/53, k = 3..60")
    # two-end classes: transfer vs FIB, and the logs' best two-end classes
    for n, kmax in ((2, 12 if FULL else 9), (3, 10 if FULL else 7)):
        for k in range(4, kmax + 1):
            zv = z_vector(n, k)
            for A1 in range(n * n + 1):
                for A2 in range(n * n + 1):
                    x = (A1,) + zv[1:-1] + (A2,)
                    ok(transfer_two_end_area(n, k, A1, A2) == fib_count((n,) * k, x),
                       f"two-end ({n}^{k}) areas ({A1}, {A2}): transfer = FIB")
    for n, path, ks in ((2, GEN_OUT / "relax_2k.txt", range(4, 17)), (3, GEN_OUT / "relax_3k.txt", range(4, 11))):
        rl = parse_relax(path)
        for k in ks:
            zv = z_vector(n, k)
            own = (zv[0], zv[-1])
            best = max(transfer_two_end_area(n, k, A1, A2) for A1 in range(n * n + 1)
                       for A2 in range(n * n + 1) if (A1, A2) != own)
            ok(k in rl and rl[k][2] == best, f"relax log ({n}^{k}): best two-end class = transfer")
    note("r_3(n) > 1 for 4 <= n <= 50; mu_1 <= 2 terms > 1 exactly for 6 <= n <= 50")
    note(f"n = 3: r_4 = 798/662, r_5 = 55020/57400, r_7 = {c3[7]}/{e3[7]}; both parity limits lie in "
         f"(r_15, r_14), inside ({floor_dec(Fraction(c3[15], e3[15]), 6)}, "
         f"{ceil_dec(Fraction(c3[14], e3[14]), 6)}) (lower end truncated, upper end rounded up)")
    note("(3^5) two-end 66024 > 57400; (3^3) tie at 20 (6 classes); n = 2: r_k <= 50/53 for k <= 60")


def sec9():
    section("[9] sweep: every transfer value computed in this run equals INS")
    keys = sorted(S_CACHE)
    for n, k, p in keys:
        ok(S_CACHE[(n, k, p)] == ins_count(n, k, p), f"sweep: ({n}^{k}) p = {p}: transfer = INS")
    by_n: dict = {}
    for n, k, _p in keys:
        by_n[n] = max(by_n.get(n, 0), k)
    note(f"{len(keys)} values (n, k, lam_1); largest k per n: "
         + ", ".join(f"n = {n}: {by_n[n]}" for n in sorted(by_n)))


# =============================================================================================
# [10] Finaliser (20 Oct 2026): every computational claim of notes/proof-lr-sandwich.md, by
#      brute force at small sizes and exact faster methods beyond.  Added after the review; the
#      sections above are unchanged except for two display lines (directed decimals).
# =============================================================================================


def floor_dec(fr: Fraction, d: int) -> str:
    """Display: the decimal TRUNCATION of fr >= 0 to d places (a lower bound)."""
    s = (fr.numerator * 10 ** d) // fr.denominator
    return f"{s // 10 ** d}.{s % 10 ** d:0{d}d}"


def ceil_dec(fr: Fraction, d: int) -> str:
    """Display: fr >= 0 ROUNDED UP to d places (an upper bound)."""
    s = -((-fr.numerator * 10 ** d) // fr.denominator)
    return f"{s // 10 ** d}.{s % 10 ** d:0{d}d}"


INSP: dict = {}


def ins_profile(n, kmax, p):
    """INS in one pass: {k: |D_k(lam)|, 2 <= k <= kmax} for lam_1 = p.  The same chain-insertion DP
    as ins_count, recording the total after each chain (so it costs one run up to kmax)."""
    if (n, p) in INSP and max(INSP[(n, p)]) >= kmax:
        return INSP[(n, p)]
    out = {2: 1}
    length = 2 * n
    state = {p + 1: 1}
    for j in range(3, kmax + 1):
        new: dict = {}
        if j % 2 == 1:
            for f, c in state.items():
                for l in range(n, f + n):
                    new[l] = new.get(l, 0) + c * comb(l - 1, n - 1)
        else:
            for l, c in state.items():
                for f in range(l + 1, length + 2):
                    new[f] = new.get(f, 0) + c * comb(length + n - f, n - 1)
        length += n
        state = new
        out[j] = sum(state.values())
    INSP[(n, p)] = out
    return out


def ins_area(n, k, A, kmax=None):
    kk = max(k, kmax or k)
    return sum(ins_profile(n, kk, lam[0])[k] for lam in projections(n) if sum(lam) == A)


def fib_profile(content, x):
    """FIBP: the words of `content` whose area on edge i+1 equals x[i] whenever x[i] is not None.
    Returns {tuple of all final edge areas: number of words}.  (FIB with free edges.)"""
    k = len(content)
    cur = {((0,) * k, (0,) * (k - 1)): 1}
    for _ in range(sum(content)):
        new: dict = {}
        for (c, ar), wt in cur.items():
            for a in range(k):
                if c[a] == content[a]:
                    continue
                c2 = c[:a] + (c[a] + 1,) + c[a + 1:]
                ar2 = ar[:a - 1] + (ar[a - 1] + c[a - 1],) + ar[a:] if a >= 1 else ar
                good = True
                for i in (a - 1, a):
                    if 0 <= i <= k - 2 and x[i] is not None:
                        left = content[i + 1] - c2[i + 1]
                        if not (ar2[i] + left * c2[i] <= x[i] <= ar2[i] + left * content[i]):
                            good = False
                            break
                if good:
                    key = (c2, ar2)
                    new[key] = new.get(key, 0) + wt
        cur = new
    out: dict = {}
    for (_c, ar), wt in cur.items():
        out[ar] = out.get(ar, 0) + wt
    return out


def words_of_fibre(content, x):
    """Every word of `content` with psi_2 = x, listed (a depth-first search pruned like FIB)."""
    k = len(content)
    res: list = []
    w: list = []

    def rec(c, ar):
        if len(w) == sum(content):
            if ar == tuple(x):
                res.append(tuple(w))
            return
        for a in range(k):
            if c[a] == content[a]:
                continue
            c2 = c[:a] + (c[a] + 1,) + c[a + 1:]
            ar2 = ar[:a - 1] + (ar[a - 1] + c[a - 1],) + ar[a:] if a >= 1 else ar
            good = True
            for i in (a - 1, a):
                if 0 <= i <= k - 2:
                    left = content[i + 1] - c2[i + 1]
                    if not (ar2[i] + left * c2[i] <= x[i] <= ar2[i] + left * content[i]):
                        good = False
                        break
            if good:
                w.append(a + 1)
                rec(c2, ar2)
                w.pop()

    rec((0,) * k, (0,) * (k - 1))
    return res


def lit_class_sizes(content):
    """LIT: {full Parikh key: number of words}, over every word of `content`."""
    k = len(content)
    out: dict = {}
    rem = list(content)
    w: list = []

    def rec():
        if not any(rem):
            key = full_key(w, k)
            out[key] = out.get(key, 0) + 1
            return
        for a in range(k):
            if rem[a]:
                rem[a] -= 1
                w.append(a + 1)
                rec()
                w.pop()
                rem[a] += 1

    rec()
    return out


def euler_numbers(kmax):
    """E_0..E_kmax by the Seidel-Entringer (boustrophedon) triangle, independent of the transfer."""
    rows = [[1]]
    for m in range(1, kmax + 1):
        row = [0]
        for j in range(1, m + 1):
            row.append(row[j - 1] + rows[m - 1][m - j])
        rows.append(row)
    return [rows[m][m] for m in range(kmax + 1)]


def bernstein_to_monomial(bc):
    """sum_i bc[i] C(d,i) m^i (1-m)^(d-i) as a monomial-basis polynomial."""
    d = len(bc) - 1
    out: list = []
    for i, c in enumerate(bc):
        out = padd(out, pscale(pmul(mono(i), one_minus_pow(d - i)), comb(d, i) * Fraction(c)))
    return out


class Lcg:
    """A fixed linear congruential generator: deterministic pseudo-random test polynomials."""

    def __init__(self, seed):
        self.x = seed

    def next(self, lo, hi):
        self.x = (1103515245 * self.x + 12345) % 2 ** 31
        return lo + self.x % (hi - lo + 1)


def lr_strict(g, h):
    """g <lr h strictly on (0, 1), certified by Bernstein: the Wronskian g h' - g' h is > 0."""
    return bern_strict_sign_open01(wronskian(g, h), 1)


def chain_links(K):
    """The adjacent links of the lr chain g_2 < g_4 < ... < g_5 < g_3 (as in section [6])."""
    return ([(k, k + 2) for k in range(2, K - 1, 2)]
            + [(k + 2, k) for k in range(3, K - 1, 2)]
            + [(k + 1, k) for k in range(3, K, 2)]
            + [(k, k + 1) for k in range(2, K, 2)])


def sec10a():
    section("[10a] finaliser: Lemma 2.5 (shape of g_k); Lemmas 3.2-3.4 on test polynomials; n = 1 chain")
    nmax = 8 if FULL else 6
    for n in range(1, nmax + 1):
        for k in range(2, 16):
            g = g_poly(n, k)
            ok(len(g) - 1 == n * (k - 2), f"Lemma 2.5: deg g_{k} = n(k-2), n = {n}")
            if k >= 3:
                ok(g[0] == 0, f"Lemma 2.5: g_{k}(0) = 0, n = {n}")
            if k >= 4:
                d, a = n * (k - 4), g_poly(n, k - 2)[-1]
                lead = a * (-1) ** n * n / (factorial(n - 1) * factorial(n) * (2 * n + d) * (n + d))
                ok(g[-1] == lead, f"Lemma 2.5: leading coefficient of g_{k}, n = {n}")
            r = list(g)
            while r and r[0] == 0:
                r = r[1:]
            ok(bernstein_positive01(r), f"Lemma 2.5: g_{k} > 0 on (0, 1] (g = m^a r, r > 0 on [0,1]), n = {n}")
    # Lemma 3.2 for n = 1 (section [6] covers n = 2..8 on the same grid)
    grid = [Fraction(i, 10) for i in range(1, 10)]
    Kf = lambda m, mp: peval(w_high(1), mp) * peval(W_low(1), min(m, mp))  # noqa: E731
    bad = sum(1 for i1, m1 in enumerate(grid) for m2 in grid[i1 + 1:] for j1, p1 in enumerate(grid)
              for p2 in grid[j1 + 1:] if Kf(m1, p1) * Kf(m2, p2) < Kf(m1, p2) * Kf(m2, p1))
    ok(bad == 0, "TP2 grid guard, n = 1")
    # Lemmas 3.3 and 3.4 on deterministic pseudo-random f <=_lr h (h = f q, q nondecreasing)
    rng = Lcg(20261020)
    trials = 0
    for n in range(1, (6 if FULL else 4) + 1):
        for _ in range(24 if FULL else 10):
            f = bernstein_to_monomial([rng.next(1, 9) for _ in range(rng.next(1, 6) + 1)])
            steps = [rng.next(0, 3) for _ in range(rng.next(1, 5) + 1)]
            if not any(steps[1:]):
                steps[-1] = 1
            qc, acc = [], rng.next(1, 4)
            for s in steps:
                acc += s
                qc.append(acc)
            q = bernstein_to_monomial(qc)  # increasing Bernstein coefficients: q nondecreasing, > 0
            h = pmul(f, q)
            ok(bernstein_positive01(f) and lr_strict(f, h), "test pair: f > 0 and f <lr h")
            Tf, Th = apply_T(f, n), apply_T(h, n)
            ok(bern_strict_sign_open01(pderiv(Tf), 1), f"Lemma 3.4: 1 <lr Tf (Tf increasing), n = {n}")
            ok(lr_strict(Tf, W_low(n)), f"Lemma 3.4: Tf <lr W_n, n = {n}")
            ok(lr_strict(Tf, Th), f"Lemma 3.3: Tf <lr Th, n = {n}")
            trials += 1
    # the lr chain for n = 1 (section [6] covers n >= 2)
    links = 0
    for a, b in chain_links(15):
        ok(lr_strict(g_poly(1, a), g_poly(1, b)), f"Bernstein: g_{a} <lr g_{b}, n = 1")
        links += 1
    note(f"Lemma 2.5: degree, leading coefficient, g_k(0) = 0 and g_k > 0 on (0,1] for n = 1..{nmax}, "
         f"k <= 15; TP2 grid n = 1")
    note(f"Lemmas 3.3-3.4: {trials} pseudo-random pairs f <lr h (n = 1..{6 if FULL else 4}): "
         f"1 <lr Tf <lr W_n and Tf <lr Th, all strict (Bernstein); n = 1 lr chain: {links} strict links")


def sec10b():
    section("[10b] finaliser: Theorem 4.1 for n = 1 and its compact form; k = 2 (Cor 2.4(4), MW47)")
    E = euler_numbers(32)
    for k in range(2, 31):
        ok(transfer_single(1, k, 1) == E[k], f"n = 1: e(Z_{k}) = E_{k}")
        ok(transfer_single(1, k, 0) == (k * E[k - 1] - E[k] if k >= 3 else 1),
           f"n = 1: |D_{k}| = k E_(k-1) - E_k (Ehrenborg 2002, Cor 3.1 with a = 0)")
    r1 = {k: Fraction(transfer_single(1, k, 0), E[k]) for k in range(2, 31)}
    ok(sandwich_ok(r1, 30), "n = 1: strict sandwich for k <= 30")
    em98 = [1, 3, 9, 35, 155, 791, 4529, 28839, 201939, 1542739]  # EM98 Fig. 5, column i = 0, rows 0..9
    a034428 = [0, 0, 1, 1, 3, 9, 35, 155, 791, 4529, 28839, 201939, 1542739, 12767689, 113794603,
               1086657403, 11068604847, 119790363489, 1372696498127, 16603828720547]  # OEIS, offset 0
    ok(all(transfer_single(1, m + 3, 0) == v for m, v in enumerate(em98)), "n = 1: EM98 Fig. 5 column 0")
    ok(all(transfer_single(1, k, 0) == a034428[k] for k in range(2, len(a034428))), "n = 1: OEIS A034428")
    kmax = 9 if FULL else 8
    for k in range(2, kmax + 1):  # literal enumeration of the permutations of [k]
        zv = z_vector(1, k)
        dv = (0,) + zv[1:]
        fib, _proj, keys, total = lit_enumerate(1, k, {dv} if k <= 7 else set())
        ok(total == factorial(k) and fib.get(zv, 0) == E[k] and fib.get(dv, 0) == transfer_single(1, k, 0),
           f"n = 1, LIT (1^{k}): e(Z) = E_k and |D_k| = transfer")
        if k <= 7:
            ok(len(keys.get(dv, set())) == 1, f"n = 1: D_{k} is one Parikh class (LIT)")
    # compact form of Theorem 4.1(1): r_{2i+1} <= r_k <= r_{2i} for k >= 2i, equality only at the ends
    nmax, K = (6, 20) if FULL else (5, 16)
    cnt = 0
    for n in range(1, nmax + 1):
        for p in range(n):
            r = {k: Fraction(transfer_single(n, k, p), transfer_single(n, k, n)) for k in range(2, K + 1)}
            for i in range(1, K // 2 + 1):
                for k in range(2 * i, K + 1):
                    hi = r[k] < r[2 * i] if k != 2 * i else True
                    lo = True if 2 * i + 1 > K or k == 2 * i + 1 else r[2 * i + 1] < r[k]
                    ok(hi and lo, f"compact sandwich, n = {n}, p = {p}, i = {i}, k = {k}")
                    cnt += 1
    # k = 2: words of (n, n) <-> projections; |D_2(lam)| = 1; |S_A| = Mann-Whitney frequency
    for n in range(1, 7):
        projs = {}
        for ones in combinations(range(2 * n), n):  # positions of the 1's
            s = set(ones)
            lam, seen = [], 0
            for pos in range(2 * n):
                if pos in s:
                    seen += 1
                else:
                    lam.append(seen)
            projs[tuple(lam)] = projs.get(tuple(lam), 0) + 1
        ok(sorted(projs) == sorted(projections(n)) and set(projs.values()) == {1},
           f"k = 2: words of ({n},{n}) <-> projections (bijection)")
        mw = {(0, 0): {0: 1}}

        def pbar(a, b):  # MW47 section 4: a 0's (our 2's), b 1's (our 1's), U = #(1 before 0)
            if (a, b) not in mw:
                if a == 0 or b == 0:
                    mw[(a, b)] = {0: 1}
                else:
                    out = {}
                    for u, c in pbar(a - 1, b).items():
                        out[u + b] = out.get(u + b, 0) + c
                    for u, c in pbar(a, b - 1).items():
                        out[u] = out.get(u, 0) + c
                    mw[(a, b)] = out
            return mw[(a, b)]

        ok(all(pbar(n, n).get(A, 0) == sum(1 for lam in projections(n) if sum(lam) == A)
               for A in range(n * n + 1)), f"k = 2: |S_A| = Mann-Whitney frequency, n = {n}")
        ok(all(transfer_single(n, 2, p) == 1 for p in range(n + 1)), f"k = 2: |D_2(lam)| = 1, n = {n}")
    note("n = 1: e(Z_k) = E_k, |D_k| = k E_(k-1) - E_k (k <= 30) = EM98 Fig. 5 col. 0 = A034428; "
         f"strict sandwich k <= 30; LIT k <= {kmax}; one class k <= 7")
    note(f"compact form: {cnt} comparisons r_(2i+1) <= r_k <= r_(2i) (n = 1..{nmax}, k <= {K}), strict "
         "off the ends; k = 2: bijection with projections and Mann-Whitney counts, n <= 6")


def sec10c():
    section("[10c] finaliser: Corollary 4.3, every one-end relaxation = D_k(S_A*) (FIB, all areas)")
    ranges = ((2, 8), (3, 6), (4, 4)) if FULL else ((2, 7), (3, 5), (4, 3))
    cnt = 0
    for n, kmax in ranges:
        for k in range(3, kmax + 1):
            zv = z_vector(n, k)
            for X in (zv, tuple(n * n - v for v in zv)):
                for e in (0, k - 2):
                    x = tuple(None if i == e else v for i, v in enumerate(X))
                    prof = fib_profile((n,) * k, x)
                    ok(prof.get(X, 0) == transfer_single(n, k, n), f"({n}^{k}): alternating class size")
                    for A in range(n * n + 1):
                        if A == X[e]:
                            continue
                        y = tuple(A if i == e else v for i, v in enumerate(X))
                        Astar = A if X[e] == n * n else n * n - A
                        ok(prof.get(y, 0) == transfer_area(n, k, Astar),
                           f"Cor 4.3: ({n}^{k}) X = {X}, edge {e + 1}, area {A}")
                        cnt += 1
    note(f"{cnt} one-end relaxation fibres (both classes, both ends, every area): "
         + ", ".join(f"n = {n}, 3 <= k <= {km}" for n, km in ranges))


def sec10d():
    section("[10d] finaliser: n = 3 (Cor 5.4 values, (3^5) one- and two-end, (3^3), (3^2), best one-end)")
    ok(Fraction(transfer_area(3, 4, 6), transfer_single(3, 4, 3)) == Fraction(399, 331), "r_4(S_6) = 798/662 = 399/331")
    # (3^5): the nine one-end values (Cor 5.4, remark), transfer and FIB
    prof = fib_profile((3,) * 5, (None, 0, 9, None))
    e5 = transfer_single(3, 5, 3)
    ok(prof[(9, 0, 9, 0)] == e5 == 57400, "(3^5): e(Z_5) = 57400 (FIB, transfer)")
    one = {A: prof.get((A, 0, 9, 0), 0) for A in range(9)}
    ok(all(one[A] == transfer_area(3, 5, A) for A in range(9)), "(3^5): |D_5(S_A)| FIB = transfer, A = 0..8")
    ok([one[A] for A in range(9)] == [4410, 4410, 8820, 24780, 24780, 36330, 55020, 50610, 34650],
       "(3^5): the nine one-end values")
    ok(max(one.values()) < e5 and max(one, key=one.get) == 6, "(3^5): every one-end value < 57400; max at A = 6")
    two = {(ar[0], ar[3]): v for ar, v in prof.items() if ar[0] != 9 and ar[3] != 0}
    best = max(two.values())
    ok(best == 66024 and [ab for ab, v in two.items() if v == best] == [(6, 3)],
       "(3^5): the largest two-end fibre (A,0,9,B) is (6,0,9,3) with 66024 words")
    ok(max(v for ar, v in prof.items() if ar != (9, 0, 9, 0)) == 66024,
       "(3^5): no fibre (A,0,9,B) other than Z_5 exceeds 66024")
    for x in ((6, 0, 9, 3), (3, 9, 0, 6)):
        ws = words_of_fibre((3,) * 5, x)
        ok(len(ws) == 66024 and len({full_key(w, 5) for w in ws}) == 1,
           f"(3^5): fibre {x} enumerated: 66024 words, one Parikh class")
    # (3^3): 218 classes; exactly six of the largest size 20
    cls = lit_class_sizes((3, 3, 3))
    tops = sorted(key for key, v in cls.items() if v == 20)
    ok(sum(cls.values()) == 1680 and len(cls) == 218 and max(cls.values()) == 20, "(3^3): 1680 words, 218 classes, max 20")
    ok(tops == [(0, 0, 9), (3, 0, 6), (3, 6, 6), (6, 0, 3), (6, 6, 3), (9, 0, 0)], f"(3^3): the six largest {tops}")
    # (3^2): the alternating classes are NOT largest at k = 2
    cls2 = lit_class_sizes((3, 3))
    ok(cls2[(9,)] == cls2[(0,)] == 1 and all(cls2[(a,)] == 3 for a in (3, 4, 5, 6))
       and max(cls2.values()) == 3, "(3^2): alternating classes 1 word; x_1 = 3..6 have 3 words")
    # best one-end class of (3^k): A = 6 (section [4] covers k <= 15)
    K = 40 if FULL else 20
    for p in range(4):
        ins_profile(3, K, p)
    bad = []
    for k in range(3, K + 1):
        vals = [transfer_area(3, k, A) for A in range(9)]
        ok(vals == [ins_area(3, k, A, K) for A in range(9)], f"(3^{k}): one-end values, transfer = INS")
        if [A for A in range(9) if vals[A] == max(vals)] != [6]:
            bad.append(k)
    ok(not bad, f"(3^k): best one-end class is A = 6 for 3 <= k <= {K}: exceptions {bad}")
    note("r_4 = 399/331; (3^5): one-end values 4410, 4410, 8820, 24780, 24780, 36330, 55020, 50610, 34650 "
         "< 57400; largest two-end fibre (6,0,9,3) = 66024, one class (enumerated), mirror likewise")
    note(f"(3^3): 218 classes, six of size 20; (3^2): alternating classes not largest; best one-end class "
         f"A = 6 for 3 <= k <= {K} (transfer = INS)")


def sec10e(ez2, R2):
    section("[10e] finaliser: n = 2 (Cor 5.6 for every area; a_0, a_1; scope: two-end relaxations)")
    a0, a1 = transfer_single(2, 4, 0), transfer_single(2, 4, 1)
    ok(a0 == 15 == trace_single(2, 4, (0, 0)) == trace_single(2, 4, (0, 1)) == trace_single(2, 4, (0, 2)),
       "a_0 = 15 (TRACE on the three projections with lam_1 = 0)")
    ok(a1 == 35 == trace_single(2, 4, (1, 1)) == trace_single(2, 4, (1, 2)), "a_1 = 35 (TRACE, lam_1 = 1)")
    fib, _p, _k, _t = lit_enumerate(2, 4, set())
    ok([fib.get((A, 0, 4), 0) for A in range(5)] == [15, 15, 50, 35, 53], "(2^4) LIT: one-end fibres 15, 15, 50, 35; e(Z) 53")
    bound = Fraction(50, 53)
    worst = Fraction(0)
    for k in range(3, 61):
        for A in range(4):
            r = Fraction(transfer_area(2, k, A), ez2[k])
            if (k, A) == (4, 2):
                ok(r == bound, "r_4(S_2) = 50/53")
            else:
                ok(r < bound, f"Cor 5.6: r_{k}(S_{A}) < 50/53")
                worst = max(worst, r)
    ok(R2[4] == 50 and ez2[4] == 53, "R_4 = 50, e(Z_4) = 53")
    # scope: the two-end relaxations
    cls = lit_class_sizes((2, 2, 2))
    ok(sum(cls.values()) == 90 and cls[(2, 0, 2)] == cls[(2, 2, 2)] == 6 == transfer_single(2, 3, 2)
       and sorted(key for key in cls if (key[0], key[2]) == (2, 2)) == [(2, 0, 2), (2, 2, 2)],
       "(2^3): the central fibre (2,2) relaxes both ends; its two classes tie e(Z_3) = 6")
    K = 12 if FULL else 9
    out = []
    for k in range(4, K + 1):
        best, ends = 0, set()
        for X in (z_vector(2, k), tuple(4 - v for v in z_vector(2, k))):
            prof = fib_profile((2,) * k, (None,) + X[1:-1] + (None,))
            for ar, v in prof.items():
                if ar[0] != X[0] and ar[-1] != X[-1]:
                    if v > best:
                        best, ends = v, {(ar[0], ar[-1])}
                    elif v == best:
                        ends.add((ar[0], ar[-1]))
        ok(best < transfer_single(2, k, 2) and ends == {(2, 2)},
           f"(2^{k}): every two-end relaxation < e(Z); the largest has end areas (2,2): {best}, {ends}")
        out.append(f"{k}: {best}")
    ok(out[0] == "4: 28" and out[1] == "5: 680", "(2^4): 28; (2^5): 680")
    note(f"Cor 5.6: r_k(S_A) < 50/53 for 3 <= k <= 60, A = 0..3, except r_4(S_2) = 50/53 "
         f"(next largest {dec(worst, 6)}); a_0 = 15, a_1 = 35 by TRACE; (2^4) one-end 15, 15, 50, 35")
    note(f"two-end: (2^3) tie at 6 (classes (2,0,2), (2,2,2)); largest two-end relaxation, k = 4..{K}: "
         + ", ".join(out) + " (all at end areas (2,2), all < e(Z))")


def sec10f():
    section("[10f] finaliser: Prop 5.2 details; Cor 5.7 brackets (directed decimals); [Y26a] overlap")
    L = largest_part_counts(50)
    for n in range(1, 51):
        low = Fraction(sum(L[n][j] * comb(2 * n - j, n) for j in (1, 2) if j <= n), comb(2 * n, n))
        ok(low == Fraction(1, 2) + Fraction((n // 2) * (n - 1), 2 * (2 * n - 1)), f"L(n) closed form, n = {n}")
    ok(Fraction(1, 2) + Fraction(2 * 3, 2 * 7) == Fraction(13, 14)
       and Fraction(1, 2) + Fraction(2 * 4, 2 * 9) == Fraction(17, 18), "L(4) = 13/14, L(5) = 17/18")
    terms = {1: [1], 2: [1, 3], 3: [1, 4, 10], 4: [1, 5, 15, 15, 35], 5: [1, 6, 21, 21, 56, 56, 126]}
    for n, want in terms.items():
        got = sorted(comb(2 * n - mu[0], n) for mu in partitions(n))
        ok(got == sorted(want), f"Prop 5.2: the terms C(2n - mu_1, n), n = {n}")
    ok([r3_formula(n) for n in range(1, 6)] == [Fraction(1, 2), Fraction(2, 3), Fraction(3, 4),
                                                Fraction(71, 70), Fraction(41, 36)], "r_3(1..5)")
    # Cor 5.7 (n = 3, S_6; n = 2, S_2): exact fractions, order, directed decimals
    r = {k: Fraction(transfer_area(3, k, 6), transfer_single(3, k, 3)) for k in (14, 15, 29, 30)}
    for k in (14, 15, 29, 30):
        ok(transfer_area(3, k, 6) == ins_area(3, k, 6, 30) and transfer_single(3, k, 3) == ins_profile(3, 30, 3)[k],
           f"n = 3, k = {k}: transfer = INS")
    ok(r[14] == Fraction(5484373207785861994913577, 5342305086075122024724638), "r_14 exact")
    ok(r[15] == Fraction(91843290059617433485827310197, 89477255454690151044003623680), "r_15 exact")
    ok(r[15] < r[29] < r[30] < r[14], "r_15 < r_29 < r_30 < r_14")
    ok((floor_dec(r[14], 9), floor_dec(r[15], 9), floor_dec(r[29], 9), floor_dec(r[30], 9))
       == ("1.026593037", "1.026442860", "1.026491718", "1.026491721"), "9-decimal truncations (note, Cor 5.7)")
    ok(Fraction("1.026442860") < r[15] and r[14] < Fraction("1.026593038")
       and Fraction("1.0264917187") < r[29] and r[30] < Fraction("1.0264917215"), "directed outer brackets")
    r2 = {k: Fraction(R2_area(k), transfer_single(2, k, 2)) for k in (59, 60)}
    for k in (59, 60):
        ok(R2_area(k) == ins_area(2, k, 2, 60), f"n = 2, k = {k}: transfer = INS")
    ok(r2[59] < r2[60] and floor_dec(r2[59], 9) == floor_dec(r2[60], 9) == "0.843915414"
       and Fraction("0.843915414") < r2[59] and r2[60] < Fraction("0.843915415"), "n = 2: (r_59, r_60)")
    # [Y26a] Thm 2 (p. 5), by reversal: |D_3(S_A)| = p(A) for A < n and p(n) + n for A = n
    pc = [1] + [0] * 6
    for part in range(1, 7):
        for s in range(part, 7):
            pc[s] += pc[s - part]
    for n in range(1, 7):
        for A in range(min(n, n * n - 1) + 1):
            ok(transfer_area(n, 3, A) == (pc[A] if A < n else pc[n] + n), f"[Y26a] overlap, n = {n}, A = {A}")
            if n <= 4:
                prof = fib_profile((n,) * 3, (n * n - A, n * n))
                ok(prof.get((n * n - A, n * n), 0) == transfer_area(n, 3, A), f"reversal fibre, n = {n}, A = {A}")
    note("L(n) closed form n <= 50; terms of r_3(n) for n <= 5; r_3(1..5) = 1/2, 2/3, 3/4, 71/70, 41/36")
    note(f"Cor 5.7, n = 3: (r_15, r_14) inside ({floor_dec(r[15], 9)}, {ceil_dec(r[14], 9)}), "
         f"(r_29, r_30) inside ({floor_dec(r[29], 10)}, {ceil_dec(r[30], 10)}); n = 2: (r_59, r_60) inside "
         f"({floor_dec(r2[59], 9)}, {ceil_dec(r2[60], 9)})")
    note("[Y26a] Thm 2 overlap: |D_3(S_A)| = p(A) (A < n), p(n) + n (A = n) for n <= 6; FIB of the reversal "
         "fibre (n^2 - A, n^2) for n <= 4")


def R2_area(k):
    return transfer_area(2, k, 2)


def main() -> int:
    print(f"== check_lr_sandwich ({'full' if FULL else 'default'} mode)", flush=True)
    ez2 = R2 = None
    for fn in (sec0, sec1, sec2, sec3, sec4, sec5, sec6, sec7):
        try:
            res = fn()
            if fn is sec3:
                ez2, R2 = res
        except Exception as exc:  # an exception is a failure
            ok(False, f"{fn.__name__} raised {exc!r}", gate=fn in (sec3, sec4, sec5))
    try:
        if ez2 is None:
            raise RuntimeError("section [3] did not finish")
        sec8(ez2, R2)
    except Exception as exc:
        ok(False, f"sec8 raised {exc!r}")
    for fn in (sec10a, sec10b, sec10c, sec10d, sec10e, sec10f):
        try:
            if fn is sec10e:
                if ez2 is None:
                    raise RuntimeError("section [3] did not finish")
                fn(ez2, R2)
            else:
                fn()
        except Exception as exc:
            ok(False, f"{fn.__name__} raised {exc!r}")
    try:
        sec9()
    except Exception as exc:
        ok(False, f"sec9 raised {exc!r}")
    dt = time.perf_counter() - T0
    if GATE_FAIL or GATE_N[0] == 0:
        print(f"GATE (1)-(3): FAIL ({len(GATE_FAIL)} of {GATE_N[0]} gate comparisons failed)")
    else:
        print(f"GATE (1)-(3): PASS (all {GATE_N[0]} gate comparisons exact: the transfer reproduces "
              "every discrete count)")
    print(f"check_lr_sandwich: {NCHECK[0]} checks, {len(FAIL)} failures, {dt:.1f} s")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
