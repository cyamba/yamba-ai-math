Copyright (c) 2006, 2026 Christopher Yamba. All rights reserved.

Verification package for "From Euler numbers to the golden ratio: rigidity, ranges and the most
ambiguous Parikh matrices for words with repeated letters" (Christopher Yamba, 2026).

Every computational statement of the article is recomputed by a standard-library Python 3.11
check. The files keep their repository paths, so run each check from this directory, e.g.
  python3 checks/check_r7_golden.py
  python3 checks/check_lr_sandwich.py --full
Each exits with a non-zero status on any failure. The certificate of Appendix A is
notes/r7-scripts/proof-golden/lemmaB_certificate.py.
Repository: https://github.com/cyamba/yamba-ai-math/tree/main/research/parikh
