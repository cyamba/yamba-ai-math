"""trace_reads.py: run one check of checks/ and list the repository files it opens.

Used to make the dry-run list of arXiv ancillary files (paper2/README.md) exact: a check's
dependencies are the files it imports or reads, which this script records through a
sys.addaudithook hook on the events "open" and "import" while the check runs in this
process (runpy, as __main__, with checks/ on sys.path as when it is run directly).

    python3 -B notes/article2-scripts/article2-check/tools/trace_reads.py check_r7_switch.py [ARGS...]

Writes the sorted list of opened files under the repository root (directories and the
interpreter's own files excluded) to stdout after the check's output, between the markers
"--- reads ---" and "--- end ---", and exits with the check's status. Worker processes of a
check that uses a process pool are not traced (only check_article2.py --full uses one).
Standard library only.
"""

from __future__ import annotations

import os
import runpy
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", "..", ".."))
CHECKS = os.path.join(ROOT, "checks")


def main() -> int:
    name = sys.argv[1]
    path = os.path.join(CHECKS, name)
    seen: set[str] = set()

    def hook(event, args):
        if event == "open" and args and isinstance(args[0], (str, bytes, os.PathLike)):
            p = os.path.abspath(os.fsdecode(args[0]))
            if p.startswith(ROOT + os.sep) and os.path.isfile(p):
                seen.add(os.path.relpath(p, ROOT))

    sys.addaudithook(hook)
    sys.argv = [path] + sys.argv[2:]
    sys.path.insert(0, CHECKS)
    status = 0
    try:
        runpy.run_path(path, run_name="__main__")
    except SystemExit as exc:
        status = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
    for mod in list(sys.modules.values()):
        f = getattr(mod, "__file__", None)
        if f and os.path.abspath(f).startswith(ROOT + os.sep):
            seen.add(os.path.relpath(os.path.abspath(f), ROOT))
    print("--- reads ---")
    for p in sorted(seen):
        if "__pycache__" not in p:
            print(p)
    print("--- end ---")
    return status


if __name__ == "__main__":
    sys.exit(main())
