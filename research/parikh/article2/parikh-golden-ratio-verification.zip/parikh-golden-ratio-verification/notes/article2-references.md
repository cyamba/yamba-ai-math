# Article 2: reference ledger

21 October 2026. Christopher Yamba's project; all rights reserved. Branch
`claude/phase3-proofs-2026-10-19`. Bibliography agent, Phase 3 prep. **Updated 22 October 2026
(Phase 4, integrating finaliser):** Sin75 and A089508 added (§7), the A081016 entry upgraded to
the full entry, the locators read first-hand in Phases 3 and 4 recorded (Yamba06, TR536, Sal06,
DS06, Sal18, Sim20), the Sta86 hash corrected, and the resolution of the new DOI logged (§9).

Article 2 is *From Euler numbers to the golden ratio: rigidity, ranges and the most ambiguous
Parikh matrices for words with repeated letters*, by Christopher Yamba alone. This ledger lists
every work the article may cite, with full bibliographic data, the identifier that was resolved
**today**, the first-hand locators the article may use, how each locator was confirmed, and a
status. It certifies nothing as new. The sources of truth for credits remain the proof notes
(`notes/proof-*.md`, final labels in their review records), `notes/article2-design.md` (errata
header first), `notes/priority-article2.md` and `notes/priority-ternary-claude.md`. This ledger
only collects their bibliographic side and checks it.

## 0. Summary for the writer

**Files.**
- `paper2/references.bib`: 76 entries (74 of 21 Oct, plus Sin75 and A089508 of 22 Oct), one per
  citable work (statuses READ or LOCATED-UNREAD; no lead). ASCII only, LaTeX accents, initials for given names, no comments.
- `notes/article2-scripts/references/resolve_refs.py`: resolves and logs every identifier the
  .bib prints (§9). Log: `out/resolve_refs.log`.
- `notes/article2-scripts/references/bibtest.py`: BibTeX + amsplain test with a document that
  cites every key, under the `article` and the `amsart` classes. Log: `out/bibtest.log`; the
  resulting `.bbl` (comment line removed) is `out/test-amsplain.bbl`.

**Statuses.**
- **READ**: the cited passage was read first-hand by this project (a local copy, or a project
  note that records a first-hand reading), at the locators given.
- **LOCATED-UNREAD (limit)**: the work exists (metadata or abstract seen) but was not read. Cite
  it only for its existence, or name it as a limit. Never attribute content to it beyond what
  the abstract or a second source that was read says, and say so.
- **LEAD**: not in the .bib; never cite (§8).

**Identifier policy (AGENTS.md rule 4).**
- A DOI is printed only if `https://api.crossref.org/works/<doi>` resolved it in today's run,
  with matching title, first author, year, volume and first page (47 DOIs on 21 Oct, and the
  DOI of Sin75 on 22 Oct: 48; §9). None was built
  from a URL pattern.
- Two works have DOIs registered only with DataCite (Crossref returns 404): JV14 and Hut22.
  They were resolved through `https://api.datacite.org/dois/<doi>` and logged, but **no DOI is
  printed for them**; the .bib cites them by the URL of the version read, or the URL registered
  with DataCite.
- Works without a DOI were checked by a Crossref bibliographic query (no record with the same
  title, apart from known separate publications of the same title: §9).
- arXiv identifiers were checked through the arXiv API, with the version actually read.
- Every other printed URL was fetched once today; where the project had recorded a SHA-256 of
  the copy it read, the hash was compared (§9).

**How the .bib prints (amsplain).**
- amsplain has no `doi`, `url` or `eprint` field. DOIs and URLs are in `note` (or `howpublished`
  for `@misc`) as `\url{https://doi.org/...}`, arXiv ids as `\href{...}{arXiv:...}`. The article
  must load `hyperref` (or at least `url`); the .bib's `@preamble` supplies a plain `\url`
  fallback and amsplain supplies `\href`.
- amsplain sets titles in sentence case: capitals are protected with braces (`{P}arikh`).
- For `@incollection` and `@inproceedings` amsplain prints `note` before `pages`, so the page
  range is written in the note, ahead of the DOI (Sal18, HMR22, HCH23, Iriarte14, JV14).
- **The .bbl that amsplain writes contains one comment line of its own**,
  `% \MRhref is called by the amsart/book/proc definition of \MR.` It must be deleted from the
  shipped `.bbl` (AGENTS.md rule 7; arXiv). The `{%` at the end of the `\MRhref` line is a bare
  `%` that suppresses a space, which the rules allow. Deleting the comment line changes nothing
  in the output (checked in `bibtest.py`, both classes).
- BibTeX (0.99e, TeX Live 2026) runs with **0 warnings and 0 errors**; pdfLaTeX shows no
  undefined citation and no LaTeX warning (§9). The only package warning is TinyTeX's
  `epstopdf` notice about `-no-shell-escape`, unrelated to the bibliography. Long URLs give a
  few underfull lines in the bibliography; `\raggedright` in the bibliography would remove them
  (Article 1 used it).

**Corrections and findings of this pass (they change what the article prints).**
1. **Salomaa 2015 is in the informatics series of the Bucharest annals.** The TUCS record (re-fetched
   today; same SHA-256 `5408b2c4…f5e3` as the copy the 21 Oct hunt saved) gives "Analele
   Universitate Bucuresti, Informatica, 62(2), 101–112, 2015", and HAL hal-01352362 (Ivanov–Verlan,
   same issue, pp. 77–88) gives "Annals of the University of Bucharest (informatics series)",
   vol. LXII, issue 2. The project notes and the task brief write "An. Univ. Bucureşti
   Mat.-Inform."; the .bib prints **An. Univ. Bucureşti Inform. 62 (2015), no. 2, 101–112**.
2. **AAP08's second author is Radu Atanasiu** (publisher PDF and Crossref).
3. **HCH23's LNCS volume number is not confirmed.** The notes write "LNCS 14151"; Crossref and
   OpenAlex give no volume, the Springer PDF and DBLP were behind bot walls (one attempt each),
   and the corrected author PDF does not print it. The .bib prints the series without a volume.
4. **HMR22's LNCS volume 13266 is confirmed** by the Loughborough repository record (figshare
   API, field "Book series: Lecture Notes in Computer Science; volume 13266"; editors P. Caron and
   L. Mignot; CIAA 2022, Rouen). Sal18's LNCS 11011 is confirmed by the footer of the local PDF.
5. **Steel 1959: only the first page (560) is in Crossref and OpenAlex**; the .bib prints
   "560 ff." (as `notes/priority-article2.md` §9.1(b) does).
6. **Iriarte is Benjamin Iriarte** (Crossref, DMTCS). The FPSAC 2014 extended abstract is
   DMTCS proc. AT (2014) 945–956 (header of the PDF fetched today).
7. **The copies read are what the printed URLs serve.** Today's downloads have the recorded
   SHA-256 for: the published [Y26a] PDF (`28b317b9…efd9`), the thesis at the Stockholm
   University URL (identical to `context/thesis-2006/2006_08_report.pdf`), DS06, ŞŞ06, MW47, JV14,
   AP93, EM98, ELR02, Ehr02, Sta86, Iriarte's accepted manuscript, HCH23, HMR22, Teh20b and Faz11.
   EC1's preprint at the printed URL is the "version of 15 July 2011".
8. **The Ehr02 author copy is not in `~/YambaCode/Math/parikh-sources/`** (the scratchpad copies
   of 20–21 Oct are gone). Its URL serves the same file today (`a1c354c4…8650`). Copying it there
   is outside this role.
9. **Sal09's publisher URL (jams.jp, and jams.or.jp) refused connections today**; it was read
   there on 18 Oct (docs/literature.md §§B, M). The .bib keeps the URL; recheck before
   submission.
10. tucs.fi serves an incomplete TLS chain that Python's OpenSSL cannot verify; the resolver
    falls back to the system `curl` (verification still on) for such hosts.

## 1. The author's own work, the classical baseline, and Yamamura

- **Yamba06** (READ). C. Yamba, *Parikh Matrices and Permutation Statistics*, Examensarbeten i
  matematik 2006:8, Matematiska institutionen, Stockholms universitet, 2006 (title page: "2006 -
  No 8"; "Examensarbete i matematik 20 poäng, fördjupningskurs"; supervisors Mats Oldin and
  Yishao Zhou). No DOI. URL printed: the Stockholm University file
  https://kurser.math.su.se/pluginfile.php/16103/mod_folder/content/0/2006/2006_08_report.pdf,
  which served today a file identical to `context/thesis-2006/2006_08_report.pdf` (SHA-256
  `eb80991f…`; 42 pp.). **Cite the original only, with both page numbers (printed p. N = PDF
  p. N+4).** Locators re-checked today with pdftotext:
  - Def. 2.8 (the Parikh matrix mapping ψ_{M_k}, a morphism into M_{k+1}): printed p. 12 /
    PDF p. 16; Thm 2.10 ("Parikh matrix mapping", the entries m_{i,j}): printed p. 13 / PDF p. 17
    (read first-hand in Phase 3 and re-checked with pdftotext on 22 Oct 2026; used in §2).
  - Thm 3.5 (Parikh Matrix Completeness Theorem): printed pp. 19–20 / PDF pp. 23–24. Cite it,
    not Prop 3.4 (printed p. 17 / PDF p. 21), which is false at j = i+1.
  - Computation 5.2 (ρ₂(1010) = ρ₂(0101) = 16): printed p. 27 / PDF p. 31.
  - Main Thm 6.12: printed pp. 31–32 / PDF pp. 35–36. Thm 6.15: printed pp. 33–34 /
    PDF pp. 37–38.
  - §8 "Summary, Conclusions and Suggestion of Further Research": printed p. 37 / PDF p. 41
    ("For instance a generalized formula for the Parikh vector statistic ρ₂(v) …"). Never say
    that this question is solved.
  - Use: the permutation baseline (classical; with EC1 Cor 1.6.5).
- **Y26a** (READ; the author's own Article 1). C. Yamba, *Partition stabilization and semigroup
  gaps for ternary Parikh matrices*, research preprint, version 1, 19 October 2026,
  https://www.christopheryamba.com/math/ternary-parikh/ (canonical URL and date from the Codex
  checkout's `paper/publication.json`: first public availability 2026-10-19T21:04:21Z). The PDF
  served today at `/math/ternary-parikh/ternary-parikh.pdf` has SHA-256 `28b317b9…efd9`, the hash
  of the copy every round read (Codex checkout `output/pdf/ternary-parikh.pdf`, 15 pp.; PDF page
  = printed page). Locators (all first-hand: `notes/priority-article2.md` §4 table, re-read in the
  Phase 1 and 2 rounds):
  - Lemma 1, eqs (2.5)–(2.7), p. 3 (gap encoding; count Π C(α_g+γ_g, α_g)); eq. (2.8), p. 3
    (z − |w|₃₂₁ = cx + ay − abc; credits its ref. [4] = TUCS TR 442).
  - Thm 2, eqs (3.1)–(3.2), p. 5 (corner chamber i + j ≤ b); the remark "The chamber is a
    sufficient condition for a forced triple coordinate; it is not claimed to be the largest
    such region" is on **p. 6**. Cor 2, p. 5 ((inv, |w|₁₂₃) determines the matrix when a ≠ c and
    inv ≤ b).
  - Lemma 4, eq. (4.1), p. 8, with the paragraph after it ("equivalently Q + T ≥ b. It
    characterizes when the affine bound (2.8) is attained"); eq. (4.3), p. 8 (profiles A_t, C_t;
    "Every such pair of profiles is realizable").
  - Prop 2, eq. (4.7), p. 11 (the |w|₁₂₃ spectrum of W(2,b,2)); Thm 6, eqs (5.1)–(5.2), p. 11
    (first exterior layer i + j = b + 1).
  - Thm 7, p. 12; Fig. 1, p. 4; Fig. 3 and Table 1, p. 12 (complete (2,3,2) fibres).
  - §7 "Further directions", item 2, p. 14 (exterior layers). Per ★2: the (2,b,2) bottom
    coefficients on [Y26a]'s exterior layers appear **only as a lemma inside the 2B2 proof**, with
    a remark crediting [Y26a] §7 item 2 (p. 14) as that article's further direction. Do not
    re-claim anything in [Y26a].
- **Yamamura23** (READ: the project page). A. Yamamura (Akita University), KAKENHI
  Grant-in-Aid for Scientific Research (C), project 23K10977 (JP23K10977), project period
  2023-04-01 to 2026-03-31. The title on the KAKEN page is in Japanese only:
  「Parikh行列に関して同値な順列とその順列統計に関する研究」. pdfLaTeX cannot set it without CJK
  packages, so the .bib gives the English translation in brackets ("[Research on permutations
  equivalent with respect to Parikh matrices and their permutation statistics]") and says that
  it is translated. URL: https://kaken.nii.ac.jp/ja/grant/KAKENHI-PROJECT-23K10977/ (fetched
  today, HTTP 200; the English page shows the same Japanese title). Locator: the research-status
  reports (FY2023, FY2024), "Outline of Annual Research Achievements", which announce that the
  largest M-equivalence class of permutations has the size of the Euler number. **Cite only the
  project, as announcing the permutation maximum; never describe his unpublished definitions or
  methods.** No paper by him on this was found (docs/literature.md §A; `priority-r7-scan.md`
  §1.5).
- **EC1** (READ, author's preprint). R. P. Stanley, *Enumerative Combinatorics*, vol. 1, 2nd ed.,
  Cambridge University Press, Cambridge, 2012. DOI 10.1017/CBO9781139058520 (Crossref:
  monograph, 2011/2012). Read in the author's preprint https://math.mit.edu/~rstan/ec/ec1.pdf,
  which today is still the "version of 15 July 2011" (page 1 text). **Item numbers are the
  preprint's; the published page numbers are unconfirmed** (docs/literature.md §E), so cite by
  item number only. Locators (docs/literature.md §E, FT ✓; `r5-opening.md` References item 2):
  Cor 1.6.5 (β_n(S) ≤ E_n, equality iff S = {1,3,…} or {2,4,…}; Notes credit Niven and de Bruijn);
  §1.4 (ID(w) = D(w⁻¹), reading set); Cor 1.4.9; Prop 1.7.1; Example 2.2.5. Caution: EC1 §1.6 uses
  "M-equivalence" for min–max trees (unrelated); say "Parikh class".
- **FS78** (READ). D. Foata, M.-P. Schützenberger, *Major index and inversion number of
  permutations*, Math. Nachr. 83 (1978) 143–159. DOI 10.1002/mana.19780830111 (Crossref). FT ✓ of
  the scan https://irma.math.unistra.fr/~foata/paper/pub30.pdf (docs/literature.md §E): p. 143
  ("IDOWN s = DOWN s⁻¹ … The notions of down and idown sets are classical"; i ∈ IDOWN s iff "i+1
  is to the left of i"); p. 144 (joint distribution with the inverse). Use: the baseline is
  classical.
- **NT23** (READ, selected sections). P. Nadeau, V. Tewari, *The permutahedral variety, mixed
  Eulerian numbers, and principal specializations of Schubert polynomials*, Int. Math. Res. Not.
  IMRN 2023, no. 5, 3615–3670. DOI 10.1093/imrn/rnab337 (Crossref; online 2021); arXiv:2005.12194v2
  (arXiv API). Read in arXiv v2: §6.3, Lemma 6.12, Prop. 6.13, Remark 6.14, pp. 22–23
  (`r5-opening.md` References item 6; docs/literature.md §N): commutation classes of Coxeter
  elements of S_{n+1} indexed by descent sets, with the Euler numbers. Use: the permutation
  dictionary is not new in combinatorial form.
- **A000111** (READ). OEIS A000111 (Euler or up/down numbers), https://oeis.org/A000111 (HTTP 200
  today). Used as the control of every OEIS search (`priority-article2.md` §5). Optional citation
  for E_n.

## 2. Parikh matrices: foundations and the subword inequalities

- **MSSY01** (READ). A. Mateescu, A. Salomaa, K. Salomaa, S. Yu, *A sharpening of the Parikh
  mapping*, RAIRO Theor. Inform. Appl. 35(6) (2001) 551–564. DOI 10.1051/ita:2001131 (Crossref).
  FT per docs/literature.md §B: Thm 2.1 (the thesis's Thm 2.10), Cor 2.2 (second diagonal). MSY04
  Thm 3 (p. 7) quotes it for the inverse matrix. Use: Parikh matrices are introduced here.
- **MSY04** (READ). A. Mateescu, A. Salomaa, S. Yu, *Subword histories and Parikh matrices*,
  J. Comput. System Sci. 68(1) (2004) 1–21. DOI 10.1016/j.jcss.2003.04.001 (Crossref). Local final
  journal PDF `msy-2004-jcss.pdf` (SHA-256 `3a59c6c0…fb86a`, re-hashed today), read first-hand
  (`priority-ternary-claude.md` §§0–2; the Phase 1 finalisers). Locators:
  - Thm 1, p. 4 (shuffle identity; with the six-term display it gives z − λ = |w|₃₂₁).
  - Def. 3 and Thm 3, p. 7 (inverse of Ψ(w) = alternate Parikh matrix of the mirror image; the
    reversal symmetry).
  - Def. 4, p. 8, and Thm 4, p. 9 (the lower bound z ≥ cx + ay − abc).
  - Displays on p. 11 (xy − bz = |w|₂₁₃₂ + |w|₂₃₁₂ in our letters).
  - **Lemma 2, p. 12** (the Cauchy bound |w|_b|w|_abc ≤ |w|_ab|w|_bc, equality iff w avoids bacb
    and bcab); Thm 6 and Cor 4, p. 12 (every minor ≥ 0); Cor 5, p. 13 (a different 3×3 minor);
    Thm 7, p. 13 (the general Cauchy inequality).
  - **§7, pp. 15–16**: the profile representation |w|_xy = Σα_i, |w|_yz = Σβ_i,
    |w|_xyz = Σα_iβ_i and the remainder D = Σ_{i<j}(α_j − α_i)(β_i − β_j) (p. 15); monotone
    profiles for a one-letter middle word (p. 16).
  - §8, p. 19: "For this we can offer no systematic method"; "How much ambiguity does a given
    Parikh matrix leave about a word?"; Lemma 8, p. 19 (one-entry full-box support).
  - §8, pp. 19–20: the (3,5,3) example (at (x,y) = (7,7) the values 0 and 3 do not occur; at
    (7,6) all of 0..8 occur); p. 20: "the consideration of minors is not sufficient for a
    characterization of Parikh matrices".
  - Report versions: TR442 (Feb 2002; cited by [Y26a]; second-hand only, §8) and TR481 (below).
- **TR481** (READ, selected pages). A. Mateescu, A. Salomaa, S. Yu, *An inequality for occurrences
  of subwords*, TUCS Technical Report 481, Turku Centre for Computer Science, December 2002 (ISBN
  952-12-1063-X). No DOI. Downloaded once on 19 Oct from
  https://tucs.fi/publications/attachment.php?fname=TR481.ps.gz (66-byte server prefix stripped;
  SHA-256 `84ac7872…d0bd`), read by `priority-ternary-claude.md` §§0, 2: its Lemma 2 (p. 11), the
  displays before it, Thm 7 and the §7 identity are worded as in MSY04. **Cite MSY04; TR481 only
  as the report version, if at all.** No URL printed.
- **MS04** (READ through the report TR536; the journal text is unread). A. Mateescu, A. Salomaa,
  *Matrix indicators for subword occurrences and ambiguity*, Int. J. Found. Comput. Sci. 15(2)
  (2004) 277–292. DOI 10.1142/S0129054104002418 (Crossref). The IJFCS text was not obtained
  (`priority-article2.md` §9.1(b)); **its numbering of Lemma 1, Thm 4 and §7/Thm 8 is unchecked**.
  Cite statements as "MS04 (TR536 numbering)".
- **TR536** (READ in full). A. Mateescu, A. Salomaa, same title, TUCS Technical Report 536, Turku
  Centre for Computer Science, May 2003 (ISBN 952-12-1181-4), record
  https://tucs.fi/publications/view/?pub_id=tMaSa03a. Local PostScript
  `mateescu-salomaa-2004-ijfcs15-tr536.ps` (SHA-256 after stripping the 66-byte prefix
  `6aea2ada…e342`), text through `notes/priority-ternary-scripts/ps_text.py`; read in full by
  `read:parikh-recent` and the topgap finaliser (21 Oct). Locators (report pages):
  - **Def. 2, p. 4**: "Two words w1, w2 ... are termed matrix equivalent, in symbols w1 ≡_M w2",
    the origin of M-equivalence (SS06 ms. p. 4 says it "was introduced in [5]" = MS04); cited in
    §1 as the report version of MS04 (Phase 4 credit referee, credit-12; re-checked through
    `ps_text.py` on 22 Oct 2026).
  - Lemma 1, p. 3 (every third diagonal 0 ≤ m_{i,i+2} ≤ m_{i,i+1}m_{i+1,i+2} occurs: full-box
    support); Thm 2, p. 3 (minors ≥ 0); p. 3: "there can be gaps between the bounds" (fourth
    diagonal).
  - Thm 3, p. 5 (binary M-unambiguous words).
  - §4, pp. 6–7: the (3,5,3) fibres at (7,7) and (7,6), with a table misprint ("4 − 1 : 9" should
    be 8; recomputed in `checks/check_top_gap.py` [12]); Thm 4, p. 7, a listing algorithm.
    **Do not repeat its polynomial-time claim**: Hut22 p. 117 and Sal18 Lemma 4 (p. 110) show the
    count is not polynomially bounded.
  - §5, p. 8: Σα_iΣβ_i = nΣα_iβ_i + D, D = Σ_{i<j}(α_j − α_i)(β_i − β_j), "easy to establish if y
    is a letter"; Thms 5–6, pp. 8–9 (chained Cauchy inequality).
  - **§7 "Gaps in Parikh matrices", Thm 8, pp. 11–12**: content (i,i,i) at (x,y) = (i² − i, i):
    0, i, i² − i occur and nothing in (0, i); the i = 4 list "0, 4, 6, 8, 9, 10, 12" (p. 12). Two
    printed instances of T2 (Theorem C must cite them). §8, p. 12.
- **Sal05** (READ). A. Salomaa, *Connections between subwords and certain matrix mappings*,
  Theoret. Comput. Sci. 340(2) (2005) 188–203. DOI 10.1016/j.tcs.2005.03.024 (Crossref). Local
  PDF `salomaa-2005-tcs340.pdf` (`25c85059…afc6`). Locators (`proof-rigidity-local.md` §7.2;
  `priority-ternary-claude.md` §8):
  - Thm 2, p. 191 (full-box support, credited to MS04); p. 191, two binary classes of 5 and 6
    words.
  - p. 193: Lemma 1; Thm 4 ("Theorem 4 is due to [10]" = MSY04); **"No general theory exists
    concerning the cases when the Cauchy inequality actually reduces to an equality."**
  - Thm 5, p. 195.
  - **Thm 6, p. 196**: every minor of M(x_1,…,x_k) is ≥ 0; its fourth display
    |w|_x|w|_yz + |w|_xy|w|_z ≤ |w|_xyz + |w|_x|w|_y|w|_z is Lemma 3.2's D ≥ 0 in minor form; "a
    general theory is missing" (strictness).
  - p. 197: the binary profile in the proof of Lemma 2.
- **Sal05i** (LOCATED-UNREAD; a named limit). A. Salomaa, *On the injectivity of Parikh matrix
  mappings*, Fund. Inform. 64(1–4) (2005) 391–404 (issue in honour of Solomon Marcus), Zbl
  1102.68072 (zbMATH page fetched today). Also TUCS Technical Report 601 (2004), never put online.
  **No DOI**: Crossref has none (bibliographic query today); the DOI string that Semantic Scholar
  lists does not resolve and was a constructed DOI removed from docs/literature.md on 18 Oct;
  never print it. Pages 391–404 per Sal06 ref. [13] and Sal18 ref. [7]; ŞŞ06's reference list
  misprints them as 188–203. Known only through: Sal06 Thm 3, p. 226 (the γ-property, "this result
  obtained in [13]"); DS06 Thm 3 (author PDF p. 7); ŞŞ06 Thm 2.4 (ms. p. 5). **Cite the γ-property
  result as "Sal05i, as quoted in Sal06 Thm 3 and DS06 Thm 3"; its own theorem number is
  unchecked.** Limit for Thm A (the converse of A(i), A(ii)): name it wherever Thm A or Lemma 3.2
  is discussed.
- **Sal06** (READ). A. Salomaa, *Independence of certain quantities indicating subword
  occurrences*, Theoret. Comput. Sci. 362(1–3) (2006) 222–231. DOI 10.1016/j.tcs.2006.06.025
  (Crossref). Local PDF `salomaa-2006-tcs362.pdf` (`5c185660…3ddb`). Locators: **Def. 3, p. 225**
("Two words w1, w2 ... are termed M-equivalent"; read first-hand in Phase 3 and re-checked on
22 Oct 2026; cited in §1 beside TR536 Def. 2); p. 223 ("it is easy
  to see that |w|abc is not uniquely determined by all the numbers |w|u, where u ∈ {a, b, c, ab,
  bc}"); foot of p. 225 (problem NI); p. 226 (Lemma 2, third-diagonal range credited to MS04; "Of
  course, specific numerical values in some entries often uniquely determine the values in the
  remaining entries"; the γ-function; **Thm 3, the γ-property, quoted from Sal05i**; "Nothing
  similar is known for diagonals beginning with the fourth"); p. 228 (Def. 4 and Thm 4, "Every
  entry is independent"; "If the γ-property is not satisfied, it is easy to give examples of
  different Parikh matrices whose second and third diagonals coincide"; "no matter how many
  diagonals we fix, the Parikh matrix is still not necessarily determined", quoted in the
  article's §9 with Thm 4). **Correction (Phase 3, s8 writer; re-checked 22 Oct 2026):** the
  p. 226 sentence "Nothing similar is known for diagonals beginning with the fourth" follows
  Lemma 2 (the values on the third diagonal); it is not a remark on the γ-property, and the
  article does not quote it.
- **DS06** (READ, author version). C. Ding, A. Salomaa, *On some problems of Mateescu concerning
  subword occurrences*, Fund. Inform. 73(1–2) (2006) 65–79, Zbl 1157.68379 (zbMATH page fetched
  today). **No DOI** (Crossref bibliographic query today; the constructed DOI removed on 18 Oct
  must never be printed). Read in the authors' PDF
  https://cse.hkust.edu.hk/faculty/cding/JOURNALS/FI062.pdf (draft header "FI 72 (2006) 1–15";
  SHA-256 `21cd7166…5cff`, equal today), on rendered pages. **Page numbers are those of the author
  PDF; the FI pagination is unchecked**, and the .bib says so. Locators: p. 6 (Lemma 1, quoted from
  MS04); p. 7 (Thm 3, the γ-property, quoted from [14] = Sal05i; words with the same projections on
  every {a_i, a_{i+1}} are trivially M-equivalent, and their M-equivalence is **stated** there:
  "any word w' obtained from a word w by applying the rewriting rules ... is M-equivalent to w";
  the rules commute letters a_i, a_{i+j}, j ≥ 2; credit-9, re-read on the rendered page of a
  fresh download with the same SHA-256 by the Phase 4 s2 fixer); p. 8 (Thm 4, "Every minor in a Parikh matrix
  and in a generalized Parikh matrix assumes a nonnegative integer value"; Lemma 2; "In many
  instances the inequalities suffice to determine x uniquely"; "the inequalities are actually
  strict if the fractions are not integers"; **Lemma 3**, AF + CE − ABC ≤ x ≤ EF/B, i.e.
  λ ≤ z ≤ xy/b, restating MSY04); pp. 11–12 (the words α_i; the p. 12 table, bounds "16632, 17173"
  for α₅); pp. 13–14 (worked inference, x = 4 for content (3,3,3,3)); p. 14 ("the fourth diagonals
  can be entirely different …": false read per vector; "We hope to return to these matters").
- **Sal09** (READ). A. Salomaa, *Upper triangular matrices and subword occurrences*, Sci. Math.
  Japonicae Online e-2009, 239–246. No DOI (Crossref query today). URL
  https://www.jams.jp/scm/contents/e-2009-4/2009-32.pdf (FT on 18 Oct; also served at jams.or.jp;
  **both refused connections on 21 Oct**). Locators (docs/literature.md §§B, M;
  `proof-r2-extrema.md` §6): §2, PDF p. 3 (the inequality "valid for all words w, x, y, z, [8]",
  [8] = MSY04); Thm 2, PDF p. 4 / printed p. 241 (restates it with a proof by 2×2 minors, Lemma 1);
  M-unambiguous words known for 2 and 3 letters. Use: cite MSY04 as the origin and Sal09 for the
  minor proof.
- **Sal10** (READ). A. Salomaa, *Criteria for the matrix equivalence of words*, Theoret. Comput.
  Sci. 411(16–18) (2010) 1818–1827. DOI 10.1016/j.tcs.2010.01.036 (Crossref). Local PDF
  `salomaa-2010-tcs411.pdf` (`7e200313…52b0`). Locators: §5, p. 1824 (all words of a ternary class
  from binary projections; "interchanging the factors ac and ca"; "the worst-case complexity is
  exponential"); §6: Lemma 4, p. 1825 ("implicit in [22]" = ŞŞ06), Defs 4–5, Lemmas 5–6, Thm 9,
  p. 1826 (moves with counters).
- **Sal15** (LOCATED-UNREAD; the highest-risk limit). A. Salomaa, *On a Cauchy-type inequality for
  subword occurrences*, Analele Universităţii Bucureşti, Informatică (Annals of the University of
  Bucharest, informatics series) 62 (LXII), no. 2 (2015), 101–112; issue in honour of Solomon
  Marcus's 90th birthday. **No DOI** (Crossref query today). Bibliographic record and abstract:
  https://tucs.fi/publications/view/?pub_id=jSalomaa_Arto15b (re-fetched today; SHA-256
  `5408b2c4…f5e3`, equal to the 21 Oct hunt's copy). The abstract (AB): "The paper studies
  properties of Parikh matrices and the resulting inequality for subword occurrences. The latter
  resembles the well-known Cauchy inequality for real numbers. Also cases are studied where the
  Cauchy-type inequality reduces to an equality." Also Sal18 ref. [12] (p. 112) and Sal18 p. 103
  ("A typical example of this is the inequality considered in [12]"). Not obtainable online
  (`priority-article2.md` §9.1(b) lists every route); a library request remains. **Name it as an
  unread limit wherever Thm B, Thm C (T2, T3) or Lemma 3.2 is discussed.**
- **Sal18** (READ). A. Salomaa, *Parikh matrices: subword indicators and degrees of ambiguity*, in
  H.-J. Böckenhauer, D. Komm, W. Unger (eds.), *Adventures Between Lower Bounds and Higher
  Altitudes* (Hromkovič Festschrift), Lecture Notes in Comput. Sci. 11011, Springer, Cham, 2018,
  100–112. DOI 10.1007/978-3-319-98355-4_7 (Crossref; volume number from the footer of the local
  PDF, "LNCS 11011, pp. 100–112, 2018"). Local PDF `salomaa-2018.pdf` (`c46b66b0…cbdbc`). Locators:
  p. 103 (the sentence on [12] = Sal15); p. 106 (Thm 5, every entry independent, "established in
  [9]"; fixing diagonals does not determine the matrix); **Def. 6, p. 109** (the degree of
  M-ambiguity d(M), "a very natural notion not at all studied by now"); Lemma 4, p. 110 (no
  polynomial bound; uses the central binary maximum); **pp. 110–111**: the ternary words with
  |w|_a = |w|_c = n and no b, sharing one Parikh matrix, whose "number ... equals the binomial
  coefficient" binom(2n, n) ≥ 2^n (p. 111): the case b = 0, a = c of the τ-classes, cited as
  "cf." in §§1, 6 and 9 (credit-13; checked first-hand by the Phase 4 fixers and re-checked on
  22 Oct 2026); Thm 8, p. 111; p. 111 (strong
  M-equivalence credited to [17]); reference list p. 112 ([12] = Sal15; [17] = "Tex, W.C.: On
  M-ambiguity for Parikh matrices. AMC 2016", probably Teh20b).
- **Faz08** (LOCATED-UNREAD). S. Z. Fazekas, *On inequalities between subword histories*, Int. J.
  Found. Comput. Sci. 19(4) (2008) 1039–1047. DOI 10.1142/S012905410800611X (Crossref). Abstract
  only (`priority-article2.md` §3.3): which subword inequalities hold for all words.
- **Faz11** (READ). S. Z. Fazekas, *On inequalities between subword histories*, RIMS Kôkyûroku
  (Sūrikaisekikenkyūsho Kōkyūroku) 1769 (2011) 140–143. No DOI (the Crossref record with this
  title is Faz08, a different publication). URL
  https://www.kurims.kyoto-u.ac.jp/~kyodo/kokyuroku/contents/pdf/1769-19.pdf (today's download
  equals the recorded copy, `dd79af5a…3d69`). Read in full (`priority-article2.md` §1.1): which
  linear subword inequalities hold for all words; nothing on fibrewise minima; credits the Cauchy
  inequality to MSY04.

## 3. M-ambiguity, M-equivalence and classes

- **SS06** (READ, authors' final manuscript). V. N. Şerbănuţă, T.-F. Şerbănuţă, *Injectivity of
  the Parikh matrix mappings revisited*, Fund. Inform. 73(1–2) (2006) 265–283, Zbl 1104.68058
  (zbMATH page fetched today). **No DOI** (Crossref query today; only FI 73(3) has DOIs). Read in
  full (three rounds) in the authors' final manuscript in the journal class, header "Fundamenta
  Informaticae XX (2006) 1–19", archived at
  https://web.archive.org/web/20170829043846id_/http://fsl.cs.illinois.edu/pubs/serbanuta-serbanuta-2006-fi.pdf
  (SHA-256 `10044968…d936`, equal today; the live file is 404). **Cite manuscript pages ("ms.
  p. N"); journal page = ms. page + 264 is an unchecked inference.** Locators: p. 2 (binary
  M-unambiguous words); Thm 2.2, p. 4; §2.3, pp. 4–5; Thm 2.3, p. 5 ("Next result from [5] (see
  also [4, 2])" = MS04, FR04, AMM02); **Thm 2.4, p. 5** ("A Parikh matrix over a binary alphabet
  is unambiguous if and only if it possesses the γ-property", attributed to Sal05i); Thm 2.5,
  p. 5; Prop 3.1, p. 7; Thm 3.1, p. 8; Thm 3.2 and Cor 3.2, pp. 8–9 (p. 9: Sal05i's criterion is
  "an instance of the above Corollary for the sequence (i, i + 1)"); Thms 3.3–3.6, pp. 10–11;
  **App. A, pp. 16–19**: "The results in this section were proved in [17]" (V. N. Şerbănuţă's 2002
  master's thesis, unread, §8); Algorithm A.1 "The Moving Algorithm", p. 16; the third paragraph
  after Fact A.2, p. 16 ("Every (i, j)-rule in Algorithm A.1 change the number of abc in the word
  with the number of c between i and j …"); p. 17 ("… we must use the same number of rules that
  decrease and increase it"); Thm A.1, p. 19 (ternary M-unambiguous words). Use: credit the move
  device here (with Sal10 §6 and HCH23 Prop 5); claim only the case analysis.
- **Ser09** (LOCATED-UNREAD; a named limit). V. N. Şerbănuţă, *On Parikh matrices, ambiguity, and
  prints*, Int. J. Found. Comput. Sci. 20(1) (2009) 151–165. DOI 10.1142/S0129054109006498
  (Crossref). Abstract only. Sal18 ref. [15]. A substitute (his PhD thesis) is located but only
  keyword-searched (§8).
- **AMM02** (LOCATED-UNREAD). A. Atanasiu, C. Martín-Vide, A. Mateescu, *On the injectivity of the
  Parikh matrix mapping*, Fund. Inform. 49(4) (2002) 289–299. DOI 10.3233/FUN-2002-49401
  (Crossref). Abstract only (binary words, palindromic amiability). Cite only as attributed in
  ŞŞ06 Thm 2.3 for the binary M-unambiguous words.
- **FR04** (LOCATED-UNREAD). S. Fossé, G. Richomme, *Some characterizations of Parikh matrix
  equivalent binary words*, Inform. Process. Lett. 92(2) (2004) 77–82. DOI 10.1016/j.ipl.2004.06.011
  (Crossref). Metadata and second-hand only. Cite only as attributed in ŞŞ06 Thm 2.3; **not** as
  the source of the move device (an unread lead for that).
- **AAP08** (READ). A. Atanasiu, R. Atanasiu (Radu), I. Petre, *Parikh matrices and amiable
  words*, Theoret. Comput. Sci. 390(1) (2008) 102–109. DOI 10.1016/j.tcs.2007.10.022 (Crossref).
  Publisher PDF at `~/Downloads/papers/1-s2.0-S0304397507007712-main.pdf` (SHA-256 `c846ad00…d282`,
  hashed today; header "Theoretical Computer Science 390 (2008) 102–109"), read in full in
  `priority-r7-scan.md` §1.3. Locator: Example 19, p. 106 (content (2,3,2): "210 sequences
  distributed in 70 classes", two self-mirror classes of sizes 4 and 6; the printed word "acbbcac"
  is a misprint for acbbbac, `notes/r7-scripts/priority/aap08_232.py`). Use: (2,3,2) class data
  beside 2B2 (no extremum there).
- **Teh15** (LOCATED-UNREAD; a limit). W. C. Teh, *On core words and the Parikh matrix mapping*,
  Int. J. Found. Comput. Sci. 26(1) (2015) 123–142. DOI 10.1142/S0129054115500069 (Crossref).
  Abstract only ("some interesting results regarding the M-equivalence classes of ternary words").
- **TK15** (LOCATED-UNREAD; a limit). W. C. Teh, K. H. Kwa, *Core words and Parikh matrices*,
  Theoret. Comput. Sci. 582 (2015) 60–69. DOI 10.1016/j.tcs.2015.03.037 (Crossref). Metadata only;
  free in Elsevier's open archive but bot-blocked for scripts.
- **Teh16** (READ). W. C. Teh, *Parikh matrices and strong M-equivalence*, Int. J. Found. Comput.
  Sci. 27(5) (2016) 545–556. DOI 10.1142/S0129054116500155 (Crossref); arXiv:1501.07354v2 (arXiv
  API). FT ✓ (docs/literature.md §C): Remark 4.6 (a referee's count: "all the 9841 ternary words of
  length at most eight" form "2729 M-equivalence classes"). Teh20b credits strong M-equivalence to
  it (its ref. [12]).
- **Teh20** (READ). W. C. Teh, *Parikh-friendly permutations and uniformly Parikh-friendly
  words*, Australas. J. Combin. 76(1) (2020) 208–219. No DOI (Crossref query today). URL
  https://ajc.maths.uq.edu.au/pdf/76/ajc_v76_p208.pdf (today: the AJC PDF, header "Volume 76(1)
  (2020), Pages 208–219"). FT (docs/literature.md §C): "permutation" there means a permutation of
  the alphabet; no overlap. Context for Sim20.
- **Teh20b** (READ). W. C. Teh, *On M-unambiguity of Parikh matrices*, Indones. J. Combin. 4(1)
  (2020) 1–9. DOI 10.19184/ijc.2020.4.1.1 (Crossref gives first page 1; the PDF header gives
  1–9). Local file `teh-2016-amc.pdf` (named after the hunt key; SHA-256 `507f77df…8ec8`, equal to
  today's download of the publisher PDF). Read in full (rigidity and topgap rounds). Locators:
  Thms 2.2–2.3; Thm 3.1 and its proof, pp. 6–7 (the count 6n − 10 of binary M-unambiguous words,
  p. 7); Thms 3.1–3.3 (prints); Acknowledgement, PDF p. 8 ("It has been presented in the Asian
  Mathematical Conference 2016 at Bali, Indonesia"). **Probably** the written version of Sal18's
  ref. [17]: an inference (titles differ; Teh20b credits strong M-equivalence to Teh16). Nothing
  on Thms A–F. The code Teh20 is taken by the AJC paper.
- **Sim20** (READ). J. Simpson, *Short witnesses for Parikh-friendly permutations*, Australas. J.
  Combin. 78(2) (2020) 329–334. No DOI (Crossref query today). URL
  https://ajc-new.maths.uq.edu.au/v78.p329 (the AJC article page, today HTTP 200 with the title;
  the AJC PDF, header "Volume 78(2) (2020), Pages 329–334", was also fetched). FT
  (docs/literature.md §C; `proof-r7-switch.md` §3 Remark (5), read first-hand by its finaliser,
  p. 331): **Thm 3(c),(d) and Cor 4, p. 331**: for palindromes in which every letter occurs twice,
  the entries are 0 or 2, with the recursive rule (Thm 3(d): "Each element p_{i,j} ... with
  j ≥ i+4 equals 2 if both p_{i,j-1} and p_{i+1,j} equal 2, and equals 0 otherwise"; Cor. 4: the
  alphabet and the fourth diagonal suffice; quoted by the Phase 4 credit referee). Use: Theorem
  H(i) (the former F(i)) is a **direct consequence** of these statements, as every trace class of
  the central fibre of (2^k) contains a special palindrome; only the explicit QP description and
  the count F_k are claimed as not located (credit-5).
- **HMR22** (READ, accepted manuscript). L. K. Hutchinson, R. Mercaş, D. Reidenbach, *A toolkit for
  Parikh matrices*, in Implementation and Application of Automata, CIAA 2022 (Rouen, France), Lecture
  Notes in Comput. Sci. 13266, Springer, Cham, 2022, 116–127. DOI 10.1007/978-3-031-07469-1_9
  (Crossref; no volume there); volume, editors and venue from the Loughborough repository record
  (figshare API, article 20222028). Accepted manuscript: handle https://hdl.handle.net/2134/20222028.v1
  (Handle API today) and file https://ndownloader.figshare.com/files/36143979 (SHA-256
  `846d782c…50ac`, equal today). Read in full by skeptic 3; locators §3.7 ("Is It Parikh?"),
  Example 5, pp. 9–10 (abbacc, a class of 4 words). A software toolkit; nothing on Thms A–F.
- **Hut22** (READ, parts). L. K. Hutchinson, *Reducing the ambiguity of Parikh matrices:
  theoretical considerations and tools*, PhD thesis, Loughborough University, January 2022
  (figshare: PhD, 2022; 134 pp.). DataCite DOI 10.26174/thesis.lboro.18865808.v1 (Crossref 404;
  resolved through DataCite today; **not printed**). Printed URL: the one registered with DataCite,
  https://repository.lboro.ac.uk/articles/thesis/Reducing_the_ambiguity_of_Parikh_matrices_theoretical_considerations_and_tools/18865808/1
  (the repository answers scripts with HTTP 202, so the URL is confirmed by the registry). Local
  PDF `hutchinson-2022-thesis.pdf` (`5515f7d9…098de`; printed page = PDF page − 1). Locators:
  pp. 12–13 (survey; p. 13: the M-unambiguity question "remains open for ternary and larger
  alphabets"); p. 117 (MS04's polynomial-time listing claim "was later shown to be exponential
  [60]", [60] = Sal18); §5.2.7.
- **HCH23** (READ, authors' corrected version). J. Hahn, H. Cheon, Y.-S. Han, *M-equivalence of
  Parikh matrix over a ternary alphabet*, in Implementation and Application of Automata, CIAA
  2023, Lecture Notes in Comput. Sci., Springer, Cham, 2023, 141–152. DOI
  10.1007/978-3-031-40247-0_10 (Crossref). **LNCS volume number unconfirmed (finding 3).** Read in
  https://toc.yonsei.ac.kr/~emmous/papers/corrected_ciaa23.pdf (14 pp., own pagination; SHA-256
  `c13bf6cd…32ef`, equal today). Locators (PDF pages): Prop 5, items 2–3, pp. 5–6 (the swap
  identity: |w|₀₁₂ changes by |u|₂ or |u|₀); Figs 1–3, pp. 6–7; Def. 5, p. 7; Lemmas 1–2 and
  Thm 2, p. 9; Cor 1 and Thm 4, p. 11. **Caution**: do not cite HCH for unit-step connectivity
  inside an (x,y)-fibre (T2 refutes that reading; `proof-top-gap-rigidity.md` §11).
- **HCH26** (LOCATED-UNREAD; a limit). J. Hahn, H. Cheon, Y.-S. Han, *Characterizations of
  M-equivalence and weak M-relation*, Int. J. Found. Comput. Sci. 37(1) (2026) 73–92. DOI
  10.1142/S0129054125410047 (Crossref; online 2025). Abstract only: the degree of the weak
  M-relation, not d(Ψ).
- **MT25** (READ, introduction and conclusion). R. Mercaş, W. C. Teh, *Ternary is still good for
  Parikh matrices*, Theoret. Comput. Sci. 1055 (2025) 115489. DOI 10.1016/j.tcs.2025.115489
  (Crossref); arXiv:2410.15004v1 (arXiv API). FT of the arXiv introduction (docs/literature.md
  §§C, L): ternary M-equivalence is completely characterized (Sal10; HCH). Use: with Sal10 and
  HCH23, the characterisations concern when two words share a class, not class sizes.
- **Ric26** (READ, selected sections). G. Richomme, *On some 2-binomial coefficients of binary
  words: geometrical interpretation, partitions of integers, and fair words*, Theoret. Comput.
  Sci. 1066 (2026) 115732. DOI 10.1016/j.tcs.2025.115732 (Crossref); arXiv:2510.07159v1. Lemmas
  4.12–4.13 (a binary class ↔ partitions of |w|_ab in a box); Thms 4.2 and 4.19 (lattices). Use:
  the binary ingredient of the profile model is classical (`proof-r2-extrema.md` §6).
- **FHM26** (READ, selected sections). S. Z. Fazekas, X. Huang, R. Mercaş, *Subsequence analysis
  problems for binary Parikh matrices*, Electron. Proc. Theor. Comput. Sci. (EPTCS) 451 (2026)
  140–154. DOI 10.4204/EPTCS.451.10 (Crossref); arXiv:2610.06717v1. Lemma 5.4, p. 149 (binary class
  sizes unimodal "by Sylvester's classical result", citing O'Hara) and its proof, p. 151; binary
  class sizes as Gaussian coefficients. Optional: the k = 2 background inside the Parikh
  literature.

## 4. Linear extensions, order polytopes and transfer operators (Theorem F; trace classes)

- **IriarteArXiv** (READ). B. Iriarte, *Graph orientations and linear extensions*,
  arXiv:1405.4880v2 (14 February 2015; v1 May 2014; arXiv API). FT of §§1–4 (`r5-opening.md`,
  References item 5): Thm 2.6 (bipartite), Def. 2.7 and Thm 2.8 (odd cycles), **Thm 3.7**
  (connected comparability graphs: the maximisers are exactly the transitive orientations), Cor
  3.11 (p. 10), Obs. 4.2 (p. 12), Obs. 4.5 and Ex. 4.6 (p. 13).
- **Iriarte14** (READ). B. Iriarte, same title, in 26th International Conference on Formal Power
  Series and Algebraic Combinatorics, FPSAC 2014 (Chicago), Discrete Math. Theor. Comput. Sci.
  Proc. AT (2014) 945–956. DOI 10.46298/dmtcs.2455 (Crossref: DMTCS, article 2455; pages from the
  PDF header "DMTCS proc. AT, 2014, 945–956", fetched today from dmtcs.episciences.org). FT of the
  extended abstract (`r5-opening.md`): Thm 2.5, Def. 3.1, Thm 3.2, Thm 4.5.
- **Iriarte17** (READ, accepted manuscript). B. Iriarte, same title, Math. Oper. Res. 42(4) (2017)
  1219–1229. DOI 10.1287/moor.2016.0845 (Crossref). Accepted manuscript (INFORMS template, accepted
  26 Oct 2016), archived at
  https://web.archive.org/web/20170830103126id_/http://math.mit.edu/~biriarte/Linear_Extensions.pdf
  (local `iriarte-2017-mor.pdf`, SHA-256 `c8368257…d56a`, equal today). **Numbering map**
  (`priority-article2.md` §9.3, Thm F): arXiv v2 Thm 3.7 = AM Theorem 3, p. 4; v2 Thm 3.5
  (Stanley) = AM Theorem 2 ([14]), p. 4; v2 Thm 2.6 = AM Corollary 2 ([13] = Stachowiak), p. 8;
  v2 Thm 2.8 = AM Theorem 4, p. 8; v2 Obs 4.2 = AM Observation 3.2, p. 8. The typeset MOR
  numbering is unchecked. **Write "Iriarte, Theorem 3 (accepted manuscript; arXiv v2 Thm 3.7)", or
  cite IriarteArXiv explicitly.** Use: isolated contents are KNOWN (Iriarte + γ, through the
  occurrence-graph reduction of `r5-opening.md` §G.2 and `proof-r7-switch.md` §5).
- **Stachowiak88** (LOCATED-UNREAD). G. Stachowiak, *The number of linear extensions of bipartite
  graphs*, Order 5(3) (1988) 257–259. DOI 10.1007/BF00354893 (Crossref). Metadata only; Iriarte's
  ref. [13]; the bipartite case, which does not apply to repeated letters.
- **Sta86** (READ). R. P. Stanley, *Two poset polytopes*, Discrete Comput. Geom. 1(1) (1986) 9–23.
  DOI 10.1007/BF02187680 (Crossref). Author scan https://math.mit.edu/~rstan/pubs/pubfiles/66.pdf
  (SHA-256 `5e5bc631…9a61f28`, equal today; journal pagination; the abbreviation `…de03` printed
  here on 21 Oct was a slip, corrected 22 Oct 2026 against `priority-article2.md` and the
  Phase 4 credit referee's download). Locators: Def 2.1 and Thm 2.2,
  pp. 12–13; **Cor. 4.2, p. 15** ("The volumes of O(P) and C(P) are given by V(O(P)) = V(C(P)) =
  e(P)/n!"); Example 4.3, p. 15; Cor 4.5, p. 16. Stanley's "transfer map" (§3) is a
  piecewise-linear bijection, not an integral operator: do not conflate.
- **Elk03** (READ, arXiv v5). N. D. Elkies, *On the sums Σ_{k=−∞}^{∞}(4k+1)^{−n}*, Amer. Math.
  Monthly 110(7) (2003) 561–573. DOI 10.1080/00029890.2003.11919997 (Crossref; the JSTOR DOI
  10.2307/3647742 is the same article, use the first); arXiv:math/0101168v5. Locators (v5): eq.
  (37), (Tf)(v) = ∫₀^{π/2−v} f(u) du; Lemma 3 (eigenvalues 1/(4k+1)).
- **BR10** (READ, arXiv v1). Y. Baryshnikov, D. Romik, *Enumeration formulas for Young tableaux in
  a diagonal strip*, Israel J. Math. 178 (2010) 157–186. DOI 10.1007/s11856-010-0061-6 (Crossref);
  arXiv:0709.0498v1 (SHA-256 `d153df81…`). Locators (v1): §3, Def. 7 and Prop. 8, eqs (18)–(19),
  pp. 12–13 (vol(P) = ⟨T_{k−1}∘⋯∘T₁(1), 1⟩, eq. (19), p. 13); §9 items 1–2, pp. 28–29.
- **EF10** (READ, arXiv v1). R. Ehrenborg, Y. Farjoun, *Asymptotics of the Euler number of
  bipartite graphs*, Adv. in Appl. Math. 44(2) (2010) 155–167. DOI 10.1016/j.aam.2009.05.002
  (Crossref); arXiv:0704.1782v1. Locators (v1): Thm 1.1, p. 2; Example 2.5, p. 4 (eigenvalues
  2/(πk)); §5, p. 12 (gluing "via linear operators and their eigenvalues").
- **ELR02** (READ). R. Ehrenborg, M. Levin, M. A. Readdy, *A probabilistic approach to the descent
  statistic*, J. Combin. Theory Ser. A 98(1) (2002) 150–162. DOI 10.1006/jcta.2001.3233 (Crossref).
  Publisher typesetting hosted by the author, https://www.ms.uky.edu/~jrge/Papers/Probabilistic.pdf
  (local `ehrenborg-levin-readdy-2002.pdf`, `44879f01…e1`, equal today; journal pages valid).
  Locators: p. 151 (Niven–de Bruijn quoted); Prop 2.1, eqs (2.1)–(2.3), p. 152; Thm 3.2, p. 153;
  Cor 3.4, p. 154; Thm 3.5 and its proof, p. 155 (the lr-type comparison 0 ≤ g(x)g′(y) − g′(x)g(y));
  Thm 4.1, p. 156; Cor 4.2 ("This corollary is well known") and Thm 4.3, p. 157. Use: "cf." for
  the conditioning device of D(i); prior method for Thm F; never call the method new.
- **EM98** (READ, authors' copy). R. Ehrenborg, S. Mahajan, *Maximizing the descent statistic*,
  Ann. Comb. 2(2) (1998) 111–129. DOI 10.1007/BF01608482 (Crossref). Authors' copy re-typeset in
  2007, https://www.ms.uky.edu/~jrge/Papers/Maximizing.pdf (local, `de36b3a2…8833`, equal today).
  **Pages are those of the authors' copy (1–21); journal pages not mapped**, and the .bib says
  so. Locators: Thm 1.2, p. 1 (Niven–de Bruijn); Lemma 2.4, p. 5; §3: Def. 3.4, p. 8; Cor 3.8,
  Lemma 3.9 and Thm 3.10, p. 9; Prop 4.2, p. 10; **Fig. 5 and its text, p. 14** ("Observe how the
  values in each row alternate …"; column i = 0: 1, 3, 9, 35, 155, …); Thm 6.1, p. 15; §7, p. 18.
- **Ehr02** (READ). R. Ehrenborg, *The asymptotics of almost alternating permutations*, Adv. in
  Appl. Math. 28(3–4) (2002) 421–437. DOI 10.1006/aama.2001.0790 (Crossref). Author copy with the
  journal header, https://www.ms.uky.edu/~jrge/Papers/Almost.pdf (SHA-256 `a1c354c4…8650`, equal
  today; journal pages valid; **not in parikh-sources**, finding 8). Locators: eq. (2.4), p. 424;
  Thm 3.2, p. 427 (limit π/2 − 1); Cor 3.1 (a = 0) and Prop 4.1, p. 428 (Prop 4.1 prints the typo
  "r1 ≥ r3 ≥ r3"); Prop 4.2, p. 429 (interior-defect limit 2/π); Thm 4.1, p. 430; Thms 5.2–5.3,
  p. 432; Conj 7.1, p. 435. Use: **n = 1 of the sandwich is classical**; the one-end limit is
  π/2 − 1, while 2/π is the interior-defect limit (design flag F5).
- **GGMM21** (READ, arXiv v2). A. Garver, S. Grosser, J. P. Matherne, A. H. Morales, *Counting
  linear extensions of posets with determinants of hook lengths*, SIAM J. Discrete Math. 35(1)
  (2021) 205–233. DOI 10.1137/20M1320730 (Crossref); arXiv:2001.08822v2 (`501a61a5…`). Locators
  (v2): Def. 4.2 (mobile posets), Thm 4.9, Cor 4.12, Cor 4.16 (pp. 16–17; = OEIS A332471).
- **FMP** (READ, arXiv v3). L. Ferroni, A. H. Morales, G. Panova, *Skew shapes, Ehrhart positivity
  and beyond*, arXiv:2503.16403v3 (28 July 2026). Locators: §§1.4, 2.1, 5.1, 7 (closed ribbons,
  printed p. 18; Example 7.8, pp. 19–20), 8. No DOI; the published version is unread.
- **StaSurv** (READ through the P4 sub-check). R. P. Stanley, *A survey of alternating
  permutations*, arXiv:0912.4240v1 (2009). (1.10), §3.8, and p. 12 ("The proof of Theorem 3.5
  generalizes a transfer operator approach to alternating permutations due to Elkies"). Published
  version not checked; cite the arXiv version.
- **StaAlt** (READ through the P4 sub-check). R. P. Stanley, *Alternating permutations and
  symmetric functions*, arXiv:math/0603520v3 (2006). §7 ((A,B)-alternating multiset permutations,
  a different alternation). Published version not checked.
- **Kre76** (READ, §4.3). G. Kreweras, *Les préordres totaux compatibles avec un ordre partiel*,
  Math. Sci. Humaines 53 (1976) 5–30 (French). No DOI (Crossref query today). Numdam
  http://www.numdam.org/item/MSH_1976__53__5_0/ (today HTTP 200, redirected to https). §4.3,
  printed pp. 20–21 (`r5-opening.md`, References item 10): m·E_{2m−1}. Only if the one-sentence
  cyclic remark is kept.
- **A034428** (READ). OEIS A034428, "E.g.f.: 1 - (1-x)*(tan(x) + sec(x))", https://oeis.org/A034428
  (fetched 20 Oct, revision 66; HTTP 200 today); a(n) = nE_{n−1} − E_n (R. Ehrenborg), cites EM98.
  The n = 1 end-relaxation numbers.
- **A332471** (READ). OEIS A332471, https://oeis.org/A332471 = GGMM's C_p(k) (docs/literature.md
  §N).

## 5. Statistics (Theorem D, H1)

- **MW47** (READ, by OCR). H. B. Mann, D. R. Whitney, *On a test of whether one of two random
  variables is stochastically larger than the other*, Ann. Math. Statistics 18(1) (1947) 50–60.
  DOI 10.1214/aoms/1177730491 (Crossref). Journal scan (Wayback capture of the Project Euclid PDF;
  local `mann-whitney-1947.pdf`, `7647e2a2…0788`, equal today; printed page = PDF page + 49).
  Locators: §3, p. 51 ("Let U count the number of times a y precedes an x"); §4, p. 51 (p̄_nm(U) and
  its recurrence); eq. (2), p. 51 (mean nm/2); eq. (5), p. 55 (variance nm(n+m+1)/12); eq. (15),
  p. 58; §5, pp. 58–59; Table I, pp. 52–54. Two samples only: **not a locator for D(i)**.
- **JV14** (READ, §3.2 of the preprint). T. S. Jayram, J. Vondrák, *Exchangeability and
  realizability: de Finetti theorems on graphs*, in Approximation, Randomization, and
  Combinatorial Optimization. Algorithms and Techniques, APPROX/RANDOM 2014, Leibniz Int. Proc.
  Inform. 28, Schloss Dagstuhl–Leibniz-Zentrum für Informatik, 2014, 762–778 (volume and pages from
  the DataCite record). DataCite DOI 10.4230/LIPIcs.APPROX-RANDOM.2014.762 (Crossref 404; resolved
  through DataCite today; **not printed**). Read in the preprint
  https://theory.stanford.edu/~jvondrak/data/G-realizable.pdf (`0b1598a0…c19a6`, equal today), which
  the .bib prints. Locator: §3.2, preprint p. 9 ("completely positive matrices correspond to
  i.i.d. mixes (up to normalization) … Clearly, every completely positive matrix is doubly
  nonnegative"). Use: the generic PSD step of D(ii).
- **Sch23** (READ). F. W. Scholz, *On Steel's test with ties*, arXiv:2308.05873v1 (2023). FT (P3
  sub-check; quote spot-checked): p. 3 ("equivalent two stage process"); p. 6, eq. (4); p. 7. The
  nearest statistical locator for D(i), which stays "standard, no exact locator".
- **Ter52** (READ, by OCR). T. J. Terpstra, *The asymptotic normality and consistency of Kendall's
  test against trend, when ties are present in one ranking*, Indag. Math. (Proceedings) 55 (1952)
  327–333 (also numbered Indag. Math. 14). DOI 10.1016/S1385-7258(52)50043-X (Crossref). CWI scan
  https://ir.cwi.nl/pub/8258/8258D.pdf (`3ac9936e…`). Lemma 2, p. 329 (a different classical
  independence).
- **Ste59** (LOCATED-UNREAD; a limit). R. G. D. Steel, *A multiple comparison rank sum test:
  treatments versus control*, Biometrics 15(4) (1959) 560 ff. DOI 10.2307/2527654 (Crossref; first
  page only). Abstract only.
- **LS95** (LOCATED-UNREAD; a limit). R. E. Lee, J. D. Spurrier, *Distribution-free multiple
  comparisons between successive treatments*, J. Nonparametr. Statist. 5(3) (1995) 261–273. DOI
  10.1080/10485259508832647 (Crossref). Abstract only ("a table of exact probability points … for
  use with Mann Whitney statistics in the equal sample size case"; successive treatments, not a
  common control).
- **Jon54** (LOCATED-UNREAD). A. R. Jonckheere, *A distribution-free k-sample test against ordered
  alternatives*, Biometrika 41(1–2) (1954) 133–145. DOI 10.1093/biomet/41.1-2.133 (Crossref; the
  JSTOR DOI 10.2307/2333011 is the same article). Metadata only.
- **vdW02** (LOCATED-UNREAD). M. A. van de Wiel, *Exact distributions of multiple comparisons rank
  statistics*, J. Amer. Statist. Assoc. 97(460) (2002) 1081–1089. DOI 10.1198/016214502388618898
  (Crossref). Abstract only.
- **FW76** (LOCATED-UNREAD; "the most plausible classical locator" for D(i)). M. A. Fligner,
  D. A. Wolfe, *Some applications of sample analogues to the probability integral transformation
  and a coverage property*, Amer. Statist. 30(2) (1976) 78–85. DOI 10.1080/00031305.1976.10479145
  (Crossref; JSTOR DOI 10.2307/2683799 is the same article). Metadata only.
- **FW82** (LOCATED-UNREAD). M. A. Fligner, D. A. Wolfe, *Distribution-free tests for comparing
  several treatments with a control*, Statist. Neerlandica 36(3) (1982) 119–127. DOI
  10.1111/j.1467-9574.1982.tb00783.x (Crossref). Abstract only.

## 6. The H1 centre value and the k = 2 background

- **AP93** (READ, authors' copy). G. E. Andrews, P. Paule, *Some questions concerning
  computer-generated proofs of a binomial double-sum identity*, J. Symbolic Comput. 16(2) (1993)
  147–151. DOI 10.1006/jsco.1993.1038 (Crossref). Authors' copy
  https://www.ricam.oeaw.ac.at/Groebner-Bases-Bibliography/gbbib_files/publication_380.pdf (today
  redirected to www3.risc.jku.at, same file, SHA-256 `9903d00c…ff11d`; 7 pp.; its header
  "J. Symbolic Computation (1994) 11, 1–7" is a preprint placeholder, so cite the journal data).
  **Page numbers are the authors' copy's; journal pages unverified**, and the .bib says so.
  Locators: eq. (1.1), p. 1 (a = c even; "Problem E3376 of Amer. Math. Monthly 97, March 1990");
  **eq. (2.2), p. 4** (the general identity; with (m, n) = (c, a) it is Theorem 1(ii) of
  `proof-h1-centre.md`: KNOWN), with (2.3), (2.4) and the Remark, p. 4; p. 6 (the 1992 solution
  reference).
- **Sta89** (READ, page images). R. P. Stanley, *Log-concave and unimodal sequences in algebra,
  combinatorics, and geometry*, Ann. New York Acad. Sci. 576 (1989) 500–535. DOI
  10.1111/j.1749-6632.1989.tb16434.x (Crossref). Author scan
  https://math.mit.edu/~rstan/pubs/pubfiles/72.pdf (image only; fetched today). **Thm 11, p. 516**
  (q-binomial coefficients are symmetric and unimodal; credits Sylvester 1878 and Elliott 1913).
  Use: the k = 2 background of H1.
- **PP13** (READ, arXiv v2). I. Pak, G. Panova, *Strict unimodality of q-binomial coefficients*,
  C. R. Math. Acad. Sci. Paris 351(11–12) (2013) 415–418. DOI 10.1016/j.crma.2013.06.008 (Crossref);
  arXiv:1306.5085v2. Thm 1, p. 1; **Thm 6, p. 3** (strict unimodality iff …; nine exceptional
  pairs). Use: a unique centre already fails at k = 2 ([5 choose 2]_q = 1, 1, 2, 2, 2, 1, 1).
- **A000515** (READ). OEIS A000515, https://oeis.org/A000515: its comment "Right-hand side of
  Sum_{i=0..n} Sum_{j=0..n} binomial(i+j,j)^2 * binomial(4n-2i-2j,2n-2j)" led to AP93.

## 7. The golden-ratio ties: Singmaster and the OEIS

**The tie set of Theorem F(vi) is classical (Phase 4, credit-1).** By Cor. 6.5(i) (cor:fone) the
tie equation c(c−1) = a(a+c−1) is binom(a+c−2, a) = binom(a+c−1, a−1), which for a ≥ 2 is
Singmaster's equation binom(n+1, k+1) = binom(n, k+2) at (n, k) = (a+c−2, a−2); its solutions are
the Fibonacci family. The article calls the tie set classical, presents Lemma 6.10 (lem:pell) as
known ("cf. [Sin75, §2]", proved for completeness), and claims as not located only parts
(iii)–(v) of Theorem F and the five largest classes in (vi).

- **Sin75** (READ). D. Singmaster, *Repeated binomial coefficients and Fibonacci numbers*,
  Fibonacci Quart. 13(4) (1975) 295–298. DOI 10.1080/00150517.1975.12430610 (Crossref, resolved
  22 Oct 2026 by the Phase 4 credit referee and again by
  `article2-check/tools/resolve_addendum.py`: title, first author, year, volume 13 and first
  page 295 match). Read first-hand in the scan served by fq.math.ca (SHA-256
  `dcd7ef885c3647fe77cceb5de7d4628f55690255d8f9b513f8a10d23e0dfc620`, copy in the session
  scratchpad, `…/scratchpad/dl-sin75/singmaster.pdf`; not yet copied to `parikh-sources/`).
  Locators: §2, pp. 295–296: eq. (1) binom(n+1, k+1) = binom(n, k+2); (2)–(3), the condition
  that 5j² − 2j + 1 be a square, rewritten as (5j−1)² − 5v² = −4; (4)–(5), the Pell-like equation
  and its solutions L_{2i−1} + F_{2i−1}√5; L_i ≡ −1 (mod 5) if and only if i ≡ 3 (mod 4); (6),
  j = F_{2i}F_{2i+3} + 1, n = F_{2i+2}F_{2i+3} − 1 (so the ties (6,10), (40,65), …; the trivial
  member (1,2) of the family is outside Singmaster's range k ≥ 0). Singmaster notes that (1) was
  also solved by Lind (his ref. [4], unread: not cited). Use: the tie set and Lemma 6.10, in §§1
  and 6 ("for a ≥ 2 Singmaster solved through a Pell equation").
- **A089508** (READ, full entry). OEIS A089508, "Solution to a binomial problem together with
  companion sequence A081016(n-1)", https://oeis.org/A089508 (HTTP 200 on 22 Oct 2026). Text
  format fetched 22 Oct 2026, SHA-256
  `6b6663f8efc36ee6a19acde03b70acddb3a61c77cee355c28472e5893db8a60f` (equal in the re-fetch of
  `resolve_addendum.py`). Its %C line: "a(n) and b(n) := A081016(n-1) are the solutions to the
  Diophantine equation binomial(a,b) = binomial(a+1,b-1)"; %D cites A. I. Shirshov, *On the
  equation binomial(n,m)=binomial(n+1,m-1)*, Kvant Selecta: Algebra and Analysis I, AMS 1999,
  pp. 83–86 (unread: not cited); links to Singmaster's conjecture. Use: the OEIS records the
  solutions of the tie equation (§6).
- **A081016** (READ, full entry; upgraded 22 Oct 2026 from "entry name"). OEIS A081016,
  "a(n) = (Lucas(4*n+3) + 1)/5, or Fibonacci(2*n+1)*Fibonacci(2*n+2)", https://oeis.org/A081016.
  Text format fetched 22 Oct 2026, SHA-256
  `cc460a199d53b263457cd6955b800aec5be7de5c7a8d2428a22e0783e528381e` (equal in the re-fetch).
  Comments read: "a(n-1) is, together with b(n) := A089508(n), n >= 1, the solution to a
  binomial problem; see A089508" and "Numbers k such that 1 - 2*k + 5*k^2 is a square"
  (Jasinski 2008), which is the reduction r² = 5a² − 2a + 1 of Lemma 6.10.
- **A064170** (READ, entry name and formula). OEIS A064170, with "a(n) =
  Fibonacci(2*n-5)*Fibonacci(2*n-3), for n >= 3", https://oeis.org/A064170.

A081016 and A064170 are the P8 hits for the tie coordinates (`priority-article2.md` §5). The
21 Oct note here, "Fibonacci products with no Parikh content", read only the entry names; the
full entries (comments and cross-references) tie the coordinates to the classical equation
binom(n, k) = binom(n+1, k−1), as above. `priority-article2.md` §5 still records only the entry
names (a file outside this pass; flagged in `paper2/VALIDATION.md`).

## 8. Not in the .bib: leads and do-not-cite items

Never cite these; the reason is given. If one is needed, it must first be located, read and
resolved, and added here and to the .bib.

| Item | Status and reason |
|---|---|
| Hardy–Littlewood–Pólya, *Inequalities*; Marshall–Olkin, *Inequalities: Theory of Majorization* | LEAD (design P9). Write "summation by parts", never "majorization" |
| Karlin, *Total Positivity* (1968) | LEAD; the TP2 lemma is proved in the text |
| I. Niven (1968), N. G. de Bruijn (1970) | Seen only in EC1's bibliography and as quoted by ELR02 p. 151 and EM98 Thm 1.2. Cite EC1 Cor 1.6.5 |
| Sylvester (1878), Elliott (1913) | Only as credited by Sta89 Thm 11 |
| Viennot (the proof EM98 p. 9 mentions); Viennot 1979, *Permutations ayant une forme donnée* | Not located / metadata only |
| Amer. Math. Monthly Problem E3376 (1990) and its solution, AMM 99 (1992) 63–65 | Not located first-hand; credited inside AP93 |
| Andrews–Paule–Riese, Problem 10831 (doi:10.2307/2695745); Andrews–Paule, *MacMahon's Partition Analysis IV* (doi:10.1007/978-3-642-56513-7_9); Sun–Ma (doi:10.37236/3701); Miana–Romero (JNT 130) | Unread leads (`proof-h1-centre.md` §8) |
| V. N. Şerbănuţă, *Matrice Parikh injective*, master's thesis, Bucharest, 2002 (ŞŞ06 ref. [17]) | Not located; mention only as "after ŞŞ06's ref. [17]" |
| V. N. Şerbănuţă, *On Parikh Matrices and Ambiguity* (PDF dated 31 August 2009; PhD, Bucharest, 2010 per Mathematics Genealogy), local `serbanuta-2009-phdthesis.pdf` (`9442f685…a431`) | Located; keyword-searched only (2B2, H1 rounds); school and year not on its title page. Substitute for Ser09, not cited |
| TUCS TR 442 (MSY 2002, cited by [Y26a] eq. (2.8)) | Second-hand only (Codex); cite MSY04 |
| MSSY00, TUCS TR 364 (2000) | Located (docs §B); not needed: cite MSSY01 |
| Lee's USC PhD thesis (1992); Orban–Wolfe | Not obtained / not located |
| Carlitz (up-down sequences with repetitions); McConville–Sagan–Smyth; Ehrenborg–Readdy/Jung; Ehrenborg–Kitaev–Perry; Edelman et al. 1989; Stachowiak 1989 | Not located or unread |
| Karataş 2025, *M-denk kelimeler* (MSc thesis, Selçuk Üniversitesi) | LEAD, unread (repository 403) |
| BHHS24 (DLT 2024, doi:10.1007/978-3-031-66159-4_6) | Metadata only, content known from a snippet (docs §J): do not cite |
| Salomaa, Bull. Comput. Data Sci. 1(1) (2020) | Do not cite (docs §I: doubtful provenance) |
| Huang, arXiv:2607.22767 | Skimmed only |
| Stanley 1980 (SIAM J. Alg. Disc. Meth.); Melczer–Panova–Pemantle 2020 | Metadata or abstract only; not needed |
| DHMR20/21, PT18, PT20, TAP18, APT19, Ata07, Ata10, APZT22, TA16, Bhattacharjee 2017 | Inspected (`priority-r7-scan.md` §§1.3–1.5): unrelated to Article 2's claims; not needed |
| Codex's `iriarte-priority-correction.md` | A note in the Codex checkout, not a publication |

## 9. Verification record

**`resolve_refs.py`** (standard library; one process; network): run on 21 October 2026.
- [1] Crossref: 47 of 47 printed DOIs resolved, each with matching title, first author, year,
  volume and first page.
- [2] DataCite: JV14 and Hut22 resolved through DataCite; Crossref returns 404 for both; not
  printed.
- [3] Crossref bibliographic queries for the ten works cited without a DOI (DS06, SS06, Sal05i,
  Sal15, Sal09, Sim20, Teh20, Faz11, Kre76, TR536): no record with the same title, except the
  separate journal publications Faz08 (for Faz11) and MS04 (for TR536).
- [4] arXiv API: 15 of 15 identifiers, with the versions read.
- [5] URLs: every printed non-DOI URL fetched once; hashes compared where recorded (finding 7).
- [6] .bib consistency: 74 entries, all keys covered by the tables; no DataCite DOI printed; no
  `doi`/`url`/`eprint` field.

**`bibtest.py`**: BibTeX 0.99e with amsplain; 74 `\bibitem`s; 0 warnings, 0 errors; pdfLaTeX
clean under `article` and `amsart` (one amsplain comment line deleted before the final runs).

The exact outputs are in `notes/article2-scripts/references/out/`. Rerun with
`/Users/christopheryamba/.pyenv/versions/3.11.9/bin/python3 -B -I <script>` from that directory.

**Phase 4 addendum (22 October 2026).** `notes/article2-scripts/article2-check/tools/resolve_addendum.py`
(standard library; network) resolved the identifiers added since: [1] Crossref, Sin75
10.1080/00150517.1975.12430610, with matching title, first author (Singmaster), year (1975),
volume (13) and first page (295); [2] the printed URL https://oeis.org/A089508, HTTP 200; [3] the
OEIS entries A089508 and A081016 in text format, with the SHA-256 of the copies read first-hand.
Log: `notes/article2-scripts/article2-check/references/resolve_refs_addendum.log`, which
`checks/check_article2.py` section (e) reads next to `references/out/resolve_refs.log`. The .bib
now has 76 entries and 48 printed DOIs, each recorded here as Crossref-resolved.
