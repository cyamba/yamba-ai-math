"""Core exact formulas for notes/proof-r7-golden.md (content (a,2,c)).

Python 3.11, standard library only.  Everything is exact integer arithmetic.

Conventions (as in the note):
  * letters 1 < 2 < 3; content (a,2,c); x = |w|_12, y = |w|_23, z = |w|_123 (scattered);
  * lattice-path model: delete the 2's; the {1,3}-word is a path from (0,0) to (a,c)
    (1 = east step, 3 = north step); the l-th 2 sits at the lattice point
    P_l = (p_l, q_l) = (#1's before it, #3's before it), P_1 <= P_2 along the path;
  * x = p1 + p2, y = 2c - q1 - q2, d = p2 - p1, e = q2 - q1, N := x*y - 2z = d*e;
  * centre M = (mu, nu) = ((p1+p2)/2, (q1+q2)/2), stored doubled as (P, Q) = (x, 2c - y).

Functions
  binom(n,k)            C(n,k), 0 outside 0 <= k <= n (also for negative n)
  brute_classes(a,c)    rho(x,y,z) by enumerating all words (small contents only)
  path_classes(a,c)     rho(x,y,z) from the b = 2 divisor formula
                        (notes/partition-route-audit.md s.5), independent of brute force
  K2(a,c,P,Q)           size of the class with centre (P/2, Q/2) and N = 0 (z = x*y/2),
                        explicit vertical + horizontal sums (note s.2)
  F(a,c,m)              P(0, 2c-m) = sum_{i=ceil(m/2)}^{min(m,c)} C(a+c-i, a)   (H3)
  boundary_max(a,c)     max over the four boundary edges
  max_class(a,c)        (max rho, sorted list of maximisers) from path_classes
"""

from __future__ import annotations

from itertools import combinations, permutations
from math import comb


def binom(n: int, k: int) -> int:
    if k < 0 or n < 0 or k > n:
        return 0
    return comb(n, k)


def counts(w):
    """(x, y, z) of a word over {1,2,3}: scattered subword counts |w|_12, |w|_23, |w|_123."""
    n1 = n12 = n2 = n23 = n123 = 0
    for ch in w:
        if ch == 1:
            n1 += 1
        elif ch == 2:
            n12 += n1
            n2 += 1
        else:  # ch == 3
            n123 += n12
            n23 += n2
    return n12, n23, n123


def words(a: int, c: int):
    """All words with a 1's, two 2's and c 3's (as tuples)."""
    n = a + c + 2
    for pos2 in combinations(range(n), 2):
        rest = [i for i in range(n) if i not in pos2]
        for pos1 in combinations(rest, a):
            w = [3] * n
            for i in pos2:
                w[i] = 2
            for i in pos1:
                w[i] = 1
            yield tuple(w)


def brute_classes(a: int, c: int) -> dict:
    rho: dict = {}
    for w in words(a, c):
        key = counts(w)
        rho[key] = rho.get(key, 0) + 1
    return rho


def path_classes(a: int, c: int) -> dict:
    """b = 2 divisor formula: rho(x,y,z) = sum over d == x, e == y (mod 2),
    0 <= d <= min(x, 2a-x), 0 <= e <= min(y, 2c-y), d*e = x*y - 2z, of
    C(a0+c0, a0) C(d+e, d) C(a2+c2, a2) with a0 = (x-d)/2, a2 = a-(x+d)/2,
    c0 = c-(y+e)/2, c2 = (y-e)/2."""
    rho: dict = {}
    for x in range(2 * a + 1):
        for y in range(2 * c + 1):
            for d in range(x % 2, min(x, 2 * a - x) + 1, 2):
                a0, a2 = (x - d) // 2, a - (x + d) // 2
                for e in range(y % 2, min(y, 2 * c - y) + 1, 2):
                    c0, c2 = c - (y + e) // 2, (y - e) // 2
                    z = (x * y - d * e) // 2
                    w = binom(a0 + c0, a0) * binom(d + e, d) * binom(a2 + c2, a2)
                    rho[(x, y, z)] = rho.get((x, y, z), 0) + w
    return rho


def K2(a: int, c: int, P: int, Q: int) -> int:
    """N = 0 class with doubled centre (P, Q) = (2 mu, 2 nu), i.e. x = P, y = 2c - Q,
    z = x*y/2.  Vertical pairs (mu integer): bottom (mu, Q - i), top (mu, i);
    horizontal pairs with s > 0 (nu integer): left (P - j, nu), right (j, nu)."""
    tot = 0
    if P % 2 == 0:
        mu = P // 2
        for i in range((Q + 1) // 2, min(Q, c) + 1):          # top height i
            tot += binom(mu + Q - i, mu) * binom(a - mu + c - i, a - mu)
    if Q % 2 == 0:
        nu = Q // 2
        for j in range(P // 2 + 1, min(P, a) + 1):            # right column j > mu
            tot += binom(P - j + nu, nu) * binom(a - j + c - nu, c - nu)
    return tot


def F(a: int, c: int, m: int) -> int:
    """P_{a,2,c}(0, 2c - m), the x = 0 boundary fibre (H3)."""
    if m < 0 or m > 2 * c:
        return 0
    return sum(binom(a + c - i, a) for i in range((m + 1) // 2, min(m, c) + 1))


def boundary_value(a: int, c: int, x: int, y: int) -> int:
    """psi_2-fibre size on the boundary of the box via H3 and the symmetries."""
    if x == 0:
        return F(a, c, 2 * c - y)
    if x == 2 * a:
        return F(a, c, y)                 # reversal: P(2a, y) = P(0, 2c - y)
    if y == 0:
        return F(c, a, 2 * a - x)         # reverse-complement: P(x, 0) = P_{c,2,a}(0, x)
    if y == 2 * c:
        return F(c, a, x)                 # P(x, 2c) = P(2a - x, 0)
    raise ValueError("not a boundary point")


def boundary_max(a: int, c: int) -> int:
    return max(max(F(a, c, m) for m in range(2 * c + 1)),
               max(F(c, a, n) for n in range(2 * a + 1)))


def max_class(a: int, c: int):
    rho = path_classes(a, c)
    M = max(rho.values())
    return M, sorted(k for k, v in rho.items() if v == M)
