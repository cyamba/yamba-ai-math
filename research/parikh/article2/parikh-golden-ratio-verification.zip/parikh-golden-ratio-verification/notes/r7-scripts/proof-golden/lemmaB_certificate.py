"""Exact finite certificate for Lemma B of notes/proof-r7-golden.md (section 5).

Used by the proof in two places: Lemma 5.9 uses [C1] and [C3]; Lemma 5.10 uses [C1] and [C2]
(and [C1], [C3] through Lemma 5.9).  [C4]-[C6] are consistency checks only.
checks/check_r7_golden.py re-implements [C1]-[C3] independently (run by `make check`).

Python 3.11, standard library only; exact integer / Fraction arithmetic throughout.

Notation (note s.5): mu >= 1 integer (the column), nu >= mu (integer or half-integer),
  g(n)   = C(mu+n, mu)          (n >= 0),   0 for n < 0,
  Gam(n) = C(mu+n+1, mu+1)      (n >= 0),   0 for n < 0,
  hmin(mu,nu) = least h >= 0 with  g(nu-h) + g(nu-h-1) <= g(nu+1)          ... (ii)
Criterion for integer nu, m = 2h:
  (a)  sum_{k=nu-2h}^{nu-h} Gam(k)  >=  C(mu+nu+1, mu)
  (b)  sum_{k=nu-h-1}^{nu-1} Gam(k) >=  sum_{k=nu-h}^{nu-1} (Gam(nu)-Gam(k)) + C(mu+nu, mu-1)
Criterion for nu = l + 1/2, m = 2h+1 (h = hmin(mu,l)):
  (b') sum_{k=l-h-1}^{l-1} Gam(k)   >=  sum_{k=l-h}^{l-1} (Gam(l)-Gam(k))

What is certified here (each item is a step of the written proof):
 [C1] mu in {2,3,4}, integer mu <= nu <= 14 (all of these, whatever hmin is):
      (ii),(a),(b) at h = hmin, except (mu,nu) = (2,3);
      half-integer nu = l+1/2 with mu <= l <= 14: (ii),(b') at h = hmin(mu,l).
 [C2] (mu,nu) = (2,3), h = 0, m = 0: the second prefix sums D2(J) of the column-basis
      coefficients (with the crude horizontal bound) are >= 0 for every J (finite range plus
      the eventual-monotonicity argument written in the note).
 [C3] the four linear inequalities closing the asymptotic region (T2) for
      (mu_lb, t1) = (5,3), (4,4), (3,5), (2,8), with ln 2 <= 6932/10000.
 [C4] (consistency, not needed by the proof) for 1 <= mu <= MU, mu <= nu <= NU:
      the full criterion at hmin holds except at (2,3); the second-order prefix sums D2 are
      >= 0 at hmin (direct computation); the derived bound h_min < (nu+mu+1)(1-2^(-1/mu)).
 [C5] (consistency) K_{a,c}(mu,nu) <= F_{a,c}(m(mu,nu)) by direct evaluation for all contents
      a + c <= S and all interior centres with mu integer, nu >= mu.
 [C6] (algebra guard) for 1 <= mu <= 10, mu <= nu <= 40 and every 0 <= h <= nu: the closed
      forms of D2(nu), D2(nu+h) (integer nu, m = 2h) and D2(nu+h+1) (half-integer centre
      nu+1/2, m = 2h+1) in the proof of Lemma 5.5 equal the second prefix sums computed from
      the coefficients; the window identity D°(nu+h) = 0 holds; the Step-1 rewriting of (b) in
      Lemma 5.9 is an identity; and (T2) implies (b) whenever h >= 1 satisfies (F2).

Usage: python3 lemmaB_certificate.py [MU NU S]     (defaults 40 400 60)
Exits non-zero on any failure.
"""

from __future__ import annotations

import sys
import time
from fractions import Fraction as Fr
from math import comb

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from a2c_core import K2, F, binom  # noqa: E402

FAIL = []


def check(cond, msg):
    if not cond:
        FAIL.append(msg)


def g(n, mu):
    return comb(mu + n, mu) if n >= 0 else 0


def Gam(n, mu):
    return comb(mu + n + 1, mu + 1) if n >= 0 else 0


def ii(mu, nu, h):
    return g(nu - h, mu) + g(nu - h - 1, mu) <= g(nu + 1, mu)


def hmin(mu, nu):
    return next(h for h in range(0, nu + 2) if ii(mu, nu, h))


def cond_a(mu, nu, h):
    return sum(Gam(k, mu) for k in range(nu - 2 * h, nu - h + 1)) >= comb(mu + nu + 1, mu)


def b_sides(mu, nu, h):
    lhs = sum(Gam(k, mu) for k in range(nu - h - 1, nu))
    rhs = sum(Gam(nu, mu) - Gam(k, mu) for k in range(nu - h, nu))
    return lhs, rhs


def cond_b(mu, nu, h):
    lhs, rhs = b_sides(mu, nu, h)
    return lhs >= rhs + binom(mu + nu, mu - 1)


def cond_bprime(mu, l, h):
    lhs, rhs = b_sides(mu, l, h)
    return lhs >= rhs


# ---------------------------------------------------------------- column-basis coefficients
def coeffs(mu, Q, m):
    """Coefficients (dict j -> int) of F(m) - Ktilde in the basis b_j (paths from (mu, j)),
    for the centre (mu, Q/2); Ktilde uses the crude horizontal bound
    H <= C(mu+nu, nu+1) (b_nu - b_{nu+1})."""
    d = {}
    lo = (m + 1) // 2
    jmax = 2 * Q + 2 * m + 8
    for j in range(lo, jmax + 1):                         # F(m): first reach of column mu
        d[j] = d.get(j, 0) + sum(binom(mu - 1 + j - i, mu - 1) for i in range(lo, min(m, j) + 1))
    for i in range((Q + 1) // 2, Q + 1):                 # vertical pairs, top i
        d[i] = d.get(i, 0) - binom(mu + Q - i, mu)
    if Q % 2 == 0:
        nu = Q // 2
        hcoef = binom(mu + nu, nu + 1)
        d[nu] = d.get(nu, 0) - hcoef
        d[nu + 1] = d.get(nu + 1, 0) + hcoef
    return d, jmax


def D2_all_nonneg(mu, Q, m):
    """Second prefix sums of the coefficients are >= 0 for every J.  For J beyond jmax the
    first prefix sums are increasing (F keeps growing, Ktilde is complete), and the last
    first prefix sum computed is checked > 0, so the second prefix sums increase from there."""
    d, jmax = coeffs(mu, Q, m)
    D = D2 = 0
    for J in range(min(d), jmax + 1):
        D += d.get(J, 0)
        D2 += D
        if D2 < 0:
            return False
    return D > 0


def prefix2(mu, Q, m):
    """dict J -> (D(J), D2(J)) for the coefficients of F(m) - Ktilde (crude horizontal bound)."""
    d, jmax = coeffs(mu, Q, m)
    out = {}
    D = D2 = 0
    for J in range(0, jmax + 1):
        D += d.get(J, 0)
        D2 += D
        out[J] = (D, D2)
    return out


def c6(MU6=10, NU6=40):
    n = 0
    for mu in range(1, MU6 + 1):
        for nu in range(mu, NU6 + 1):
            for h in range(0, nu + 1):
                pr = prefix2(mu, 2 * nu, 2 * h)
                D2nu = sum(Gam(k, mu) for k in range(nu - 2 * h, nu - h + 1)) - comb(mu + nu + 1, mu)
                lhs, rhs = b_sides(mu, nu, h)
                D2nuh = lhs - rhs - binom(mu + nu, mu - 1)
                check(pr[nu][1] == D2nu, f"C6 D2(nu) {(mu, nu, h)}")
                check(pr[nu + h][1] == D2nuh, f"C6 D2(nu+h) {(mu, nu, h)}")
                # window identity: D°(nu+h) = D(nu+h) (+C if h = 0)
                Dnh = pr[nu + h][0] + (binom(mu + nu, mu - 1) if h == 0 else 0)
                check(Dnh == 0, f"C6 window {(mu, nu, h)}")
                prh = prefix2(mu, 2 * nu + 1, 2 * h + 1)
                check(prh[nu + h + 1][1] == lhs - rhs, f"C6 D2 half {(mu, nu, h)}")
                # Step-1 rewriting of (b)
                left = (h + 1) * Gam(nu - h - 1, mu)
                right = sum((h - 2 * s) * (g(nu - s, mu) - g(nu - h + s, mu))
                            for s in range(0, (h + 1) // 2)) + binom(mu + nu, mu - 1)
                check((left - right) == (lhs - rhs - binom(mu + nu, mu - 1)),
                      f"C6 step1 {(mu, nu, h)}")
                # (T2) => (b) under (F2), h >= 1 (exact rationals)
                if h >= 1 and g(nu - h + 1, mu) + g(nu - h, mu) > g(nu + 1, mu) and nu - h >= 0:
                    L = Fr(nu - h, mu + 1)
                    R = (2 + Fr(mu, nu - h + 1)) * mu * (Fr(h * (h + 2), 6 * (mu + nu))
                                                         + Fr(1, (h + 1) * (nu + 1)))
                    if L >= R:
                        check(cond_b(mu, nu, h), f"C6 T2=>b {(mu, nu, h)}")
                n += 1
    return n


def main():
    MU = int(sys.argv[1]) if len(sys.argv) > 1 else 40
    NU = int(sys.argv[2]) if len(sys.argv) > 2 else 400
    S = int(sys.argv[3]) if len(sys.argv) > 3 else 60
    t0 = time.time()

    # [C1]
    n1 = 0
    for mu in (2, 3, 4):
        for nu in range(mu, 15):
            h = hmin(mu, nu)
            if (mu, nu) != (2, 3):
                check(cond_a(mu, nu, h) and cond_b(mu, nu, h), f"C1 integer {(mu, nu, h)}")
                n1 += 1
            hb = hmin(mu, nu)                     # l = nu for the half-integer centre l+1/2
            check(cond_bprime(mu, nu, hb), f"C1 half {(mu, nu, hb)}")
            n1 += 1
    check(not (cond_a(2, 3, 1) and cond_b(2, 3, 1)), "C1: (2,3) was expected to fail at h=1")
    print(f"[C1] mu in {{2,3,4}}, nu <= 14: criterion holds at hmin ({n1} cases; (2,3) excluded)")

    # [C2]
    check(D2_all_nonneg(2, 6, 0), "C2 (2,3) with m = 0")
    print("[C2] (mu,nu) = (2,3), m = 0: all second prefix sums >= 0")

    # [C3] linear closing inequalities, exact rationals; cl >= ln 2
    cl = Fr(6932, 10000)
    for mu_lb, t1 in ((5, 3), (4, 4), (3, 5), (2, 8)):
        t1 = Fr(t1)
        delta1 = t1 * (1 - cl / mu_lb) - cl / mu_lb
        check(delta1 > 0, f"C3 delta1 {mu_lb}")
        fac = 2 + 1 / delta1
        kap = (1 + t1) / (1 + t1 - Fr(1, mu_lb))
        A2 = fac * kap * cl * cl / 6
        A1 = fac * (kap * cl * (cl + 2) / 6 + 1 / (3 * t1))
        L2 = 1 - (1 + cl) / (mu_lb + 1)
        L1 = (1 + cl) / (mu_lb + 1)
        ok = L2 > A2 and (L2 - A2) * t1 >= A1 + L1
        check(ok, f"C3 {mu_lb} {t1}")
        print(f"[C3] mu>={mu_lb}, t>={t1}: slope {float(L2 - A2):.4f} > 0, "
              f"value at t1 {float((L2 - A2) * t1 - A1 - L1):.4f} >= 0: {ok}")

    # [C4] consistency over a large range
    bad = []
    nchk = 0
    for mu in range(1, MU + 1):
        th = 1 - 2 ** (-1 / mu)
        for nu in range(mu, NU + 1):
            h = hmin(mu, nu)
            nchk += 1
            if h >= 1:
                check(h < th * (nu + mu + 1) + 1e-9, f"C4 hbound {(mu, nu, h)}")
            if (mu, nu) == (2, 3):
                continue
            if not (cond_a(mu, nu, h) and cond_b(mu, nu, h) and cond_bprime(mu, nu, h)):
                bad.append((mu, nu, h))
            if mu <= 12 and nu <= 60:
                check(D2_all_nonneg(mu, 2 * nu, 2 * h), f"C4 D2 int {(mu, nu, h)}")
                check(D2_all_nonneg(mu, 2 * nu + 1, 2 * h + 1), f"C4 D2 half {(mu, nu, h)}")
    check(not bad, f"C4 criterion failures {bad[:10]}")
    print(f"[C4] criterion at hmin: {nchk} pairs (mu<= {MU}, nu<= {NU}), failures {len(bad)}")

    # [C5] direct comparison on contents a + c <= S
    def m_of(mu, Q):
        if mu == 1:                                   # hand proof, s.5.3
            nu2 = Q
            if nu2 == 2:
                return 0
            if nu2 % 2 == 0:
                nu = nu2 // 2
                return 2 if nu == 2 else 2 * (nu // 2)
            l = (nu2 - 1) // 2                       # nu = l + 1/2
            return 2 * ((l + 1) // 2)
        if Q % 2 == 0:
            nu = Q // 2
            return 0 if (mu, nu) == (2, 3) else 2 * hmin(mu, nu)
        return 2 * hmin(mu, (Q - 1) // 2) + 1
    n5 = 0
    for s in range(2, S + 1):
        for a in range(2, s):
            c = s - a
            for P in range(2, 2 * a, 2):
                mu = P // 2
                for Q in range(2 * mu, 2 * c):
                    m = m_of(mu, Q)
                    check(K2(a, c, P, Q) <= F(a, c, m), f"C5 {(a, c, P, Q, m)}")
                    n5 += 1
    print(f"[C5] K <= F(m) on {n5} (content, centre) pairs, a + c <= {S}")
    n6 = c6()
    print(f"[C6] closed forms of Lemma 5.5, window identity, Lemma 5.9 Step 1 and (T2) => (b): "
          f"{n6} triples (mu <= 10, nu <= 40, h <= nu)")
    print(f"total {time.time() - t0:.1f} s; failures: {len(FAIL)}")
    if FAIL:
        print(FAIL[:20])
        sys.exit(1)


if __name__ == "__main__":
    main()
